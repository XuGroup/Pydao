from pylab import *;

def compile_expression(condition,names,values):
	import copy;
	compiled=copy.copy(condition);
	for i in range(len(names)):
		name=names[i];
		value=values[i];
		compiled=compiled.replace(name,repr(value));
	return compiled;
	
def distinct(alist,compfun=None):
	import copy;
	N=len(alist);
	value_list=[]
	value_list=[]
	index_checked_list=[];
	index_list_list=[]
	for i in range(N):
		if index_checked_list.count(i)==0:
			v1=alist[i];
			value_list.append(v1);
			index_checked_list.append(i);
			index_list_thisv=[i];
			for j in range(i+1,N):
				if index_checked_list.count(j)==0:
					v2=alist[j];
					if compfun is None:
						condition=(v1==v2);
					else:
						condition=compfun(v1,v2);
					# print "v1,v2,condition",v1,v2,condition
					if condition:
						index_checked_list.append(j)
						index_list_thisv.append(j);
			index_list_list.append(index_list_thisv);
	return value_list,index_list_list;
	
def eqa(a,b):
	return a==b