from pylab import *;
from pydao.ohdf import OGroup;

class Relation_Table(OGroup):
	def __init__(self,rows=None,idname=None):
		OGroup.__init__(self);
		if type(rows) is list:
			self.set('rows',rows);
		else:
			self.set('rows',[]);
		self.set('idname',idname);
		
	def get_Nrow(self):
		rows=self.get('rows');
		return len(rows);
	
	def get_row(self,id):
		idname=self.get('idname');
		rows=self.get('rows');
		found_row=None;
		# print "in get_row, idname:",idname,"id:",id
		for row in rows:
			rowid=row.get(idname);
			if id==rowid:
				found_row=row;
				break;
		return found_row;
	
	def get_col(self,colname):
		Nrow=self.get_Nrow();
		colvalues=range(Nrow);
		rows=self.get('rows');
		for i in range(Nrow):
			colvalues[i]=rows[i].get(colname);
		return array(colvalues);
		
	def get_ids(self):
		idname=self.get('idname');
		return self.get_col(idname);
		
	def get_cols(self,colnames):
		colvalueslist=range(len(colnames));
		for i in range(len(colnames)):
			colvalueslist[i]=self.get_col(colnames[i]);
		return colvalueslist;
		
	def test_row(self,_row,_condition):
		from pydao.ohdf import natural_name;
		for _k in _row.keys():
			_k1=natural_name(_k)
			_cmd=_k1+"=_row.get('"+_k1+"')";
			# print "_cmd:",_cmd
			exec(_cmd);
		try:
			_answer=eval(_condition);
		except:
			print "bad _condition:",_condition
			_answer=False;
		return _answer;
		
	def append(self,row):
		rows=self.get('rows');
		rows.append(row);
		self.set('rows',rows);
		
	def select(self,condition,varnames=None,varvalues=None):
		import copy;
		condition=self.process_expression(condition,varnames,varvalues);
		# print "select condition:",condition
		rows=self.get('rows');
		rowsselected=[];
		for row in rows:
			satisfy=self.test_row(row,condition);
			if satisfy:
				rowsselected.append(row);
		rtable=copy.copy(self);
		rtable.clear();
		for k in self.keys():
			rtable.set(k,self.get(k));
		rtable.set('rows',rowsselected);
		rtable.set('idname',self.get('idname'));
		# rtable=Relation_Table(rowsselected,idname=self.get('idname'));
		return rtable;
		
	def delete(self,condition,varnames=None,varvalues=None):
		condition=self.process_expression(condition,varnames,varvalues);
		# print "select condition:",condition
		rows=self.get('rows');
		rowsselected=[];
		for row in rows:
			satisfy=self.test_row(row,condition);
			if not satisfy:
				rowsselected.append(row);
		rtable=Relation_Table(rowsselected,idname=self.get('idname'));
		return rtable;
		
	def update_row(self,_row,_varname,_expression):
		from pydao.ohdf import natural_name;
		for _k in _row.keys():
			_k1=natural_name(_k)
			_cmd=_k1+"=_row.get('"+_k1+"')";
			# print "_cmd:",_cmd
			exec(_cmd);
		_value=eval(_expression);
		_row.set(_varname,_value)
		return 
		
	def process_expression(self,expression,varnames=None,varvalues=None):
		from functions import compile_expression;
		if varnames is not None:
			expression=compile_expression(expression,varnames,varvalues);
		return expression;
	
	def update(self,varname,expression,varnames=None,varvalues=None,condition='True'):
		expression=self.process_expression(expression,varnames,varvalues);
		condition=self.process_expression(condition,varnames,varvalues);
		rows=self.get('rows');
		for row in rows:
			if self.test_row(row,condition):
				self.update_row(row,varname,expression);
		return;
		
	def update_row_para(self,_row,_varname,_expression,_paranames=[],_paravalues=[]):
		from pydao.ohdf import natural_name;
		i=0;
		for _para in _paranames:
			_cmd=_para+"=_paravalues["+str(i)+"]";
			exec(_cmd)
			i=i+1;
		for _k in _row.keys():
			_k1=natural_name(_k)
			_cmd=_k1+"=_row.get('"+_k1+"')";
			# print "_cmd:",_cmd
			exec(_cmd);
		_value=eval(_expression);
		_row.set(_varname,_value)
		return 
		
	def update_para(self,varname,expression,paranames=None,paravalues=None,condition='True'):
		rows=self.get('rows');
		for row in rows:
			if self.test_row(row,condition):
				self.update_row_para(row,varname,expression,paranames,paravalues);
		return;
		
	def exe_row(self,_row,_expression,_paranames=[],_paravalues=[]):
		from pydao.ohdf import natural_name;
		i=0;
		for _para in _paranames:
			_cmd=_para+"=_paravalues["+str(i)+"]";
			exec(_cmd)
			i=i+1;
		for _k in _row.keys():
			_k1=natural_name(_k)
			_cmd=_k1+"=_row.get('"+_k1+"')";
			# print "_cmd:",_cmd
			exec(_cmd);
		exec(_expression);
		return 
		
	def exe(self,expression,paranames=None,paravalues=None,condition='True'):
		rows=self.get('rows');
		for row in rows:
			if self.test_row(row,condition):
				self.exe_row(row,expression,paranames,paravalues);
		return;
		
	def max(self,varname):
		idname=self.get('idname');
		rows =self.get('rows');
		values=self.get_col(varname);
		maxvalue=max(values);
		irow=values.index(maxvalue);
		if idname is None:
			id=irow;
		else:
			id=rows[irow].get(idname);
		return maxvalue,id;
		
	def min(self,varname):
		idname=self.get('idname');
		rows =self.get('rows');
		values=self.get_col(varname);
		minvalue=min(values);
		irow = list(values).index(minvalue);
		if idname is None:
			id=irow;
		else:
			id=rows[irow].get(idname);
		return minvalue,id;
		
	def avg(self):
		# print "in Relation_Table: avg()"
		Nrow=self.get_Nrow();
		newrow=self.sum();
		for k in newrow.keys():
			v=newrow.get(k);
			# print "k:",k,v,type(v)
			try:
				newrow.set(k,v/float(Nrow));
			except:
				newrow.remove(k);
		return newrow;
	
	def sum(self):
		rows=self.get('rows');
		if len(rows)>0:
			return self.sum_nonzero();
		else:
			return ;
			
	def sum_nonzero(self):
		# print "in Relation_Table: sum()"
		import copy;
		rows=self.get('rows');
		keys=rows[0].keys();
		# newrow=rows[0].copy2mem();
		newrow=copy.copy(rows[0]);
		newrow.clear();
		
		for k in keys:
			# print "k:",k
			try:
				irow=0;
				for row in rows:
					if irow ==0:
						v=row.get(k);
					else:
						v=row.get(k)+v;
					# if type(v) is ndarray:
						# print "irow:",irow,"len(v)",len(v)
					irow=irow+1;
				newrow.set(k,v);
				# print k,'can be summed'
			except:
				newrow.remove(k);
				# print k,"can not be summed."
		return newrow;
		
	def orderby(self,varname,desc=False):
		Nrow=self.get_Nrow();
		rows=self.get('rows');
		for i in range(Nrow):
			for j in range(Nrow):
				row1=rows[i];
				row2=rows[j];
				v1=row1.get(varname);
				v2=row2.get(varname);
				if desc:
					if v1>v2:
						rows[i]=row2;
						rows[j]=row1;
				else:
					if v1<v2:
						rows[i]=row2;
						rows[j]=row1;
		return;
		
	def groupby(self,varname,method='average',showvalues=False):
		# Here we merge the rows with the same varname values
		# The other variables can be either averaged or summed.
		rows=self.get('rows');
		value_list=list(self.get_col(varname));
		if showvalues:
			print "values to group:",value_list;
		rtable=Relation_Table([],idname=self.get('idname'));
		rowscopy=list(copy(rows));
		#print "type(rowscopy):",type(rowscopy)
		while len(value_list)>0:
			value=value_list[0];
			valuecount=value_list.count(value);
			# print "value_list:",value_list
			if valuecount==1:
				i_thisvalue=value_list.index(value);
				rtable.append(rowscopy[i_thisvalue]);
				value_list.remove(value);
				rowscopy.remove(rowscopy[i_thisvalue]);
			else:
				rowsofthisvalue=[];
				for ii in range(valuecount):
					i_thisvalue=value_list.index(value);
					rowsofthisvalue.append(rowscopy[i_thisvalue]);
					value_list.remove(value);
					rowscopy.remove(rowscopy[i_thisvalue]);
				
				tb=Relation_Table(rowsofthisvalue,idname=self.get('idname'));
				if method=='average':
					rowofthisvalue=tb.avg();
				elif method=='sum':
					rowofthisvalue=tb.sum();
				rtable.append(rowofthisvalue);
		return rtable;
################################################

	def plot(self,xname=None,yname=None,pstyle="o-"):
		scanx=self.get_col(xname);
		scany=self.get_col(yname);
		plot(scanx,scany,pstyle);
		# xlabel(xname);
		# axis('tight');
		return;