from pylab import *;
from pydao.tools import mccd2array,int_filter,Progress_Teller;
from scipy.signal import convolve;

from scipy.optimize import fmin;
from pydao.database import Relation_Table;
from imgarray import ImgArray;
from pydao.math import vlen;
import gc;

class Img14ID_TimeResolve(Relation_Table):
	def __init__(self,directory=None,rois=None,roinames=None,logfile=None):
		Relation_Table.__init__(self,rows=None,idname=None);
		if directory is not None:
			self.set('directory',directory);
		if rois is not None:
			self.set('rois',rois);
		if roinames is not None:
			self.set('roinames',roinames);
		if logfile is not None:
			self.set('logfile',logfile);
			
	def process_time_scan(self,origin_px,factor,rois,roinames):
		import os;
		directory = self.get('directory');
		logfile = self.get('logfile');
		if rois is None:
			rois = self.get('rois');
		# print "in read_scan, roi:",roi
		files=os.listdir(directory);
		pt = Progress_Teller(len(files));
		i=0;
		for file in files:
			#gc.collect();
			i=i+1;
			pt.tell(i);
			dirname=os.path.join(directory,file);
			if os.path.isdir(dirname):
				print "\n dir#:",i
				print "dirname:",dirname;
				if logfile is not None:
					logfile.printf(["\n dir#:",i]);
					logfile.printf(["dirname:",dirname]);
					logfile.timestamp();
				scan = Img14ID_AngleScan(dirname,logfile=logfile);
				scan.read_scan(rois=rois,roinames=roinames);
					
				scan.analyze_reflection(roiname=roinames[0],origin = origin_px,factor=factor);
				if logfile is not None:
					logfile.printf(["roi_reflection: ",roinames[0]]);
					p = scan.get('iangle2omega');
					logfile.printf(['origin_px: ',origin_px]);
					logfile.printf(['factor: ',factor]);
					logfile.printf(['iangle2omega: ',p]);
				for roiname in roinames:
					scan.cal_profiles(roiname=roiname,origin = origin_px,factor=factor);
				self.append(scan);
		return;
			
	def analyze_reflection(self,roiname,origin,factor):
		rows = self.get('rows');
		logfile = self.get('logfile');
		for scan in rows:
			scan.analyze_reflection(roiname=roiname,origin = origin_px,factor=alpha);
			if logfile is not None:
				logfile.printf(["roi_reflection: ",roiref]);
				p = scan.get('iangle2omega');
				logfile.printf(['origin_px: ',origin_px]);
				logfile.printf(['factor: ',alpha]);
				logfile.printf(['iangle2omega: ',p]);
			
	def cal_profiles(self,roiname,origin,factor):
		rows = self.get('rows');
		logfile = self.get('logfile');
		roinames = self.get('roinames');
		for scan in rows:
			for roiname in roinames:
				scan.cal_profiles(roiname=roiname,origin = origin,factor=factor);
		return;				
		
	
class Img14ID_AngleScan(Relation_Table):
	def __init__(self,directory=None,rois=None,logfile=None):
		Relation_Table.__init__(self,rows=None,idname=None);
		if directory is not None:
			self.set('directory',directory);
		if rois is not None:
			self.set('rois',rois);
		if logfile is not None:
			self.set('logfile',logfile);
		
	def read_scan(self,rois=None,roinames=''):
		import os;
		directory = self.get('directory');
		logfile = self.get('logfile');
		if rois is None:
			rois = self.get('rois');
		# print "in read_scan, roi:",roi
		files=os.listdir(directory);
		pt = Progress_Teller(len(files));

		i=0;
		for file in files:
			#gc.collect();
			i=i+1;
			pt.tell(i);
			fullfile=os.path.join(directory,file);
			if not os.path.isdir(fullfile):
				fs = file.split('.');
				if fs[-1]=='png':
					print "\n file#:",i
					print "fullfile:",fullfile;
					if logfile is not None:
						logfile.printf(["\n file#:",i]);
						logfile.printf(["fullfile:",fullfile]);
						logfile.timestamp();
					img = Img14ID(fullfile,logfile=logfile);
					img.read(rois=rois,roinames=roinames);
					self.append(img);
		return;
	
	def cal_iomega_pix_map(self,roiname):
		rows = self.get('rows');
		img_array = rows[0].get('img_array'+roiname);
		Nz,Ny = img_array.shape;
		Nrow = len(rows);
		
		omegay_map = zeros([len(rows),Ny]);
		omegaz_map = zeros([len(rows),Nz]);
		i=0;
		for row in rows:
			img_array = row.get('img_array'+roiname);
			omegaz_map[i] = img_array.sum(1); # sum the "y" or horizontal dimension, keep the "z"
			omegay_map[i] = img_array.sum(0);
			i = i+1;
		
		intensity_y = omegay_map.sum(0);
		intensity_z = omegaz_map.sum(0);
		intensity_iangle = omegaz_map.sum(1);
		
		self.set('iomegay_pix_map',omegay_map);
		self.set('iomegaz_pix_map',omegaz_map);
	
		return omegay_map,omegaz_map,intensity_y,intensity_z,intensity_iangle;
		
	def cal_profiles(self,roiname,origin,factor):
		omegay_map,omegaz_map,intensity_y,intensity_z,intensity_iangle = self.cal_iomega_pix_map(roiname);
		
		roi = self.get('rows')[0].get('fromroi'+roiname);
		z = (origin[1]-arange(roi[0],roi[1]))*factor;
		y = (arange(roi[2],roi[3])-origin[0])*factor;
		iangle2omega = self.get('iangle2omega');
		iangle = arange(len(self.get('rows')))+1;
		omega = iangle*iangle2omega[0]+iangle2omega[1];
		
		savetxt(roiname+'iomegay_pix_map.txt',omegay_map);
		savetxt(roiname+'iomegaz_pix_map.txt',omegaz_map);
		
		#print "y,intensity_y",len(y),len(intensity_y);
		#print "z,intensity_z",len(z),len(intensity_z);
		
		logfile = self.get('logfile');
		logfile.printf(["roiname:",roiname]);
		logfile.printf(["roi:",roi]);
		
		dir = self.get('directory');
		savetxt(roiname+'_'+dir.split("\\")[-1]+'_intensity_y.txt',transpose(vstack((y,intensity_y))));
		savetxt(roiname+'_'+dir.split("\\")[-1]+'_intensity_z.txt',transpose(vstack((z,intensity_z))));
		savetxt(roiname+'_'+dir.split("\\")[-1]+'_intensity_omega.txt',transpose(vstack((omega,intensity_iangle))));
		
		
		#figure();
		subplot(2,3,1);
		sigma = omegay_map.std();
		average = omegay_map.mean();
		imshow(transpose(omegay_map),vmin = average-2*sigma,vmax=average+2*sigma);axis('tight');
		colorbar();
		ylabel('ypix');xlabel('iangle')
		subplot(2,3,3);
		sigma = omegaz_map.std();
		average = omegaz_map.mean();
		imshow(transpose(omegaz_map),vmin = average-2*sigma,vmax=average+2*sigma);axis('tight');
		ylabel('zpix');xlabel('iangle')
		colorbar();
		subplot(2,3,4);
		plot(y,intensity_y);xlabel('y/L')
		subplot(2,3,5);
		plot(z,intensity_z);xlabel('z/L')
		subplot(2,3,6);
		plot(omega,intensity_iangle);xlabel('omega(degree)')
		show();
		
		dir = self.get('directory').split("\\");
		mng = get_current_fig_manager();
		mng.window.showMaximized();
		gcf().savefig(dir[-2]+dir[-1]+roiname+'.png');
		close(gcf());
		return omegay_map,omegaz_map;
	
	def analyze_reflection(self,roiname,origin,factor):
		from pydao.math import find_peak_trajectory_linear;
		omegay_map,omegaz_map,intensity_y,intensity_z,intensity_iangle = self.cal_iomega_pix_map(roiname);
		
		rows = self.get('rows');
		roi = rows[0].get('fromroi'+roiname);
			
		Iangle,Izpix,p = find_peak_trajectory_linear(omegaz_map,slope=-1,precision=1);
		
		subplot(2,3,3);
		plot(Iangle,Izpix,'r+');
		p = polyfit(Izpix,Iangle,1);
		plot(Izpix*p[0]+p[1],Izpix,'r');
		axis('tight');
		
		iangles = Iangle+1;
		zs = (origin[1]-(Izpix+roi[0]))*factor;
		omegas = arctan(zs)/2*180/pi;
		
		p = polyfit(iangles,omegas,1);
		
		logfile = self.get('logfile');
		logfile.printf(['origin:',origin]);
		logfile.printf(['Izpix:',Izpix]);
		logfile.printf(['roi:',roi]);
		logfile.printf(['zs:',zs]);
		logfile.printf(['p:',p]);
		
		self.set('iangle2omega',p);
		print "roi:",roi
		print "origin:",origin
		print "polyfit iangles",p;
		return;
		
class Img14ID(ImgArray):
	def __init__(self,filename=None,dilimiter='\t',row_width_chosen=None,logfile=None):
		ImgArray.__init__(self,filename=None,dilimiter=dilimiter,row_width_chosen=None);
		if logfile is not None:
			self.set('logfile',logfile);
		if filename is not None:
			self.analyze_filename(filename);
			self.set('filename',filename);
		
	def analyze_filename(self,filename):
		import os;
		# S003_0.6mj_-1ns1_001
		# print "fullname:",filename
		fs = os.path.split(filename);
		# print "path fs:",fs
		fname = fs[-1];
		fs = fname.split('.');
		# print "suffix fs:",fs
		fname = fname.replace('.'+fs[-1],'');
		
		fs = fname.split('_');
		# print "file fs:",fs
		sample_name = fs[0];
		
		fluencestr = fs[1].replace('mj','');
		fluence = float(fluencestr);
		
		pulsedelaystr = fs[2];
		if pulsedelaystr.count('ns')==1:
			pulsedelayunit = 'ns';
		elif pulsedelaystr.count('ps')==1:
			pulsedelayunit = 'ps';
		
		ss = pulsedelaystr.split(pulsedelayunit);
		pulsedelay = float(ss[0]);
		iscan = int(ss[1]);
		
		iangle = int(fs[3]);
		
		self.set('sample_name',sample_name);
		self.set('fluence',fluence);
		self.set('pulsedelay',pulsedelay);
		self.set('pulsedelayunit',pulsedelayunit);
		self.set('iscan',iscan);
		self.set('iangle', iangle);
		
		
		print "sample_name:",sample_name
		print "fluence:",fluence
		print "pulsedelay:",pulsedelay
		print "pulsedelayunit:",pulsedelayunit
		print "iscan:",iscan
		print "iangle:",iangle
		logfile = self.get('logfile');
		print "logfile:",logfile
		if logfile is not None:
			logfile.printf([ "sample_name:",sample_name]);
			logfile.printf( ["fluence:",fluence])
			logfile.printf([ "pulsedelay:",pulsedelay]);
			logfile.printf (["pulsedelayunit:",pulsedelayunit]);
			logfile.printf(["iscan:",iscan]);
			logfile.printf([ "iangle:",iangle]);
		return ;
		
	def read(self,rois,filename=None,roinames=''):
		if filename is None:
			filename = self.get('filename');
		# print "filename:",filename
		success = ImgArray.read(self,filename);
		logfile = self.get('logfile');
		if logfile is not None:
			print "roinames:"
			print roinames;
			print "rois:"
			print rois;
		if success:
			img_array = self.get('img_array');
			print "original image shape:",img_array.shape;
			print "rois:",rois
			print "roinames:",roinames
			if len(rois.shape)>1:
				i = 0;
				for roi in rois:
					img_array1 = img_array[roi[0]:roi[1],roi[2]:roi[3]];
					img_array1 = img_array1 +zeros(img_array1.shape);
					self.set('img_array'+roinames[i],img_array1);
					self.set('fromroi'+roinames[i],roi);
					i = i+1;
			else:	
				roi = rois;
				roiname = roinames;
				img_array1 = img_array[roi[0]:roi[1],roi[2]:roi[3]];
				img_array1 = img_array1 +zeros(img_array1.shape); # to release the memory of 'img_array'
				#print "img_array1.shape",img_array1.shape
				self.set('img_array'+roiname,img_array1);
				self.set('fromroi'+roiname,roi);
			#del img_array;
			if roinames is not None:
				self.set('img_array',None);
			return success;
		
	def set_geometric_factor(self,factor):
		# Here we assume detector-sample distance is 1.
		# The -x axis is the incident beam.
		# So y = y_pixel*geometric_factor
		# z = z_pixel*geometric_factor
		self.set('geometric_factor',factor); 
		return;
	
	def set_origin_pixel(self,origin):
		self.set('origin_pixel',origin);
		return;
		
	def set_lattice_basis(self,basis):
		self.set('basis',basis);
		return;
	
	def set_omega(self,omega):
		self.set('omega',omega);
		return;
		
	def set_xray_energy(self,energy):
		self.set('energy',energy);
		k0 = energy*1.60217657e-19/2.99792458e8/(6.62606957e-34/2/pi);
		self.set('k0',k0);
		return;
		
	def yzs2hl(xy_pix,ys,zs,k0=None,origin=None,factor=None,iangle2omega=None):
		if k0 is None:
			k0 = self.get('k0');
		if origin is None:
			origin_pix = self.set('origin_pixel');
		if factor is None:
			factor = self.get('geometric_factor'); 
		if iangle2omega is None:
			iangle2omega=self.get('iangle2omega');
			
		omega = self.get('iangle')*iangle2omega[0]+iangle2omega[1];
		omegar = omega*pi/180;

		qls = zeros([len(ys),len(zs)]);
		qhks = zeros([len(ys),len(zs)]);
		
		
		surface_normal = array([sin(omegar),0,cos(omega(r))]);
		
		for i in range(len(ys)):
			y = ys[i]
			for j in range(len(zs)):
				z = zs[j];
				yz_pix = (y,z);
				yz = yz_pix-origin_pix;
				yz = yz*factor;
				xyz = array([1,yz[0],yz[1]]);
				k_dif = array(xyz);
				k_dif = k_dif/vlen(k_dif)*k0;
				k_inc = array([-1.,0,0])*k0;
				q = k_dif-k_inc;
				qls[i,j] = sum(q*surface_normal);
				qhk[i,j] = vlen(q-qls[i,j]);
		return qls,qls;
	
	def xy2hkl(xy_pix):
		k0 = self.get('k0');
		origin_pix = self.set('origin_pixel');
		xy = xy_pix-origin_pix;
		factor = self.get('geometric_factor'); 
		basis = self.get('basis');
		xy = xy*factor;
		xyz = array([xy[0],xy[1],1]);
		
		k_dif = array(xyz);
		k_dif = k_dif/vlen(k_dif)*k0;
		k_inc = array([-1,0,0])*k0;
		q = k_dif-k_inc;
		hkl = cartesian2direct(basis,q);
		return hkl;
		
		