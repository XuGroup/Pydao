from pylab import *;
from pydao.math import XyDiscreteFun;

def sort2d(array2d,rowvar):
	array2dsorted = array2d-array2d; 
	# we sort the rows according to the additional array that indicates the row values
	rowvarsorted = sort(rowvar);
	i = 0;
	for var in rowvarsorted:
		index = list(rowvar).index(var);
		array2dsorted[i] = array2d[index];
		i = i+1;
	return array2dsorted,rowvarsorted;
	
def find_peak_trajectory_shift(array2d, pause=False,nspike=2,Nmax=20):
	Nrow,Ncol = array2d.shape; # we will compare the rows.
	shifts = zeros(Nrow);
	factors = zeros(Nrow)+1;
	backgrounds = array2d.min()+zeros(Nrow);
	
	background = array2d.min();
	x = arange(Ncol);
	sp0 = XyDiscreteFun();
	sp0.set('x',x);
	sp0.set('y',array2d[0]-background);
	print "removing spikes for sp0"
	sp0.remove_spike(nspike);
	
	plot(x,sp0.get('y'),'bo-',linewidth=10);
	
	for i in range(Nrow-1,0,-1):
		print "i:",i;
		sp = XyDiscreteFun();
		sp.set('x',x);
		sp.set('y',array2d[i]-background);
		print "removing spikes for sp"
		sp.remove_spike(nspike,Nmax,sp0);
		
		#figure();
		#subplot(i,1,1);
		
		#subplot(i,1,1);
		plot(x,sp.get('y'),'*');

		#paras = sp0.find_xshift_renormbg(sp);
		paras = sp0.find_xshift_renorm(sp);
		delta = paras[0];
		factor = paras[1];
		#background = paras[2];
		shifts[i] = delta;
		factors[i] = factor;
		backgrounds[i] = background;
		print paras;

		xfit = x+delta;
		#yfit = (y-background)*factor+background;
		yfit = (sp.get('y'))*factor;
		#subplot(i,1,1);
		#plot(x,y,'o-');
		plot(xfit,yfit,'r');
		plot(x,yfit,'b');
		#plot(x,x-x+background,'g');
		title('bg:'+str(background))
		show();
		#if pause:
		#ginput();
			#wait = input("PRESS ENTER TO CONTINUE.")
		#close(gcf());
		
	return shifts,factors,backgrounds;
	
def find_peak_trajectory_linear_once(array2d,slope=-1,intercept=0,width=5):
	array2d = array2d-array2d.min();
	Nrow, Ncol = array2d.shape;
	Irow = arange(Nrow);
	Icolzmax = zeros(Nrow);
	Irowzmax = [];
	Icolzmax = [];
	icolwidth = width; 
	
	for irow in range(Nrow):
		#icolcenter = float(irow)/Nrow*Ncol;
		icolcenter = irow*slope+intercept;
		icolcenter = int(icolcenter);
		icolmin = max(0,icolcenter-icolwidth);
		icolmax = min(Ncol,icolcenter+icolwidth);
		subrow = array2d[irow][icolmin:icolmax]; 
		
		zmax = max(subrow);
		if zmax > array2d.mean()+1*array2d.std():
			#print "irow:",irow,"zmax:",zmax
			icolzmax = list(subrow).index(zmax)+icolmin;
			Irowzmax.append(irow);
			Icolzmax.append(icolzmax);
	return array(Irowzmax),array(Icolzmax);
		
def find_peak_trajectory_linear(array2d,slope=-1,precision=5):
	Nrow,Ncol = array2d.shape;
	if slope == -1:
		p = polyfit(array([0,Nrow]),array([Ncol,0]),1);
	elif slope == 1:
		p = polyfit(array([0,Nrow]),array([0,Ncol]),1);
	Irowzmax,Icolmax = find_peak_trajectory_linear_once(array2d,slope=p[0],intercept=p[1],width=50);
	p = polyfit(Irowzmax,Icolmax,1);
	#print "p once:",p
	Irowzmax,Icolmax = find_peak_trajectory_linear_once(array2d,slope=p[0],intercept=p[1],width=precision);
	p = polyfit(Irowzmax,Icolmax,1);
	return Irowzmax,Icolmax,p;