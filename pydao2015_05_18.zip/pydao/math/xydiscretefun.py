from ..ohdf import OGroup;
from pylab import *;
#from ..physics import *;
from ..physics import Unit;

import pylab;
import scipy.interpolate;
import scipy.optimize;
import scipy;
import numpy;
import copy;
import os;

class XyDiscreteFun(OGroup):
	def __init__(self,x=None,y=None):
		OGroup.__init__(self);
		self.set('xunit',Unit());
		self.set('yunit',Unit());
		self.set('x',x);
		self.set('y',y);
		pass;
		
	def __call__(self,x):
		if issubclass(type(x),list): 
			y=scipy.interp(x,self.get('x'),self.get('y'));
		else:
			y=scipy.interp([x],self.get('x'),self.get('y'));
			y=y[0];
		return y;
		
	def shift(self,delta):
		x=self.get('x')+delta;
		self.set('x',x);
		
	def exportascii(self,farg,dataname=''):
		DataObject.exportascii(self,farg,dataname);
		x=XOS();
		if isinstance(farg,str):
			fname=farg;
		else:
			fh=farg;
			fname=fh.name;
		myfname=x.filenameappend(fname,dataname+'_xy');
		print "Exporting "+dataname+"[XyDiscreteFun] to:",myfname
		myfh=open(myfname,'w');
			
			
		for i in range(len(self.get('x'))):
			myfh.write(str( self.get('x')[i])+','+str(self.get('y')[i]));
			myfh.write("\n");
		myfh.close();
		
	def numstrsetting(self):
		self.uiset(datatype='string');
		self.uiset(datatype='numeric');
		
	def copynumstrsettingto(self,anotherfun):
		for k in self.keys():
			if isstring(self[k]) or isnumeric(self[k]):
				anotherfun[k]=self[k];
				

#=========================================================================
# mono spect operation
#=========================================================================
	def update(self,_updatecmd):
		_oldkeys=self.keys();
		for _iupdaterow in self.keys():
			_cmd=_iupdaterow+"=self.get('"+_iupdaterow+"')";
			exec(_cmd);
		exec(_updatecmd);
		#print "updatecmd:",_updatecmd
		#print "Temperature:",Temperature
		for _iupdaterow in _oldkeys:
			_cmd="self.set('"+_iupdaterow+"','"+_iupdaterow+"')";
			exec(_cmd);

	def cumsum(self,xmin=None,xmax=None):
		spect=self.copyxy();
		spect.pick(xmin,xmax);
		x=spect.get('x');
		y=spect.get('y');
		
		#xomega=2*numpy.pi*3e8*x*1e2;
		#neff0=self['y'][0]*xomega[0];
		sum0=y[0];
		sum=x-x;
		for i in range(len(x)):
			if i==0:
				sum[i]=sum0;
			else:
				sum[i]=sum[i-1]+y[i]*(x[i]-x[i-1]);
		spect.set('y',sum);
		return spect;
	
	def integral(self,xmin=None,xmax=None):
		cumsumspect=self.cumsum(xmin,xmax);
		result=cumsumspect.get('y')[-1];
		return result;
	
	def wheremax(self,xmin=None,xmax=None):
		spect=self.copyxy();
		spect.pick(xmin,xmax);
		x=spect.get('x');
		y=spect.get('y');
		I=argmax(y);
		x_max=x[I];
		return x_max;
		
	def wheremin(self,xmin=None,xmax=None):
		spect=self.copyxy();
		spect.pick(xmin,xmax);
		x=spect.get('x');
		y=spect.get('y');
		I=argmin(y);
		x_min=x[I];
		return x_min;	
		
	def copyxy(self):
		#import copy;
		#sp=self.copy2mem();
		#sp['num_matrix']=None;
		sp = XyDiscreteFun();
		x = self.get('x');
		y = self.get('y');
		N = len(x);
		sp.set('x',zeros(N)+x);
		sp.set('y',zeros(N)+y);
		return sp;
		
	# def convertx(self,tounit):
		# xunit=self['xunit'];
		#print "xunit:",xunit
		# x=self['x'];
		# x=xunit.convert(x,tounit);
		# self.set('x',x);
		# self.sortx();
		
	def sortx(self):
		I=numpy.argsort(self.get('x'));
		self.set('x',self.get('x')[I]);
		self.set('y',self.get('y')[I]);
	
	def pick(self,xmin=None,xmax=None,ymin=None,ymax=None):
		x=self.get('x').copy();
		y=self.get('y').copy();
		if xmin is None:
			xmin=min(x);
		if xmax is  None:
			xmax=max(x);
		if ymin is  None:
			ymin=min(y);
		if ymax is  None:
			ymax=max(y);
		Ix = logical_and(x>=xmin,x<=xmax);
		Iy = logical_and(y>=ymin,y<=ymax);
		I = logical_and(Ix,Iy);
		x = x[I];
		y = y[I];
		self.set('x',x);
		self.set('y',y);
		return;
	
	def pick1(self,xmin=None,xmax=None,ymin=None,ymax=None,nonempty=None):
		self.sortx();
		eps=self.get('xunit').getcurrenttolerance();
		#print "eps",eps

		Imin=-len(x);
		Imax=len(x);
		if xmin is None:
			xmin=min(x);
		if xmax is  None:
			xmax=max(x);
		if ymin is  None:
			ymin=min(y);
		if ymax is  None:
			ymax=max(y);
		#print 'x:',
		#print 'xmin:',xmin
		
		x1=self.get('x')[(x-xmin)<=eps];
		if len(x1)>0:
			Imin=len(x1);
		x2=self.get('x')[(x-xmax)>=-eps];
		if len(x2)>0:
			Imax=len(x)-len(x2)-1;
			
		I=numpy.core.logical_and((x-xmin)>=-eps, (x-xmax)<=eps);
		#x=x[I];
		#y=y[I];	
			
		#if len(x)>0:
		I=numpy.core.logical_and(I,y>=ymin);
		I=numpy.core.logical_and(I,y<=ymax);
		
		x=x[I];
		y=y[I];
			
		if nonempty is not None and len(x)<nonempty:
			dx=xmax-xmin;
			dy=ymax-ymin;
			xmin1=xmin-dx/2;
			xmax1=xmax+dx/2;
			ymin1=ymin-dy/2;
			ymax1=ymax+dy/2;
			Imin,Imax=self.pick(xmin1,xmax1,ymin1,ymax1,1);
		else:
			self.set('x',x);
			self.set('y',y);
		
		#print "lenx",len(x)
		#print "nonempty:",nonempty
		return (Imin,Imax);
		
	def yconstrain(self,ymin=None,ymax=None):
		try:
			eps=self.get('yunit').getcurrenttolerance();
		except:
			eps=1e-9;
		y=self.get('y');
		if ymin is None:
			ymin=min(y);
		if ymax is None:
			ymax=max(y);
		Iin=numpy.core.logical_and((y-ymin)>=-eps, (y-ymax)<=eps);
		Ilow=(y-ymin)<-eps;
		Ihigh=(y-ymax)>eps;
		ylow=min(y[Iin]);
		yhigh=max(y[Iin]);
		y[Ilow]=ylow+numpy.zeros(len(y[Ilow]));
		y[Ihigh]=yhigh+numpy.zeros(len(y[Ihigh]));
		
	def refine(self,resolution):
		xmin=self.get('x').min();
		xmax=self.get('x').max();
		xrefine=arange(xmin,xmax,resolution);
		yrefine=self(xrefine);
		#spect=copy.deepcopy(self);
		self.set('x',xrefine);
		self.set('y',yrefine);
		#return spect;
		
	def cull(self,resolution,xmin=None,xmax=None):
		self.sortx();
		x=self.get('x');
		if xmin is None:
			xmin=min(x);
		if xmax is None:
			xmax=max(x);
		spect=self.copyxy();
		Imin,Imax=spect.pick(xmin,xmax);
		evenoddsign=1;
		while spect.summarize().get('res_min')<resolution:
			#print "before",spect.summarize()['res_min']
			spect.cullonce(resolution,(evenoddsign+1)/2);
			evenoddsign=evenoddsign*-1;
			#print "culled once."
			#print "after",spect.summarize()['res_min']
		x=numpy.hstack((spect.get('x')[0:Imin-1],spect.get('x'),spect.get('x')[Imax+1:]));
		self.set('x',x);
		y=numpy.hstack((spect.get('y')[0:Imin-1],spect.get('y'),spect.get('y')[Imax+1:]));
		self.set('y',y);
		
	def remove_spike_peak_once(self,nslope=2,reference=None):
		from scipy.interpolate import interp1d;
		from pydao.math import complement_array;
		x = self.get('x');
		y = self.get('y');
		slope = diff(y)/diff(x);
		xslope = x[0:-1];
		diff2 = diff(slope)/diff(xslope);
		xdiff2 = xslope[0:-1];
		
		condition = abs(diff2)>abs(diff2).mean()*nslope;
		Iremove = find(condition)+1;
		Ikeep = complement_array(arange(len(x)),Iremove);
		
		if reference is not None:
			sp = reference.copyxy();
			sp.addshoulder();
			f = interp1d(sp.get('x'), sp.get('y'), kind='linear');
		else:
			xkeep = x[Ikeep];
			ykeep = y[Ikeep];
			f = interp1d(xkeep, ykeep, kind='linear');
		y[Iremove] = f(x[Iremove]);
		return x[Iremove],y[Iremove];
		
	def remove_spike_slope_once(self,nslope=2,reference=None):
		from pydao.math import complement_array;
		from scipy.interpolate import interp1d;
		x = self.get('x');
		y = self.get('y');
		slope = diff(y)/diff(x);
				
		condition = abs(slope)>abs(slope).mean()*nslope;
		Iremove = find(condition);
		Ikeep = complement_array(arange(len(x)),Iremove);
		
		xkeep = x[Ikeep];
		ykeep = y[Ikeep];
		Ikeep = list(Ikeep)
		if Ikeep.count(0)==0:
			xkeep = list(xkeep);
			xkeep.insert(0,x[0]);
			ykeep = list(ykeep);
			ykeep.insert(0,y[xkeep[1]]);
			xkeep.insert(0,x[0]-mean(diff(x)));
			ykeep.insert(0,y[xkeep[1]]);
		f = interp1d(xkeep, ykeep, kind='linear');	
		if reference is not None:
			sp = reference.copyxy();
			sp.addshoulder();
			f = interp1d(sp.get('x'), sp.get('y'), kind='linear');
		
		y[Iremove] = f(x[Iremove]);
		return x[Iremove],y[Iremove];
		
	def remove_spike(self,nslope=2,Nmax=10,reference=None):
		N = Nmax;
		Nremove = 0;
		nremove = 10;
		i = 0;
		while nremove >0 and i<N:
			xremove,yremove = self.remove_spike_slope_once(nslope=nslope,reference=reference);
			xremove,yremove = self.remove_spike_peak_once(nslope=nslope,reference=reference);
			nremove = len(xremove);
			Nremove = Nremove+nremove;
			print "nremove:",nremove
			i=i+1;
		print "number of iteration in remove_spike:",i,",total removed:",Nremove;
		return i;
	
	def remove_spike1(self,nsig=3):
		from scipy.interpolate import interp1d;
		x = self.get('x');
		y = self.get('y');
		ave = y.mean();
		sigma = y.std();
		Iremove = logical_or(y>ave+nsig*sigma,y<ave-nsig*sigma);
		Ikeep = logical_and(y<=ave+nsig*sigma,y>=ave-nsig*sigma);
		xkeep = x[Ikeep];
		ykeep = y[Ikeep];
		f = interp1d(xkeep, ykeep, kind='cubic');
		# sometimes, the point to remove is out of the Ikeep
		xremove = x[Iremove];
		Iremoveout = logical_or(xremove>=min(xkeep),xremove<=max(xkeep));
		Iremovein = logical_and(xremove<min(xkeep),xremove>max(xkeep));
		xremoveout = xremove[Iremoveout];
		xremovein = xremove[Iremovein];
		y[Iremove[Iremovein]] = f(xremovein);
		y[Iremove[Iremoveout]] = xremoveout-xremoveout+y.min();
		return xremove,y[Iremove];
		
		
	def cullonce(self,resolution,evenoddchoice):
		x=self.get('x');
		difx=numpy.diff(x);
		difx=numpy.hstack((difx,resolution*2));
		I1=range(len(x));

		I=numpy.core.logical_or(difx>resolution, pylab.mod(I1,2)==evenoddchoice);
		#I=[];
		#i=0;
		#while i <len(difx):
		#	I.append(i);
		#	if difx[i]<resolution:
		#		i=i+2;
		#	else:
		#		i=i+1;
		#I.append(len(x)-1);
		#I=numpy.array(I);
		#print "shape before",x.shape
		x=self.get('x')[I];
		self.set('x',x);
		y=self.get('y')[I];
		self.set('y',y);
		#print "shape after",self['x'].shape
	
	def smooth(self,xwidth=None,xmin=None,xmax=None,xwidthN=100,base=0,edgeconserve=0):
		# print "in XyDiscreteFun->smooth"
		x = self.get('x');
		y = self.get('y');
		# figure();
		# plot(x,y,'o')
		
		if xmin is None:
			xmin=min(x);
		if xmax is None:
			xmax=max(x);
		if xwidth is None:
			xwidth=(xmax-xmin)/xwidthN;
		spect=self.copyxy();
		spect.pick(xmin=xmin,xmax=xmax);
		
		#print "widthratio:",xwidth/(xmax-xmin)
		# print "before gausscov"
		# plot(spect.get('x'),spect.get('y'))
		
		spect.gaussconv(xwidth,base=base,edgeconserve=edgeconserve);
		# print "after gausscov"
		# print len(spect.get('x')),len(self.get('x'))
		# plot(spect.get('x'),spect.get('y'),'o')
		
		if len(spect.get('x'))<len(self.get('x')):
			spect.extend(self,smooth=0);
		
		self.set('x',spect.get('x'));
		self.set('y',spect.get('y'));
		
		# plot(self.get('x'),self.get('y'))
		
		# ginput()
		return;
		
	def gaussconv1(self,xwidth,xmin=None,xmax=None,Nx=None):
		x=self.get('x');
		y=self.get('y');
		if xmin is None:
			xmin=min(x)-(max(x)-min(x))/10.;
			xmax=max(x)+(max(x)-min(x))/10.;
			Nx=1000.;
		dx=(xmax-xmin)/float(Nx);
		xnew=arange(xmin,xmax,dx);
		fnew=zeros(len(xnew));
		for i in range(len(x)):
			xi=x[i];
			yi=y[i];
			g=exp(-(xnew-xi)**2./xwidth**2/2.)/sqrt(2*pi)/xwidth;
			g=yi*g;
			fnew=fnew+g;
		spect=self.copyxy();
		spect.set('x',xnew);
		spect.set('y',fnew);
		return spect;
		
	def gaussconv(self,xwidth,base=0,edgeconserve=0):
		x=self.get('x');
		y=self.get('y');
		if len(x)>=2:
			dx1 = min(abs(diff(x)));
			dx2 = mean(abs(diff(x)))/10;
			dx = max(dx1,dx2);
			N = int(ceil((max(x)-min(x))/dx));
			dx = (max(x)-min(x))/N;
		
			xint=arange(min(x),max(x)+dx,dx);
			self_b=self.copyxy();
			self_b.addshoulder();
			#print "after addshoulder"
			int1=scipy.interpolate.interp1d(self_b.get('x'),self_b.get('y'));
			yint=int1(xint);
			#print "after interp1d"
			
			spectint=self.copyxy();
			spectint.set('x',xint);
			spectint.set('y',yint);
			# print 'xint','yint',xint,yint
			spectint.addshoulder();
			xint=spectint.get('x');
			yint=spectint.get('y');

			Ng=int(numpy.ceil(3*xwidth/dx));
		#print "Ng:",Ng
		#print "dx",dx;
		#print "xwidth",xwidth
		#xg=numpy.arange(-Ng*dx,Ng*dx+dx,dx);
		#if len(xg)%2==0:
		#	xg=numpy.hstack((xg,Ng*dx+dx));
		#xg=xarange(-Ng*dx,Ng*dx+dx,dx);
			xg=scipy.linspace(-Ng*dx,Ng*dx,Ng*2+1);
			yg=exp(-(xg/xwidth)**2/2.);
			yg = yg/yg.sum();
		#print "lyg",len(yg);
		
			if base==1:
				P=numpy.polyfit(numpy.array([xint[0],xint[-1]]),numpy.array([yint[0],yint[-1]]),1);
			#print "lx",len(xint),"ly",len(yint)
				ybase=numpy.polyval(P,xint);
			#print "len:",len(ybase)
				yint=yint-ybase;
			#pylab.plot(x,y);
			#pylab.hold(True);
			#pylab.plot(x,ybase);

			yconv=numpy.convolve(yint,yg);
			#print "after yconv"
			yconv=yconv[Ng:-Ng];
		#print "Ly:",len(y),"Lyconv",len(yconv)
		#pylab.plot(x,yconv);
			if base==1:
				yconv=yconv+ybase;
		#print "Lx:",len(x),"Ly",len(y);	
			int2=scipy.interpolate.interp1d(xint,yconv);
			ynew=int2(x);
		#pylab.plot(self['x'],ynew);
		
			if edgeconserve==1:
			#P=numpy.polyfit(numpy.array([x[0],x[-1]]),numpy.array([y[0],y[-1]]),1);
			#ybase=numpy.polyval(P,x);
				ybase=self.getbaseline();
				spect0=self.copyxy();
				spect0.set('y',spect0.get('y')-ybase);
				M0=spect0.nthmoment(0);
			
				spect0.set('y',ynew);
				ybase0=spect0.getbaseline();
				spect0.set('y',spect0.get('y')-ybase0);
				M1=spect0.nthmoment(0);
			#print "M1:",M1,"M0:",M0
				if M1!=0:
					spect0.set('y',spect0.get('y')*M0/M1);
				self.set('y',spect0.get('y')+ybase);
			else:
				# print "edgeconserve = 0"
				self.set('y',ynew);
		#figure();
		# plot(x,y,linewidth=2); plot(x,ynew,linewidth=5);
		return;
		
	def inverse(self):
		spect.set('y',1/spect.get('y'));
		
	def fixglich(self,xmin,xmax):
		spect=self.copyxy();
		spect.pick(xmin,xmax);
		x=spect.get('x');
		y=spect.get('y');
		P=numpy.polyfit(numpy.array([min(x), max(x)]), numpy.array([y[0], y[-1]]),1);
		ypoly=numpy.polyval(P,x);
		spect.set('y',ypoly);
		spect.extend(self,smooth=1);
		self.set('y',spect.get('y'));

	def yerrmean(self):
		y=self.get('y');
		yerr=self.get('yerr');
		yerr=nonzeroarray(yerr,1e-9);
		return (y/yerr).sum()/(1/yerr).sum();
		
	def addshoulder(self,xleft=None,xright=None):
		self.sortx();
		x=self.get('x');
		y=self.get('y');
		#dx=None;
		if xleft is None:
			#dx=numpy.mean(numpy.fabs(numpy.diff(x)));
			dx=x[1]-x[0];
			#xmin=min(x)-dx;
			xleft=x[0]-dx;
		if xright is None:
			#if dx is None:
			#	dx=numpy.mean(numpy.fabs(numpy.diff(x)));
			dx=x[-1]-x[-2];
			#xmax=max(x)+dx;
			xright=x[-1]+dx;
		xint=numpy.hstack((xleft,x,xright));
		yint=numpy.hstack((y[0],y,y[-1]));
		self.set('x',xint);
		self.set('y',yint);
		return;
		
	def uniquex(self,xeps=1e-9,Sum=False):
		x=self.get('x');
		Iall=arange(len(x));
		Idub0=abs(diff(x))<xeps;
		Idub1=abs(diff(diff(x)))>=xeps;
		Idub1=hstack((Idub1,True));
		Idub2=logical_and(Idub0,Idub1);
		Idub2=hstack((Idub2,False));
		Idub=Iall[Idub2];
		Ikeep=logical_not(Idub2);
		
		while len(Idub)>0:
			# print Idub
			x=self.get('x');
			y=self.get('y');
			self.set('x',x[Ikeep]);
			if Sum:
				y[Idub+1]=y[Idub+1]+y[Idub];
			self.set('y',y[Ikeep]);
			
			x=self.get('x');
			Iall=arange(len(x));
			Idub0=abs(diff(x))<xeps;
			Idub1=abs(diff(diff(x)))>=xeps;
			Idub1=hstack((Idub1,True));
			Idub2=logical_and(Idub0,Idub1);
			Idub2=hstack((Idub2,False));
			Idub=Iall[Idub2];
			Ikeep=logical_not(Idub2);
		
			
	def nthmoment(self,n):
		x=self.get('x');
		y=self.get('y');
		dx=numpy.fabs(numpy.diff(x));
		dx=numpy.hstack((dx,dx[-1]));
		xmean=(x*y*dx).sum()/(y*dx).sum();
		if n==0:
			moment=(y*dx).sum();
		elif n==1:
			moment=xmean;
		else:
			moment=(numpy.power(x-xmean,n)*y*dx).sum()/(y*dx).sum();
		return moment;
	
	def getbaseline(self):
		x=self.get('x');
		y=self.get('y');
		P=numpy.polyfit(numpy.array([x[0],x[-1]]),numpy.array([y[0],y[-1]]),1);
		#print "lx",len(xint),"ly",len(yint)
		ybase=numpy.polyval(P,x);
		return ybase;
	
	def smoothstep(self,xmin,xmax):
		x=self.get('x');
		spect=self.copyxy();
		I=numpy.core.logical_and(x>=xmin, x<=xmax);
		x=spect.get('x')[I];
		spect.set('x',x);
		y=spect.get('y')[I]
		spect.set('y',y);
		y0=spect.get('y')[0];
		yend=spect.get('y')[-1];
		smoothwidth=(max(spect.get('x'))-min(spect.get('x')))/4;
		for i in range(5):
			spect.gaussconv(smoothwidth,base=1);
			y=spect.get('y');
			y[0]=y0;
			y[-1]=yend;
			spect.set('y',y);
		y=self.get('y');
		y[I]=spect.get('y');
		self.set('y',y);
	
	def polyfit(self,n,xmin=None,xmax=None):
		if xmin is None:
			xmin=min(self.get('x'));
		if xmax is None:
			xmax=max(self.get('y'));
		spect=self.copyxy();
		spect.pick(xmin,xmax);
		P=numpy.polyfit(spect.get('x'),spect.get('y'),n);
		yfit=numpy.polyval(P,spect.get('x'));
		check=numpy.core.maximum(numpy.core.fabs(yfit),numpy.core.fabs(spect.get('y')));
		dy=sqrt(((yfit-spect.get('y'))**2/check).sum()/(1/check).sum());
		return (P,dy);
		
	def gaussfit(self,xmin=None,xmax=None,method=None):
		spect=self.copyxy();
		spect.pick(xmin,xmax);
		x=spect.get('x');
		y=spect.get('y');
		
		center=spect.nthmoment(1);
		width=spect.nthmoment(2)**0.5;
		amp=spect.nthmoment(0)*2/(max(x)-min(x));
		slope=0;
		intercept=0;
		if method=="baseslope" or method==2:
			paras0=pylab.array([amp,center,width,slope,intercept]);
			paras=scipy.optimize.fmin(self.gaussfit_baseslope_chi2,paras0,args=(x,y));
		elif method=="base" or method==1:
			paras0=pylab.array([amp,center,width,intercept]);
			paras=scipy.optimize.fmin(self.gaussfit_base_chi2,paras0,args=(x,y));
			lp=list(paras)
			lp.append(0);
			paras=numpy.array(lp);
		elif method is None or method==0:
			paras0=pylab.array([amp,center,width]);
			paras=scipy.optimize.fmin(self.gaussfit_chi2,paras0,args=(x,y));
			lp=list(paras);
			lp.append(0);lp.append(0);
			paras=numpy.array(lp);
		return paras;
	
	def peak_area_simple(self,xmin=None,xmax=None):
		spect=self.copyxy();
		spect.pick(xmin,xmax);
		x=spect.get('x');
		y=spect.get('y');
		ixmin=list(x).index(min(x));
		ixmax=list(x).index(max(x));
		y_xmin=y[ixmin];
		y_xmax=y[ixmax];
		basey=(y_xmin+y_xmax)/2;
		area=spect.nthmoment(0);
		spect.set('y',y-y+basey);
		basearea=spect.nthmoment(0);
		peakarea=area-basearea;
		return (peakarea,basearea);
	
	def peak_area_baseline(self,xmin=None,xmax=None):
		import copy;
		spect=self.copyxy();
		spect.pick(xmin,xmax);
		x=spect.get('x');
		y=spect.get('y');
		
		paras0=pylab.array([0,y.mean()]);
		paras=scipy.optimize.fmin(self.posotivebaselinefit_chi2,paras0,args=(x,y));
		
		slope=paras[0];
		intercept=paras[1];
		ybase=x*slope+intercept;
		
		ypeak=y-ybase;
		
		spect1=spect.copyxy();
		spect1.set('y',ypeak);
		peakarea=spect1.nthmoment(0);
		
		spect1=spect.copyxy();
		spect1.set('y',ybase);
		peakarea1,basearea=spect1.peak_area_simple();
		
		# pylab.hold(False);
		# pylab.plot(x,y);pylab.hold(True);
		# pylab.plot(x,ybase);
		# pylab.plot(x,ypeak);
		
		return (peakarea,basearea,slope,intercept);
		
	def expdecayfit(self,xmin=None,xmax=None):
		spect=self.copyxy();
		spect.pick(xmin,xmax);
		x=spect.get('x');
		y=spect.get('y');
		
		I0=y[0]-y[-1];
		tau=spect.nthmoment(2)**0.5;
		baseline=mean(y);
		
		paras0=pylab.array([I0,tau,baseline]);
		paras=scipy.optimize.fmin(self.expdecayfit_chi2,paras0,args=(x,y));
		
		I0=paras[0];
		tau=paras[1];
		baseline=paras[2];
		
		yfit=I0*exp(-x/tau)+baseline;
		check=numpy.core.maximum(numpy.core.fabs(y),numpy.core.fabs(yfit));
		
		spect.plot();pylab.hold(True);
		pylab.plot(x,yfit,'r');pylab.hold(False);
		#pylab.show();
		
		#chi2=self.expdecayfit_chi2(paras,x,y);
		#dchi2dtau=(2*(y-yfit)/check*I0*exp(-x/tau)*x/tau**2).sum();
		#dchi2dtau=(2*(y-yfit)*I0*exp(-x/tau)*x/tau**2).sum();
		#tauerror=pylab.fabs(chi2/dchi2dtau);
		#check=1;
		chi2I0I0=(2*exp(-2*x/tau)/check).sum();
		chi2I0tau=(2*(yfit-y)*exp(-x/tau)*x/tau**2/check+2*I0*exp(-2*x/tau)*x/tau**2/check).sum();
		chi2tautau=(2*I0*exp(-2*x/tau)*x**2/tau**4/check+2*(yfit-y)*I0*exp(-x/tau)*x**2/tau**4/check-4*(yfit-y)*I0*exp(-x/tau)*x/tau**2/check).sum();
		errormatrix=pylab.array([[chi2I0I0,chi2I0tau],[chi2I0tau,chi2tautau]]);
		#print 'errormatrix',errormatrix
		inverr=scipy.linalg.inv(errormatrix);
		#print 'inverr',inverr
		tauerror=(pylab.fabs(inverr[1][1]))**0.5;
		print 'tauerror',tauerror
		
		return (paras,tauerror);
	
	def fixjump(self,xmin,xmax,norder=1,npoints=20):
		spectL=self.copyxy();
		spectL.pick(xmax=xmin);
		spectR=self.copyxy();
		spectR.pick(xmin=xmax);
		spectM=self.copyxy();
		spectM.pick(xmin=xmin,xmax=xmax);
		spL=spectL.copyxy();
		spR=spectR.copyxy();
		x=spL.get('x')[-npoints:];
		spL.set('x',x);
		y=spL.get('y')[-npoints:]
		spL.set('y',y);
		x=spR.get('x')[:npoints];
		spR.set('x',x);
		y=spR.get('y')[:npoints];
		spR.set('y',y);
		spR.nonoverlaprenormpoly(spL,norder);
		gainfactor=spR.getfromlog(-1,"gainfactor");
		#x=numpy.hstack((spectL['x'],spectR['x']));
		#y=numpy.hstack((spectL['y'],spectR['y']*gainfactor));
		P=spR.get('poly');
		x=numpy.hstack((spectL.get('x'),spectM.get('x'),spectR.get('x')));
		y=numpy.hstack((spectL.get('y'),pylab.polyval(P,spectM.get('x')),spectR.get('y')*gainfactor));
		self.set('x',x);
		self.set('y',y);
		self.log({"method":"fixjump","gainfactor":gainfactor});
		
	def fixnotch(self,xmin,xmax,norder=1,npoints=20):
		spectL=self.copyxy();
		spectL.pick(xmax=xmin);
		spectR=self.copyxy();
		spectR.pick(xmin=xmax);
		spectM=self.copyxy();
		spectM.pick(xmin=xmin,xmax=xmax);
		spL=spectL.copyxy();
		spR=spectR.copyxy();
		x=spL.get('x')[-npoints:];
		spL.set('x',x);
		y=spL.get('y')[-npoints:];
		spL.set('y',y);
		x=spR.get('x')[:npoints];
		spR.set('x',x);
		y=spR.get('y')[:npoints];
		spR.set('y',y);
		x=numpy.hstack((spL.get('x'),spR.get('x')));
		y=numpy.hstack((spL.get('y'),spR.get('y')));
		PR=numpy.polyfit(x,y,norder);
		
		x=numpy.hstack((spectL.get('x'),spectM.get('x'),spectR.get('x')));
		y=numpy.hstack((spectL.get('y'),pylab.polyval(PR,spectM.get('x')),spectR.get('y')));
		self.set('x',x);
		self.set('y',y);
		self.log({"method":"fixnotch","poly":PR});
		
		
	def fft(self):
		self.sortx();
		xmin=min(self.get('x'));
		xmax=max(self.get('x'));
		dx=numpy.fabs(numpy.mean(diff(self.get('x'))));
		Nx=(xmax-xmin)/dx;
		xnew=numpy.linspace(xmin,xmax,Nx+1);
		spect=self.copyxy();
		spect.set('x',xnew);
		spect.set('y',xnew);
		spect1=self.copyxy();
		spect1.mapx(spect);
		newy=pylab.fft(spect1.get('y'));
		newx=arange(len(spect1.get('x')))/float(len(spect1.get('x')))/dx;
		spect1.set('x',newx);
		spect1.set('y',newy.real);
		return spect1;
		
#=================================================================
#=================================================================
# binary operation
#=================================================================
	def binop(self,spect2,op):
		spect=spect2.copyxy();
		spect.mapx(self);
		#print type(spect)
		#self['ybak']=copyxy.copy(self['y']);
		cmd="self.set('y',self.get('y')"+op+"spect.get('y'))";
		#print "cmd:",cmd;
		exec(cmd);
		
	def divideby(self,dividerspect):
		spect=dividerspect.copyxy();
		spect.mapx(self);
		#self['ybak']=copy.copy(self['y']);
		y=self.get('y')/spect.get('y')
		self.set('y',y);
	
	def subtract(self,spect2subtract):
		spect=spect2subtract.copyxy();
		print "ylen before mapx:",len(self.get('y')),len(spect.get('y'));
		spect.mapx(self);
		#self['ybak']=copy.copy(self['y']);
		print "ylen after mapx:",len(self.get('y')),len(spect.get('y'));
		y=self.get('y')-spect.get('y')
		self.set('y',y);
		
	def minus(self,spect2subtract):
		# print "in mimus"
		x,y1,y2=self.getcommonxy(spect2subtract);
		spect=spect2subtract.copyxy();
		spect.set('x',x);
		spect.set('y',y1-y2);
		return spect;
		
	def ratio(self,spect2):
		if self.has_key('yerr'):
			yerr=self.get('yerr');
		else:
			yerr=numpy.sqrt(numpy.fabs(self.get('y')));
		if spect2.has_key('yerr'):
			y2err=spect2.get('yerr');
		else:
			y2err=numpy.sqrt(numpy.fabs(spect2.get('y')));
		
		y=self.get('y');
		y2=spect2.get('y');
		#print "len y:",len(y),"len y2:",len(y2)
		y2nz=nonzeroarray(y2.copy(),1e-9);
		ynew=y/y2nz;
		
		ynewerr2=(y*y*y2err*y2err)/y2nz/y2nz/y2nz/y2nz+yerr*yerr/y2nz/y2nz;
		self.set('y',ynew);
		yerr=nonzeroarray(numpy.sqrt(ynewerr2),1e-9)
		self.set('yerr',yerr);
	
	def conv(self,spect2):
		sp1=self.copyxy();
		sp2=spect2.copyxy();

		center1=sp1.nthmoment(1);
		center2=sp2.nthmoment(1);
		sp1.shift(-center1);
		sp2.shift(-center2);
		
		resolution=min(mean(abs(diff(sp1.get('x')))),mean(abs(diff(sp2.get('x')))));
		x1=arange(min(sp1.get('x')),max(sp1.get('x'))+resolution,resolution);
		x2=arange(min(sp2.get('x')),max(sp2.get('x'))+resolution,resolution);
		
		yf=sp1(x1);
		yg=sp2(x2);
		yconv=numpy.convolve(yf,yg);
		yconv=yconv*resolution;
		xmin_conv=min(sp1.get('x'))+min(sp2.get('x'));
		xmax_conv=max(sp1.get('x'))+max(sp2.get('x'));
		xconv=arange(xmin_conv,xmax_conv+resolution,resolution);
		if len(xconv)>=len(yconv):
			xconv=xconv[0:len(yconv)];
		else:
			while len(xconv)<len(yconv):
				xconv=list(xconv)+[xconv[-1]+resolution];
				xconv=array(xconv);
		resultspect=self.copyxy();
		x=xconv+center1+center2;
		resultspect.set('x',x);
		y=yconv;
		resultspect.set('y',y);
		#print "m0:",self.nthmoment(0),spect2.nthmoment(0),resultspect.nthmoment(0),resolution
		#print "m1:",self.nthmoment(1),spect2.nthmoment(1),resultspect.nthmoment(1)
		#print "m2:",self.nthmoment(2),spect2.nthmoment(2),resultspect.nthmoment(2)
		return resultspect;
		
	def deconv(self,spect2,Nmax=100,alpha=0.1):
		# self is the convolution of spect2 and the spect to find
		#Nmax=100;
		eps=1e-3;
		lamb=1e-2;
		lamb=alpha;
		
		m0ratio=self.nthmoment(0)/spect2.nthmoment(0);
		m1diff=self.nthmoment(1)-spect2.nthmoment(1);
		m2diff=abs(self.nthmoment(2)-spect2.nthmoment(2));
		#print "m0ratio",self.nthmoment(0),spect2.nthmoment(0)
		#print "m1diff",self.nthmoment(1),spect2.nthmoment(1)
		#print "m2diff",self.nthmoment(2),spect2.nthmoment(2)
		
		xgauss=self.get('x')-self.nthmoment(1)+m1diff;
		ygauss=exp(-(xgauss-m1diff)**2/2/m2diff);
		ygauss=ygauss/ygauss.sum()*m0ratio;
		spectgauss=self.copyxy();
		spectgauss.set('x',xgauss);
		spectgauss.set('y',ygauss);
		
		
		chi=1e10;
		spectresult=spectgauss;
		spectdiff=self.copyxy();
		y=self.get('x')-self.get('x');
		spectdiff.set('y',y);
		
		n=0;
		while n<Nmax and chi>eps:
			y=spectresult.get('y')-spectdiff.get('y')*lamb;
			y=abs(spectresult.get('y'));
			spectresult.set('y',y);
			spectconv=spect2.conv(spectresult);
			yconv=spectconv(self.get('x'));
			x=self.get('x');
			spectconv.set('x',x);
			spectconv.set('y',yconv);
			spectdiff=spectconv.copyxy();
			y=yconv-self.get('y');
			spectdiff.set('y',y);
			chi=spectdiff.get('y')**2/(abs(self.get('y'))+abs(yconv));
			chi=chi.mean();
			n=n+1;
			print "n,chi:",n,chi
		if n>=Nmax:
			print "reached Nmax for deconv"
		else:
			print "reached eps for deconv"
		return spectresult;
		
	def diff(self,spect2):
		if self.has_key('yerr'):
			yerr=self.get('yerr');
		else:
			yerr=numpy.sqrt(numpy.fabs(self.get('y')));
		if spect2.has_key('yerr'):
			y2err=spect2.get('yerr');
		else:
			y2err=numpy.sqrt(numpy.fabs(spect2.get('y')));
		y=self.get('y');
		y2=spect2.get('y');
		ynew=y-y2;
		ynewerr2=numpy.sqrt(yerr*yerr+y2err*y2err);
		self.set('y',ynew);
		yerr=nonzeroarray(numpy.sqrt(ynewerr2),1e-9)
		self.set('yerr',yerr);
		
	def renorm(self,xyfunstandard,xmin=None,xmax=None,gainorshift=0):
		xmincom,xmaxcom=self.commonrange(xyfunstandard);
		if xmin is None:
			xmin=xmincom;
		if xmax is None:
			xmax=xmaxcom;
			
		x,y1,y2=self.getcommonxy(xyfunstandard,xmin,xmax);
		if gainorshift==0: # gain
			paras=scipy.optimize.leastsq(self.renormgain_chi2,1,args=(y1,y2));
		#print "optparas",paras[0]
			y=self.get('y')*paras[0];
			self.set('y',y);
		elif gainorshift==1: #shift
			paras=scipy.optimize.leastsq(self.renormshift_chi2,0,args=(y1,y2));
			y=self.get('y')+paras[0]
			self.set('y',y);
		elif gainorshift==2:
			paras0=(1., 0.);
			paras=scipy.optimize.fmin(self.renormboth_chi2,paras0,args=(y1,y2));
			print paras
			#self['y']=self['y']+(self['x']-min(self['x']))*paras[0]+paras[1];
			y=self.get('y')*paras[0]+paras[1]
			self.set('y',y);
		elif gainorshift==3:
			paras0=(1., 0.);
			paras=scipy.optimize.fmin(self.renormramp_chi2,paras0,args=(x,y1,y2));
			#print paras
			#self['y']=self['y']+(self['x']-min(self['x']))*paras[0]+paras[1];
			y=self.get('y')*(paras[0]+paras[1]*self.get('x'))
			self.set('y',y);	
		elif gainorshift==4:
			paras0=(1., 0.,0.);
			paras=scipy.optimize.fmin(self.renormrampshift_chi2,paras0,args=(x,y1,y2));
			#print paras
			#self['y']=self['y']+(self['x']-min(self['x']))*paras[0]+paras[1];
			y=self.get('y')*(paras[0]+paras[1]*self.get('x'))+paras[2]
			self.set('y',y);
	
	def nonoverlaprenormpoly(self,spect,norder=1):
		PR=numpy.polyfit(self.get('x'),self.get('y'),norder);
		PL=numpy.polyfit(spect.get('x'),spect.get('y'),norder);
		#x=numpy.hstack(self['x'],spect['x']);
		xR=self.get('x');
		xL=spect.get('x');
		yR=self.get('y');
		yL=spect.get('y');
		gainfactor=1;
		P=(PL+PR)/2;
		paras0=numpy.hstack((gainfactor,P));
		paras=scipy.optimize.fmin(self.noneoverlap_renormgain_chi2,paras0,args=(xL,yL,xR,yR));
		gainfactor=paras[0];
		y=self.get('y')*gainfactor
		self.set('y',y);
		self.set('poly',paras[1:]);
		self.log({"method":"nonoverlaprenormpoly","gainfactor":gainfactor});
		
		
	def meanmerge(self,spect,xmin=None,xmax=None):
		x,y1,y2=self.getcommonxy(spect,xmin,xmax);
		#print "Lx:",len(x)
		if x is None:
			newx=numpy.hstack((self.get('x'),spect.get('x')));
			newy=numpy.hstack((self.get('y'),spect.get('y')));
		else:
			if xmin is None:
				xmin=min(x);
			if xmax is None:
				xmax=max(x);
			xsigma=(xmax-xmin)/4;
			IL=x<xmin;
			xL=x[IL];
			yL=y1[IL];
			IR=x>xmax;
			xR=x[IR];
			yR=y2[IR];
			IMid=numpy.core.logical_and(x>=xmin, x<=xmax);
			xMid=x[IMid];
			yMid=(y1[IMid]*numpy.exp(-numpy.power((xMid-xmin)/xsigma,2)/2)+y2[IMid]*numpy.exp(-numpy.power((xMid-xmax)/xsigma,2)/2))/(numpy.exp(-numpy.power((xMid-xmin)/xsigma,2)/2)+numpy.exp(-numpy.power((xMid-xmax)/xsigma,2)/2));
		#print "midlen:",len(xMid),len(yMid)
		#print "Llen:",len(xL),len(yL);
		#print "Rlen:",len(xR),len(yR);
		
			ycommon=numpy.hstack((yL,yMid,yR));
		#print "xlen:",len(x),len(ycommon)
		
			IL=self.get('x')<min(x);
			xL=self.get('x')[IL];
			yL=self.get('y')[IL];
			IR=spect.get('x')>max(x);
			xR=spect.get('x')[IR];
			yR=spect.get('y')[IR];
			newx=numpy.hstack((xL,x,xR));
			newy=numpy.hstack((yL,ycommon,yR));
		#print "lx",len(newx),"ly",len(newy)
		self.set('x',newx);
		self.set('y',newy);
		self.uniquex();
		
	def indmerge(self,spect1,xmin,xmax,gainorshift=0):
		x,y1,y2=self.getcommonxy(spect1,xmin,xmax);
		if self.renormshift_chi2(0,y1,y2)>1e-9:
			if gainorshift==0:
				paras=scipy.optimize.leastsq(self.renormgain_chi2,1,args=(y2,y1));
				y=spect1.get('y')*paras[0];
				spect1('y',y);
			elif gainorshift==1:
				paras=scipy.optimize.leastsq(self.renormshift_chi2,1,args=(y2,y1));
				y=spect1.get('y')+paras[0]
				spect1.set('y',y);
			elif gainorshift==2:
				paras=[1];
		#print "optparas",paras[0]
		
			self.meanmerge(spect1,xmin,xmax);
			self.log({"gainfactor":paras[0],"xmin":xmin,"xmax":xmax});
			return paras[0];
		else:
			self.meanmerge(spect1,xmin,xmax);
			if gainorshift==0:
				return	1;
			elif gainorshift==1:
				return 0;
		
	def extend(self,broaderspect,smooth=0):
		b=broaderspect;
		xmin,xmax=self.commonrange(b);
		IL=b.get('x')<xmin;
		IR=b.get('x')>xmax;
		newx=numpy.hstack((b.get('x')[IL],self.get('x'),b.get('x')[IR]));
		newy=numpy.hstack((b.get('y')[IL],self.get('y'),b.get('y')[IR]));
		self.set('x',newx);
		self.set('y',newy);
		if smooth==1:
			Dx=(xmax-xmin)/20;
			dx=Dx/2;
			self.smoothstep(xmin-Dx,xmin+Dx);
			self.smoothstep(xmax-Dx,xmax+Dx);
		
	def commonrange(self,spect):
		xmin=max(min(self.get('x')),min(spect.get('x')));
		xmax=min(max(self.get('x')),max(spect.get('x')));
		return (xmin,xmax)
		
	def mapx(self,standardspect):
		spect=standardspect.copyxy();
		spect1=self.copyxy();
		spect1.addshoulder();
		xint=spect1.get('x');
		yint=spect1.get('y');
		ints=scipy.interpolate.interp1d(xint,yint);
		xnew=spect.get('x');
		#print min(self['x']),max(self['x']);
		#print min(xnew),max(xnew);
		# Inew=logical_and(xnew>=min(xint),xnew<=max(xint));
		# xnew=xnew[Inew];
		ynew=ints(xnew);
		self.set('x',xnew);
		self.set('y',ynew);

	def getcommonxy1(self,spect0,xmin=None,xmax=None):
		# print "in getcommonxy:"
		
		spectself = self.copyxy();
		spect2 = spect0.copyxy();
		
		spectself.sortx();
		spect2.sortx();
		if xmin is None:
			xmin=min(min(spectself.get('x')),min(spect2.get('x')));
		if xmax is None:
			xmax=max(max(spectself.get('x')),max(spect2.get('x')));
		I1=numpy.core.logical_and(spectself.get('x')>=xmin, spectself.get('x')<=xmax);
		I2=numpy.core.logical_and(spect2.get('x')>=xmin, spect2.get('x')<=xmax);
		if len(spectself.get('x')[I1])==0 or len(spect2.get('x')[I2])==0:
			x=[];
			y1=[];
			y2=[];
		else:
			#print "none zero"
			xlow=max(min(spectself.get('x')[I1]),min(spect2.get('x')[I2]));
			xhigh=min(max(spectself.get('x')[I1]),max(spect2.get('x')[I2]));
			if xlow <= xhigh:
				N1=len(spectself.get('x')[I1]);
				N2=len(spect2.get('x')[I2]);
				N=max(N1,N2);
				dx=(xhigh-xlow)/N/2;
				x=scipy.linspace(xlow,xhigh,2*N+1);
				#print xlow,xhigh,dx,len(x)
				spectself.addshoulder();
				spect2.addshoulder();
				int1=scipy.interpolate.interp1d(spectself.get('x'),spectself.get('y'),kind='cubic');
				int2=scipy.interpolate.interp1d(spect2.get('x'),spect2.get('y'),kind='cubic');
				y1=int1(x);
				y2=int2(x);
			else:
				x = [];
				y1 = [];
				y2 = [];
		return (x,y1,y2);
	
	def getcommonxy(self,spect0,xmin=None,xmax=None):
		# print "in getcommonxy:"
		commonxy = True;
		
		spect1 = self.copyxy();
		spect1.sortx();
		spect1.pick(xmin,xmax);
		
		spect2 = spect0.copyxy();
		spect2.sortx();
		spect2.pick(xmin,xmax);

		
		xs1 = spect1.get('x');
		ys1 = spect1.get('y');
		dx1 = diff(xs1).mean();
		
		xs2 = spect2.get('x');
		ys2 = spect2.get('y');
		dx2 = diff(xs2).mean();
		# print "xs2",min(xs2),max(xs2)
		dx = min(dx1,dx2);
		
		xlow = max(xs1.min(),xs2.min());
		xhigh = min(xs1.max(),xs2.max());
		 
		if xlow>= xhigh:
			commonxy = False;
		else:
			x = arange(xlow,xhigh,dx);
			y1 = interp(x,xs1,ys1);
			y2 = interp(x,xs2,ys2);
		if not commonxy:
			x = [];
			y1 = [];
			y2 = [];
		return (x,y1,y2);
		
	def find_xshift_renorm(self,spect2):
		delta0 = self.nthmoment(1)-spect2.nthmoment(1);
		factor0 = self.nthmoment(0)/spect2.nthmoment(0);
		paras0 = [delta0, factor0];
		# paras0 = [0.,1.];
		print "paras0:",paras0
		# print self.get('x')
		# print spect2.get('x')
		paras = scipy.optimize.fmin(self.xshift_renorm_chi2,paras0,args=(self,spect2));
		return paras;
		
	def find_xshift_renormbg(self,spect2):
		x0 = self.get('x')+0;
		y0 = self.get('y')+0;
		x1 = spect2.get('x')+0;
		y1 = spect2.get('y')+0;
		bg0 = min(y0+y1)/2;
		
		y0 = y0-bg0;
		y1 = y1-bg0;
		delta0 = sum(x0*y0)/sum(y0)-sum(x1*y1)/sum(y1);
		factor0 = sum(y0)/sum(y1);
		
		# delta0 = self.nthmoment(1)-spect2.nthmoment(1);
		# factor0 = self.nthmoment(0)/spect2.nthmoment(0);
		# bg0 = min(spect2.get('y'));
		paras0 = [delta0, factor0,bg0];
		# paras0 = [0.,1.];
		print "paras0:",paras0
		# print self.get('x')
		# print spect2.get('x')
		paras = scipy.optimize.fmin(self.xshift_renormbg_chi2,paras0,args=(self,spect2));
		return paras;
		
#==========================================================================
# pure functions
#==========================================================================
	def xshift_renorm_chi2(self,paras,sp1,sp2):
		delta = paras[0];
		factor = paras[1];
		sp2 = sp2.copyxy();
		sp2.shift(delta);
		x,y1,y2 = sp1.getcommonxy(sp2);
		if len(x)>0 and factor>0:
			y2fit = y2*factor;
			chi2 = (abs(y1-y2fit)).mean();
		else:
			chi2 = 1e100;		
		return chi2;
	
	def xshift_renormbg_chi2(self,paras,sp1,sp2):
		delta = paras[0];
		factor = paras[1];
		bg = paras[2];
		sp2 = sp2.copyxy();
		sp2.shift(delta);
		x,y1,y2 = sp1.getcommonxy(sp2);
		if len(x)>0:
			y2fit = (y2-bg)*factor+bg;
			chi2 = abs(y1-y2fit).mean();
		else:
			chi2 = 1e10;		
		return chi2;
		
	def renormgain_chi2(self,gainfactor,y2gain,ystandard):
		check=numpy.core.maximum(numpy.core.fabs(ystandard),numpy.core.fabs(y2gain));
		yfit=y2gain*gainfactor;
		chi2=(numpy.power(yfit-ystandard,2)/check).sum();
		return chi2;
		
	def noneoverlap_renormgain_chi2(self,paras,xL,yL,xR,yR):
	# here xR and yR times a gainfactor will fit the same polynomial as xL and yL
		gainfactor=paras[0];
		P=paras[1:];
		yfitL=numpy.polyval(P,xL);
		checkL=numpy.core.maximum(numpy.core.fabs(yL),numpy.core.fabs(yfitL));
		yfitR=numpy.polyval(P,xR)/gainfactor;
		checkR=numpy.core.maximum(numpy.core.fabs(yR),numpy.core.fabs(yfitR));
		chi2L=(numpy.power(yfitL-yL,2)/checkL).sum();
		chi2R=(numpy.power(yfitR-yR,2)/checkR).sum();
		chi2=chi2L+chi2R;
		return chi2;
		
	def renormshift_chi2(self,shift,y2gain,ystandard):
		check=numpy.core.maximum(numpy.core.fabs(ystandard),numpy.core.fabs(y2gain));
		yfit=y2gain+shift;
		chi2=(numpy.power(yfit-ystandard,2)/check).sum();
		return chi2
		
	def renormramp_chi2(self,paras,x,y2gain,ystandard):
		#gainfactor=paras[0];
		#shift=paras[1];
		#print "shift and gain:",paras
		check=numpy.core.maximum(numpy.core.fabs(ystandard),numpy.core.fabs(y2gain));
		yfit=y2gain*(paras[0]+paras[1]*x);
		chi2=(numpy.power(yfit-ystandard,2)/check).sum();
		return chi2
		
	def renormrampshift_chi2(self,paras,x,y2gain,ystandard):
		#gainfactor=paras[0];
		#shift=paras[1];
		#print "shift and gain:",paras
		check=numpy.core.maximum(numpy.core.fabs(ystandard),numpy.core.fabs(y2gain));
		yfit=y2gain*(paras[0]+paras[1]*x)+paras[2];
		chi2=(numpy.power(yfit-ystandard,2)/check).sum();
		return chi2

	def renormboth_chi2(self,paras,y2gain,ystandard):
		gainfactor=paras[0];
		shift=paras[1];
		#print "shift and gain:",paras
		check=numpy.core.maximum(numpy.core.fabs(ystandard),numpy.core.fabs(y2gain));
		yfit=y2gain*gainfactor+shift;
		chi2=(numpy.power(yfit-ystandard,2)/check).sum();
		return chi2
		
	def gaussfit_baseslope_chi2(self,paras,x,y):
		#gainfactor=paras[0];
		#shift=paras[1];
		#print "shift and gain:",paras
		amp=paras[0];
		center=paras[1];
		sigma=paras[2];
		slope=paras[3];
		intercept=paras[4];
		
		yfit=amp*numpy.exp(-(x-center)**2/sigma**2/2)+slope*x+intercept;
		check=numpy.core.maximum(numpy.core.fabs(y),numpy.core.fabs(yfit));
		chi2=((yfit-y)**2/check).sum();
		return chi2
		
	def gaussfit_base_chi2(self,paras,x,y):
		#gainfactor=paras[0];
		#shift=paras[1];
		#print "shift and gain:",paras
		amp=paras[0];
		center=paras[1];
		sigma=paras[2];
		slope=0;
		intercept=paras[3];
		
		yfit=amp*numpy.exp(-(x-center)**2/sigma**2/2)+slope*x+intercept;
		check=numpy.core.maximum(numpy.core.fabs(y),numpy.core.fabs(yfit));
		chi2=((yfit-y)**2/check).sum();
		return chi2
		
	def gaussfit_chi2(self,paras,x,y):
		#gainfactor=paras[0];
		#shift=paras[1];
		#print "shift and gain:",paras
		amp=paras[0];
		center=paras[1];
		sigma=paras[2];
		slope=0#paras[3];
		intercept=0#paras[4];
		
		yfit=amp*numpy.exp(-(x-center)**2/sigma**2/2)+slope*x+intercept;
		check=numpy.core.maximum(numpy.core.fabs(y),numpy.core.fabs(yfit));
		chi2=((yfit-y)**2/check).sum();
		return chi2
	
	def expdecayfit_chi2(self,paras,x,y):
		I0=paras[0];
		tau=paras[1];
		baseline=paras[2];
		
		yfit=I0*numpy.exp(-x/tau)+baseline;
		check=numpy.core.maximum(numpy.core.fabs(y),numpy.core.fabs(yfit));
		#check=1;
		chi2=((yfit-y)**2/check).sum();
		#chi2=((yfit-y)**2).sum();
		return chi2;
		
	def posotivebaselinefit_chi2(self,paras,x,y):
		slope=paras[0];
		intercept=paras[1];
		
		yfit=slope*x+intercept;
		check=numpy.core.maximum(numpy.core.fabs(y),numpy.core.fabs(yfit));
		#check=1;
		
		L=len(x);
		Inum=pylab.arange(L);
		
		Ilogic=y-yfit>=0;
		chi2=((yfit[Ilogic]-y[Ilogic])**2/check[Ilogic]).sum();
		Ilogic=y-yfit<0;
		chi2=chi2+((yfit[Ilogic]-y[Ilogic])**2/check[Ilogic]).sum()*1e3;

		return chi2;
		
	def contextmenu(self,menu,dataname=''):
		import time,os;
		topmaster=gettoplevelmaster(menu);
		
		menu=DataObject.__dict__['contextmenu'](self,menu);
		menu.add_separator();
		menu.add_command(label="Setxy",command=lambda:self.uisetxy());
		menu.add_command(label="Summary",command=lambda:self.summarize(topmaster));
		return menu;
	
	def uisetxy(self):
		xexpression=self.get('xexpression');
		yexpression=self.get('yexpression');
		if xexpression is None:
			xexpression='numpy.arange(0,100,1)';
		if yexpression is None:
			yexpression='x';
		msg="Enter the field\n";
		msg=msg+"e.g.\n" 
		msg=msg+"x=numpy.arange(0,100,1)\n";
		msg=msg+"y=pylab.log(y)\n";
		answers=easygui.multenterbox(msg,"Setting x y",['x=','y='],[xexpression,yexpression]);
		if answers is not None:
			x=self.get('x');
			y=self.get('y');
			if answers[0] is not None:
				xexpression=answers[0];
			if answers[1] is not None:
				yexpression=answers[1];
			x=eval(xexpression);
			y=eval(yexpression);
			self.set('x',x);
			self.set('y',y);
			self['xexpression']=xexpression;
			self['yexpression']=yexpression;
			
	def summarize(self,topmaster=None):
		x=self.get('x');
		summary=OGroup();
		summary.set('len',len(x));
		xc=x.copy();
		xc.sort();
		difx=numpy.diff(xc);
		#summary['xunit']=self['xunit']['currentunit'];
		summary.set('res_min',min(difx));
		summary.set('res_max',max(difx));
		summary.set('res_mean',numpy.mean(difx));
		if topmaster is not None:
			topmaster.stdout( summary);
		return summary;
		#self['summary']=summary;