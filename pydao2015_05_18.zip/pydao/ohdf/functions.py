from pylab import *;

#=================classes========================================
def classdict(vartype): # the input can be a type, or a str describing the type
	import re;
	answer={};
	if vartype is None:
		answer=None;
#	else: type(s0) is not str:
#		s=str(type(s0));
	elif type(vartype) is str:
		s=vartype;
	else:
		s=str(vartype);
	if vartype is not None:
		#print "s:",s,type(s)
		g=re.search("<(\S+) '(\S+)'>",s);
		typeclass=g.group(1);
		answer['type']=typeclass;
		modandclass=g.group(2);
		mlist=modandclass.split('.');
		answer['modlist']=mlist;
		answer['classname']=mlist[-1];
	return answer;

def importcmd(importname,modname=None,level=None):
	if level is None:
		level=len(modname)-2;
	if type(modname) is list:
		mname=modname[0]
		for i in range(min(level,len(modname)-2)):
			mname=mname+"."+modname[i+1];
	elif type(modname) is str:
		mname=packagename()+"."+modname;
	else:
		mname=packagename();
	cmd="from "+mname+" import "+importname;
	return cmd;

def get_empty_instance(obj):
	import pydao,copy;
	# print "in get_empty_instance:",type(obj),obj
	if type(obj) is not dict:
		class_dict=classdict(type(obj));
	else:
		class_dict=obj;
	#print "--------------------"
	#print "class_dict",class_dict
	class_str=str(class_dict);
	if pydao.etc.globalcfg.empty_instances.has_key(class_str):
		#print "found instance",class_dict
		temp=pydao.etc.globalcfg.empty_instances[class_str];
		empty_instance=copy.copy(temp);
		#dcopyall(temp,empty_instance,True);
		#ddel_all(empty_instance);
		empty_instance.__init__();
	else:
		#print "new instance"
		empty_instance=get_empty_instance_new(obj);
		#print 1
		temp=copy.copy(empty_instance);
		#print 2
		# print "obj:",type(obj)
		# print "empty_instance:",type(empty_instance)
		ddel_all(temp);
		temp.__init__();
		#dcopyall(empty_instance,temp,True);
		#print 3
		pydao.etc.globalcfg.empty_instances[str(class_dict)]=temp;
		#print 4
	#print empty_instance
	#print "--------------"
	return empty_instance;
	
def get_empty_instance_new(obj): # the input can be an object or a class_dict
	empty_instance=None;
	# print "in get_empty_instance_new: type(obj)",type(obj),obj
	if type(obj) is not dict:
		class_dict=classdict(type(obj));
	else:
		class_dict=obj;
	#print '-------------------------'
	#print "class_dict:",class_dict
	success=False;
	Nlevel=len(class_dict['modlist'])-2;
	level=Nlevel-1;
	while not success and level>=0:
		try:
			cmd=importcmd(class_dict['classname'],class_dict['modlist'],level);
			#print "cmd:",cmd
			exec(cmd);
			expr=class_dict['classname']+"()";
			#print "expr:",expr
			empty_instance=eval(expr);
			success=True;
			#print "success",empty_instance
		except:
			level=level-1;
	#print "get_empty_instance cmd:",cmd
	return empty_instance;
	
#================== HasTraits ==============================
def dget(obj,traitname):
	from enthought.traits.api import HasTraits;
	v=None;
	tdict=HasTraits.get(obj,traitname);
	if tdict is not None:
		if len(tdict)>0:
			v=tdict[tdict.keys()[0]];
	return v;
	
def dset(obj,name,value):
	name1=name.replace(' ','_')
	name1=name1.replace('.','_')
	cmd='obj.'+name1+'=value';
	exec(cmd);
		
def dkeys(obj):
	from enthought.traits.api import HasTraits;
	from models import Meta_Data_Prefix;
	#print obj
	l=obj.all_trait_names();
	#print "l:",l
	l.remove('trait_added');
	l.remove('trait_modified');
	#print "l:",l
	ks=[];
	import inspect;
	for l0 in l:
		if len(HasTraits.get(obj,l0))>0 and not l0.startswith(Meta_Data_Prefix):
			if not inspect.ismethod(eval('obj.'+l0)):
				ks.append(l0);
	ks.sort();
	return ks;
	
	
def ddel(obj,name):
	return obj.remove_trait(name);
	
def ddel_all(obj):
	keys=dkeys(obj);
	for k in keys:
		ddel(obj,k);
	
def dcopy(obj_from,obj_to,name,deep=False):
	import copy;
	v=dget(obj_from,name);
	if deep:
		v=copy.deepcopy(v);
	dset(obj_to,name,v);
	
def dcopyall(obj_from,obj_to,deep=False):
	for k in dkeys(obj_from):
		dcopy(obj_from,obj_to,k,deep);
	
def natural_name(name):
	import os;
	import copy;
	fname=copy.deepcopy(name);
	for char in name:
		#print char
		if not (char.isdigit() or char.isalpha()):
			fname=fname.replace(char,'_');
			#print "replaced"
	#fname=fname.replace('-','_');
	#fname=fname.replace('.','_');
	#fname=fname.replace(' ','_');
	if fname[0].isdigit():
		fname='_'+fname;
	# print name,"natural name:",fname
	return fname;
		
#==================================
def isnumeric(a):
	isornot=True;
	try:
		b=a+1;
	except:
		isornot=False;
	return isornot;

#==============string====================
def sscan2(string,pattern):
	#the format is sscan(string,"%s1%s2%s3%"); 
	#here the s1, s2 and s3 are matching patterns and 3% correspond to 3 values (either numeric or string).
	#note that the start and end will always be % even if that's not the values we want.
	import copy;
	resultvalues=[];
	# print "string:",string,"pattern",pattern,type(string)
	patternlist=(pattern.rstrip()).split("%");
	patternlist.pop();
	patternlist.pop(0);
	print "patternlist",patternlist
	
	allmatch=True;
	for p in patternlist:
		if string.find(p)<0:
			allmatch=False;
	if allmatch:
		string1=copy.copy(string);
		# print "string1 start:",string1,",len:",len(string1);
		for i in range(len(patternlist)):
			# print "i:",i
			# print "string1:",string1,type(string1),"patternlist[i]:",patternlist[i]
			string1list=string1.split(patternlist[i]);
			# print "string1list",string1list
			v=try_str2num(string1list[0]);
			resultvalues.append(v);
			# print "resultvalues:",resultvalues
			string2remove=string1list[0]+patternlist[i];
			# print "string2remove:",string2remove,"len:",len(string2remove);
			string1=string1.replace(string2remove,"",1);
			string1=string1.strip();
			#string1=string1.strip(patternlist[i])
			# print "string1:",string1,",len:",len(string1);
			if len(string1)==0:
				break;
		if len(string1)>0:
			# print "string1:",string1
			v=try_str2num(string1);
			resultvalues.append(v);
	# if allmatch:
		# print "string:",string,"pattern:",pattern,resultvalues
	return resultvalues;
	
def sscan(string,pattern):
	# print "string:",string
	# print "pattern:",pattern
	import copy;
	string1 = copy.copy(string);
	if pattern[0]=="%":
		beginwithknown = False;
	else:
		beginwithknown = True;
	if pattern[-1]=="%":
		endwithknown = False;
	else:
		endwithknown = True;
	N2find = pattern.count("%");
	values2find=[];
	# print "string:",string,"pattern",pattern,type(string)
	knownlist=pattern.split("%");
	if knownlist[0]=='':
		knownlist.pop(0);
	if knownlist[-1]=='':
		knownlist.pop();
	Nknown = len(knownlist);
	
	for known in knownlist:
		# print "known:",known,'string1:',string1
		string1_split = string1.split(known);
		# print "string1_split:",string1_split
		if len(string1_split) >= 2:
			if beginwithknown and string1_split[0]=='':
				pass;
			elif not beginwithknown:
				values2find.append(string1_split[0]);
			string1 = string1.replace(string1_split[0]+known,'',1);
			beginwithknown = False;
		else:
			break;
	if not endwithknown:
		values2find.append(string1);
	i=0;	
	for v in values2find:
		v1 = try_str2num(v);
		values2find[i] = v1;
		i = i+1;
	return values2find;
	

def try_str2num(string):
	try:
		v=float(string);
	except:
		v=string;
	return v;
	
def str2list(string):
	resultlist=string.split();
	for i in range(len(resultlist)):
		v=try_str2num(resultlist[i]);
		resultlist[i]=v;
	return resultlist;
	
def remove_numstr(string0):
	string1 = string0;
	for i in range(10):
		string1=string1.replace(str(i),'');
	return string1;
	
def remove_consecutive_space(string0):
	string1 = "";
	string2 = string0;
	while string2 != string1 and string2 != "":
		string1 = string2;
		string2 = string1.replace("  "," ");
	# print "string0:",string0
	# print "string1:",string1
	return string1;