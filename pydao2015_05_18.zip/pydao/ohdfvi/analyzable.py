from ..ohdf import OGroup;
from ..ohdfvi import Application;
from pylab import *;

class Analyzable(OGroup,Application):
	def __init__(self):
		OGroup.__init__(self);
		#OGroup.set(self,'columns',OGroup());
		Application.__init__(self);
		from pydao import add_extended_methods
		import analyzable_methods as methods;
		add_extended_methods(self,methods);

#=======================methods===================================
	def OnOpen(analyzable,event=None):
		from analyzable_views import analyzable_view_modify;
		view=analyzable_view_modify(analyzable);
		analyzable.configure_traits(view=view);
