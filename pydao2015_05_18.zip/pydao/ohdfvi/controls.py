from enthought.traits.ui.api import  Handler

#=========================================================================
# View Handler
#=========================================================================
class Hanlder_to_Fix_TextEditor(Handler):
	def init(self,info):
		from monitors import Monitor_to_Fix_TextEditor;
		info.object.uiinfo=info;
		info.object.__pydao__monitor=Monitor_to_Fix_TextEditor(info.object);
		#print info.object.__pydao__monitor,type(info.object.__pydao__monitor)
		#info.ui.title=str(info.object.ondisk);
		
	def setattr(self, info, object, name, value):
		Handler.setattr(self, info, object, name, value)
		#print info.object.__pydao__monitor
		info.object.__pydao__monitor.correct(object,[name]);
		
	def close(self,info,is_ok):
		return Handler.close(self,info,is_ok);
		
		
class OGroup_List_Viewer_Handler(Handler):
	def init(self,info):
		info.object.uiinfo=info;
		
	def setattr(self, info, object, name, value):
		Handler.setattr(self, info, object, name, value)
		#info.object._updated = True	
		#print "set len:",len(info.object.filepages);
		
	def close(self,info,is_ok):
		for opage in info.object.opages:
			print opage,"closed."
			opage.close();
		info.object.history_file.close();
		return Handler.close(self,info,is_ok);
		
class OFile_Viewer_Handler(Handler):
	def init(self,info):
		info.object.uiinfo=info;
		#info.ui.control.ohdf_viewer=object;
		#from detc import version;
		#info.ui.title=version;
		#print "hand init: info",info
		
	def setattr(self, info, object, name, value):
		Handler.setattr(self, info, object, name, value)
		#info.object._updated = True	
		#print "set len:",len(info.object.filepages);
		
class OTable_Spreadsheet_View_Handler(Handler):
	def init(self,info):
		#print "in OTable_Spreadsheet_View_Handler:"
		info.object.uiinfo=info;
		
	def setattr(self, info, object, name, value):
		Handler.setattr(self, info, object, name, value)
		#info.object._updated = True	
		#print "set len:",len(info.object.filepages);
		
#===========================================================================
# Editor Handler
#===========================================================================
		
class OGroup_Exporler_Editor_Handler(Handler):
	def init(self,info):
		info.object.uiinfo=info;
		#info.ui.control.root_hastraits=object;
		pass;
		
	def setattr(self, info, object, name, value):
		Handler.setattr(self, info, object, name, value)
		#info.object._updated = True
		#print "set len:",len(info.object.filepages);
		
	def object__fullfilename_changed(self, info):
		#print "fullfilename changed, new name:",info.object.fullfilename
        #if info.initialized:
         #   info.ui.title += "*"
		pass;
		 
	def close(self,info,is_ok):
		return Handler.close(self,info,is_ok);
		
class OTable_Spreadsheet_Editor_Handler(Handler):
	def init(self,info):
		info.object.uiinfo=info;
		#info.ui.control.root_hastraits=object;
		pass;
		
	def setattr(self, info, object, name, value):
		Handler.setattr(self, info, object, name, value)
		#info.object._updated = True
		#print "set len:",len(info.object.filepages);
		
	def object__fullfilename_changed(self, info):
		#print "fullfilename changed, new name:",info.object.fullfilename
        #if info.initialized:
         #   info.ui.title += "*"
		pass;
		 
	def close(self,info,is_ok):
		return Handler.close(self,info,is_ok);