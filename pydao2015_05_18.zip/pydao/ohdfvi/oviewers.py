from pylab import *;
from enthought.traits.api import HasTraits;
import wx;


#===================================================================================================
#                Viewer for 
#===================================================================================================

class SpreadSheet_Viewer(HasTraits):
	from enthought.traits.api import Event,Any;
	clicked=Any;
	column_clicked=Any;
	right_clicked=Any;
	
	def __init__(self,object,spreadsheet,col_names,title=None):
		self.object=object;
		self.spreadsheet=spreadsheet;
		self.col_names=col_names;
		self.title=title;
		self.on_trait_change(self.OnCliked, 'clicked');
		self.on_trait_change(self.OnClikedColumn, 'column_clicked');
		self.on_trait_change(self.OnRightClicked, 'right_clicked');
		
	def main(self):
		self.clicked=None;
		spreadsheet_view=self.get_spreadsheet_view(self.col_names);
		ok=self.configure_traits(view=spreadsheet_view);
		self.get_uiroot().oroot=self;
		
		listctr=self.get_listctr();
		listctr.Bind(wx.EVT_MOTION,self.ONMouseMotion,id=listctr.GetId());
		
		if self.title is not None:
			self.uiinfo.ui.title=self.title;
		return ok;
		
	def get_spreadsheet_view(self,col_names):
		from enthought.traits.ui.api import Item,Group,View,TabularEditor;
		from enthought.traits.ui.table_column import ObjectColumn;
		from enthought.traits.ui.tabular_adapter import TabularAdapter;
		#from controls import spreadsheet_Spreadsheet_View_Handler;
		from pydao.ohdfvi import Hanlder_to_Fix_TextEditor;
		
		menubar=self.get_menubar();
		toolbar=self.get_toolbar();
		
		adapter=TabularAdapter();
		columns=[];
		for k in col_names:
			columns.append(k);
		adapter.columns=columns;
		editor = TabularEditor(adapter=adapter,editable=True,multi_select=True,operations=[ 'delete', 'insert', 'append', 'edit', 'move' ],clicked='clicked',column_clicked='column_clicked',right_clicked='right_clicked');
		ssview=View(Group(Item('spreadsheet',editor=editor,resizable = True,id='expeditorid'),show_labels=False),kind='live',width=.5,height=.5,resizable = True,scrollable=True,handler=Hanlder_to_Fix_TextEditor(),menubar=menubar);
		return ssview;
		
	def get_menubar(self):
		from enthought.traits.ui.menu import Menu, MenuBar, Action;
		file_export = Action(name = "Export",action = "do_spreadsheet_export")
		filemenu=Menu(file_export,name = 'File');
		menubar = MenuBar(filemenu);
		return menubar;
		
	def get_toolbar(self):
		from enthought.traits.ui.menu import Menu, ToolBar, Action;
		from enthought.pyface.api import ImageResource;
		toolbar=ToolBar();
		return toolbar;
		
	def get_uiroot(self):
		return self.uiinfo.ui.control;
	
	def get_listctr(self):
		uiroot=self.get_uiroot();
		listctr=uiroot.GetChildren()[0].GetChildren()[0].GetChildren()[0];
		return listctr;
		
	def do_spreadsheet_export(self):
		from enthought.traits.ui.api import FileEditor,View;
		from enthought.traits.api import HasTraits;
		ht=HasTraits();
		ht.targetfile='';
		view1=View(Item(name='targetfile',editor=FileEditor(),style="simple"),buttons = ['OK', 'Cancel'],resizable=True,width=.5,kind='livemodal');
		ok=ht.configure_traits(view=view1);
		if ok:
			self.object.export_ascii(ht.targetfile);
		
	def OnCliked(self):
		#print "OnCliked:"
		#print self.clicked.column,
		#print self.clicked.row,
		#print self.clicked.item,
		#print self.clicked.editor
		pass;
		
	def OnClikedColumn(self):
		print "OnClikedColumn";
		column=self.column_clicked.column;
		field_names=self.column_clicked.editor.adapter.columns;
		columnname=field_names[column];
		#self.inmemory.sort(order=columnname);
		
	def OnRightClicked(self):
		import wx;
		#print "OnRightClicked";
		#print self.right_clicked
		#print type(self.right_clicked.item),self.right_clicked.item
		listctr=self.get_listctr();
		menu=wx.Menu();
		item=menu.Append(wx.NewId(),"Refresh","Refresh");
		self.get_uiroot().Bind(wx.EVT_MENU, self.OnList_Refresh, item);
		listctr.PopupMenu(menu,self.mouse_position);
		
	def OnList_Refresh(self,event):
		print "refreshed!"
		
	def ONMouseMotion(self, event):
		#print event.GetPosition() 
		self.mouse_position=event.GetPosition();
