from pylab import *;

def langevin(x):
	y = 1/tanh(x) - 1./x;
	return y;
	
def spherical_harmonic(l,m,theta,phi):
	jj=complex(0,1);
	Phi = exp(jj*phi*m)/(2*pi)**0.5;
	if l==0 and m==0:
		Theta = 2**0.5/2;                       # Y(0,0)
	elif l==1 and m==0:
		Theta = 6**0.5/2*cos(theta);                # Y(1,0)
		#print "l,m",l,m
	elif l==1 and abs(m)==1:
		Theta= (-1)**(m+1)*3**0.5/2*sin(theta);              # Y(1, +/-1)
	elif l==2 and m==0:
		Theta = 10**0.5/4*(3*cos(theta)**2-1.);     # Y (2,0)
	elif l==2 and abs(m)==1:
		Theta = (-1)**(m+1)*15**0.5/2*cos(theta)*sin(theta);    # Y (2,+/-1)
	elif l==2 and abs(m)==2:
		Theta = 15**0.5/4*sin(theta)**2;       # Y(2,+/-2)
	elif l==3 and m==0:
		Theta = 3*14**0.5/4*(5./3*cos(theta)**3-cos(theta));    
	elif l==3 and abs(m)==1:
		Theta = (-1)**(m+1)*42**0.5/8*(5*cos(theta)**2-1)*sin(theta);    
	elif l==3 and abs(m)==2:
		Theta = 105**0.5/4*sin(theta)**2*cos(theta);       
	elif l==3 and abs(m)==3:
		Theta = (-1)**(m+1)*70**0.5/8*sin(theta)**3;       
	elif l==4 and m==0:
		Theta = 9*2**0.5/16*(35./3*cos(theta)**4-10*cos(theta)**2+1);    
	elif l==4 and abs(m)==1:
		Theta = (-1)**(m+1)*9*10**0.5/8*(7/3.*cos(theta)**3-cos(theta))*sin(theta);    
	elif l==4 and abs(m)==2:
		Theta = 3*5**0.5/8*sin(theta)**2*(7*cos(theta)**2-1);       
	elif l==4 and abs(m)==3:
		Theta = (-1)**(m+1)*3*70**0.5/8*sin(theta)**3*cos(theta);    
	elif l==4 and abs(m)==4:
		Theta = 3*35**0.5/16*sin(theta)**4;
	elif l==5 and m==0:
		Theta = 15*22**0.5/16*(21./5*cos(theta)**5-14./3*cos(theta)**3+cos(theta));    
	elif l==5 and abs(m)==1:
		Theta = (-1)**(m+1)*165**0.5/16*(21.*cos(theta)**4-14*cos(theta)**2+1)*sin(theta);    
	elif l==5 and abs(m)==2:
		Theta = 1155**0.5/8*sin(theta)**2*(3*cos(theta)**3-cos(theta));       
	elif l==5 and abs(m)==3:
		Theta = (-1)**(m+1)*770**0.5/32*sin(theta)**3*(9*cos(theta)**2-1);    
	elif l==5 and abs(m)==4:
		Theta = 3*385**0.5/16*sin(theta)**4*cos(theta);
	elif l==5 and abs(m)==5:
		Theta = (-1)**(m+1)*3*154**0.5/32*sin(theta)**5;    
	Y = Theta*Phi;
	return Y;