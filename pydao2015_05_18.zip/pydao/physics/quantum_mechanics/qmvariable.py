from pylab import *;
from pydao.ohdf import OGroup,isnumeric;
import pydao.math,copy;

class QMVariable(OGroup):
	def __init__(self,kind='base'):
		OGroup.__init__(self);
		self.initqmvkind(kind);
		
	def qmvkind(self):
		cft=self.get('coefficient');
		subs=self.get('subs');
		stack=self.get('stack');
		#print "cft,subs,stack",cft,subs,stack
		if cft is not None:
			answer="base";
		elif type(subs) is list and stack is None:
			answer="super";
		elif type(stack) is list and subs is None:
			answer="stack";
		return answer;
		
	def initqmvkind(self,kind):
		if kind=='base':
			self.initbase();
		elif kind=="super":
			self.initsuper();
		elif kind=="stack":
			self.initstack();
	
	def initbase(self):
		self.set('coefficient',0.);
		self.set('subs',None);
		self.set('stack',None);
		return;
		
	def initsuper(self):
		self.set('coefficient',None);
		self.set('subs',[]);
		self.set('stack',None);
		return;
		
	def initstack(self):
		self.set('coefficient',None);
		self.set('subs',None);
		self.set('stack',[]);
		return;
		
	def turnbase(self):
		if self.qmvkind()!="base":
			self.initbase();
		return;
	
	def turnsuper(self):
		if self.qmvkind()!="super":
			self.initsuper();
		return;
		
	def turnstack(self):
		if self.qmvkind()!="stack":
			self.initstack();
		return;		
		
	def set2qmvzero(self):
		self.initbase();
		
	def isqmvzero(self):
		if self.qmvkind()=='base':
			cft=self.get('coefficient');
			if cft==0:
				answer=True;
			else:
				answer=False;
		elif self.qmvkind()=='super':
			sbvs=self.get('subs');
			if len(sbvs)==0:
				answer=True;
			else:
				answer=False;
		elif self.qmvkind()=='stack':
			stack=self.get('stack');
			if len(stack)==0:
				answer=True;
			else:
				answer=False;
		return answer;
	
	def getcft(self):
		if self.qmvkind()=='base':
			cft=self.get('coefficient');
		elif self.qmvkind()=='stack':
			stack=self.get('stack');
			cft=1;
			for s in stack:
				cft=cft*stack[i].get('coefficient');
		return cft;
			
	def remove_zero(self):
		if self.qmvkind()=='super':
			sbvs=self.get('subs');
			new_subvs=[];
			for sbv in sbvs:
				if not sbv.isqmvzero():
					new_subvs.append(sbv);
			self.set('subs',new_subvs);
		return;
		
	def combine(self): # if we use matrix_element, this is not needed
		print "in QMVariable->combine:"
		if self.qmvkind()=='super':
			sbvs=self.get('subs');
			tmp_subvs=[];
			new_subvs=[sbvs[0]];
			for i in range(len(sbvs)-1):
				tmp_subvs.append(sbvs[i+1]);
			while len(tmp_subvs)>0:
				wf=tmp_subvs[0];
				found_identical=False;
				for i in range(len(new_subvs)):
					wf1=new_subvs[i];	
					if wf.isidentical(wf1):
						cf1=wf1.getcft();
						cf=wf.getcft();
						wf1.times((cf1+cf)/cf1);
						print "combined."
						found_identical=True;
						break;
				if not found_identical:
					new_subvs.append(wf);
				tmp_subvs.remove(wf);
			self.set('subs',new_subvs);
		return;
	
	def isidentical(self,wf): # if we use matrix_element, this is not needed
		answer=True;
		if self.qmvkind()=='stack':
		# this is to test whether two many-body wave functions are identical. 
			bra_stack=self.get('stack');
			ket_stack=wf.get('stack');
			if len(bra)==len(ket):
				for i in range(len(bra)):
					bra=bra_stack[i];
					ket=ket_stack[i];
					if not bra.identical(ket):
						answer=False;
						break;
		elif self.qmvkind()=='super':
		# here we return an error
			answer='error';
		return answer;
			
	def qmvcopy(self,qmv=None):
		# print "in QMVariable>qmvcopy"
		#print "self kind:",self.qmvkind()
		if qmv is None:
			qmv=QMVariable();
		if self.qmvkind()=='base':
			#qmv.turnbase();
			qmv.set('coefficient',self.get('coefficient'));
		elif self.qmvkind()=='super':
			#print "in super"
			self_subvs=self.get('subs');
			#print "len(self_subvs)",len(self_subvs)
			qmv_subvs=[];
			for self_subv in self_subvs:
				self_subv_copy=self_subv.qmvcopy();
				qmv_subvs.append(self_subv_copy);
			qmv.set('subs',qmv_subvs);
			#print "len(qmv_subvs)",len(qmv_subvs)
		elif self.qmvkind()=='stack':
			self_stack=self.get('stack');
			qmv_stack=[];
			for self_s in self_stack:
				self_s_copy=self_s.qmvcopy();
				qmv_stack.append(self_s_copy);
			qmv.set('stack',qmv_stack);
		#print "qmv kind:",qmv.qmvkind()
		return qmv;
		
	def info(self,indent=0):
		print indent*"|_","<QMVariable>",
		if self.qmvkind()=='base':
			print "Base"
			print indent*"|_",
			print "coefficient:",self.get('coefficient')
		elif self.qmvkind()=="super":
			#print indent*"|_",
			sub_vars=self.get('subs');
			print "Super,",len(sub_vars),'subs'
			i=0;
			for sub_var in sub_vars:
				print indent*"|_",
				print "sub",i,":" 
				sub_var.info(indent+1);
				i=i+1;
		elif self.qmvkind()=="stack":
			#print indent*"|_",
			sub_vars=self.get('stack');
			print "Stack,",len(sub_vars),'items:'
			i=0;
			for sub_var in sub_vars:
				print indent*"|_",
				print "item",i,":" 
				sub_var.info(indent+1);
				i=i+1;
	
	def __div__(self, divider):
		#print "in __div__", type(divider);
		if isnumeric(divider):
			qmvar_div=self*(1./divider);
		else:
			raise Exception('in QMVariable->__div__, divider must be numeric, found'+str(type(divider))+' instead.');
		return qmvar_div;
		
	def __rmul__(self, multiplier):
		if isnumeric(multiplier):
			qmvar_mul=self*multiplier;
		else:
			raise Exception('in QMVariable->__rmul__, multiplier must be numeric, found'+str(type(multiplier))+' instead.');
		return qmvar_mul;
		
	def __sub__(self,qmvar):
		qmvar=qmvar*(-1);
		return self+qmvar;
		
	def times(self,multiplier):
		result=None;
		if isnumeric(multiplier):
			result=self.__mul__(multiplier,copyqmv=False);
		else:	
			raise Exception('in QMVariable->times, multiplier must be numeric, found'+str(type(multiplier))+' instead.');
		return result;
	
	def qmvtimes(self,multiplier):
		result=None;
		if isinstance(multiplier,QMVariable):
			result=self.__mul__(multiplier,copyqmv=False);
		else:	
			raise Exception('in QMVariable->qmvtimes, multiplier must be QMVariable, found'+str(type(multiplier))+' instead.');
		return result;
		
	############################################
	def __mul__(self, multiplier,copyqmv=True):
		# print "in QMVariable->__mul__"
		# print "multiplier:",multiplier
		# self.info()
		# multiplier.info();
		
		if self.isqmvzero():
			if copyqmv:
				qmvar_mul=self.qmvcopy();
			else:
				qmvar_mul=self;
		elif isnumeric(multiplier):
			#print "self:"
			#print self.qmnumbers();
			#self.info();
			if copyqmv:
				qmvar_mul=self.qmvcopy();
			else:
				qmvar_mul=self;
			# print "qmvar_mul:"
			#qmvar_mul.info();
			if multiplier==0:
				qmvar_mul.set2qmvzero();
				#pass;
			elif self.qmvkind()=='base':				
				cft=self.get('coefficient');
				qmvar_mul.set('coefficient',cft*multiplier);
			elif self.qmvkind()=='super':
				subvars=qmvar_mul.get('subs');
				i=0;
				for subvar in subvars:
					subvar.times(multiplier);
			elif self.qmvkind()=='stack':
				# print "in stack"
				# print "qmvar_mul info"
				# qmvar_mul.info();
				stack=qmvar_mul.get('stack');
				# print "stack len:",len(stack)
				stack[0].times(multiplier);
				# print "qmvar_mul info"
				# qmvar_mul.info();
		elif isinstance(multiplier,QMVariable):
			qmvar_mul=self.qmvproduct(multiplier,copyqmv);
		else:
			raise Exception('in QMVariable->__mul__, multiplier must be numeric or QMVariable, found'+str(type(multiplier))+' instead.');
		# print "qmvar_mul:", qmvar_mul.info()
		return qmvar_mul;
	
	def qmvproduct(self,multiplier,copyqmv=True):
		# print "in QMVariable->qmvproduct:"
		if self.isqmvzero() or multiplier.isqmvzero():
			if isinstance(self,Operator):
				product=Operator();
			elif isinstance(self,WaveFunction):
				product=WaveFunction();
			product.set2qmvzero();
		elif self.qmvkind()!='super':
			product=self.lbasestack_qmvproduct(multiplier,copyqmv);
		elif self.qmvkind()=="super":
			self_sbvs=self.get('subs');
			i=0;
			for self_sbv in self_sbvs:
				# if self_sbv.qmvkind()!="super":
					# pr=self_sbv.lbasestack_qmvproduct(multiplier,copyqmv);
				# else:
				pr=self_sbv.qmvproduct(multiplier,copyqmv);
				if i==0:
					product=pr;
				else:
					product=product.plus(pr);
				i=i+1;
		return product;
	
	def lbasestack_qmvproduct(self,multiplier,copyqmv=True):
		if self.isqmvzero() or multiplier.isqmvzero():
			if isinstance(self,Operator):
				product=Operator();
			elif isinstance(self,WaveFunction):
				product=WaveFunction();
			product.set2qmvzero();
		elif multiplier.qmvkind()!="super":
			product=self.basestack_qmvproduct(multiplier,copyqmv);
			#print "op_cft:",op_cft
			# product=product*op_cft;
		elif multiplier.qmvkind()=="super":
			multi_subs=multiplier.get('subs');
			i=0;
			for multi_sub in multi_subs:
				pr=self.basestack_qmvproduct(multi_sub,copyqmv);
				if i==0:
					product=pr;
				else:
					product=product.plus(pr);
				i=i+1;
		return product;
		
	def basestack_qmvproduct(self,qmvar,copyqmv=True):
		if isinstance(qmvar,Operator):
			new_qmvar=Operator();
		elif isinstance(qmvar,WaveFunction):
			new_qmvar=WaveFunction();
		# print self.info()
		# print qmvar.info()
		new_qmvar.turnstack();
		
		if self.isqmvzero() or qmvar.isqmvzero():
			new_qmvar.set2qmvzero();
		else:
		
			if copyqmv:
				qmv1=self.qmvcopy();
				qmv2=qmvar.qmvcopy();
			else:
				qmv1=self;
				qmv2=qmvar;
		
			qmv1_stack=qmv1.get('stack');
			qmv2_stack=qmv2.get('stack');
		
			if qmv1.qmvkind()=='base':
				new_qmvar_stack=[qmv1];
			else:
				new_qmvar_stack=qmv1_stack;
			if qmv2.qmvkind()=='base':
				new_qmvar_stack.append(qmv2);
			else:
				new_qmvar_stack=new_qmvar_stack+qmv2_stack;
			new_qmvar.set('stack',new_qmvar_stack);
	
		return new_qmvar;
		
	def expandstack2super(self):
		# print "in QMVariable->expandstack2super:"
		result=None;
		qmv=self;
		if qmv.qmvkind()=='stack':
			stack=qmv.get('stack');
			if len(stack)==1:
				result=stack[0];
			elif len(stack)==2:
				# print "stack len=",2
				stack0=stack[0];
				stack1=stack[1];
				if stack0.qmvkind()=='base':
					stack0=[stack0];
				else:
					stack0=stack0.get('subs');
				if stack1.qmvkind()=='base':
					stack1=[stack1];
				else:
					stack1=stack1.get('subs');
					
				if len(stack0)>1 or len(stack1)>1:
					i=0;
					for s0 in stack0:
						j=0;
						for s1 in stack1:
							s=s0*s1;
							if i==0 and j==0:
								result=s;
							else:
								result=result.plus(s);
							j=j+1;						
						i=i+1;
				else:
					result=qmv;
			else:
				stack0=stack.pop(0);
				qmv=qmv.expandstack2super();
				result=stack0.qmvtimes(qmv);
				result=result.expandstack2super();
		return result;
			
	def plus(self,qmvar):
		return self.__add__(qmvar,copyqmv=False);
		
	def __add__(self,qmvar,copyqmv=True):
		#print "in __add__ "
		#print "self:"
		#self.info();
		#print "qmvar:"
		#qmvar.info();
		if isinstance(qmvar,Operator):
			new_qmvar=Operator();
		elif isinstance(qmvar,WaveFunction):
			new_qmvar=WaveFunction();
		#new_qmvar=type(qmvar)();
		#new_qmvar=QMVariable();
		new_qmvar.initsuper();

		#print "new_qmvar:"
		#new_qmvar.info();
		
		if copyqmv:
			qmv1=self.qmvcopy();
			qmv2=qmvar.qmvcopy();
		else:
			qmv1=self;
			qmv2=qmvar;
		
		qmv1_subs=qmv1.get('subs');
		qmv2_subs=qmv2.get('subs');
		
		if qmv1.qmvkind()!='super':
			new_qmvar_subs=[qmv1];
		else:
			new_qmvar_subs=qmv1_subs;
		if qmv2.qmvkind()!='super':
			new_qmvar_subs.append(qmv2);
		else:
			new_qmvar_subs=new_qmvar_subs+qmv2_subs;
		new_qmvar.set('subs',new_qmvar_subs);
		#print "new_qmvar:",new_qmvar.info();
		new_qmvar.remove_zero(); 
		new_qmvar_subs=new_qmvar.get('subs');
		if len(new_qmvar_subs)==1:
			new_qmvar=new_qmvar_subs[0];
		#print "new_qmvar after remove_zero:",new_qmvar.info();
		return new_qmvar;
			
###############################		
class WaveFunction(QMVariable):	
	def __init__(self):
		QMVariable.__init__(self);
		self.set('coefficient',1);
		
	def info(self,indent=0):
		print indent*"|_","<WaveFunction>"
		QMVariable.info(self,indent+1);
		# print indent*"|_",
		# print ">"
		
	def qmvcopy(self,qmv=None):
		# print "in WaveFunction->qmvcopy"
		# print "test value self:",self.get('xyzfun')(0,0,1e-10);
		if qmv is None:
			qmv=WaveFunction();
			qmv.initqmvkind(self.qmvkind());
		qmv=QMVariable.qmvcopy(self,qmv);
		return qmv;
		
	def __mul__(self,multiplier,copyqmv=True):
		if isinstance(multiplier,WaveFunction):
			# product=self.wfwfproduct(multiplier,copyqmv);
			product=self.qmvproduct(multiplier,copyqmv);
			#product.expandstack2super();
		else:
			product=QMVariable.__mul__(self,multiplier,copyqmv);
		return product;
		
	def innerproduct(self,wf):
		# print "in WaveFunction->innerproduct:"
		# self.info();
		if self.isqmvzero() or wf.isqmvzero():
			product=0;
		elif self.qmvkind()=='base': # this is one particle case
			# print "self:",self
			# print "wf:",wf
			product=self.lbase_innerproduct(wf)
		elif self.qmvkind()=='stack': # this is many body case
			product=self.lstack_innerproduct(wf);
		elif self.qmvkind()=='super': # not sure which case, have to unwrap and see
			#print "super"
			self_sbvs=self.get('subs');
			i=0;
			for self_sbv in self_sbvs:
				#print "i:",i
				pr=self_sbv.innerproduct(wf);
				if i==0:
					product=pr;
				else:
					product=product+pr;
				i=i+1;
		return product;
	
	def lbase_innerproduct(self,wf):
		# print "in WaveFunction->lbase_innerproduct:"
		if self.isqmvzero() or wf.isqmvzero():
			product=0;
		elif wf.qmvkind()=='base': # this is base-base particle case
			# print "self:",self
			# print "wf:",wf
			product=self.baseinnerproduct(wf)
		elif wf.qmvkind()=='super': # unwrap 
			#print "super"
			sbvs=wf.get('subs');
			i=0;
			for sbv in sbvs:
				#print "i:",i
				pr=self.lbase_innerproduct(sbv);
				if i==0:
					product=pr;
				else:
					product=product+pr;
				i=i+1;
		return product;
		
	def lstack_innerproduct(self,wf):
		# print "in WaveFunction->lbaseinnerproduct:"
		if self.isqmvzero() or wf.isqmvzero():
			product=0; 
		elif wf.qmvkind()=='stack':
			product=self.lstack_rstack_innerproduct(wf);
		elif wf.qmvkind()=='super':
			#print "super"
			wf_sbvs=wf.get('subs');
			i=0;
			for wf_sbv in wf_sbvs:
				pr=self.lstack_rstack_innerproduct(wf_sbv);
				if i==0:
					product=pr;
				else:
					product=product+pr;
				i=i+1;
		# elif wf.qmvkind()=='stack':
			# product=self.lbase_rstackinnerproduct(wf,istack);#this time product can be a wavefunction
		return product;
	
	def baseinnerproduct(self,wf):
		# print "in WaveFunction->baseinnerproduct"
		# The coefficients of both "self" and "wf" are taken care of here.
		# The method baseiproduct() takes care of the content.
		bracft=self.get('coefficient');
		ketcft=wf.get('coefficient');
		product=self.baseiproduct(wf);
		product=product*(bracft*ketcft);
		# print "bra_cft:",bracft,"ketcft:",ketcft
		return product;
		
########### for many body ###############
	def lstack_rstack_innerproduct(self,wf,istack=0):
		# print "in WaveFunction->lstackinnerproduct"
		# in this case, there will be some intermediate products (wavefunction) that are not numbers
		if self.isqmvzero() or wf.isqmvzero():
			product=0; 
		elif self.qmvkind()=='stack':
			self_stack=self.get('stack');
			wf_stack=wf.get('stack');
			N=len(self_stack);
			product=1;
			# print "self.info"
			# self.info();
			# print "wf.info"
			# wf.info();
			for i in range(N):
				self_sub=self_stack[i];
				wf_sub=wf_stack[i];
				pr=self_sub.baseinnerproduct(wf_sub);
				product=product*pr;
				if product==0:
					break;
				# print "i:",i,"product:",product
		return product;
		
	def symmetrize(self):
		# print "in WaveFunction->symmetrize:"
		if self.qmvkind()=='super':
			#print "super"
			subs=self.get('subs');
			i=0;
			for sub in subs:
				sub.symmetrize();
				if i==0:
					wf_sym=sub;
					i=i+1;
				else:
					wf_sym=wf_sym.plus(sub);
		elif self.qmvkind()=='stack':
			#wf=self.qmvcopy();
			wf=self;
			wf_stack=wf.get('stack');
			N=len(wf_stack);
			if N==1:
				wf_sym=wf;
			elif N==2:
				# wf_sym=wf_stack[0]*wf_stack[1]-wf_stack[1]*wf_stack[0];
				# wf_sym=wf_sym*0.5**0.5;
				wf_sym1=wf_stack[0]*wf_stack[1]
				wf_sym2=wf_stack[1].qmvtimes(wf_stack[0]);
				wf_sym2.times(-1);
				wf_sym=wf_sym1.plus(wf_sym2);
				wf_sym.times(0.5**0.5);
			else:
				for i in range(N):
					wf=self.qmvcopy();
					wf_stack=wf.get('stack');
					wfleft=wf_stack[i];
					wf_stack.remove(wfleft);
					#wfright=wf.symmetrize();
					wf.symmetrize();
					if i==0:
						wf_sym=wfleft.qmvtimes(wf);
					else:
						wf_sym=wf_sym.plus(wfleft.qmvtimes(wf));
				#wf_sym=wf_sym/N**0.5;
				wf_sym.times(1./N**0.5);
		self.turnsuper();
		self.set('subs',wf_sym.get('subs'));
		return;
		
class Operator(QMVariable):
	def __init__(self):
		QMVariable.__init__(self);
		self.set('coefficient',1);
		self.set('particle_index',0);
		
	def info(self,indent=0):
		print indent*"|_","<Operator>"
		if self.qmvkind()=='base':
			print indent*"|_","particle_index:",self.get('particle_index');
		QMVariable.info(self,indent+1);
		
	def qmvcopy(self,qmv=None):
		if qmv is None:
			qmv=Operator();
			qmv.initqmvkind(self.qmvkind());
		qmv=QMVariable.qmvcopy(self,qmv);
		if self.qmvkind()=='base':
			qmv.set('particle_index',self.get('particle_index'));
		return qmv;
		
	def __mul__(self,multiplier,copyqmv=True):
		# print "in Operator __mul__"
		# print "test value:",multiplier.get('xyzfun')(0,0,1e-10);
		# print "multiplier:"
		# multiplier.info();
		if isinstance(multiplier,WaveFunction):
			product=self.opwfproduct(multiplier);
		else:
			product=QMVariable.__mul__(self,multiplier,copyqmv);
		return product;
		
	#######opwfproduct######
	#the following two methods are to expand the linear combinations of the op, and wf 
	def opwfproduct(self,multiplier):
		# print "in Operator->opwfproduct:"
		# print "test value:",multiplier.get('xyzfun')(0,0,1e-10);
		multi=multiplier.qmvcopy();
		# print "test value after copy:",multi.get('xyzfun')(0,0,1e-10);
		# print multiplier.qmvkind(),multi.qmvkind();
		if self.qmvkind()=="super":
			self_sbvs=self.get('subs');
			i=0;
			for self_sbv in self_sbvs:
				pr=self_sbv.lbasestack_opwfproduct(multi);
				if i==0:
					product=pr;
				else:
					product=product.plus(pr);
				i=i+1;
		else: 
			# print "base stack"
			product=self.lbasestack_opwfproduct(multi);
		return product;
		
	def lbasestack_opwfproduct(self,multiplier):
		# print "in Operator->lbasestack_opwfproduct:"
		# print "test value:",multiplier.get('xyzfun')(0,0,1e-10);
		# print multiplier.qmvkind();
		if multiplier.qmvkind()=="super":
			# print "super"
			mul_sbvs=multiplier.get('subs');
			# print "mul_sbvs:",mul_sbvs
			i=0;
			for sbv in mul_sbvs:
				pr=self.lbasestack_rbasestack_opwfproduct(sbv);
				if i==0:
					product=pr;
				else:
					product=product.plus(pr);
				i=i+1;
		else:
			product=self.lbasestack_rbasestack_opwfproduct(multiplier);
		return product;
		
	def lbasestack_rbasestack_opwfproduct(self,multiplier):
		# print "in Operator->lbasestack_rbasestack_opwfproduct:"
		# print "test value:",multiplier.get('xyzfun')(0,0,1e-10);
		if self.qmvkind()=='stack':
			# print "self stack"
			stack=self.get('stack');
			N=len(stack);
			product=multiplier;
			for i in range(len(stack)):
				item=stack[N-i-1];
				product=item.lbasestack_opwfproduct(product); 
				# this is because after lbase_rbasestack_opwfproduct, product may become super.
		else:
			# print "self base"
			product=self.lbase_rbasestack_opwfproduct(multiplier);
			# this is to avoid copying 
		return product;
		
	def lbase_rbasestack_opwfproduct(self,multiplier):
		# print "in Operator->lbase_rbasestack_opwfproduct:"
		# print "test value:",multiplier.get('xyzfun')(0,0,1e-10); 
		# print multiplier.qmvkind()
		particle_num=self.get('particle_index');
		# print "particle_index:",particle_num
		
		# print "op info:"
		# self.info();
		# print "wf info:"
		# multiplier.info();
		
		new_qmv=multiplier; 
		# this is because multiplier is already a copy made in opwfproduct()
			
		if new_qmv.qmvkind()=='stack': # this is the many body case		
			stack=new_qmv.get('stack');
			s=stack[particle_num];
			s=self.base_opwfproduct(s);
			stack[particle_num]=s;
			# print "s.info"
			# s.info();
			# print "new_qmv info before expandstack2super:"
			# new_qmv.info();
			new_qmv=new_qmv.expandstack2super();
			# print "new_qmv info after expandstack2super:"
			# new_qmv.info();
			product=new_qmv;
		else:
			# base, this is the one particle case
			product=self.base_opwfproduct(new_qmv);
		return product;
		
	def base_opwfproduct(self,multiplier):
		# print "in Operator->base_opwfproduct"
		# The coefficient of the "self" is taken care of here.    
		# The coefficient of the "multiplier" is taken care of in baseopwfmultiply() method in other files.
		# print "test value:",multiplier.get('xyzfun')(0,0,1e-10);
		op_cft=self.get('coefficient');
		#wf_cft=multiplier.get('coefficient');
		product=self.baseopwfmultiply(multiplier);
		product.times(op_cft);
		#pass;
		return product;
		
	
	def matrix_element1(self,bra,ket):
		# print "in Operator->matrix_element"
		wfR=self*ket;
		# print "wfR.info"
		# wfR.info();
		matele=bra.innerproduct(wfR);
		#print bra.qmnumbers(),ket.qmnumbers(),matele
		return matele;
		
	#######matrix_element######
	# the following three methods are to expand the linear combinations of the op, bra and ket
	def matrix_element(self,bra,ket):
		if self.qmvkind()=='super':
			self_subs=self.get('subs');
			mate=0;
			iop=0;
			for self_sub in self_subs:
				# print "iop:",iop
				pr=self_sub.basestack_op_mate(bra,ket);
				mate=mate+pr;
				# print "pr:",pr
				iop=iop+1;
		else:
			mate=self.basestack_op_mate(bra,ket);
		return mate;
	
	def basestack_op_mate(self,bra,ket):
		#print "in Operator->basestack_op_mate"
		if bra.qmvkind()=="super":
			bra_subs=bra.get('subs');
			mate=0;
			i_bra=0;
			for bra_sub in bra_subs:
				# print "  i_bra:",i_bra
				pr=self.basestack_braop_mate(bra_sub,ket);
				mate=mate+pr;
				# print "  pr:",pr;
				i_bra=i_bra+1;
				
		else:
			mate=self.basestack_braop_mate(bra,ket);
		return mate;
		
	def basestack_braop_mate(self,bra,ket):
		if ket.qmvkind()=="super":
			ket_subs=ket.get('subs');
			mate=0;
			i_ket=0;
			for ket_sub in ket_subs:
				# print "    i_ket:",i_ket,
				pr=self.basestack_braopket_mate(bra,ket_sub);
				mate=mate+pr;
				# print "pr:",pr;
				i_ket=i_ket+1;
		else:
			mate=self.basestack_braopket_mate(bra,ket);
		return mate;
	
	def basestack_braopket_mate(self,bra,ket):
	# Here we only treat several cases for op. 
	# The idea is to reduce the case with base wave function if the bra and ket are stack
	# by sorting the bra, ket and op according to particle index.
	# 1) op is many body, but it's qmvkind() is 'base'. 
	# In this case, we overwrite this method in the definition of the operator. 
	# Then the coefficient will be taken care of at that level.
	# 2) op is single particle, its qmvkind() is 'stack'. 
	# This the the case this function treats. 
	# Here, we sort the bra, ket and op according to particle_index then reduce the matrix_element to a product of
	# matrix element of each particles.
		if self.qmvkind()=='stack':
			op_stack=self.get('stack');
		else:
			op_stack=[self];

		if bra.qmvkind()=='stack':
			mate=1.;
			op_list_sorted=[];
			bra_stack=bra.get('stack');
			ket_stack=ket.get('stack');
			for i in range(len(bra_stack)): # first survey the op for each particle_index
				op_list=[];
				for op in op_stack:
					if op.get('particle_index')==i:
						op_list.append(op);
				op_list_sorted.append(op_list);
				
			particle_index=0; 
			for op_list in op_list_sorted:
				# here we treat the mate not involving op first to save some computing time.
				b=bra_stack[particle_index];
				k=ket_stack[particle_index];
				if len(op_list)==0: 
					pr=b.innerproduct(k);
					mate=mate*pr;
				if mate==0:
					break;
				particle_index=particle_index+1;
			if mate!=0:
				particle_index=0; 
				for op_list in op_list_sorted:
				# now we treat the mate involving op only when the mate from above is non-zero.
					b=bra_stack[particle_index];
					k=ket_stack[particle_index];
					if len(op_list)==1:
						op=op_list[0];
						op.set('particle_index',0);
						pr=op.base_braket_base_op_mate(b,k);
						op.set('particle_index',particle_index);
						mate=mate*pr;
					elif len(op_list)>1:
						op=Operator();
						op.turnstack();
						op.set(stack,op_list);
						for op in op_list:
							op.set('particle_index',0);
						pr=op.base_braket_stack_op_mate(b,k);
						for op in op_list:
							op.set('particle_index',particle_index);
						mate=mate*pr;
					if mate==0:
						break;
					particle_index=particle_index+1;
			else:
				#print "pr=0 due to unmatched wf.",
				pass;
		else:
			mate=self.base_braket_basestack_op_mate(bra,ket);
		return mate;
					
	def base_braket_basestack_op_mate(self,bra,ket):
		# If the one-particle operators have op*ket operations, this method works
		# If not, this method needs to be overwritten.
		if self.qmvkind()=='stack':
			mate=self.base_braket_stack_op_mate(bra,ket);
		else:
			mate=self.base_braket_base_op_mate(bra,ket);
		return mate;
		
	def base_braket_stack_op_mate(self,bra,ket):
		return self.base_braket_base_op_mate(bra,ket);
		
	def base_braket_base_op_mate(self,bra,ket):
		# print "op_cft:",self.get('coefficient'),
		# print "bra_cft:",bra.get('coefficient'),
		# print "ket_cft:",ket.get('coefficient'),
		wfR=self*ket;
		# print "wfR_cft:",wfR.get('coefficient');
		mate=bra.innerproduct(wfR);
		# print "op_cft:",self.get('coefficient'),
		# print "bra_cft:",bra.get('coefficient'),
		# print "ket_cft:",ket.get('coefficient'),
		# print "wfR_cft:",wfR.get('coefficient');
		return mate;
		
	#######matrix_rep######
	def matrix_rep(self,wfs):
		from pydao.tools import Progress_Teller;
		if type(wfs) is list:
			N=len(wfs);
			mat=matrix(zeros([N,N]))+0j;
			pt=Progress_Teller((N+1)*N/2,text='matrix_rep: ');
			i_progress=0;
			for i in range(N):
				bra=wfs[i];
				# print "row:",i # ,'[',
				for j in range(N):
					# print j,',',
					ket=wfs[j];
					if j>=i:
						ip=self.matrix_element(bra,ket);
						i_progress=i_progress+1;
						pt.tell(i_progress);
					else:
						ip=conjugate(mat[j,i]);
					#ip=bra.innerproduct(self*ket);
					mat[i,j]=ip
				#	print "ip:",ip
				# print ']'
		return mat;
		
	def measure(self,wf):
		if isinstance(wf,WaveFunction):
			msr=wf.innerproduct(self*wf);
		return msr;
				
