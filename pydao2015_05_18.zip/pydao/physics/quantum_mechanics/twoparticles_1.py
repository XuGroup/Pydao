from pylab import *;
from pydao.ohdf import OGroup,isnumeric;
import pydao.math,copy;
from qmvariable import WaveFunction, Operator;
from oneparticles import OnePWaveFunction_Xyz;

class Base_Xyz2B(OGroup):
	def __init__(self):
		#OGroup.__init__(self);
		self.set2xyz2bzero();
	
	def __call__(self,x,y,z,x1,y1,z1):
		value=1.*x*y*z/x/y/z*x1/x1*y1/y1*z1/z1;
		wfunction=self.get('xyz2bfun');
		if wfunction is not None:
			value=value*wfunction(x,y,z,x1,y1,z1);
		return value;
		
	def xyz2bpara_get(self,name):
		xyz2bparas=self.get('xyz2bparas');
		return xyz2bparas.get(name);
		
	def xyz2bpara_set(self,name,value):
		xyz2bparas=self.get('xyz2bparas');
		xyz2bparas.set(name,value);
		return;
		
	def xyz2bpara_keys(self):
		xyz2bparas=self.get('xyz2bparas');
		return xyz2bparas.keys();
		
	def set2xyz2bzero(self):
		self.set('xyz2bfun',0);
		self.set('xyz2bparas',OGroup());
		
	def qmvcopy(self,qmv=None):
		if qmv is None:
			qmv=Base_Xyz();
		qmv.set('xyz2bfun',self.get('xyz2bfun'));
		return qmv;
		
	def info(self,indent=0):
		print indent*"|_","<Base_Xyz2B>"
		print indent*"|_",
		if self.qmvkind()=='base':
			print "xyz2b function:",self.get('xyz2bfun')
		
	def basemultiply_xyz2b(self,multiplier):
		#print "in Base_Xyz multiply"
		self_fun=self.get('xyz2bfun');
		multiplier_fun=multiplier.get('xyz2bfun');
		new_fun=lambda x,y,z,x1,y1,z1:self_fun(x,y,z)*multiplier_fun(x,y,z);
		
		new_funobj=multiplier.qmvcopy();
		new_funobj.turnbase();
		new_funobj.set('xyz2bfun',new_fun);
		#print "new_funobj before invalidate:"
		#new_funobj.info();
		if isinstance(multiplier,Base_Sym):
			new_funobj.invalidatesym();
		#new_funobj.function_modified();
		#print "new_funobj after invalidate:"
		#new_funobj.info();
		return new_funobj;

	def baseiproduct_xyz2b(self,wf):
		if isinstance(wf,Base_Xyz2B):
			r_max=self.rrange();
			xmin=-r_max;
			xmax=r_max;
			ymin=-r_max;
			ymax=r_max;
			zmin=-r_max;
			zmax=r_max;
			Np=self.xyz2bpara_get('Np');
			if Np is None:
				Np=12;
			dx=1.*(xmax-xmin)/(Np-1);
			dy=1.*(ymax-ymin)/(Np-1);
			dz=1.*(zmax-zmin)/(Np-1);
			x,y,z,x1,y1,z1= mgrid[xmin:xmax:Np*1j,ymin:ymax:Np*1j,zmin:zmax:Np*1j,\
			xmin:xmax:Np*1j,ymin:ymax:Np*1j,zmin:zmax:Np*1j];
			self_fun=self.get('xyz2bfun');
			wf_fun=wf.get('xyz2bfun');
			product=(self_fun(x,y,z,x1,y1,z1)*conjugate(wf_fun(x,y,z,x1,y1,z1))).sum()*(dx*dy*dz)**2;
		return product;
		
	def baserpeak(self):
		return 1;
		
	def baserspread(self):
		return 1;
		
	def rrange(self):
		return self.rpeak()+2.*self.rspread();

class MBOperator(Operator,Base_Xyz2B):
	def __init__(self):
		Operator.__init__(self);
		Base_Xyz2B.__init__(self);
		self.set('coefficient',1);
		self.set('particle_list',[0]);
		
	def matrix_element(self,bra,ket):
		if self.qmvkind()=='super':
			self_subs=self.get('subs');
			mate=0;
			for self_sub in self_subs:
				mate=mate+self_sub.basestackop_mate(bra,bet);
		else:
			mate=self.basestackop_mate(bra,ket);
		return mate;
		
	def basestackop_mate(self,bra,ket):
		if bra.qmvkind()=="super":
			bra_subs=bra.get('subs');
			mate=0;
			for bra_sub in bra_subs:
				mate=mate+self.basestackopbra_mate(bra_sub,ket);
		else:
			mate=self.basestackopbra_mate(bra,ket);
		return mate;
		
	def basestackopbra_mate(self,bra,ket):
		if ket.qmvkind()=="super":
			ket_subs=ket.get('subs');
			mate=0;
			for ket_sub in ket_subs:
				mate=mate+self.basestackopbraket_mate(bra,ket_sub);
		else:
			mate=self.basestackopbraket_mate(bra,ket);
		return mate;
		
	def basestackopbraket_mate(self,bra,ket,Np=None):
		plist=self.get('particle_list');
		if len(plist)==1:
			mate=Operator.matrix_element(self,bra,ket);
		else:
			bra_stack=bra.get('stack');
			ket_stack=ket.get('stack');
			bra0=bra0;
			bra0=bra1;
			bra0=ket0;
			bra0=ket1;
			bra_fun0=bra0.get('xyzfun');
			bra_fun1=bra1.get('xyzfun');
			ket_fun0=ket0.get('xyzfun');
			ket_fun1=ket1.get('xyzfun');
			bra_2bfun=lambda x,y,z,x1,y1,z1: bra_fun0(x,y,z)*bra_fun1(x1,y1,z1);
			ket_2bfun=lambda x,y,z,x1,y1,z1: ket_fun0(x,y,z)*ket_fun1(x1,y1,z1);
			op_2bfun=self.get('xyz2bfun')
			
			r_peak=max([bra0.rpeak(),bra1.rpeak(),ket0.rpeak(),ket1.rpeak()]);
			r_sigma=max([bra0.rspread(),bra1.rspread(),ket0.rspread(),ket1.rspread()]);
			r_max=r_peak+2*r_sigma;
			
			xmin=-r_max;
			xmax=r_max;
			ymin=-r_max;
			ymax=r_max;
			zmin=-r_max;
			zmax=r_max;
			if Np is None:
				Np=12;
			dx=1.*(xmax-xmin)/(Np-1);
			dy=1.*(ymax-ymin)/(Np-1);
			dz=1.*(zmax-zmin)/(Np-1);
			x,y,z,x1,y1,z1= mgrid[xmin:xmax:Np*1j,ymin:ymax:Np*1j,zmin:zmax:Np*1j,\
			xmin:xmax:Np*1j,ymin:ymax:Np*1j,zmin:zmax:Np*1j];

			mate=(bra_2bfun(x,y,z,x1,y1,z1)*conjugate(op_2bfun(x,y,z,x1,y1,z1)*ket_2bfun(x,y,z,x1,y1,z1))).sum()*(dx*dy*dz)**2;		
		return mate;
		
	def qmvcopy(self,qmv=None):
		if qmv is None:
			qmv=MBOperator();
		qmv.set('particle_list',self.get('particle_list'));
		return qmv;
	
class WaveFunction_Xyz2B(WaveFunction,Base_Xyz2B):
	def __init__(self):
		WaveFunction.__init__(self);
		Base_Xyz2B.__init__(self);
		self.set('coefficient',1);
		self.set('particle_list',[0]);
		
	def set2zero(self):
		self.set2qmvzero();
		self.set2xyz2bzero();
		return;

	def __call__(self,x,y,z,x1,y1,z1):
		wf_subs=self.get('subs');
		coefficient=self.get('coefficient');
		if self.qmvkind()=='base':
			value=Base_Xyz2B.__call__(self,x,y,z,x1,y1,z1);
			value=value*coefficient;
		else:
			value=0;
			for wf in wf_subs:
				value=value+wf(x,y,z,x1,y1,z1);
		return value;
		
	def info(self,indent=0):
		print indent*"|_","<WaveFunction_Xyz2B>"
		WaveFunction.info(self,indent+1);
		if self.qmvkind()=='base':
			Base_Xyz2B.info(self,indent+1);
		
	def baseinnerproduct(self,wf):
		self_cft=self.get('coefficient');
		wf_cft=wf.get('coefficient');
		product=self.baseiproduct_xyz(wf)*self_cft*wf_cft;
		return product;
	
	def qmvcopy(self,qmv=None):
		if qmv is None:
			qmv=WaveFunction_Xyz2B();
			qmv.initqmvkind(self.qmvkind());
		qmv=WaveFunction.qmvcopy(self,qmv);
		if self.qmvkind()=='base':
			qmv=Base_Xyz2B.qmvcopy(self,qmv);
		return qmv;

class Operator_Xyz2B(Operator,Base_Xyz2B):
	def __init__(self):
		Operator.__init__(self);
		Base_Xyz2B.__init__(self);
		self.set('coefficient',1);
		self.set('particle_list',[0]);
	
	def info(self,indent):
		print indent*"|_","<Operator_Xyz2B>"
		Operator.info(self,indent+1);
		Base_Xyz2B.info(self,indent+1);
	
	def baseopwfmultiply(self,multiplier):
		if isinstance(multiplier,OnePWaveFunction_Xyz):
			product=WaveFunction_Xyz2B();
			
		
		return self.basemultiply_xyz(multiplier);
		
	def qmvcopy(self,qmv=None):
		if qmv is None:
			qmv=Operator_Xyz2B();
			qmv.initqmvkind(self.qmvkind());
		qmv=Operator.qmvcopy(self,qmv);
		if self.qmvkind()=='base':
			qmv=Base_Xyz2B.qmvcopy(self,qmv);
		return qmv;
