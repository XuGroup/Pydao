from Heisenberg_model import *;

from pylab import *;
def Langevin(x):
	return 1/tanh(x)-1/x;
	
def inv_Langevin(y):
	x=0;
	xlow=0;
	xhigh=1e100;
	eps=1e-10;
	x=(xlow+xhigh)/2;
	yL=Langevin(x);
	if y<1 and y>0:
		while abs(yL-y)>eps:
			if yL>y:
				xhigh=x;
			else:
				xlow=x;
			x=(xlow+xhigh)/2;
			yL=Langevin(x);
	else:
		x=-1;
	return x;