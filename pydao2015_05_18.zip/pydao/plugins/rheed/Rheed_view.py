from pylab import *;
from  pydao.ohdfvi import Application;
from  pydao.ohdf import OGroup;

def rheed_analysis_view(app):
	from Rheed_controls import RHEED_ModelView;
	from enthought.traits.ui.api import \
	Item,Group,Tabbed,VGroup,HGroup,View,\
	ArrayEditor,ButtonEditor,CheckListEditor,BooleanEditor;
	
	handler=RHEED_ModelView(app);
	
	app.i_polar=1;
	group_cal=VGroup(\
	Item('i_polar',show_label=True),\
	Item('bu_rotate_kspace',editor=ButtonEditor(label='rotate_kspace')),\
	Item('bu_cal_list_theta_phi',editor=ButtonEditor(label='cal_list_theta_phi')),\
	Item('bu_cal_cal_list_theta_phi_island',editor=ButtonEditor(label='cal_list_theta_phi_island')),\
		#Item('bu_cal_spectrum',editor=ButtonEditor(label='spectrum')),\
	show_labels=False,show_border = True,label='Analysis');
		
	editor1=CheckListEditor(values=app.keys());
	app.color=zeros(3);
	app.mode_index=3;
	app.k_index=0;
	app.atom_displacement_factor=50;
	app.center_of_mass_displacement_factor=1;
	app.i_polar=1;
	app.new_figure=True;
	group_view=VGroup(\
	Item('k_index',show_label=True),\
	Item('bu_plot3d_rheed',editor=ButtonEditor(label='plot3d_rheed')),\
	Item('i_polar',show_label=True),\
	Item('bu_plot3d_rheed_island',editor=ButtonEditor(label='plot3d_rheed_island')),\
	Item('mode_index',show_label=True),\
	Item('color',show_label=True,editor=ArrayEditor()),\
	Item('atom_displacement_factor',show_label=True),\
	Item('center_of_mass_displacement_factor',show_label=True),\
	Item('bu_plot_mode',editor=ButtonEditor(label='plot_mode')),\
	Item('bu_plot_spectrum',editor=ButtonEditor(label='plot_spectrum')),\
	Item('bu_plot_primitive_cell',editor=ButtonEditor(label='plot_primitive_cell')),\
	Item('new_figure',editor=BooleanEditor(),show_label=True),\
	show_labels=False,show_border = True,label='View');
	
	view=View(Tabbed(group_cal,group_view),handler=handler,kind='live',\
	title=app.string()+'OnAnalysis');
	#app.configure_traits(view=view);
	return view;