from pylab import *;
from pylab import *;
from pydao.ohdf import OGroup;

from scipy.optimize import fmin;


class XMXD_File(OGroup):
	def __init__(self,filename=None,):
		OGroup.__init__(self);
		self.set('filename',filename);
		self.set('mat',None);
		self.set('i_col',None);
		
	def load(self):
		success=0;
		if self.get('filename') is not None:
			try:
				mat=loadtxt(self.get('filename'));
				self.set('mat',mat);
				success=1;
			except:
				print "failed to load file:",self.get('filename');
		if success:
			SampleT=self.getfromheader('# Extra PV 96: 4idc1:LS340:TC2:Sample, 7T T sample, "(\d+(\.\d*)?|\.\d+)",',"pattern",1);
			self.set('SampleT',SampleT);
			SampleB=self.getfromheader('# Extra PV 100: 4idc2:AMI430:Field, 7T field \(T\), "([-+]?(\d+(\.\d*)?|\.\d+)([eE][-+]?\d+)?)",',"pattern",1); 
			self.set('SampleB',SampleB);
			#print SampleT,SampleB;
		return success;
	
	def getfromheader(self,condition,method="pattern",npattern=None):
		resultstr=None;
		f=open(self.get('filename'),"rU");
		flist=list(f);
		f.close();	
		if method=="pattern":
			import re;
			for line in flist:
				g=re.search(condition,line);
				try: 	
					resultstr=g.group(npattern);
					break;
				except:
					pass;
		elif method=="lineNo":
			if len(flist)>condition:
				resultstr=flist[condition];
			else:
				resultstr="";
		elif method=="tokenline":
			import string;
			foundtoken=False;
			for line in flist:
				#print line,condition
				if foundtoken:
					resultstr=line;
					break;
				if string.strip(line)==condition:
					foundtoken=True;
					#print "foundtoken"
		else:
			print "wrong method:",method
		if isinstance(resultstr,str):
			resultstr=resultstr.replace("\n",'');
		return resultstr;
	
	#def get_property(self,prptname):	
		
	def get_col(self,i_col):
		self.i_col=i_col;
		return mat[:,col];

class XMXD_FileSet(OGroup):
	def __init__(self,dirname=None,filename0=None,filenamelist=None):
		OGroup.__init__(self);
		self.dirname=dirname;
		self.filename0=filename0;
		self.filenamelist=filenamelist;
		self.xmxdfile_list=[];
		
	def load_files(self):
		import os;
		for fname in filenamelist:
			fullname=os.path.join(self.dirname,self.filename0,fname);
			xmdfile=XMXD_File(fullname);
			self.xmxdfile_list.append(xmdfile);
