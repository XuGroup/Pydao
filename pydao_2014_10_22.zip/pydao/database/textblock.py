from pylab import *;
from pydao.ohdf import OGroup;
from pydao.ohdf import sscan;

class TextBlock(OGroup):
	def __init__(self,textcontent=None):
		OGroup.__init__(self);
		self.set('textcontent',textcontent);
		self.set('stopstr',None);
		self.set('blockstr','loop_');
		self.set('comment_char',None);
		
	def find_pattern1(self,condition,method="pattern",npattern=None):
		resultstr=None;
		flist=self.get('textcontent');
		#print "len(f)",len(flist)
		#print "method:",method
		if method=="pattern":
			import re;
			for line in flist:
				g=re.search(condition,line);
				try: 	
					resultstr=g.group(npattern);
					break;
				except:
					pass;
		elif method=="lineNo":
			if len(flist)>condition:
				resultstr=flist[condition];
			else:
				resultstr="";
		elif method=="tokenline":
			import string;
			foundtoken=False;
			for line in flist:
				#print line,condition
				if foundtoken:
					resultstr=line;
					break;
				if string.strip(line)==condition:
					foundtoken=True;
					#print "foundtoken"
		else:
			print "wrong method:",method
		if isinstance(resultstr,str):
			resultstr=resultstr.replace("\n",'');
		return resultstr;
		
	def find_pattern(self,pattern):
		resultstr=None;
		flist=self.get('textcontent');
		#print "len(f)",len(flist)
		#print "method:",method
		for line in flist:
			resultvalues=sscan(line,pattern);
			if len(resultvalues)==pattern.count("%"):
				break;
		return resultvalues;
	
	def is_blockhead(self,line,blockstr="loop_",wholeword=True):
		isheader = False;
		stripline = line.strip();
		if wholeword:
			fields = stripline.split();
			if len(fields)>0:
				if fields[0]==blockstr:
					isheader = True;
		else:
			if stripline.startswith(blockstr):
				isheader = True;
		# if isheader:
			# print "blockstr:",blockstr,"wholeword:",wholeword,isheader
		if self.is_commentline(line):
			isheader = False;
		return isheader;
		
	def is_stopline(self,line):
		isend = False;
		stopstr = self.get('stopstr');
		stripline = line.strip();
		if stopstr is None:
			isend = False;
		elif stripline.startswith(stopstr):
			isend = True;
		if self.is_commentline(line):
			isend = False;
		return isend;
		
	def is_commentline(self,line):
		iscomment = False;
		comment_char = self.get('comment_char');
		if comment_char is not None:
			stripline = line.strip();
			if stripline.startswith(comment_char):
				iscomment = True;
		return iscomment;
		
	def n_blocks(self,blockstr="loop_",wholeword=True):
		fstr=self.get('textcontent');
		nblock=0;
		for line in fstr:
			stripline = line.strip();
			if self.is_blockhead(stripline,blockstr,wholeword):
				nblock=nblock+1;
		# self.set('nblock',nblock);
		return nblock;
		
	def get_nblocks(self,blockstr="loop_",wholeword=True):
		# nblocks=self.get('nblocks');
		nblocks = None;
		if nblocks is None:
			nblocks=self.n_blocks(blockstr,wholeword);
		return nblocks;
	
	def get_block_sequence_all(self,blockstr="loop_",wholeword=True):
		textcontent=self.get('textcontent');
		block_sequence=[];
		block_content=[];
		nblock=0;
		for line in textcontent:
			line1=line.strip();
			fields=line1.split();
			#print "fields:",fields
			if self.is_stopline(line1):
				break;
			if len(fields)>0:
				#print fields[0],":",blockstr
				if self.is_blockhead(line1,blockstr,wholeword):
				# if fields[0]==blockstr:
					nblock=nblock+1;
					# print "find block:",line,"nblock:",nblock
					if len(block_content)>0:
						# if block_content is not empty, we save it as a block
						blk=TextBlock(block_content);
						block_sequence.append(blk);
						block_content=[];
						# print "2nd or later block"
					else:
						# print "first block."
						pass;
				if nblock>0:
					#if it is in a block, we record the line;
					block_content.append(line1);
		if len(block_content)>0:
			# print "last block len:",len(block_content),"n_seq:",len(block_sequence);
			blk=TextBlock(block_content);
			block_sequence.append(blk);
		# self.set('block_sequence',block_sequence);
		# print "nblock:",nblock,"len(block_sequence):",len(block_sequence)
		return block_sequence;
		
	def get_block_sequence(self,ilist=None,blockstr="loop_",wholeword=True):
		if ilist is None:
			nblocks=self.get_nblocks(blockstr,wholeword);
			ilist=range(nblocks);
		block_sequence=range(len(ilist));
		block_sequence_all=self.get('block_sequence');
		# print "ilist:",ilist
		if block_sequence_all is None:
			block_sequence_all=self.get_block_sequence_all(blockstr,wholeword);
		# print "len(block_sequence_all):",len(block_sequence_all)
		i=0;
		for iblock in ilist:
			# print "i:",i,"iblock:",iblock,"len(ilist):",len(ilist),"len(block_sequence)",len(block_sequence)
			block_sequence[i]=block_sequence_all[iblock];
			i=i+1;
			# print "i:",i,"i+1:",i+1
		return block_sequence;
		
	def get_block(self,iblock=1,blockstr="loop_",wholeword=True):
		block_sequence=self.get_block_sequence([iblock],blockstr,wholeword);
		return block_sequence[0];
		
	def insert_line(self,irow,textline):
		textcontent=self.get('textcontent');
		textcontent.insert(irow,textline);
		self.set('textcontent',textcontent);
		return textcontent;
		
	def append_line(self,textline):
		textcontent=self.get('textcontent');
		textcontent.append(textline);
		self.set('textcontent',textcontent);
		return textcontent;
		
	def get_nlines(self):
		textcontent=self.get('textcontent');
		return len(textcontent);
		
	def remove_line(self,startstr='\\'):
		textcontent=self.get('textcontent');
		textcontentnew=[];
		for line in textcontent:
			if not line.startswith(startstr):
				textcontentnew.append(line);
		self.set('textcontent',textcontentnew);
		return textcontentnew;
				
	def get_segment(self,blockstr,stopstr):
		nb = self.get_nblocks(blockstr,wholeword=False);
		print "blockstr:",blockstr
		print "stopstr:",stopstr
		print "nb:",nb
	
		self.set('stopstr',stopstr)
		segment = self.get_block_sequence(blockstr=blockstr,wholeword=False)[0];
		return segment;