from pylab import *;
from pydao.tools import tif2array,int_filter,array2bmp;
from scipy.signal import convolve;

from scipy.optimize import fmin;
from pydao.database import Relation_Table;
from nummatrixcsv import NumMatrixCSV;
from pydao.ohdf import sscan;

class BNL_NSLS_UPS_DataFile(NumMatrixCSV):
	def __init__(self,filename=None, Ndim=None,shape=None,dilimiter='\t'):
		NumMatrixCSV.__init__(self,filename=filename,dilimiter=dilimiter,row_width_chosen=None);
		photonenergy = 0;
		workfunction = 0;
	
	def analyze(self):
		self.convertcsv();
		data = self.get('num_matrix');
		data = data[:,1:];
		self.set('data',data);
		
		strs = self.find_pattern('Dimension 1 scale=%\n')
		xstr = strs[0].replace(' ',',');
		x = eval('['+xstr+']');
		x = array(x);
		
		strs = self.find_pattern('Dimension 2 scale=%\n')
		ystr = strs[0].replace(' ',',');
		y = eval('['+ystr+']');
		y = array(y);
		
		self.set('energy',x);
		self.set('angle',y);
		print data.shape,x.shape, y.shape
		
		filename = self.get('filename');
		IE = data.sum(1); # integrate to get the energy dependence only
		Efilename = filename.replace('.txt','_energy.txt')
		savetxt(Efilename,transpose(vstack((x,IE))));
		
		IA = data.sum(0); # integrate to get the angular dependence only
		Afilename = filename.replace('.txt','_angle.txt');
		# plot(y,'o');show();
		savetxt(Afilename,transpose(vstack((y,IA))));
		
		return;
		
	def plot_sum(self,pstyle='b'):
		photonenergy = self.get('photonenergy');
		workfunction = self.get('workfunction');
		energy = array(self.get('energy'))-photonenergy+workfunction;
		plot(energy,self.get('num_matrix').sum(1),pstyle);
		return;