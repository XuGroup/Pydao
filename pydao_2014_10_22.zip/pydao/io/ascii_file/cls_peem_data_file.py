from pylab import *;
from pydao.tools import tif2array,int_filter,array2bmp;
from scipy.signal import convolve;

from scipy.optimize import fmin;
from pydao.database import Relation_Table;
from nummatrixcsv import NumMatrixCSV;

def getloxfile(dirname,ilox,stack=None):
	import os;
	if stack:
		lox=os.path.join(dirname,ilox,ilox);
	else:
		lox=os.path.join(dirname,ilox);
	return lox;

class CLS_LOX(NumMatrixCSV):
	def __init__(self,filename=None, Ndim=None,shape=None,dilimiter='\t'):
		if not filename.endswith('.lox'):
			loxfilename=filename+'.lox';
		NumMatrixCSV.__init__(self,filename=loxfilename,dilimiter=dilimiter,row_width_chosen=None);
	
	def analyze(self,istart=None,iend=None,isep=None):
		loxtype=self.find_pattern('%<loxheader type="%"%');
		loxtype=loxtype[1];
		print "loxtype:",loxtype
		if loxtype =="image":
			img=self.analyze_img();
		elif loxtype == "spectra":
			img=self.analyze_spectra(istart,iend,isep);
		elif loxtype == "stack":
			img=self.analyze_stack(istart,iend,isep);
			print "Nrow=",img.get_Nrow();
		return img;
		
	def analyze_img(self):
		filename=self.get('filename');
		tif_filename=filename.replace('.lox','.tif');
		img=ImgArray(tif_filename);
		img.set('filecontent',self.get('filecontent'));
		img.set('T',self.get_T());
		img.set('Energy',self.get_energy());
		img.set('ilox',self.get_ilox());
		return img;
		
	def analyze_spectra(self,istart=None,iend=None,isep=None):
		import os;
		img_dbase=Relation_Table();
		if istart is None:
			istart=1;
		if iend is None:
			iend=1e10;
		i=istart;
		pa=self.find_pattern('%point index="'+str(i)+'" Time(s)="%"%');
		while len(pa)>0 and i<iend:
			# print "pa:",pa
			filename=self.get('filename');
			filename=filename.replace('.lox','');
			tif_filename=filename+"#"+str(i)+'.tif';
			img=ImgArray(tif_filename);
			img.set('T',self.get_T());
			img.set('Energy',self.get_energy());
			img.set('ilox',self.get_ilox());
			img.set('iscan',i);
			img_dbase.append(pa[1]);
			img.set('Time',time);
			# print i,pa[1];
			i=i+1;
			pa=self.find_pattern('%point index="'+str(i)+'" Energy(eV)="%"%');
			# print pa
		return img_dbase;
		
		
	def analyze_stack(self,istart=None,iend=None,isep=None):
		import os;
		from pydao.ohdf import natural_name;
		img_dbase=Relation_Table();
		if istart is None:
			istart=1;
		if iend is None:
			iend=1e10;
		if isep is None:
			isep=1;
		i=istart;
		# <point index="1" Time(s)="1.796" dwell="1000" averaging="1" />
		# <point index="1" Energy(eV)="700.004" dwell="1000" averaging="8" />
		pa=self.find_pattern('%<point index="'+str(i)+'" %="%" dwell="%" averaging="%" /%');
		# print "pa:",pa,len(pa)
		while len(pa)>2 and i<iend:
			# print i,len(pa)
			# print "\t",pa;
			scan_varname =  pa[1];
			scan_varvalue = pa[2];
			scan_varname = natural_name(scan_varname);
			# print "pa:",pa
			filename=self.get('filename');
			filename=filename.replace('.lox','');
			tif_filename=filename+"#"+str(i)+'.tif';
			img=ImgArray(tif_filename);
			img.set('T',self.get_T());
			img.set(scan_varname,scan_varvalue);
			img.set('ilox',self.get_ilox());
			img.set('iscan',i);
			img.set('Energy',self.get_energy());
			img.set('RingCurrent',self.get_RingCurrent());
			img_dbase.append(img);
			i=i+isep;
			pa=self.find_pattern('%<point index="'+str(i)+'" %="%" dwell="%" averaging="%" /%');
			# print pa
		return img_dbase;
		
	def get_ilox(self):
		import os;
		filename=self.get('filename');
		# print filename
		fs=os.path.split(filename);
		# print fs
		ilox=fs[1];
		return ilox;
		
	def get_energy(self):
		E=self.find_pattern("%Energy	%");
		# print "E:",E
		self.set('Energy',E[1]);
		return E[1];
		
	def get_T(self):
		T=self.find_pattern("%Sample Temp.	%");
		self.set('T',T[1]);
		return T[1];
		
	def get_RingCurrent(self):
		rc=self.find_pattern("%RingCurrent	%");
		self.set('RingCurrent',rc);
		return rc;	


class Lox_Stack(Relation_Table):
	def __init__(self,dirname=None,ilox=None):
		Relation_Table.__init__(self,rows=None,idname=None);
		if dirname is not None and ilox is not None:
			self.setfile(dirname,ilox);
			
	def setfile(self,dirname,ilox):
		loxfile=getloxfile(dirname,ilox,stack=True);
		self.set('dirname',dirname);
		self.set('ilox',ilox);
		self.set('filename',loxfile);
		return loxfile;
	
	def read_img_seq(self,dirname,ilox_start,ilox_end):
		for ilox in range(ilox_start,ilox_end+1):
			loxfile = getloxfile(dirname,str(ilox));
			# print "loxfile:",loxfile
			lox = CLS_LOX(loxfile);
			img = lox.analyze();
			self.append(img);
		return;
	
	def read_imgs(self,isep=1,dirname=None,ilox=None):
		if dirname is not None and ilox is not None:
			self.setfile(dirname,ilox);
		loxfile=self.get('filename');
		
		lox=CLS_LOX(loxfile);
		img_dbase=lox.analyze(isep=isep);
		for k in img_dbase.keys():
			self.set(k,img_dbase.get(k));
		return;
			
	def light_intensity_normalization(self,pre_energy,post_energy=None,method='preedge'):
		if method == "preedge" or method == "slope":
			pre_dbase=self.select('Energy_eV_<pre_energy',['pre_energy'],[pre_energy]);
			pre=pre_dbase.avg();
			pre=pre.get('img_array');
			print "mean(pre)",pre.mean();
		
		if method == "slope":
			post_dbase=self.select('Energy_eV_>post_energy',['post_energy'],[post_energy]);
			post=post_dbase.avg();
			post=post.get('img_array');
			print "mean(post)",post.mean();
		
		if method == "slope":
			DE=post_energy-pre_energy;
			self.exe('_row.set("img_array",img_array/(pre+(Energy_eV_-pre_energy)/DE*(post-pre)))',['pre','post','pre_energy','DE'],[pre,post,pre_energy,DE]);
		elif method == "preedge":
			self.update_para('img_array','img_array/pre',['pre'],[pre]);
		elif method == "external":
			external_row = pre_energy;
			imgext = external_row.get('img_array');
			self.update_para('img_array','img_array/imgext',['imgext'],[imgext]);
		
		return;
		
	def linear_background_subtract(self,pre_energy,post_energy=None,method="preedge"):
		if method == "slope" or method == "preedge":
			pre_dbase=self.select('Energy_eV_<pre_energy',['pre_energy'],[pre_energy]);
			pre=pre_dbase.avg();
			pre=pre.get('img_array');
			print "mean(pre)",pre.mean();
	
		if method == "slope":
			post_dbase=self.select('Energy_eV_>post_energy',['post_energy'],[post_energy]);
			post=post_dbase.avg();
			post=post.get('img_array');
			print "mean(post)",post.mean();
			
		if method == "preedge":
			self.exe('_row.set("img_array",img_array-pre)',['pre'],[pre]);
		elif method == "slope":
			self.exe('_row.set("img_array",img_array-(pre+(post-pre)*(Energy_eV_-pre_energy)/DE))',['pre','post','pre_energy','DE'],[pre,post,pre_energy,DE]);
		elif method == "external":
			pre = pre_energy.get('img_array');
			self.exe('_row.set("img_array",img_array-pre)',['pre'],[pre]);
		return;
	
	def constant_sum_normalize(self,loxstack):
		a1=self.roi_mean().sum();
		a2=loxstack.roi_mean().sum();
		self.update('img_array','img_array/a1*a2',['a1','a2'],[a1,a2]);
		return a1,a2;
		
	def roi_mean(self,roi=None):
		if roi is None:
			self.update('_temp','_row.mean()');
		else:
			self.update_para('_temp','_row.get_region_of_interest(roi).mean()',['roi'],[roi]);
		roi=self.get_col('_temp');
		return array(roi);
		
	def save_img(self):
		from PIL import Image;
		from pydao.tools import Progress_Teller;
		N=self.get_Nrow();
		pt=Progress_Teller(N)
		ilox=self.get('ilox');
		rows = self.get('rows')
		for i in range(N):
			pt.tell(i);
			img = rows[i];
			iscan = img.get('iscan');
			filename = ilox+"#"+str(iscan)+"_"+str(i)+'.bmp';
			img_array = img.get('img_array');
			imarr = img_array*128;
			array2bmp(imarr,filename);
			# im = Image.fromarray(img_array)
			# im.save(filename);
		return;
		
	def save_diff(self,loxstack):
		from pydao.tools import Progress_Teller;
		N=self.get_Nrow();
		pt=Progress_Teller(N)
		ilox=self.get('ilox');
		ilox1=loxstack.get('ilox');
		for i in range(N):
			pt.tell(i);
			cw=self.get('rows')[i];
			ccw=loxstack.get('rows')[i];
			iscan=cw.get('iscan');
			iscan1=ccw.get('iscan');
			dif=cw-ccw;
			dif=((cw-ccw)+1)*2**7;
			filename = ilox+'-'+str(ilox1)+'#'+str(iscan)+"_"+str(i)+'.bmp';
			# print "filename:",filename
			dif.savebmp(filename);
		return;

	def compare_roi(self,loxstack,varname,roi=None,disp=True):
		# print "in compare_roi:"
		# print "varname:",varname
		Energy = array(self.get_col(varname));
		# print "Energy:", Energy
		roi_cw = self.roi_mean(roi);
		roi_ccw = loxstack.roi_mean(roi);
		dif_roi = array(roi_cw)-array(roi_ccw);
		if disp:
			plot(Energy,roi_cw);
			plot(Energy,roi_ccw,'r');
			plot(Energy,dif_roi);
			plot(Energy,Energy-Energy);
			axis('tight')
			title(str(roi));
		return Energy,roi_cw,roi_ccw,dif_roi;
	
class ImgArray(NumMatrixCSV):
	def __init__(self,filename=None,dilimiter='\t',row_width_chosen=None):
		NumMatrixCSV.__init__(self,filename=filename,dilimiter=dilimiter,row_width_chosen=None);
		self.set('filename',filename);
		# print "filename in ASCIIFile:",filename
		if filename is not None:
			self.read_file_to_mem();
		
	def read_file_to_mem(self,filename=None):
		success=True;
		if filename is None:
			filename=self.get('filename');
		if filename is None:
				print ".read_file_to_mem failed, filename is None!"
				success=False;
		else:
			self.set('filename',filename);
			img_array=tif2array(filename);
			self.set('img_array',img_array);
		return success;
	
	def savebmp(self,filename=None,renormalize=False):
		from pydao.tools import array2bmp;
		if filename is None:
			filename=self.get('filename');
		# print "savebmp filename:",filename
		filename=filename.replace('tif','bmp');
		if not filename.endswith('bmp'):
			filename=filename+'.bmp';
		img_array=self.get('img_array');
		# print "saving bmp to:",filename
		array2bmp(img_array,filename,renormalize=renormalize);
		return;
		
	def savepng(self,filename=None,renormalize=False):
		from matplotlib import image as im;
		from PIL import Image;
		if filename is None:
			filename=self.get('filename');
			filename=filename.replace('tif','png');
		if not filename.endswith('png'):
			filename=filename+'.png';
		
		# print "filename:",filename
		img_array = self.get('img_array');
		N,M = img_array.shape
		im = Image.new('P', (M,N));
		im.putdata(transpose(img_array).reshape(-1));
		im.save(filename);
		return;
	
	def readpng(self,filename):
		from matplotlib import image as im;
		if filename is None:
			filename=self.get('filename');
		# print "savebmp filename:",filename
		filename=filename.replace('tif','png');
		if not filename.endswith('png'):
			filename = filename+'.png';
		img_array = im.imread(filename);
		self.set('img_array',img_array);
		
	
	def savetxt(self,filename=None):
		if filename is None:
			filename=self.get('filename');
		# print "savebmp filename:",filename
		filename=filename.replace('tif','txt');
		if not filename.endswith('txt'):
			filename=filename+'.txt';
		img_array=self.get('img_array');
		# print "img_array shape:",img_array.shape
		# print "txt filename:",filename
		savetxt(filename,img_array,"%5.2g");
			
	def scale(self,power):
		import copy;
		img_array=self.get('img_array');
		img_array=copy.copy(img_array);
		I=img_array>0;
		img_array[I]=img_array[I]**power;
		I=img_array<0;
		img_array[I]=-(-img_array[I])**power;
		
		new_mimg=ImgArray();	
		new_mimg.set('img_array',img_array);
		return new_mimg;
		

	def gsmooth(self,sigma):
		from pydao.tools import gauss_smooth;
		img_array=self.get('img_array');
		img_array_smooth=gauss_smooth(img_array,sigma);
		new_mimg=ImgArray();	
		new_mimg.set('img_array',img_array_smooth);
		return new_mimg;
		
	def set_roi(self,roi):
		self.set('roi',roi);
		return;
		
	def get_region_of_interest(self,roi):
		xmin,xmax,ymin,ymax=roi;
		
		img_array=self.get('img_array');
		N,M=img_array.shape;
	
		x1s=arange(N);
		y1s=arange(M);
	
		Ix=logical_and(x1s>=xmin, x1s<=xmax);
		Iy=logical_and(y1s>=ymin, y1s<=ymax);
	
		x1s_in_roi_min=min(x1s[Ix]);
		x1s_in_roi_max=max(x1s[Ix]);
		y1s_in_roi_min=min(y1s[Iy]);
		y1s_in_roi_max=max(y1s[Iy]);
	
		roi_array=img_array[x1s_in_roi_min:x1s_in_roi_max+1,y1s_in_roi_min:y1s_in_roi_max+1];

		return roi_array;
		
	def get_roi_img(self,roi=None):
		if roi is None:
			roi=self.get('roi');
		xmin,xmax,ymin,ymax=roi;
		
		img_array=self.get('img_array');
		N,M=img_array.shape;
	
		x1s=arange(N);
		y1s=arange(M);
	
		Ix=logical_and(x1s>=xmin, x1s<=xmax);
		Iy=logical_and(y1s>=ymin, y1s<=ymax);
	
		x1s_in_roi_min=min(x1s[Ix]);
		x1s_in_roi_max=max(x1s[Ix]);
		y1s_in_roi_min=min(y1s[Iy]);
		y1s_in_roi_max=max(y1s[Iy]);
	
		roi_array=img_array[x1s_in_roi_min:x1s_in_roi_max+1,y1s_in_roi_min:y1s_in_roi_max+1];
		
		new_mimg=ImgArray();	
		new_mimg.set('img_array',roi_array);
		
		return new_mimg;
		
	def __sub__(self, mimg):
		img_array=self.get('img_array');
		if type(mimg) is ImgArray:
			img_array2=mimg.get('img_array');
			newarray=img_array-img_array2;
		else:
			newarray=img_array-mimg;
		new_mimg=ImgArray();
		new_mimg.set('img_array',newarray);
		return new_mimg;
	
	def __add__(self, mimg):
		img_array=self.get('img_array');
		if type(mimg) is ImgArray:
			img_array2=mimg.get('img_array');
			newarray=img_array+img_array2;
		else:
			newarray=img_array+mimg;
		new_mimg=ImgArray();
		new_mimg.set('img_array',newarray);
		return new_mimg;
	def __mul__(self, mimg) :
		img_array=self.get('img_array');
		N,M=img_array.shape;
		# print "self:",self.info();
		# print "mimg",mimg.info();
		if type(mimg) is ImgArray:
			img_array2=mimg.get('img_array');
			newarray=img_array*(img_array2+zeros([N,M]));
		else:
			newarray=img_array*(mimg+zeros([N,M]));
		new_mimg=ImgArray();
		new_mimg.set('img_array',newarray);
		# print type(newarray)
		return new_mimg;
		
	def __div__(self, mimg) :
		img_array=self.get('img_array');
		N,M=img_array.shape;
		# print "self:",self.info();
		# print "mimg",mimg.info();
		if type(mimg) is ImgArray:
			img_array2=mimg.get('img_array');
			newarray=img_array/(img_array2+zeros([N,M]));
		else:
			newarray=img_array/(mimg+zeros([N,M]));
		new_mimg=ImgArray();
		new_mimg.set('img_array',newarray);
		# print type(newarray)
		return new_mimg;
	
		
	def disp_img(self,roi=None,vmin=None,vmax=None):
		img_array=self.get('img_array');
		imshow(img_array,vmin=vmin,vmax=vmax);
		if roi is not None:
			self.disp_roi(roi);
		# axis('tight');
	
	def disp_roi(self,roi,pstyle='-'):
		plot(roi[2:4],roi[0]+zeros(2),pstyle);
		plot(roi[2:4],roi[1]+zeros(2),pstyle);
		plot(roi[2]+zeros(2),roi[0:2],pstyle);
		plot(roi[3]+zeros(2),roi[0:2],pstyle);
		return;
	
	def info(self):
		img_array=self.get('img_array');
		img_lin=img_array.reshape(-1);
		return min(img_lin),max(img_lin),mean(img_lin),std(img_lin);
	
	def fft_info(self):
		img_array=self.get('img_array');
		imarr=fft(img_array);
		return real(imarr).mean(),real(imarr).std(),imag(imarr).mean(),imag(imarr).std(),abs(imarr).mean(),abs(imarr).std(),
	
	def sum(self):
		img_array=self.get('img_array');
		# imarr=fft(img_array);
		return img_array.sum();
		
	def mean(self):
		inf=self.info();
		return inf[2];
		
	def std(self):
		inf=self.info();
		return inf[3];
	
	def min(self):
		inf=self.info();
		return inf[0];
		
	def max(self):
		inf=self.info();
		return inf[1];
		
	def abs(self):
		img_array=self.get('img_array');
		new_mimg=ImgArray();
		new_mimg.set('img_array',abs(img_array));
		return new_mimg;
		
	def hist(self,N=100,range=None,plot=True):
		img_array=self.get('img_array');
		if plot:
			output=hist(img_array.reshape(-1),N,range=range);
		else:
			output=histogram(img_array.reshape(-1),N,range=range);
		return output;
		
	def average(self,roi=None):
		if roi is not None:
			roi_img=self.get_roi_img(roi);
			img_array=roi_img.get('img_array');
		else:
			img_array=self.get('img_array');
		return mean(img_array);
		
	def shift(self,dx,dy):
		from pydao.tools import shift_array;
		import copy;
		img_array=self.get('img_array');
		imga=copy.copy(img_array);
		imga,img_in,region=shift_array(dx,dy,imga);
		new_mimg=ImgArray();
		new_mimg.set('img_array',imga);
		return new_mimg;
		
	def smooth(self,sigma):
		from pydao.tools import gauss_smooth;
		img_array=self.get('img_array');
		img_array=gauss_smooth(img_array,sigma);
		new_mimg=ImgArray();
		new_mimg.set('img_array',img_array);
		return new_mimg;
		
	def normalize(self,factor,baseline):
		newimg=self*factor;
		newimg=newimg+baseline;
		return newimg;
		
	def shiftnorm(self,dx,dy,factor):
		shifted=self.shift(dx,dy);
		shiftednorm=shifted*factor;
		return shiftednorm;
	
		# shiftnorm=shifted
		
	def find_match(self,img2,paras0=None,roi=None):
		from pydao.tools import match_byshiftnorm,shiftnorm_2match,get_roi;
		import copy;
		img_array=self.get('img_array');
		img_array2=img2.get('img_array');
		N,M=img_array.shape;
		
		if roi is None:
			roi=[0,N,0,M];
		roi1=get_roi(img_array,roi);
		roi2=get_roi(img_array2,roi);
		if paras0 is None:
			ratio=roi2.sum()/roi1.sum();
			paras0=[0.5,0.5,ratio];
		print "paras0:",paras0
		arrayshiftnorm,paras=shiftnorm_2match(roi1,roi2,paras0);
		# arrayshift,paras=match_byshiftnorm(img_array,img_array2,paras0);
		
		new_mimg=ImgArray();
		new_mimg.set('img_array',copy.copy(img_array));
		new_mimg=new_mimg.shiftnorm(paras[0],paras[1],paras[2]);
		print paras;
		return new_mimg,paras;

##########################################################################
##						 Back up										##
##########################################################################
		
class CLS_LOX_Stack(NumMatrixCSV,Relation_Table):
	def __init__(self,filename=None, Ndim=None,shape=None,dilimiter='\t'):
		if not filename.endswith('.lox'):
			loxfilename=filename+'.lox';
		NumMatrixCSV.__init__(self,filename=loxfilename,dilimiter=dilimiter,row_width_chosen=None);
		img=None;
		if filename is not None:
			self.convertcsv();
		
	def analyze(self):
		num_matrix=self.get('num_matrix');	
		Nimg,Nroi=num_matrix.shape;
		self.set('Nimg',Nimg);
		self.set('Nroi',Nroi);
		print "Nimg,Nroi:",Nimg,Nroi;
		
	def get_singleimg(self,i_img):
		filename=self.get('filename');
		tiffilename=filename.replace('.lox','#'+str(i_img)+'.tif');
		img_array=tif2array(tiffilename);
		new_mimg=ImgArray();	
		new_mimg.set('img_array',img_array);
		return new_mimg;
		
	def img_sum(self,shiftnorm=False,imgrange=None,roi=None):
		Nimg=self.get('Nimg');
		if shiftnorm:
			shiftnorm_paras_list=self.get('shiftnorm_paras_list');
			# print "shiftnorm_paras_list:",len(shiftnorm_paras_list);
			# print "Nimg:",Nimg
		img=None;
		if imgrange is None:
			imgrange=range(1,Nimg+1);
		for i in imgrange:
			# print "i:"
			new_img=self.get_singleimg(i);
			if shiftnorm and i>0:
				print i,len(shiftnorm_paras_list)
				paras=shiftnorm_paras_list[i-1];
				new_img=new_img.shiftnorm(paras[0],paras[1],paras[2],paras[3]);
			if img is None:
				img=new_img;
			else:
				img=img+new_img;
		return img;
		
	def img_average(self,shiftnorm=False,imgrange=None):
		Nimg=self.get('Nimg');
		img=self.img_sum(shiftnorm,imgrange,roi);
		img=img/Nimg;
		return img;
		
	def find_shiftnorm(self,roi=None,paras=None):
		Nimg=self.get('Nimg');
		stardard_img=self.get_singleimg(1);
		N,M=(stardard_img.get('img_array')).shape;
		if roi is None:
			roi=[0,N,0,M];
		stardard_img.disp_img();
		stardard_img.disp_roi(roi);
		paras_list=[];
		if paras is None:
			paras=[1.,1.,1.,0.]
		for i in range(1,Nimg):
			print "align, i:",i
			img=self.get_singleimg(i);
			img_roi=img.get_roi_img(roi);
			paras0=[1.,1.,1.,0.];
			new_mimg,paras=img_roi.find_match(stardard_img.get_roi_img(roi),paras);
			paras_list.append(paras);
			print paras;
		self.set('shiftnorm_paras_list',paras_list);
		return paras_list;

	def get_dim(self):
		stardard_img=self.get_singleimg(1);
		N,M=(stardard_img.get('img_array')).shape;
		return N,M

	def substract(self,loxs,roi=None,shiftnorm=False):
		if roi is None:
			N,M=self.get_dim();
			roi=[0,N,0,M];
		if shiftnorm:
			paras_list=self.find_shiftnorm(roi,[1.,1.,1.,0]);
			paras_list1=loxs.find_shiftnorm(roi,[1.,1.,1.,0]);
		self_mean_img=self.img_average(shiftnorm);
		loxs_mean_img=loxs.img_average(shiftnorm);
		
		if shiftnorm:
			self_mean_img,paras=self_mean_img.find_match(loxs_mean_img,roi=roi);
		diff_mean_img=self_mean_img-loxs_mean_img;
			
		return diff_mean_img;
		