from pylab import *;
from functions import *;
lazy=False;

def OnOpen(ws_col,event):
	from ws_col_views import ws_col_view_modify;
	view=ws_col_view_modify(ws_col);
	ws_col.configure_traits(view=view);
	
def OnPlot(ws_col,event):
	ws_col.plotdata();
	
def append(self,data):
	olddata=self.get('data');
	if olddata is None or olddata.shape==(0,):
		newdata=data;
	else:
		newdata=hstack((olddata,data));
	self.set('data',newdata);
	
def remove(self,istart,iend):
	olddata=self.get('data');
	I=range(istart)+range(iend+1,len(olddata));
	newdata=olddata[I];
	self.set('data',newdata);
	
def plotdata(ws_col):
	try:
		data=ws_col.get('data');
		data1=data+1;
		plot(data);
	except:
		print "non-numeric data"
		
def size(self):
	mysize=0;
	data=self.get('data');
	if data is not None:
		mysize=data.shape;
	return mysize;