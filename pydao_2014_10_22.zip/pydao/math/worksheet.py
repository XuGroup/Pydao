from ..ohdf import OGroup;
from ..ohdfvi import Application;
from worksheet_views import worksheet_table_view;
from pylab import *;
from multidim_dataset import MultiDim_DataSet;

class WorkSheet(OGroup,Application,MultiDim_DataSet):
	#table_view=worksheet_table_view();
	def __init__(self,):
		import time,pydao;
		from pydao.ohdf.functions import dget;
		t0=time.time();
		OGroup.__init__(self);
		#t1=time.time();
		OGroup.set(self,'columns',OGroup());
		#t2=time.time();
		Application.__init__(self);
		#t3=time.time();
		MultiDim_DataSet.__init__(self);
		
	def contextmenu(self,parentmenu):
		import wx;
		Application.contextmenu(self,parentmenu);
		item=parentmenu.Append(wx.NewId(),"TableView","TableView");
		parentmenu.Bind(wx.EVT_MENU,self.OnTableView,item);
		item=parentmenu.Append(wx.NewId(),"ExcelView","ExcelView");
		parentmenu.Bind(wx.EVT_MENU,self.OnExcelView,item);
	
	def contextmenu_members(self,parentmenu):
		import wx;
		Application.contextmenu_members(self,parentmenu);
		item=parentmenu.Append(wx.NewId(),"Plot Columns","Plot Columns");
		parentmenu.Bind(wx.EVT_MENU,self.On_PlotColumns,item);
	
#================================methods==========================================
	def OnOpen(self,event):
		from worksheet_views import worksheet_view_modify;
		view=worksheet_view_modify(self);
		self.configure_traits(view=view);
		
	def OnTableView1(self,event):
		from worksheet_viewers import WorkSheet_Viewer;
		viewer=WorkSheet_Viewer(self,self.get_worksheet_2darray(),self.col_names());
		viewer.main();

	def OnTableView(self,event):
		#self.spreadsheet=self.get_worksheet_2darray();
		from worksheet_views import worksheet_table_view_modify;
		title=str(self.get_link());
		view=worksheet_table_view_modify(self,title=title);
		#,self.get_worksheet_2darray(),self.col_names());
		self.configure_traits(view=view);
		
	def OnExcelView(self,event):
		#self.spreadsheet=self.get_worksheet_2darray();
		from win32com.client import constants, Dispatch;
		import pythoncom;
		excelapp = Dispatch("Excel.Application");
		excelapp.visible=1;
		workbook = excelapp.Workbooks.Add();
		spreadsheet=self.get_worksheet_2darray();
		nrow,ncol=spreadsheet.shape;
		iname=1;
		for col_name in self.col_names():
			ran=self.nn2an(1,iname);
			excelapp.Range(ran).Value=col_name;
			iname=iname+1;
			
		# for irow in range(nrow):
			# for icol in range(ncol):
				# ran=self.nn2an(irow+2,icol+1);
				#print "ran:",ran;
				# excelapp.Range(ran).Value=spreadsheet[irow,icol];
		coldatalist=range(nrow);
		for icol in range(ncol):
			print 'icol:',icol
			coldata=spreadsheet[:,icol];
			for irow in range(nrow):
				coldatalist[irow]=(spreadsheet[irow,icol],);
			ran1=self.nn2an(0+2,icol+1);
			ran2=self.nn2an(nrow+1,icol+1);
			excelapp.Range(ran1+":"+ran2).Value=tuple(coldatalist);
		
	def nn2an(self,r,c):
		#Thanks Brett Shoelson
		col=c;
		colstr='';
		while col>26:
			co=col%26;
			colstr=chr(co+65)+colstr;
			col=(col-co)/26;
		colstr=chr(col+64)+colstr;
		return colstr+str(r);

	def On_PlotColumns(self,event):
		membername_list=self.member_name_selected;
		xcolname=None;
		ycolnames=[];
		yerrcolname=None;
		for member in membername_list:
			col=self.get_col(member);
			if col.get('coordinate')=='x':
				xcolname=member;
			elif col.get('coordinate')=='y':
				ycolnames.append(member);
			elif col.get('coordinate')=='yerr':
				yerrcolname=member;
		if yerrcolname is not None:
			if len(ycolnames)>0:
				ycolname=ycolnames[0];
			else:
				print "Error! no y coordinate selected."
			
			self.ploterr(x=xcolname,y=ycolname,yerr=yerrcolname);
		else:
			self.plotline(x=xcolname,y=ycolnames);

	# def get_column(self,name):
		# col=self.get_col(name);
		# return col.get('data');

	# def new_col(self):
		# from worksheet import WorkSheet_Column;
		# newcol=WorkSheet_Column();
		# col_names=self.col_names();
		# new_colname0='new_col';
		# new_colname=new_colname0;
		# i=0;
		# while col_names.count(new_colname)>0:
			# new_colname=new_colname0+str(i);
			# i=i+1;
		# self.set_col(col_name,newcol);
		# return newcol;
		
	def set_col(self,name,col):
		columns=self.get('columns');
		columns.set(name,col);
		
	def get_col(self,name):
		columns=self.get('columns');
		col=columns.get(name);
		if isinstance(col,OGroup):
			col=col.get('data');
		return col;
		
	def del_col(self,name):
		columns=self.get('columns');
		columns.remove(name);
		chosen=self.get('chosen');
		if chosen is not None:
			if chosen.count(name)>0:
				chosen.remove(name);
				self.set('chosen',chosen);

	def rename_col(self,oldname,newname):
		columns=self.get('columns');
		columns.rename(oldname,newname);

	def append2col(self,name,data0):
		#from worksheet import WorkSheet_Column;
		import copy;
		col=self.get_col(name);
		#data=copy.deepcopy(data0);
		data=data0;
		if col is None:
			#wkc=WorkSheet_Column(array(data));
			self.set_col(name,data);
			#print "|||||||||||||||||||||"
			#print name
			#print wkc
			#print data
			#print wkc.get('data')
			#print self.get_col(name).get('data')
		else:
			newcol=hstack((col,array(data)));
			self.set_col(name,newcol);
			#col.append(array(newcol));
		#print "append2col:",col,data
			
	def calculate_new_col(self,_expression,_col_name=None):
		for _k in self.col_names():
			_col=self.get_col(_k);
			#_cmd=_k+"=_col.get('data')"
			_cmd=_k+"=_col"
			exec(_cmd);
		print "_expression",_expression
		#from worksheet import WorkSheet_Column;
		try:
			data=eval(_expression);
			print "formula evaluated."
		except:
			data=None;
			newcol=None;
			print "Error in evaluating the formula \n"+_expression+"\n in calculate_new_col."
		if data is not None:
			if _col_name is not None and _col_name!='':
				#newcol=WorkSheet_Column();
				#newcol.set('data',data);
				self.set_col(_col_name,data);
			else:
				#newcol=self.new_col();
				#newcol.set('data',data);
				#newcol.set('formula',_expression);
				self.set_col('new_col_calculated',data);
		return data;
		
	def append_row(self,rowdict):
		#print "append_row"
		for col_name in rowdict.keys():
			col_data=rowdict[col_name];
			self.append2col(col_name,col_data);
			#print col_name,col_data

	def remove_row(self,irowstart,irowend):
		for col_name in self.col_names():
			col=self.get_col(col_name);
			olddata=col;
			#col.remove(irowstart,irowend);
			I=range(irowstart)+range(irowend+1,len(olddata));
			newdata=olddata[I];
			self.set_col(col_name,newdata);
			
	def get_row(self,irow):
		row={};
		for name in self.col_names():
			col=self.get_col(name);
			row[name]=col[irow];
		return row;
		
	def col_names(self):
		columns=self.get('columns');
		return columns.keys();
			
	def nrows(self):
		N=0;
		for k in self.col_names():
			col=self.get_col(k);
			#data=col.get('data');
			data=col;
			L=len(data);
			if L>N:
				N=L;
		return N;
			
	def size(self):
		ncol=len(self.col_names());
		nrow=self.nrows();
		return (nrow,ncol);
			
	def export_ascii(self,filename):
		col_names=self.col_names();
		N=self.nrows();
		
		f=open(filename,'w');
		for name in col_names:
			f.write(name+"\t");
		f.write("\n");
			
		for i in range(N):
			for name in col_names:
				col=self.get_col(name);
				#data=col.get('data');
				data=col;
				if len(data)>i:
					v=data[i];
					f.write(str(v)+"\t");
				else:
					f.write('-'+"\t");
			f.write("\n");
		f.close();
		print "WorkSheet exported to:",filename;
		
	def get_worksheet_2darray(self,all_col=True):
		N=self.nrows();
		data_list=[];
		for k in self.col_names():
			col=self.get_col(k);
			data=col;
			#data=col.get('data');
			L=len(data)
			if L<N:
				if all_col:
					nanarray=zeros(N-L)+nan;
					data1=hstack((data,nanarray));
				else:
					data1=None;
			else:
				data1=data;
			if data1 is not None:
				data_list.append(data1);
		data_tuple=tuple(data_list);
		worksheet_2darray=column_stack(data_tuple);
		return worksheet_2darray;

	def import_from_csv(self,csvfilename):
		from numstrmatrixcsv import NumStrMatrixCSV;
		from ..ohdf import natural_name;
		from functions import strarray_to_numarray;
		delimeter=',';
		csvfile=NumStrMatrixCSV(csvfilename,delimeter=delimeter);
		csvfile.importcsv();
		numstr_matrix=csvfile.get('numstr_matrix');
		Nrow,Ncol=numstr_matrix.shape;
		print "numstr_matrix:",numstr_matrix.shape;
		col_names=self.col_names();
		#from worksheet import WorkSheet_Column;
		for icol in range(Ncol):
			trykey='col'+str(icol);
			reckey=self.test_key(trykey);
			#print icol,reckey
			col_data=numstr_matrix[:,icol];
			num_data,n_nan=strarray_to_numarray(col_data);
			if n_nan<len(col_data):
				col_data=num_data;
			#wkc=WorkSheet_Column(col_data);
			#self.set_col(trykey,wkc);
			self.set_col(trykey,col_data);
			
		header=csvfile.get('header');
		self.set('header',header);
		label_list=None;
		for line in header:
			label_list_candidate=line.split(delimeter);
			#print len(label_list_candidate),len(self.col_names())
			if len(label_list_candidate)==len(self.col_names()):
				label_list=label_list_candidate;
		#print "found label_list",label_list
		
		if label_list is None:
			label_list=numstr_matrix[0,:];
			self.remove_row(0,0);
			
		if label_list is not None:
			icol=-1;
			for label in label_list:
				icol=icol+1;
				colkey='col'+str(icol);
				#print colkey,label,
				col=self.get_col(colkey);
				#col.set('label',label);
				newcolkey=natural_name(label);
				self.rename_col(colkey,newcolkey);
				#print newcolkey
				
		# get the name and labels
		
		
	def plotline(self,x=None,y=None,pstyle=None):
		xcolname=x;
		ycolnames=y;
		
		if pstyle is None:
			pstyle="-o";	

		if xcolname is None:
			#xcolname=self.col_names()[0];
		#print "xcolname:",xcolname
			xdata=None;
		else:
			#xdata=self.get_col(xcolname).get('data');
			xdata=self.get_col(xcolname);
		if ycolnames is None:
			col_names=self.col_names();
			if col_names.count(xcolname):
				col_names.remove(xcolname);
			ycolnames=col_names;
			
		#print "ycolnames:",ycolnames
		
		from pydao.math import isnumeric;
		legendstr=[];
		if type(ycolnames) is str:
			ycolnames=[ycolnames];
		for k in ycolnames:
			wsc=self.get_col(k);
			if wsc is not None:
				if wsc.get('coordinate')=='y' and k!=xcolname:
					ydata=wsc.get('data');
					if isnumeric(ydata):
						if xdata is None:
							plot(ydata,pstyle);
						else:
							plot(xdata,ydata,pstyle);
						legendstr.append(k);
			else:
				print "error!",k,"is not a column."
		legend(legendstr);
		show();

	def ploterr(self,x=None,y=None,yerr=None,pstyle=None):
		xcolname=x;
		ycolname=y;
		yerrcolname=yerr;
		
		if pstyle is None:
			pstyle="-o";
			
		if xcolname is None:
			xdata=None;
		else:
			#xdata=self.get_col(xcolname).get('data');
			xdata=self.get_col(xcolname);
			
		from pydao.math import isnumeric;
		legendstr=[ycolname];
			
		wscy=self.get_col(ycolname);
		wscyerr=self.get_col(yerrcolname);
		if wscy is not None and wscyerr is not None:
			ydata=wscy.get('data');
			yerrdata=wscyerr.get('data');
			if isnumeric(ydata) and isnumeric(yerrdata):
				if xdata is None:
					xdata=arange(len(ydata));
					errorbar(xdata,ydata,yerrdata,fmt=pstyle);
				else:
					errorbar(xdata,ydata,yerrdata,fmt=pstyle);
				legend(legendstr);
				show();
			else:
				print "error!",ycolname,'and/or',yerrcolname,"is/are not non-numeric."
		else:
			print "error!",ycolname,'and/or',yerrcolname,"is/are not non-column."
		
		
	def plot_image(self):
		data2d=self.get_worksheet_2darray();
		imshow(data2d);
		
	def plot_surface(self):
		from enthought.mayavi import mlab;
		data2d=self.get_worksheet_2darray();
		mlab.surf(data2d);

# WorkSheet_Column is actually not used after version pydao0.975, it is left is just to be compatible to the older version of hdf file.
class WorkSheet_Column(OGroup,Application):
	def __init__(self,data=None):
		OGroup.__init__(self);
		if data is None:
			OGroup.set(self,'data',array([]));
		else:
			OGroup.set(self,'data',data);
		OGroup.set(self,'unit',None);
		OGroup.set(self,'label','');
		OGroup.set(self,'coordinate','y');
		
	def contextmenu(self,parentmenu):
		import wx;
		Application.contextmenu(self,parentmenu);
		item=parentmenu.Append(wx.NewId(),"Plot","Plot");
		parentmenu.Bind(wx.EVT_MENU,self.OnPlot,item);
		
#=============================methods================================================
	def OnOpen(ws_col,event):
		from ws_col_views import ws_col_view_modify;
		view=ws_col_view_modify(ws_col);
		ws_col.configure_traits(view=view);
		
	def OnPlot(ws_col,event):
		ws_col.plotdata();
		
	def append(self,data):
		olddata=self.get('data');
		if olddata is None or olddata.shape==(0,):
			newdata=data;
		else:
			newdata=hstack((olddata,data));
		self.set('data',newdata);
		
	def remove(self,istart,iend):
		olddata=self.get('data');
		I=range(istart)+range(iend+1,len(olddata));
		newdata=olddata[I];
		self.set('data',newdata);
		
	def plotdata(ws_col):
		try:
			data=ws_col.get('data');
			data1=data+1;
			plot(data);
		except:
			print "non-numeric data"
			
	def size(self):
		mysize=0;
		data=self.get('data');
		if data is not None:
			mysize=data.shape;
		return mysize;