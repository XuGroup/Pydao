from enthought.traits.api import HasTraits;
from pylab import *;
from functions import *;
from copy import *;

Meta_Data_Prefix="__pydao__";
Empty_Instance_Name=Meta_Data_Prefix+"empty_instance";

class OCommon():
	def __init__(self):
		self._ondisk=None;
		self._parent=None;
		self._inmemory={};
		self._inmemory_meta={};
		
		import pydao;
		if pydao.etc.globalcfg.OCommon_created_count.has_key(str(type(self))):
			count=pydao.etc.globalcfg.OCommon_created_count[str(type(self))];
			count=count+1;
		else:
			count=1;
		pydao.etc.globalcfg.OCommon_created_count[str(type(self))]=count;
	
	def is_ondisk(self):
		_ondisk=True;
		if self._ondisk is None:
			_ondisk=False;
		return _ondisk;
		
	def get_hdf(self):
		hdf=None;
		if self.is_ondisk():
			try:
				hdf=self._hdf;
			except:
				hdf=self._parent.get_hdf();
		else:
			pass;
		return hdf;

	def get_top(self):
		top=None;
		if self._parent is not None:
			return self._parent.get_top();
		else:
			return self;
		
	def set_diskmeta(self,name,value):
		from tables import Group, Table;
		if self.is_ondisk():
			if isinstance(self._ondisk,Group):
				cmd='self._ondisk._v_attrs.'+name+'=value';
				#print "set_diskmeta cmd:",cmd
				exec(cmd);
			else:
				cmd='self._ondisk.attrs.'+name+'=value';
				exec(cmd);
		else:
			pass;
			
			
	def get_diskmeta(self,name):
		from tables import Group, Table;
		if self.is_ondisk():
			if isinstance(self._ondisk,Group):
				cmd='value=self._ondisk._v_attrs.'+name;
				#print "get_diskmeta cmd:",cmd
				try:
					exec(cmd);
				except:
					value=None;
			else:
				cmd='value=self._ondisk.attrs.'+name;
				try:
					exec(cmd);
				except:
					value=None;
		else:
			pass;
		return value;
	
	def set_meta(self,name,value):
		meta_dict_name=Meta_Data_Prefix+'meta_dict';
		if self.is_ondisk():
			meta_dict=self.get_diskmeta(meta_dict_name);
			#print "set_meta meta_dict:",meta_dict
			#if meta_dict is None:
			if type(meta_dict) is not dict:
				meta_dict={};
			meta_dict[name]=value;
			self.set_diskmeta(meta_dict_name,meta_dict);
		else:
			self._inmemory_meta[name]=value;
			
	def get_meta(self,name):
		value=None;
		meta_dict_name=Meta_Data_Prefix+'meta_dict';
		if self.is_ondisk():
			meta_dict=self.get_diskmeta(meta_dict_name);
			#if meta_dict is not None:
			if type(meta_dict) is dict:
				if meta_dict.has_key(name):
					value=meta_dict[name];
		else:
			if self._inmemory_meta.has_key(name):
				value=self._inmemory_meta[name];
		return value;
		
	def meta_keys(self):
		meta_dict_name=Meta_Data_Prefix+'meta_dict';
		keys=[];
		if self.is_ondisk():
			meta_dict=self.get_diskmeta(meta_dict_name);
			#if meta_dict is not None:
			if type(meta_dict) is dict:
				keys=meta_dict.keys();
		else:
			keys=self._inmemory_meta.keys();
		return keys;
		
	def string(self):
		if self.is_ondisk():
			str0=str(self._ondisk);
		else:
			str0=self.get_path_inmemory();
		return str0;
		
	def get_name_inmemory(self):
		myname=None;
		if self._parent is not None:
			for k in self._parent._inmemory.keys():
				v=self._parent._inmemory[k];
				try:
					if v==self:
						myname=k;
				except:
					if (v==self).all():
						myname=k;
		return myname;
	
	def get_path_inmemory(self):
		myname=self.get_name_inmemory();
		if myname is not None:
			parent_path=self._parent.get_path_inmemory();
			mypath=parent_path+'/'+myname;
		else:
			mypath='';
		return mypath;

	def get_ondisk(self):
		return self._ondisk;
		
	def get_link(self,name=None):
		import link;
		datadict=self;
		if self.is_ondisk():
			file_name=self.get_hdf().filename.encode('ascii');
			file_name=file_name.replace('.swp','');
		else:
			top=self.get_top();
			try:
				file_name=top.name;
			except:
				file_name='';
		opath_name=datadict.string().split(' ')[0];
		link_tuple=(file_name,opath_name);
		if name is not None:
			if self.keys().count(name)>0:
				link_tuple=link.join(link_tuple,name);
		return link_tuple;
		
	def typecast(self,new_empty_instance):
		if self.is_ondisk():
			new_empty_instance._ondisk=self._ondisk;
			new_empty_instance._parent=self._parent;
			if isinstance(self,OFile):
				new_empty_instance.name=self.name;
				new_empty_instance._hdf=self._hdf;
		else:
			new_empty_instance._parent = self._parent;
			new_empty_instance._inmemory = self._inmemory;
			new_empty_instance._inmemory_meta = self._inmemory_meta;
		return new_empty_instance;
		
class OGroup(HasTraits,OCommon):
	#_ondisk=None;
	#inmemory={};
	def __init__(self,parent=None):
		OCommon.__init__(self);
		self._parent=parent;
		self._buffer_keys=None;
		self._buffer_keys_time_stamp=None;
		#self.stamp_time();
		#self.cache={};
		pass;
		
	def stamp_time(self,timetype='update_key'):
		import time;
		#self.set_meta('time_'+timetype,str(time.localtime()));
		self.set_meta('time_'+timetype,time.time());
	
	def get_time_stamp(self,timetype='update_key'):
		import time;
		time_modified=self.get_meta('time_'+timetype);
		#if time_modified is not None:
		#	time_modified=eval(time_modified);
		return time_modified;

	def stamp_member_time(self,name):
		import time;
		#self.set_meta('time_'+timetype,str(time.localtime()));
		member_time_dict=self.get_meta('member_time_dict');
		if member_time_dict is None:
			member_time_dict={};
		member_time_dict[name]=time.time();
		#self.set_meta('time_'+timetype,time.time());
		self.set_meta('member_time_dict',member_time_dict);
	
	def get_member_time_stamp(self,name):
		import time;
		member_time=None;
		member_time_dict=self.get_meta('member_time_dict');
		if member_time_dict is not None:
			if member_time_dict.has_key(name):
				member_time=member_time_dict[name];
		return member_time;
		
	def copy2mem(self,deep=False):
		success=False;
		import copy;
		mycopy=get_empty_instance(self);
		#mycopy=copy.copy(self);
		ks=self.keys();
		if len(ks)>20:
			# print "copy2mem","ondisk",self.is_ondisk(),"deep:",deep,len(ks);
			from pydao.tools import Progress_Teller;
			pt=Progress_Teller(len(ks));
			i=0;
		if self.is_ondisk():
			for k in self.keys():
				if len(ks)>20:
					i=i+1;
					pt.tell(i);
				v=self.get(k);
				if isinstance(v,OGroup) or isinstance(v,OTable):
					vcopy=v.copy2mem();
				else:
					vcopy=copy.deepcopy(v);
				mycopy.set(k,vcopy);
			meta_dict_name=Meta_Data_Prefix+'meta_dict';
			meta_dict=self.get_meta(meta_dict_name);
			if meta_dict is not None:
				#mycopy.set(meta_dict_name,meta_dict);
				mycopy._inmemory_meta=meta_dict;
		else:
			#mycopy = copy.copy(self);
			if deep:
				for k in self.allkeys_real():
					if len(ks)>20:
						i=i+1;
						pt.tell(i);
					v=self.get(k);
					if isinstance(v,OCommon):# or isinstance(v,OTable):
						v1=v.copy2mem(deep=True);
					else:
						v1=copy.deepcopy(v);
					mycopy.set(k,v1);
				for k in self.meta_keys():
					v=self.get_meta(k);
					v1=copy.deepcopy(v);
					mycopy.set_meta(k,v1);
			else:
				mycopy._inmemory=copy.deepcopy(self._inmemory);
				mycopy._inmemory_meta=copy.deepcopy(self._inmemory_meta);
		return mycopy;
		
	def test_key(self,key):
		akeys=self.allkeys();
		recommendedkey=key;
		while akeys.count(recommendedkey)>0:
			recommendedkey=recommendedkey+'_';
		return recommendedkey;
		
	def set(self,name,value,flush=False):
		legalname=natural_name(name);
		if legalname!=name:
			#print "Warning, unrecommended name:'",name,"'. Recommended name:'",legalname,"'"
			pass;
		if self.is_ondisk():
			#print "_ondisk,set",name
			hdf=self.get_hdf();
			if isinstance(value,OGroup):
				value.hookupto(self,name,True);
			elif isinstance(value,OTable):
				value.hookupto(self,name,True);
				#pass;
			elif type(value) is ndarray:
				if self.keys().count(name)>0:
					node=hdf.getNode(self._ondisk,name);
					hdf.removeNode(self._ondisk,name,recursive=True);
				if len(value)>0:
					obj=hdf.createArray(self._ondisk, name,value);
					obj.attrs.pydaoclass='ndarray';
				else:
					obj=hdf.createArray(self._ondisk,name,'');
					obj.attrs.pydaoclass='empty_ndarray';
					
			elif isnumeric(value):
				if self.keys().count(name)>0:
					node=hdf.getNode(self._ondisk,name);
					hdf.removeNode(self._ondisk,name,recursive=True);
				obj=hdf.createArray(self._ondisk, name,value);
				obj.attrs.pydaoclass='numeric';
			elif type(value) is str:
				if self.keys().count(name)>0:
					node=hdf.getNode(self._ondisk,name);
					hdf.removeNode(self._ondisk,name,recursive=True);
				obj=hdf.createArray(self._ondisk,name,array([value]));
				#obj.append(value);
				obj.attrs.pydaoclass='str';
			elif type(value) is unicode:
				if self.keys().count(name)>0:
					node=hdf.getNode(self._ondisk,name);
					hdf.removeNode(self._ondisk,name,recursive=True);
				obj=hdf.createArray(self._ondisk,name,array([value.encode('ascii')]));
				#obj.append(value);
				obj.attrs.pydaoclass='str';
			elif value is None:
				if self.keys().count(name)>0:
					node=hdf.getNode(self._ondisk,name);
					hdf.removeNode(self._ondisk,name,recursive=True);
				obj=hdf.createArray(self._ondisk,name,'');
				obj.attrs.pydaoclass='None';
			elif type(value) is list:
				if self.keys().count(name)>0:
					node=hdf.getNode(self._ondisk,name);
					hdf.removeNode(self._ondisk,name,recursive=True);
				if len(value)>0:
					obj=hdf.createArray(self._ondisk,name,array(value));
					obj.attrs.pydaoclass='list';
				else:
					obj=hdf.createArray(self._ondisk,name,'');
					obj.attrs.pydaoclass='empty_list';
			elif type(value) is tuple:
				if self.keys().count(name)>0:
					node=hdf.getNode(self._ondisk,name);
					hdf.removeNode(self._ondisk,name,recursive=True);
				if len(value)>0:
					obj=hdf.createArray(self._ondisk,name,array(value));
					obj.attrs.pydaoclass='tuple';
				else:
					obj=hdf.createArray(self._ondisk,name,'');
					obj.attrs.pydaoclass='empty_tuple';
			elif type(value) is dict:
				og=self.dict2OGroup(value);
				obj=og.hookupto(self,name,True);
				obj._v_attrs.pydaoclass='dict';
			else:
				if self.keys().count(name)>0:
					node=hdf.getNode(self._ondisk,name);
					hdf.removeNode(self._ondisk,name,recursive=True);
				from tables import ObjectAtom;
				obj=hdf.createVLArray(self._ondisk,name,ObjectAtom());
				obj.append(value);
				obj.attrs.pydaoclass='misc';
				#obj=hdf.createVLArray(self._ondisk,name,ObjectAtom());
				#obj.append(value);
			if not isinstance(value,OGroup) and not isinstance(value,OTable):
				self._inmemory[name]=value;
			if flush:
				self.get_hdf().flush();
		else:
			#print "in memory,set",name
			self._inmemory[name]=value;
			if isinstance(value,OGroup):
				value._parent=self;
		#if self._buffer_keys is not None:
		#self.append_key(name);
		self.stamp_time();
		self.stamp_time('modified');
		self.stamp_member_time(name);
		#self.refresh_buffer_keys(name);
		
	def get(self,name):
		#print "getting...",name,self.is_ondisk();
		v=None;
		if self._inmemory.has_key(name):
			v=self._inmemory[name];
			if isinstance(v,OCommon) and v.is_ondisk():
				v.read2memory();
				#print "reading...",name,'to memory...'
				#print "ondisk",v.is_ondisk();
		else:
			v=self.get_real(name);
			if isinstance(v,OCommon) and v.is_ondisk():
				v.read2memory();
		return v;
		
	def get_real(self,name):
		import time;
		from tables import Group, Table;
		v=None;
		if self.is_ondisk():
			hdf=self.get_hdf();
			if self.keys().count(name)>0:
				t0=time.time();
				node=hdf.getNode(self._ondisk,name);
				t1=time.time();
				#print "node:", name," type:",type(node)
				#print time.time()-t0,'get node time'
				if type(node) is Group:
					#v=self._hdfgroup2ogroup(node);
					hdfgroup=node;
					class_dict=hdfgroup._v_attrs.class_dict;
					ogroup=get_empty_instance(class_dict);
					if ogroup is None:
						ogroup=OGroup();
					t2=time.time();
					ogroup._ondisk=hdfgroup;
					ogroup._inmemory={};
					ogroup._parent=self;
					#print time.time()-t0,'before stamp'
					ogroup.stamp_time();
					#print time.time()-t0,'after stamp'
					ogroup._hdf=self._hdf;
					v=ogroup;
					t3=time.time();
					try:
						if hdfgroup._v_attrs.pydaoclass=='dict':
							v=v.copy2mem();
							v=v._inmemory;
					except:
						pass;
					t4=time.time();
					#print t1-t0,t2-t1,t3-t2,t4-t3,name
				elif type(node) is Table:
					hdftable=node;
					try:
						class_dict=hdftable.attrs.class_dict;
						otable=get_empty_instance(class_dict);
						#otable=hdftable.attrs._OTable__empty__instance;
						#ogroup=vlarray.read()[0];
					except:
						#import traceback;
						#traceback.print_exc();
						#print "generic OTable"
						otable=OTable();
					otable._ondisk=hdftable;
					otable._parent=self;
					v=otable;
				elif node.attrs._f_list().count('pydaoclass')>0:
					if node.attrs.pydaoclass=='ndarray':
						v=node.read();
					elif node.attrs.pydaoclass=='numeric':
						v=node.read();
					elif node.attrs.pydaoclass=='str':
						v=node.read();
						v=v[0];
						v=str(v);
					elif node.attrs.pydaoclass=='None':
						v=None;
					elif node.attrs.pydaoclass=='empty_list':
						v=[];
					elif node.attrs.pydaoclass=='empty_tuple':
						v=();
					elif node.attrs.pydaoclass=='empty_ndarray':
						v=array([]);
					elif node.attrs.pydaoclass=='list':
						v=node.read();
						v=list(v);
					elif node.attrs.pydaoclass=='tuple':
						v=node.read();
						v=tuple(v);
					elif node.attrs.pydaoclass=='misc':
						v=node.read();
						v=v[0];
				else:
					v=node.read();
		else:
			if self._inmemory.has_key(name):
				v=self._inmemory[name];
		return v;
	
	def read2memory(self):
		success=False;
		import copy,time;
		from pydao.tools import Progress_Teller;
		
		if self.is_ondisk():
			#mycopy=get_empty_instance(self);
			keys=self.keys();
			#if len(keys)>20:
				#print "read2memory..",len(keys);
			pt=Progress_Teller(len(keys),0.01,text='read2memory'+str(len(keys)));
			i=0;
			
			for k in keys:
				pt.text='read2memory '+k;
				v=self.get(k);
				self._inmemory[k]=v;
				i=i+1;
				pt.tell(i);
			meta_dict_name=Meta_Data_Prefix+'meta_dict';
			meta_dict=self.get_diskmeta(meta_dict_name);
			if meta_dict is not None:
				#mycopy.set(meta_dict_name,meta_dict);
				self._inmemory_meta=meta_dict;
			self._ondisk=None;
			success=True;
		#print "after read2memory..",self.is_ondisk();
		return success;
	
	def get_withpath(self,path_str):
		path_list=path_str.split('/');
		path_list=path_list[1:];
		data=self;
		for name in path_list:
			data=data.get(name);
		return data;
		
	def allkeys_real(self):
		from tables import Group
		hdf=self.get_hdf();
		name_list=[];
		#if self._buffer_keys is not None:
		#	name_list=copy(self._buffer_keys);
		if self.is_ondisk():
			for node in hdf.listNodes(self._ondisk):
				#print type(node)
				if type(node) is Group:
					name=node._v_name;
				else:
					name=node.name;
				name_list.append(name);
			#self._buffer_keys=copy(name_list);
		else:
			name_list=self._inmemory.keys();
			#self._buffer_keys=copy(name_list);
		name_list.sort();
		return name_list;
	
	def allkeys(self):
		if self.is_ondisk():
			if self.has_outdated_buffer_keys():
				self.refresh_buffer_keys();
			name_list=self._buffer_keys;
			name_list.sort();
		else:
			self.refresh_buffer_keys();
			name_list=self.allkeys_real();
		return name_list;
			
	def keys(self):
		allks=self.allkeys();
		ks=[];
		for k in allks:
			if not k.startswith(Meta_Data_Prefix):
				ks.append(k);
		return ks;
	
	def og_keys(self):
		ks=self.keys();
		ogks=[];
		for k in ks:
			v=self.get(k);
			if isinstance(v,OGroup):
			#if self.is_subgroup(k):
				ogks.append(k);
		return ogks;
		
	# def is_subgroup(self,name):
		# from tables import Group, Table;
		# import time;
		# t0=time.time();
		# print "is_subgroup"
		# answer=False;
		# keys=self.keys();
		# print "keys",time.time()-t0
		# if self.is_ondisk():
			# hdf=self.get_hdf();
			# if keys.count(name)>0:
				# print name,time.time()-t0
				# node=hdf.getNode(self._ondisk,name);
				# print name,time.time()-t0
				# if type(node) is Group:
					# answer=True;
		# else:
			# v=self.get(name);
			# if isinstance(v,OGroup):
				# answer=True;
		# return answer;
		
	def nog_keys(self):
		ks=self.keys();
		ogks=[];
		for k in ks:
			v=self.get(k);
			if not isinstance(v,OGroup):
				ogks.append(k);
		return ogks;
		
	def has_key(self,k):
		answer=False;
		ks=self.keys();
		#print "in has_key"
		#print "ks:",ks
		#print "k:",k
		#print ks.count(k)
		if ks.count(k)>0:
			answer=True;
		return answer;
		
	# def append__buffer_key(self,k):
		# if self.has_outdated_buffer_keys:
			# self.refresh_buffer_keys();
		# if self._buffer_keys.count(k)==0:
			# self._buffer_keys.append(k);
			
	def refresh_buffer_keys(self,newkey=None):
		if newkey is None:
			self._buffer_keys=self.allkeys_real();
		elif self._buffer_keys is None:
			self._buffer_keys=[newkey];
		elif self._buffer_keys.count(newkey)==0:
			self._buffer_keys.append(newkey);
		self._buffer_keys_time_stamp=self.get_time_stamp();
		
	def has_outdated_buffer_keys(self):
		import time;
		outdated=False;
		if self._buffer_keys is None:
			outdated=True;
		else:
			time_stamp=self.get_time_stamp();
			#print "time_stamp:",time_stamp,self._buffer_keys_time_stamp
			if time_stamp is None or self._buffer_keys_time_stamp is None:
				outdated=True;
			else:
				#time1=time.mktime(time_stamp);
				#time2=time.mktime(self._buffer_keys_time_stamp);
				time1=time_stamp;
				time2=self._buffer_keys_time_stamp;
				if time1!=time2:
					outdated=True;
					#print "time1,time2:",time1,time2
		return outdated;
		
	def remove(self,name):
		hdf=self.get_hdf();
		Found=False;
		if self.keys().count(name)>0:
			if self.is_ondisk():
				hdf.removeNode(self._ondisk,name,recursive=True);
			else:
				self._inmemory.pop(name);
			Found=True;
			self.stamp_time();
			self.stamp_time('modified');
		return Found;
		
	def clear(self):
		ks=self.keys();
		if self.is_ondisk():
			for k in self.keys():
				self.remove(k);
		else:
			self._inmemory={};
		return;
		
	def rename(self,oldname,newname):
		hdf=self.get_hdf();
		if self.has_key(newname):
			return False;
		elif self.is_ondisk():
			hdf.flush();
			hdf.renameNode(self._ondisk,newname,oldname);
			self.stamp_time();
			self.stamp_time('modified');
			return True;
		else:
			value=self.get(oldname);
			self.set(newname,value);
			self._inmemory.pop(oldname);
			self.stamp_time();
			self.stamp_time('modified');
			return True;
			
	def hookupto(self,parent,name,deletegroup=False):
		from tables import Group;
		import copy;
		#print "hooking up",name,"to",parent._ondisk,self.is_ondisk();
		success=False;
		if self.is_ondisk():
			cp=self;
			#cp=self.copy2mem();
			#cp.hookupto(parent,name);
			pass;
		else:
			#cp=self.copy2mem();
			#cp=get_empty_instance(self);
			cp=copy.copy(self);
			cp._parent=parent;
			#cp=self;
			hdf=parent.get_hdf();
			#print "hdf:",hdf
			#node=hdf.getNode(parent._ondisk,name);
			#print "got node",node;
			if parent.keys().count(name)>0:
				try:
					node=hdf.getNode(parent._ondisk,name);
				except:
					node=None;
			else:
				node=None;
				
			if node is not None:
				if type(node) is not Group:
					hdf.removeNode(parent._ondisk,name,recursive=True);
				elif deletegroup:
					hdf.removeNode(parent._ondisk,name,recursive=True);
					cp._ondisk=hdf.createGroup(parent._ondisk,name);
					cp._ondisk._v_attrs.class_dict=classdict(type(cp));
				else:
					#print "using old node:",node
					cp._ondisk=node;
					#cp._ondisk._v_attrs.class_dict=classdict(type(self));
			else:
				cp._ondisk=hdf.createGroup(parent._ondisk,name);
				cp._ondisk._v_attrs.class_dict=classdict(type(cp));
			
			ks=self._inmemory.keys()
			ks1=cp.keys();
			if len(ks)>20:
				print "hookupto",len(ks);
				from pydao.tools import Progress_Teller;
				pt=Progress_Teller(len(ks));
			i=0;
			for k in ks:
				v=self._inmemory[k];
				cp.set(k,v);
				if len(ks)>20:
					i=i+1;
					pt.tell(i);
				if ks1.count(k)>0:
					ks1.remove(k);
			for k in ks1:
				hdf.removeNode(cp._ondisk,k,recursive=True);
			for k in self.meta_keys():
				v=self.get_meta(k);
				#print "set_meta",k,'to',v
				cp.set_diskmeta(k,v);
			success=True;
		parent.stamp_time();
		parent.stamp_time('modified');
		return cp._ondisk;
	
	def dict2OGroup(self,vdict):
		og=OGroup();
		og._inmemory=vdict;
		return og;
		
	def oview(self,title=None):
		self.clipborad=HasTraits();
		from ..ohdfvi import get_ogroup_explorer_view as gview;
		ok=self.configure_traits(view=gview());
		self.uiinfo.ui.control.oroot=self;
		if title is not None:
			self.uiinfo.ui.title=title;
		return ok;
		
	def size(self):
		return (len(self.keys()));
		
	def configure_ogroup(self,view=None):
		if view is None:
			from ..ohdfvi import ogroup_property_view;
			view=ogroup_property_view(self);
		fieldnames=self.keys();
		for k in fieldnames:
			dset(self,k,self.get(k));
		
		ok=self.configure_traits(view=view);
		try:
			trait_change_list=self.trait_change_list;
		except:
			trait_change_list=self.keys();
		if ok:
			for k in fieldnames:
				if trait_change_list.count(k)>0:
					self.set(k,dget(self,k));
				ddel(self,k);
		return ok;
		
#-------------------------------for ondisk/expert only-------------------------------------------
	def copyto_newparent(self,newparent,newname):
		hdf=self.get_hdf();
		newnode=hdf.copyNode(self._ondisk, newparent=newparent._ondisk, newname=newname, name=None,recursive=True);
		#if newparent.allkeys().count(newname)==0:
			#if newparent.all_keys is not None:
		#		newparent.all_keys.append(newname);
		newogroup=get_empty_instance(self);
		newogroup._parent=newparent;
		newogroup._ondisk=newnode;
		#newparent.append_key(newname);
		newparent.stamp_time();
		newparent.stamp_time('modified');
		return self._ondisk;
		#return newogroup;
		
class OTable(HasTraits,OCommon):
	def __init__(self):
		OCommon.__init__(self);
		pass;
		
	def create(self,parent_group,tablename,table_descriptor,objlist=None):
		self._parent=parent_group;
		self.tablename=tablename;
		self.table_descriptor=table_descriptor;
		hdf=self._parent.get_hdf();
		
		if self._parent.keys().count(self.tablename)>0:
			hdf.removeNode(self._parent._ondisk,self.tablename,recursive=True);
		self._ondisk=hdf.createTable(self._parent._ondisk,self.tablename,self.table_descriptor);
		self._ondisk.attrs.class_dict=classdict(type(self));
		if objlist is not None:
			row=self._ondisk.row;
			for obj in objlist:
				for k in table_descriptor.keys():
					row[k]=obj.get(k);
				row.append();
			self._ondisk.flush();
		#parent_group.append_key(tablename);
		parent_group.stamp_time();
		parent_group.stamp_time('modified');
		#print parent_group.allkeys()

	def get_field_type_dict(self):
		if self.is_ondisk():
			tab=self._ondisk.read();
		else:
			tab=self._inmemory['table'];
		type_str=str(tab.dtype);
		type_list0=eval(type_str);
		type_list=[];
		name_list=[];
		for type_tuple in type_list0:
			name_list.append(type_tuple[0]);
			type_list.append(type_tuple[1][1:]);
		type_dict={};
		type_dict['fieldnames']=name_list;
		type_dict['types']=type_list;
		return type_dict;
		
	def get_fieldnames(self):
		if self.is_ondisk():
			names=self._ondisk.colnames;
		else:
			names=self.get_field_type_dict['fieldnames'];
		return names;
		
	def get_column(self,fieldname):
		if self.is_ondisk():
			table=self._ondisk;
			col=table.col(fieldname);
		else:
			i=self.get_fieldnames().index(fieldname);
			col=self._inmemory['table'][:,i];
		return col;
		
	def size(self):
		N=self.nrows();
		#print N
		M=len(self.get_fieldnames());
		#print M
		#print "table size",N,M
		return (N,M)

	def nrows(self):
		if self.is_ondisk():
			nro=self._ondisk.nrows;
		else:
			nro,ncol=self._inmemory['table'].shape;
		return nro;
		
	def copy2mem(self,deep=False):
		success=False;
		import copy;
		if self.is_ondisk():
			mycopy=get_empty_instance(self);
			mycopy._inmemory['table']=self._ondisk.read();
			meta_dict_name=Meta_Data_Prefix+'meta_dict';
			meta_dict=self.get_meta(meta_dict_name);
			if meta_dict is not None:
				#mycopy._inmemory['meta_dict_name']=meta_dict;
				mycopy._inmemory_meta=meta_dict;
		else:
			mycopy=copy.deepcopy(self);
		return mycopy;
		
	def get_element(self,irow,fieldname):
		fieldname_list=self.get_fieldnames();
		ifield=fieldname_list.index(fieldname);
		element=None;
		if self.is_ondisk():
			row=self._ondisk.read(irow,1);
			element=row[ifield];
		else:
			element=self._inmemory['table'][irow,ifield];
		return element;
		
#-------------------------------for ondisk/expert only-------------------------------------------
	def row(self):
		if self.is_ondisk():
			ro=self._ondisk.row;
		else:
			ro=None;
		return  ro;

	def read2memory(self):
		nrows=self._ondisk.nrows;
		self._inmemory['table']=self._ondisk.read(0,nrows);
		return self._inmemory['table'];
		
	def export_ascii(self,filename):
		self.export(filename);
		
	def export(self,filename):
		table=self._ondisk;
		fieldnames=self.get_fieldnames();
		htlist=[];
		f=open(filename,'w');
		for field in fieldnames:
			f.write(field+"\t");
		f.write("\n");
		for row in table.iterrows():
			for field in fieldnames:
				v=row[field];
				f.write(str(v)+"\t");
			f.write("\n");
		f.close();
		print "table exported to:",filename;

	def oview(self,title=None):
		self.clipborad=HasTraits();
		self.convert2list();
		from ..ohdfvi import get_otable_spreadsheet_view as tview;
		view=tview(self);
		ok=self.configure_traits(view=view);
		self.uiinfo.ui.control.oroot=self;
		if title is not None:
			self.uiinfo.ui.title=title;
		return ok;
		
	def flush(self):
		self._ondisk.flush();
		
	def copyto_newparent(self,newparent,newname):
		hdf=self.get_hdf();
		newnode=hdf.copyNode(self._ondisk, newparent=newparent._ondisk, newname=newname, name=None,recursive=True);
		#if newparent.allkeys().count(newname)==0:
		#	if newparent.all_keys is not None:
		#		newparent.all_keys.append(newname);
		newotable=get_empty_instance(self);
		newotable._parent=newparent;
		newotable._ondisk=newnode;
		newparent.stamp_time();
		newparent.stamp_time('modified');
		return newotable;
		
	def hookupto(self,parent,tablename):
		success=False;
		if self.is_ondisk():
			cp=self.copy2mem();
			cp.hookupto(parent,tablename);
		else: 
			import tables;
			table_descriptor={};
			field_type_dict=self.get_field_type_dict();
			ifield=-1;
			for fieldname in field_type_dict['fieldnames']:
				ifield=ifield+1;
				typename=field_type_dict['types'][ifield];
				if typename=='i3':
					table_descriptor[fieldname]=tables.Int32Col();
				elif typename=='i2':
					table_descriptor[fieldname]=tables.Int16Col();
				elif typename.startswith('S'):
					strlen=eval(typename[1:]);
					table_descriptor[fieldname]=tables.StringCol(itemsize=strlen);
				else:
					table_descriptor[fieldname]=tables.Float32Col();
			self.create(parent,tablename,table_descriptor);
			
			memarray=self._inmemory['table'];
			#print "memarray",memarray,type(memarray),memarray.dtype
			#print memarray.shape,size(memarray),table_descriptor
			#Nrow,Ncol=memarray.shape;
			ro=self.row();
			for irow in range(len(memarray)):
				mrow=memarray[irow];
				for icol in range(len(mrow)):
					fieldname=field_type_dict['fieldnames'][icol];
					ro[fieldname]=mrow[icol];
				ro.append();
			self._ondisk.flush();
			return self._ondisk;
		
class OFile(OGroup):
	def __init__(self,filename=None):
		OGroup.__init__(self);
		self.name=filename;
		self._hdf=None;
		#self.name=filename;
		
	def open(self,mode='a'):
		from tables import openFile;
		try:
			self._hdf=openFile(self.name,mode);
			self._ondisk=self._hdf.root;
			#self._hdf.enableUndo();
			#self._hdf.mark();
		except:
			import traceback;
			traceback.print_exc();
		
	def get_hdf(self):
		return self._hdf;
		
	def close(self):
		if self.is_ondisk():
			#self._hdf.disableUndo();
			self._hdf.close();
			self._hdf=None;
			self._ondisk=None;
		else:
			pass;
		
	def flush(self):
		self._hdf.flush();
		
	def isopen(self):
		return self._hdf.isopen;

	def get_data_with_path(self,path=None):
		data=self;
		for field in path:
			data=data.get(field);
		return (data);

	def list_path(self,group_path):
		groupdata=self.get_data_with_path(group_path);
		keys=groupdata.keys();
		return keys;
		
	def copy2mem(self):
		newofile=OGroup.copy2mem(self)
		newofile.name=self.name+'.mem';
		#newofile._hdf=
		return newofile;
		
	def save2disk_1(self):
		import os;
		import time;
		import pydao;
		success=False;
		
		if self.is_ondisk():
			cp=self.copy2mem();
			cp.save2disk();
		else: 
			backupfname=self.name+'.bak';
			print '-----------'
			time0=time.time();
			for i_back in range(pydao.etc.N_Backup_File,0,-1):
				backupfname1=backupfname+str(i_back);
				backupfname2=backupfname+str(i_back-1);
				if os.path.exists(backupfname1):
					os.remove(backupfname1);
					print "Old backup file",backupfname1,'removed'
				if os.path.exists(backupfname2):
					os.rename(backupfname2,backupfname1);
					print backupfname2,'renamed to',backupfname1
					
			if os.path.exists(self.name):
				os.rename(self.name,backupfname2);
				print self.name,'renamed to',backupfname
			else:
				print self.name,'does not exist, creating new...';
			
			
			hdf=self.get_hdf();
			if hdf is None:
				self.open();
			self._ondisk=hdf.root;
			#for k in self.keys():
			#	self.remove(k);
			for k in self._inmemory.keys():
				v=self._inmemory[k];
				self.set(k,v);
			#self.close();
			success=True;
		print "Time taken",time.time()-time0,'seconds'
		
		return self._ondisk;
		
	def save2disk(self):
		import os;
		import time;
		import pydao;
		success=False;
		time0=time.time();
		if self.is_ondisk():
			cp=self.copy2mem();
			cp.save2disk();
		else: 
			print '-----------'
			
			#self.open();
			
			hdf=self.get_hdf();
			if hdf is None:
				self.open();
				hdf=self.get_hdf();
			self._ondisk=hdf.root;
			#for k in self.keys():
			#	self.remove(k);
			#ks=self.keys();
			ks=self.allkeys_real();
			for k in self._inmemory.keys():
				print "saving",k
				v=self._inmemory[k];
				self.set(k,v);
				if ks.count(k)>0:
					ks.remove(k);
			if len(ks)==0:
				print "No root group to remove."
			for k in ks:
				print "removing ",k
				self.remove(k);
			#self.close();
			hdf.flush();
			self._ondisk=None;
			success=True;
		print "Time taken",time.time()-time0,'seconds.'
		
		return self._ondisk;