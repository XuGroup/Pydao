from pylab import *;
from enthought.traits.api import HasTraits, List;
from ..ohdf import OGroup,OFile,OTable;
from mvc_views import application_view,application_group_view,\
	application_group_list_view;
	
class Application():
	app_view=application_view();
	app_group_view=application_group_view();
	app_group_list_view=application_group_list_view();
	hasgroup=True;
	
	def __init__(self):
		#import pydao;
		#pydao.gohome();
		try:
			self.add_class_trait('work_space_list',List( OGroup ))
		except:
			try:
				self.add_trait('work_space_list',List( OGroup ))
			except:
				pass;
	
	def contextmenu(self,parentmenu,args=None):
		import wx;
		item=parentmenu.Append(wx.NewId(),"Open Analysis","Open Analysis");
		parentmenu.Bind(wx.EVT_MENU,self.OnOpen,item);
		
	def contextmenu_members(self,parentmenu,args=None):
		import wx;
		#item=parentmenu.Append(wx.NewId(),"Pass","Pass");
		#parentmenu.Bind(wx.EVT_MENU,self.OnOpen,item);
		pass;
		
	def OnOpen(self):
		pass;
		
	def refresh_editor(self):
		try:
			self.editor.refresh(lazy=False);
		except:
			print "editor not found."

	def isgrouped(self):
		cfg=self.work_space_list.selected.get('config');
		try:
			grouped=cfg.get('_0group') is not None;
		except:
			grouped=False;
		return grouped;
		
	def set_nonegrouped(self):
		cfg=self.work_space_list.selected.get('config');
		cfg.remove('_0group');
		
	def get_cfg_input(self,name):
		input=self.work_space_list.selected.get('config').get('_1inputs');
		return input.get(name);
		
	def set_cfg_input(self,name,value):
		input=self.work_space_list.selected.get('config').get('_1inputs');
		input.set(name,value);
		
	def get_cfg_analysis(self,name):
		cfg=self.work_space_list.selected.get('config').get('_2analysis');
		return cfg.get(name);
		
	def set_cfg_analysis(self,name,value):
		cfg=self.work_space_list.selected.get('config').get('_2analysis');
		return cfg.set(name,value);
		
	def get_cfg_output(self,name):
		cfg=self.work_space_list.selected.get('config').get('_3outputs');
		return cfg.get(name);
		
	def set_cfg_output(self,name,value):
		cfg=self.work_space_list.selected.get('config').get('_3outputs');
		return cfg.set(name,value);
		
	def set_workspace_cfg(self,workspace,part,name,value):
		cfg0=workspace.get('config');
		if part=="group":
			cfg=cfg0.get('_0group');
		elif part=='input':
			cfg=cfg0.get('_1inputs');
		elif part=='analysis':
			cfg=cfg0.get('_2analysis');
		elif part=="output":
			cfg=cfg0.get('_3outputs');
		return cfg.set(name,value);
		
	def get_workspace_cfg(self,workspace,part,name):
		cfg0=workspace.get('config');
		if part=="group":
			cfg=cfg0.get('_0group');
		elif part=='input':
			cfg=cfg0.get('_1inputs');
		elif part=='analysis':
			cfg=cfg0.get('_2analysis');
		elif part=="output":
			cfg=cfg0.get('_3outputs');
		return cfg.get(name);

	def set_workspace_nonegrouped(self,workspace):
		cfg0=workspace.get('config');
		cfg0.remove('_0group');
		
	def add_extended_methods1(self, methods):
		import inspect;
		#if not methods.lazy:
		#	reload(methods);
		self.methods=methods;
		
		modulefile=inspect.getfile(methods);
		modulefile=modulefile.replace('.pyc','.py');
		
		for k in methods.__dict__.keys():
			expr="methods."+k;
			v=eval(expr);
			if inspect.isfunction(v) and inspect.getfile(v)==modulefile:
				import new;
				cmd="self."+k+"=new.instancemethod(methods."+k+", self, type(self))";
				exec(cmd);