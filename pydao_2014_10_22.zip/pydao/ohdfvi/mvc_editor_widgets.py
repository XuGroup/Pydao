from enthought.traits.api import HasTraits;

class Widget(HasTraits):
	def __init__(self):
		self.EventIdDict={};
		#pass;
		
	def create(self, *args, **kwargs):
		import wx;
		cmd=self.widgetclass+"(*args, **kwargs)";
		#print "cmd:",cmd
		self.widget=eval(cmd);
		self.widget.xpy=self;
		#print "widget type:",type(self['widget'])
		
	def getparent(self):
		p=self.widget.GetParent();
		try:
			parent=p.xpy;
		except:
			parent=p;
		return parent;
	
	def get_rootframe(self):
		master_widget=self.getparent();
		if master_widget is None:
			this_widget=self;
		while master_widget is not None:
			this_widget=master_widget;
			if issubclass(type(master_widget),Widget):
				master_widget=this_widget.getparent();
			else:
				master_widget=this_widget.GetParent();
			try:
				master_widget=master_widget.xpy;
			except:
				pass;
		return this_widget;
	
	def get_oroot(self):
		rootframe=self.get_rootframe();
		try:
			oroot=rootframe.oroot;
		except:
			oroot=None;
		return oroot;
		
# class Menu(Widget):
	# def __init__(self, *args, **kwargs):
		# Widget.__init__(self, *args, **kwargs);
		# self.widgetclass="wx.Menu";
		#dWidget.__init__(self, *args, **kwargs);

	# def add_separator(self):
		# self.widget.AppendSeparator();
	
	# def add_command(self,label="",command=None):
		# item=self.widget.Append(wx.NewId(),label,label);
		# self.widget2bind.Bind(wx.EVT_MENU,command,item);
		
#===================================================================
class Page(Widget):
	def _init__(self, *args, **kwargs):
		Widget.__init__(self, *args, **kwargs);

	def getframe(self):
		nb=self.getparent();
		frame=nb.GetParent();
		#frame=frame.xpy;
		return frame;
