from enthought.traits.ui.api import ModelView, Handler;
from pylab import *;

#=========================================================================
# View Handler
#=========================================================================
class MyModelView(ModelView):
	def init_info(self,info):
		ModelView.init_info(self,info);
		if self.model is not None:
			self.model.uiinfo=info;
		
	def get_uiroot(self):
		return self.model.uiinfo.ui.control;
		
	
class OGroup_Property_ModelView(MyModelView):
	def init_info(self,info):
		MyModelView.init_info(self,info);
		self.prepare_traits(self.model);
		
	def init(self,info):
		from mvc_monitors import Monitor_to_Fix_TextEditor;
		info.object.__pydao__monitor=Monitor_to_Fix_TextEditor(info.object);
		info.object.trait_change_list=[];
		
	def setattr(self, info, object, name, value):
		from ..ohdf import OGroup,dget,dset,dcopyall;
		from enthought.traits.api import Button;
		
		#print self, info, object, name, value
		#print dget(object,name),isinstance(dget(object,name),Button)

		if isinstance(dget(object,name),Button):
			cmd="self._"+name+"_fired(object)";
			#print "cmd:",cmd
			try:
				exec(cmd);
			except:
				import traceback;
				traceback.print_exc();
				print "can not execute:",cmd;
		else:
			MyModelView.setattr(self, info, object, name, value)
			
		if info.object.trait_change_list.count(name)==0:
			info.object.trait_change_list.append(name);
			
		info.object.__pydao__monitor.correct(object,[name]);
		
	def close(self,info,is_ok):
		if is_ok:
			self.apply_traits(info.object);
		return Handler.close(self,info,is_ok);
		
	def prepare_traits(self,ogroup,fieldnames=None):
		from ..ohdf import OGroup,dget,dset,dcopyall;
		if fieldnames is None:
			fieldnames=ogroup.keys();
		for k in fieldnames:
			dset(ogroup,k,ogroup.get(k));
		
	def apply_traits(self,ogroup,fieldnames=None):
		from ..ohdf import OGroup,dget,dset,dcopyall,ddel;
		if fieldnames is None:
			fieldnames=ogroup.keys();
		for k in fieldnames:
			if ogroup.trait_change_list.count(k)>0:
				ogroup.set(k,dget(ogroup,k));
			ddel(ogroup,k);
	
class OGroup_Tabular_ModelView(MyModelView):
	def init_info(self,info):
		from enthought.traits.api import Event,Any;
		MyModelView.init_info(self,info);
		#print "OGroup_Tabular_ModelView init_info",self.model
		if self.model is not None:
			self.model.uiinfo=info;
			self.prepare_traits(self.model);
		#print self.model.tabular
		
	def init(self,info):
		import wx;
		from ..ohdf import dkeys;
		#print "OGroup_Tabular_ModelView init"
		#self.prepare_traits(info.object);
		self.model=info.object;
		self.model.uiinfo=info;
		
		listctr=self.get_listctr();
		listctr.Bind(wx.EVT_MOTION,self.ONMouseMotion,id=listctr.GetId());
		
		#print "info.object",info.object.keys();
		#print "self dkeys:",dkeys(self),self.class_trait_names()

	def prepare_traits(self,ogroup):
		from ..ohdf import OGroup,ddel,dkeys;
		from enthought.traits.api import Event,Any;
		tabular=[];
		for k in ogroup.keys():
			v=ogroup.get(k);
			record=[];
			record.append(k);
			if isinstance(v,OGroup):
				record.append('*');
			else:
				record.append('');
				
			record.append(str(type(v)));
			
			from numpy import ndarray;
			if type(v) is ndarray:
				size=str(v.shape);
			else:
				try:
					size=str(v.size());
				except:
					try:
						size=str(len(v));
					except:
						size="NA";
			record.append(size);
			#intro=str(v)[:40];
			intro=str(v);
			record.append(intro);
			tabular.append(record);
		
		#ddel(ogroup,'tabular');
		print "subogroup type",type(ogroup)
		if dkeys(ogroup).count('tabular')==0:
			ogroup.add_class_trait('tabular',array(tabular));
		ogroup.tabular=array(tabular);
		print ogroup.tabular
		
		model=ogroup;
		
		ctn=model.class_trait_names();
		print "ctn:",ctn
		print type(model)
		if ctn.count('clicked')==0:
			try:
				model.add_class_trait('clicked',Any);
			except: 
				pass;
		if ctn.count('dclicked')==0:
			try:
				model.add_class_trait('dclicked',Any);
			except:
				pass;
		if ctn.count('column_clicked')==0:
			try:
				model.add_class_trait('column_clicked',Any);
			except:
				pass;
		if ctn.count('right_clicked')==0:
			try:
				model.add_class_trait('right_clicked',Any);
			except:
				pass;
	
		#model.on_trait_change(self.OnCliked, 'clicked');
		model.on_trait_change(self.OnDCliked, 'dclicked');
		model.on_trait_change(self.OnClikedColumn, 'column_clicked');
		model.on_trait_change(self.OnRightClicked, 'right_clicked');
		
	def get_listctr(self):
		uiroot=self.get_uiroot();
		listctr=uiroot.GetChildren()[0].GetChildren()[0].GetChildren()[0];
		return listctr;
		
	def OnCliked(self):
		clicked=self.model.clicked
		print "OnCliked:",clicked.column, clicked.row
		name=self.model.tabular[clicked.row][0];
		print name,self.model.get(name)
		
	def OnDCliked(self):
		dclicked=self.model.dclicked
		print "OndCliked:",dclicked.column, dclicked.row
		name=self.model.tabular[dclicked.row][0];
		print name,self.model.get(name);
		
	def OnClikedColumn(self):
		print "OnClikedColumn";
		model=self.model;
		column=model.column_clicked.column;
		field_names=model.column_clicked.editor.adapter.columns;
		columnname=field_names[column];
		#self.inmemory.sort(order=columnname);
		
	def OnRightClicked(self):
		import wx;
		model=self.model;
		listctr=self.get_listctr();
		menu=wx.Menu();
		item=menu.Append(wx.NewId(),"Refresh","Refresh");
		self.get_uiroot().Bind(wx.EVT_MENU, self.OnList_Refresh, item);
		listctr.PopupMenu(menu,self.model.mouse_position);
		
	def OnList_Refresh(self,event):
		print "refreshed!"
		
	def ONMouseMotion(self, event):
		#print event.GetPosition() 
		self.model.mouse_position=event.GetPosition();
		
class OGroup_Exporler_ModelView(MyModelView):
	def init_info(self,info):
		#print "OGroup_Exporler_ModelView init_info:"
		MyModelView.init_info(self,info);
		if self.model is not None:
			self.model.uiinfo=info;
			self.prepare_traits(self.model);
			
	def init(self,info):
		self.model=info.object;
		self.model.uiinfo=info;
		self.prepare_traits(info.object);
		
	def prepare_traits(self,ogroup,fieldnames=None):
		from ..ohdf import dkeys, dget,ddel,OGroup;
		#print ogroup.class_trait_names()
		#print dkeys(ogroup)
		
		#if dkeys(ogroup).count('ogroup')>0:
		#	ddel(ogroup,'ogroup');
		if ogroup.class_trait_names().count('ogroup')==0:
			ogroup.add_class_trait('ogroup',OGroup());
		ogroup.ogroup=ogroup;
		
		if ogroup.class_trait_names().count('subogroup')==0:
			ogroup.add_class_trait('subogroup',OGroup());
		ogroup.subogroup=ogroup;
		
	def object_subogroup_changed(self, info):
		if info.initialized:
			info.ui.title += "*"
		#print "object_subogroup_changed",self.model.subogroup.keys()
		otm=OGroup_Tabular_ModelView();
		otm.prepare_traits(self.model.subogroup);

class OGroup_Analyzer_ModelView(OGroup_Property_ModelView):
	def init_info(self,info):
		MyModelView.init_info(self,info);
		self.preprocess(self.model);
		
	def preprocess(self,model):
		from enthought.traits.api import Button;
		model.bu_analyze=Button();

	def _bu_analyze_fired(self,model):
		print "_bu_analyze_fired!"
		import pydao;
		ana_configure=model.ana_configure;
		model.ana_method();

class OGroup_Analyzer_Group_ModelView(OGroup_Property_ModelView):
	def init_info(self,info):
		MyModelView.init_info(self,info);
		self.preprocess(self.model);
		
	def preprocess(self,model):
		from enthought.traits.api import Button;
		from ..ohdf import OGroup;
		model.bu_preprocess=Button();
		model.bu_nextgroup=Button();
		model.bu_previousgroup=Button();
		model.bu_dispcurrentgroup=Button();
		model.bu_analyze=Button();
		model.bu_pass=Button();
		model.bu_reset=Button();
		model.bu_resetall=Button();
		model.bu_joindata=Button();
		model.bu_save=Button();
		
		work_space=OGroup();
		
		group=OGroup();
		group.set('criteria',[]);
		group.set('current_group',-1);
		group.set('number_of_groups',-1);
		work_space.set('group',group);
		
		inputs=OGroup();
		work_space.set('inputs',inputs);
		
		parameters=OGroup();
		work_space.set('parameters',parameters);
		
		outputs=OGroup();
		outputs.set('dir_link',str(model.get_link()));
		outputs.set('name','output');
		work_space.set('outputs',outputs);
		
		_1preprocessed=OGroup();
		work_space.set('_1preprocessed',_1preprocessed);
		
		model.work_space=work_space;
		
	def _bu_preprocess_fired(self,model):
		from ..ohdf import OGroup,get_empty_instance;
		import pydao;
		work_space=model.work_space;
		inputs=work_space.get('inputs');
		group_config=work_space.get('group');
		input_groups=OGroup();

		igroup=0;
		for kinputs in inputs.keys():
			in_link=inputs.get(kinputs);
			inputdbase=pydao.viewer.get_data_of_link(in_link);
			for kobj in inputdbase.keys():
				obj=inputdbase.get(kobj);
				criteria_dict={};
				for groupk in group_config.get('criteria'):
					criteria_dict[groupk]=obj.get(groupk);
				group,groupkey=self.find_group(input_groups,criteria_dict);
				if group is not None:
					dbases=group.get('dbases');
					if dbases is None:
						dbases=OGroup();
						newdbase=get_empty_instance(inputdbase);
						newdbase.set(kobj,obj.copy2mem());
						dbases.set(kinputs,newdbase);
						group.set('dbases',dbases);
					elif dbases.keys().count(kinputs)==0:
						newdbase=get_empty_instance(inputdbase);
						newdbase.set(kobj,obj.copy2mem());
						dbases.set(kinputs,newdbase);
					else:
						group.get('dbases').get(kinputs).set(kobj,obj.copy2mem());
				else:
					group=OGroup();
					group.set('criteria_dict',criteria_dict);
					group.set('dbases',OGroup());
					newdbase=get_empty_instance(inputdbase);
					newdbase.set(kobj,obj.copy2mem());
					group.get('dbases').set(kinputs,newdbase);
					input_groups.set('group'+str(igroup),group);
					#print "add group:",'group'+str(igroup),input_groups.keys(),\
					input_groups._inmemory.keys()
					igroup=igroup+1;
						
		work_space.get('_1preprocessed').set('input_groups',input_groups);
		work_space.get('_1preprocessed').set('output_groups',OGroup());
		#model.input_group_list=group_list;
		#model.output_group_list=[];
		
		work_space.get('group').set('number_of_groups',len(input_groups.keys()));
		work_space.get('group').set('current_group',0);
		#work_space.set('input_group_list',model.input_group_list);
		#work_space.set('output_group_list',model.output_group_list);
		print "group sorted."
		
	def _bu_nextgroup_fired(self,model):
		self.change_group(model,1);
		print "group changed"
	
	def _bu_previousgroup_fired(self,model):
		self.change_group(model,-1);
		
	def _bu_dispcurrentgroup_fired(self,model):
		group=self.get_current_input_group(model);
		work_space=model.work_space;
		igroup=work_space.get('group').get('current_group');
		print "igroup:",igroup
		print group.get('criteria_dict');
		#print group.get('dbases')
	
	def _bu_analyze_fired(self,model):
		#print "_bu_analyze_fired fired!"
		import pydao;
		work_space=model.work_space;
		model.current_group=self.get_current_input_group(model);
		outgroup=model.ana_method();
		self.set_group(work_space.get('_1preprocessed').get('output_groups'),outgroup);
		print "analyze done."
		
	def _bu_pass_fired(self,model):
		work_space=model.work_space;
		ingroup=self.get_current_input_group(model);
		self.set_group(work_space.get('_1preprocessed').get('output_groups'),ingroup);
	
	def _bu_reset_fired(self,model):
		work_space=model.work_space;
		ingroup=self.get_current_input_group(model);
		self.remove_group(work_space.get('_1preprocessed').get('output_groups'),\
		ingroup.get('criteria_dict'));
		
	def _bu_resetall_fired(self,model):
		from ..ohdf import OGroup;
		work_space=model.work_space;
		work_space.get('_1preprocessed').set('output_groups',OGroup());
		
	def _bu_joindata_fired(self,model):
		from ..ohdf import OGroup;
		work_space=model.work_space;
		igroup=0;
		outputs=OGroup();
		output_groups=work_space.get('_1preprocessed').get('output_groups');
		for kgroup in output_groups.keys():
			group=output_groups.get(kgroup);
			dbase_dict=group.get('dbases');
			for kdbase in dbase_dict.keys():
				dbase=dbase_dict.get(kdbase);
				if igroup==0:
					outputs.set(kdbase,dbase);
				else:
					for k in dbase.keys():
						outputs.get(kdbase).set(k,dbase.get(k));
			igroup=igroup+1;
		model.outputs=outputs;
		print "data joined";
		
	def _bu_save_fired(self,model):
		import pydao;
		work_space=model.work_space;
		outputs=work_space.get('outputs');
		outdir_link=outputs.get('dir_link')
		outname=outputs.get('name')
		out_dir=pydao.viewer.get_data_of_link(outdir_link);
		for k in model.outputs.keys():
			out_dir.set(outname+k,model.outputs.get(k));
		print "saved to:",outdir_link
				
	def find_group(self,groups,criteria_dict):
		group_found=None;
		group_key=None;
		for kgroup in groups.keys():
			group=groups.get(kgroup);
			cri_dict=group.get('criteria_dict');
			#print kgroup,cri_dict,criteria_dict
			exist=True;
			for k in cri_dict.keys():
				if cri_dict[k]!=criteria_dict[k]:
					exist=False;
					
			if exist==True:
				group_found=group;
				group_key=kgroup;
				break;
			
		#print group_found,group_key,'-----------------------'
		return (group_found,group_key);
		
	def change_group(self,model,n):
		work_space=model.work_space;
		Ngroup=work_space.get('group').get('number_of_groups');
		igroup=work_space.get('group').get('current_group');
		igroup=igroup+n;
		while igroup>=Ngroup:
			igroup=igroup-Ngroup;
		while igroup<0:
			igroup=igroup+Ngroup;
		work_space.get('group').set('current_group',igroup);
		print "igroup:",igroup;
		
	def get_current_input_group(self,model):
		work_space=model.work_space;
		igroup=work_space.get('group').get('current_group');
		current_group=work_space.get('_1preprocessed').\
		get('input_groups').get('group'+str(igroup));
		return current_group;
		
	def set_group(self,groups,group):
		model=self.model;
		work_space=model.work_space;
		igroup=work_space.get('group').get('current_group');
		group1,groupkey=self.find_group(groups,group.get('criteria_dict'));
		if group1 is None:
			groups.set('group'+str(igroup),group);
		else:
			groups.set(groupkey,group);
			
	def remove_group(self,groups,criteria_dict):
		group,groupkey=self.find_group(groups,criteria_dict);
		if group is not None:
			groups.pop(groupkey);
			
class OGroup_Analyzer_Group_List_ModelView(OGroup_Property_ModelView):
	def init_info(self,info):
		MyModelView.init_info(self,info);
		self.preprocess(self.model);
		
	def close(self,info,is_ok):
		#for opage in info.object.opages:
		#	print opage,"closed."
		#	opage.close();
		#info.object.history_file.close();
		li=info.object.work_space_list;
		while len(li)>0:
			li.pop(0);
		li.selected=None;
		return OGroup_Property_ModelView.close(self,info,is_ok);
		
	def preprocess(self,model):
		from enthought.traits.api import Button;
		from enthought.traits.api import List;
		from ..ohdf import OGroup;
		model.bu_preprocess=Button();
		model.bu_nextgroup=Button();
		model.bu_previousgroup=Button();
		model.bu_dispcurrentgroup=Button();
		model.bu_analyze=Button();
		model.bu_pass=Button();
		model.bu_reset=Button();
		model.bu_resetall=Button();
		model.bu_joindata=Button();
		model.bu_save=Button();
		
		model.ana_method_list=[];
		
	def get_default_work_space(self,model):
		from ..ohdf import OGroup;
		#model=self.model;
		#print "model:",model
		work_space=OGroup();
		work_space.name=None;
		
		#==============config====================
		config=OGroup();
		
		group=OGroup();
		group.set('criteria',[]);
		group.set('current_group',-1);
		group.set('number_of_groups',-1);
		config.set('_0group',group);
		
		inputs=OGroup();
		config.set('_1inputs',inputs);
		
		analysis=OGroup();
		config.set('_2analysis',analysis);
		
		outputs=OGroup();
		outputs.set('dir_link',str(model.get_link()));
		outputs.set('name','output');
		config.set('_3outputs',outputs);
		
		work_space.set('config',config);
		
		#=================data======================
		data=OGroup();
		
		preprocessed=OGroup();
		data.set('_1preprocessed',preprocessed);
		analyzed=OGroup();
		data.set('_2analyzed',analyzed);
		ready4output=OGroup();
		data.set('_3ready4output',ready4output);
		
		work_space.set('data',data);
		
		#=================work space======================
		from ..ohdf import join;
		workspace_loadsave=OGroup();
		workspace_loadsave.set('load_link',str(join(model.get_link(),'workspace')));
		#workspace_loadsave.set('load_name','workspace');
		workspace_loadsave.set('save_link',str(model.get_link()));
		workspace_loadsave.set('save_name','workspace');
		
		work_space.set('work_space',workspace_loadsave);
		
		return work_space;
		
	def has_group(self):
		hasgroup=True;
		model=self.model;
		work_space=model.work_space_list.selected;
		group_config=work_space.get('config').get('_0group');
		
		if group_config is None:
			hasgroup=False;
		print "hasgroup:",hasgroup
		return hasgroup;
		
	def _bu_preprocess_fired(self,model):
		from ..ohdf import OGroup,get_empty_instance;
		import pydao;
		work_space=model.work_space_list.selected;
		
		inputs=work_space.get('config').get('_1inputs');
		group_config=work_space.get('config').get('_0group');
		
		input_groups=OGroup();
		igroup=0;
		
		if len(inputs.keys())>0:
			for kinputs in inputs.keys():
				in_link=inputs.get(kinputs);
				inputdbase=pydao.viewer.get_data_of_link(in_link);
				igroup=self.group_a_dbase(model,kinputs,inputdbase,input_groups,igroup);
		else:
			inputdbase=model;
			#print "type model:",type(model)
			igroup=self.group_a_dbase(model,'cog',inputdbase,input_groups,igroup);
			
		work_space.get('data').set('_1preprocessed',input_groups);
		#work_space.get('_1preprocessed').set('output_groups',OGroup());
		#model.input_group_list=group_list;
		#model.output_group_list=[];
		
		work_space.get('config').get('_0group').set('number_of_groups',len(input_groups.keys()));
		work_space.get('config').get('_0group').set('current_group',0);
		#work_space.set('input_group_list',model.input_group_list);
		#work_space.set('output_group_list',model.output_group_list);
		print "group sorted, totally",igroup,'groups';
		
	def group_a_dbase(self,model,kinputs,inputdbase,input_groups,igroup):
		from ..ohdf import OGroup,get_empty_instance;
		work_space=model.work_space_list.selected;
		
		inputs=work_space.get('config').get('_1inputs');
		group_config=work_space.get('config').get('_0group');
		for kobj in inputdbase.keys():
			print "kobj:",kobj
			obj=inputdbase.get(kobj);
			criteria_dict={};
			for groupk in group_config.get('criteria'):
				criteria_dict[groupk]=obj.get(groupk);
			group,groupkey=self.find_group(input_groups,criteria_dict);
			if group is not None:
				dbases=group.get('dbases');
				if dbases is None:
					dbases=OGroup();
					newdbase=get_empty_instance(inputdbase);
					newdbase.set(kobj,obj.copy2mem());
					dbases.set(kinputs,newdbase);
					group.set('dbases',dbases);
				elif dbases.keys().count(kinputs)==0:
					newdbase=get_empty_instance(inputdbase);
					newdbase.set(kobj,obj.copy2mem());
					dbases.set(kinputs,newdbase);
				else:
					group.get('dbases').get(kinputs).set(kobj,obj.copy2mem());
			else:
				group=OGroup();
				group.set('criteria_dict',criteria_dict);
				group.set('dbases',OGroup());
				newdbase=get_empty_instance(inputdbase);
				newdbase.set(kobj,obj.copy2mem());
				group.get('dbases').set(kinputs,newdbase);
				input_groups.set('group'+str(igroup),group);
				#print "add group:",'group'+str(igroup),input_groups.keys(),\
				#input_groups._inmemory.keys()
				igroup=igroup+1;
		return igroup;
		
	def _bu_nextgroup_fired(self,model):
		self.change_group(model,1);
		print "group changed"
	
	def _bu_previousgroup_fired(self,model):
		self.change_group(model,-1);
		
	def _bu_dispcurrentgroup_fired(self,model):
		group=self.get_current_input_group(model);
		work_space=model.work_space_list.selected;
		igroup=work_space.get('config').get('_0group').get('current_group');
		print "igroup:",igroup
		print group.get('criteria_dict');
		#print group.get('dbases')
	
	def _bu_analyze_fired(self,model):
		#print "_bu_analyze_fired fired!"
		import pydao;
		work_space=model.work_space_list.selected;
		try:
			model.current_group=self.get_current_input_group(model);
		except:
			pass;
		index=model.work_space_list.index(work_space);
		print "work space index:",index
		outgroup=model.ana_method_list[index]();
		try:
			self.set_group(work_space.get('data').get('_2analyzed'),\
			outgroup);
		except:
			pass;
		print "analyze done."
		
	def _bu_pass_fired(self,model):
		work_space=model.work_space_list.selected;
		ingroup=self.get_current_input_group(model);
		self.set_group(work_space.get('data').get('_2analyzed'),ingroup);
		print "group passed."
	
	def _bu_reset_fired(self,model):
		work_space=model.work_space_list.selected;
		ingroup=self.get_current_input_group(model);
		self.remove_group(work_space.get('_2analyzed'),ingroup.get('criteria_dict'));
		print "group reset."
		
	def _bu_resetall_fired(self,model):
		from ..ohdf import OGroup;
		work_space=model.work_space_list.selected;
		work_space.set('_2analyzed',OGroup());
		
	def _bu_joindata_fired(self,model):
		from ..ohdf import OGroup;
		work_space=model.work_space_list.selected;
		igroup=0;
		outputs=OGroup();
		output_groups=work_space.get('data').get('_2analyzed');
		for kgroup in output_groups.keys():
			group=output_groups.get(kgroup);
			dbase_dict=group.get('dbases');
			for kdbase in dbase_dict.keys():
				dbase=dbase_dict.get(kdbase);
				if igroup==0:
					outputs.set(kdbase,dbase);
				else:
					for k in dbase.keys():
						outputs.get(kdbase).set(k,dbase.get(k));
			igroup=igroup+1;
		work_space.get('data').set('_3ready4output',outputs)
		#model.outputs=outputs;
		print "data joined";
		
	def _bu_save_fired(self,model):
		import pydao;
		work_space=model.work_space_list.selected;
		outputscfg=work_space.get('config').get('_3outputs');
		outdir_link=outputscfg.get('dir_link')
		outname=outputscfg.get('name')
		out_dir=pydao.viewer.get_data_of_link(outdir_link);
		if out_dir is None:
			out_dir=model;
			print "invalid out_dir, use current dir instead..."
		data4outputs=work_space.get('data').get('_3ready4output')
		for k in data4outputs.keys():
			out_dir.set(outname+k,data4outputs.get(k));
		print "saved to:",outdir_link

	def find_group(self,groups,criteria_dict):
		group_found=None;
		group_key=None;
		for kgroup in groups.keys():
			group=groups.get(kgroup);
			cri_dict=group.get('criteria_dict');
			#print kgroup,cri_dict,criteria_dict
			exist=True;
			for k in cri_dict.keys():
				if cri_dict[k]!=criteria_dict[k]:
					exist=False;
					
			if exist==True:
				group_found=group;
				group_key=kgroup;
				break;
			
		#print group_found,group_key,'-----------------------'
		return (group_found,group_key);
		
	def change_group(self,model,n):
		work_space=model.work_space_list.selected;
		Ngroup=work_space.get('config').get('_0group').get('number_of_groups');
		igroup=work_space.get('config').get('_0group').get('current_group');
		igroup=igroup+n;
		while igroup>=Ngroup:
			igroup=igroup-Ngroup;
		while igroup<0:
			igroup=igroup+Ngroup;
		work_space.get('config').get('_0group').set('current_group',igroup);
		print "igroup:",igroup;
		
	def get_current_input_group(self,model):
		work_space=model.work_space_list.selected;
		igroup=work_space.get('config').get('_0group').get('current_group');
		current_group=work_space.get('data').get('_1preprocessed').\
		get('group'+str(igroup));
		return current_group;
		
	def set_group(self,groups,group):
		model=self.model;
		work_space=model.work_space_list.selected;
		igroup=work_space.get('config').get('_0group').get('current_group');
		group1,groupkey=self.find_group(groups,group.get('criteria_dict'));
		if group1 is None:
			groups.set('group'+str(igroup),group);
		else:
			groups.set(groupkey,group);
			
	def remove_group(self,groups,criteria_dict):
		group,groupkey=self.find_group(groups,criteria_dict);
		if group is not None:
			groups.remove(groupkey);
			#groups.pop(groupkey);
	
	def On_WorkSpace_Load(self,event):
		import pydao;
		model=self.model;
		work_space=model.work_space_list.selected;
		load_link=work_space.get('work_space').get('load_link');
		#load_name=work_space.get('workspace_loadsave').get('load_name');
		#save_link=work_space.get('workspace_loadsave').get('save_link');
		ws=pydao.viewer.get_data_of_link(load_link);
		ws=ws.copy2mem()
		ws.name=ws.get('name');
		ws.remove('name');
		#ws=load_dir.get(load_name);
		index=model.work_space_list.index(work_space);
		#model.work_space_list.remove(work_space);
		model.work_space_list[index]=ws;
		#model.work_space_list.append(ws);
		model.work_space_list.selected=ws;
		
	def On_WorkSpace_Save(self,event):
		import pydao;
		from pydao.ohdf import OGroup;
		model=self.model;
		work_space=model.work_space_list.selected;
		save_link=work_space.get('work_space').get('save_link');
		save_name=work_space.get('work_space').get('save_name');
		print save_link,save_name
		save_dir=pydao.viewer.get_data_of_link(save_link);
		ws=work_space.copy2mem();
		ws.set('data',OGroup());
		ws.set('name',work_space.name);
		save_dir.set(save_name,ws);
		
	def On_WorkSpace_Close(self,event):
		import pydao;
		from pydao.ohdf import OGroup;
		model=self.model;
		work_space=model.work_space_list.selected;
		if work_space is not None:
			index=model.work_space_list.index(work_space);
			model.work_space_list.pop(index);
			model.ana_method_list.pop(index);
			L=len(model.work_space_list);
			if L>0:
				model.work_space_list.selected=model.work_space_list[L-1];
			else:
				model.work_space_list.selected=None;
		
#==========================================================================
# other handler
#==========================================================================
class OGroup_List_Viewer_Handler(Handler):
	def init(self,info):
		info.object.uiinfo=info;
		
	def setattr(self, info, object, name, value):
		Handler.setattr(self, info, object, name, value)
		#info.object._updated = True	
		#print "set len:",len(info.object.filepages);
		
	def close(self,info,is_ok):
		for opage in info.object.opages:
			print opage
			opage.close();
		return Handler.close(self,info,is_ok);
		
class OFile_Viewer_Handler(Handler):
	def init(self,info):
		info.object.uiinfo=info;
		#info.ui.control.ohdf_viewer=object;
		#from detc import version;
		#info.ui.title=version;
		#print "hand init: info",info
		
	def setattr(self, info, object, name, value):
		Handler.setattr(self, info, object, name, value)
		#info.object._updated = True	
		#print "set len:",len(info.object.filepages);
		
class OTable_Spreadsheet_ModelView(Handler):
	def init(self,info):
		#print "in OTable_Spreadsheet_ModelView:"
		info.object.uiinfo=info;
		
	def setattr(self, info, object, name, value):
		Handler.setattr(self, info, object, name, value)
		#info.object._updated = True	
		#print "set len:",len(info.object.filepages);
		
#===========================================================================
# Editor Handler
#===========================================================================
		
class OGroup_Exporler_Editor_Handler(Handler):
	def init(self,info):
		info.object.uiinfo=info;
		#info.ui.control.root_hastraits=object;
		pass;
		
	def setattr(self, info, object, name, value):
		Handler.setattr(self, info, object, name, value)
		#info.object._updated = True
		#print "set len:",len(info.object.filepages);
		
	def object__fullfilename_changed(self, info):
		#print "fullfilename changed, new name:",info.object.fullfilename
        #if info.initialized:
         #   info.ui.title += "*"
		pass;
		 
	def close(self,info,is_ok):
		return Handler.close(self,info,is_ok);
		
class OTable_Spreadsheet_Editor_Handler(Handler):
	def init(self,info):
		info.object.uiinfo=info;
		#info.ui.control.root_hastraits=object;
		pass;
		
	def setattr(self, info, object, name, value):
		Handler.setattr(self, info, object, name, value)
		#info.object._updated = True
		#print "set len:",len(info.object.filepages);
		
	def object__fullfilename_changed(self, info):
		#print "fullfilename changed, new name:",info.object.fullfilename
        #if info.initialized:
         #   info.ui.title += "*"
		pass;
		 
	def close(self,info,is_ok):
		return Handler.close(self,info,is_ok);