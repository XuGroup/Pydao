from pylab import *;
from enthought.traits.api import HasTraits, List;
from pydao.ohdf import OGroup,OFile,OTable;

class OGroup_List_Viewer(HasTraits):
	# The list offiles  being browsed:
	from olist_views import get_tabbed_explorer_view;
	opages = List( OGroup );
	status_txt='status';
	traits_view=get_tabbed_explorer_view();
	#print "OGroup_List_Viewer:",traits_view
	
	def __init__(self):
		pass;
		
	def tabbed_explorer_view(self):
		from enthought.traits.ui.api import Item;
		#item=Item( 'opages',show_label = False,style= 'custom',editor=editor,padding=-15);
		#item_status=Item( 'status_txt',show_label = False,style= 'readonly',padding=-15);
		self.trait_view().menubar=self.setmenubar();
		self.trait_view().toolbar=self.settoolbar();
		#print "traits_view:",self.trait_view()
		#self.trait_view('opages',item_status)
		ok=self.configure_traits();
		self.get_uiroot().oroot=self;
		return ok;

		
	def setmenubar(self):
		pass;
		
	def settoolbar(self):
		pass;
		
	def pagenames(self):
		names=[];
		for page in self.opages:
			s=page.name.encode('ascii');
			names.append(s);
		return names;
		
	def has_page(self,absfilename):
		answer=False;
		names=self.pagenames();
		#print "names:",names
		#print "absfilename",absfilename
		if names.count(absfilename)>0:
			answer=True;
		return answer;
		
	def get_page(self,pagename):
		foundpage=None;
		if self.has_page(pagename):
			for page in self.opages:
				s=page.name.encode('ascii');
				if s==pagename:
					foundpage=page;
		return foundpage;
			
	def get_uiroot(self):
		return self.uiinfo.ui.control;
		
class OFile_List_Viewer(OGroup_List_Viewer):
	file2open = '';
	file2save = '';
	#recentfilelist=[];
	
	def __init__(self,fname=None):
		if fname is not None:
			self.open_ofile(fname);
		self.registry=HasTraits();
		self.registry.application_list=[];
		self.registry.packages=[];
		self.clipborad=HasTraits();
		self.version=None;
		import pydao,os;
		history_file_name=os.path.join(pydao.packagerootdir(),pydao.etc.history_file_name);
		self.history_file=OFile(history_file_name);
		self.history_file.open();

	def main(self):
		ok= self.tabbed_explorer_view();
		self.set_title('');
		return ok;
	
	def set_title(self,title=None):
		if self.version is not None:
			version=self.version;
		else:
			version=''
		if title is not None:
			titlestr=version+' '+title;
		else:
			titlestr=version;
		
		self.uiinfo.ui.title=titlestr;
		
	def get_title(self):
		return self.uiinfo.ui.title;
		
	def setmenubar(self):
		#from enthought.traits.ui.api import Menu
		#from wx import MenuBar
		from enthought.traits.ui.menu import Menu, MenuBar, Action;
		
		file_new = Action(name = "New",action = "do_file_new")
		file_open = Action(name = "Open",action = "do_file_open")
		file_open_recent = Action(name = "Open Recent",action = "do_file_open_recent")
		file_close = Action(name = "Close",action = "do_file_close")
		file_save = Action(name = "Save",action = "do_file_save")
		file_save_as = Action(name = "Save as",action = "do_file_save_as")

		filemenu=Menu(file_new,file_open,file_open_recent,file_close,file_save,file_save_as,name = 'File');
		
		#reg_load = Action(name = "Load preference",action = "do_reg_load")
		#reg_save = Action(name = "Save preference",action = "do_reg_save")
		#reg_config = Action(name = "Configure preference",action = "do_reg_config")
		#systemmenu=Menu(reg_load,reg_save,reg_config,name = 'System');
		self.menubar = MenuBar(filemenu);
		
		edit_refresh = Action(name = "Refresh",action = "do_refresh")
		#edit_selectall = Action(name = "Select All",action = "do_select_all")
		
		import pydao;
		if not pydao.etc.memory_mode:
			#edit_undo = Action(name = "Undo",action = "do_undo")
			#edit_redo = Action(name = "Redo",action = "do_redo")
			#edit_selectall = Action(name = "Select All",action = "do_select_all")
			#editmenu=Menu(edit_undo,edit_redo,edit_refresh,name = 'Edit');
			editmenu=Menu(edit_refresh,name = 'Edit');
			#pass;
		else:
			editmenu=Menu(edit_refresh,name = 'Edit');
		
		self.menubar.insert(1,editmenu);
		
		nav_goup = Action(name = "Go up",action = "do_go_up")
		nav_goback = Action(name = "Go back",action = "do_go_back")
		editmenu=Menu(nav_goup,nav_goback,name = 'Walk');
		self.menubar.insert(2,editmenu);
		
		tools_analyze = Action(name = "Analyze",action = "do_analyze")
		toolsmenu=Menu(tools_analyze,name = 'Tools');
		self.menubar.insert(3,toolsmenu);
		
		help_about = Action(name = "About",action = "do_about")
		helpmenu=Menu(help_about,name = 'Help');
		self.menubar.insert(4,helpmenu);
		
		return self.menubar;
		
	def settoolbar(self):
		from enthought.traits.ui.menu import Menu, ToolBar, Action;
		from enthought.pyface.api import ImageResource;
		#from dfunction import imagefilename;
		file_new = Action(name = "New",action = "do_file_new",image=ImageResource('fnew.png'))
		file_open = Action(name = "Open",action = "do_file_open",image=ImageResource('fopen.png'))
		file_close = Action(name = "Close",action = "do_file_close",image=ImageResource('fclose.png'))
		file_save = Action(name = "Save",action = "do_file_save",image=ImageResource('fsave.png'))
		go_up = Action(name = "GoUp",action = "do_go_up",image=ImageResource('go_up.png'))
		go_back = Action(name = "GoBack",action = "do_go_back",image=ImageResource('go-previous.png'))
		refresh = Action(name = "Refresh",action = "do_refresh",image=ImageResource('view-refresh.png'))
		import pydao;
		if not pydao.etc.memory_mode:
			#undo = Action(name = "Undo",action = "do_undo",image=ImageResource('edit_undo.png'))
			#redo = Action(name = "Redo",action = "do_redo",image=ImageResource('edit_redo.png'))
			#self.toolbar=ToolBar(file_new, file_open,file_close,file_save,go_up,go_back,refresh,undo,redo);
			self.toolbar=ToolBar(file_new, file_open,file_close,file_save,go_up,go_back,refresh);
		else:
			self.toolbar=ToolBar(file_new, file_open,file_close,file_save,go_up,go_back,refresh);
		return self.toolbar;
	
	def do_file_new(self):
		import pydao.etc;
		import os;
		i=0;
		filename="untitled0.hdf"
		while self.pagenames().count(filename)>0 or os.path.exists(filename):
			i=i+1;
			filename="untitled"+str(i)+".hdf";
		ofile=OFile();
		swpfilename=filename+".swp";
		ofile.name=swpfilename;
		ofile.open();
		ofile.read2memory();
		#print "new hdf",ofile.get_hdf()
		ofile.name=filename;
		if pydao.etc.memory_mode:
			ofile1=ofile.copy2mem();
			ofile1.name=filename;
			ofile.close();
			ofile=ofile1;
		self.opages.append(ofile);
		info=self.uiinfo;
		info.opages.selected=ofile;
		#ofile.get_hdf().enableUndo();
		
	def open_ofile(self,fname):
		#print "fname to load:",fname
		import os;
		import shutil;
		import pydao.etc;
		import time;
		absfname= os.path.abspath(fname)
		swpfname=absfname+".swp";
		print '--------------------'
		time0=time.time();
		print "absfname to open:",fname
		if self.has_page(absfname):
			print absfname," already loaded."
		else:
			import tables;
			print "Copying ",absfname,'to',swpfname,'...'
			#tables.copyFile(absfname,swpfname,overwrite=True);
			shutil.copy2(absfname,swpfname);
			print 'Opening the .swp file...'
			try:
				ofile=OFile(swpfname);
				ofile.open('r+');
				ofile.name=absfname;
				#ofile.get_hdf().enableUndo();
				#print ofile,ofile.hdf
			except:
				import traceback;
				traceback._exc();
			if pydao.etc.memory_mode:
				print 'Opened, copying to memory in memory mode...'
				lazy_reload=pydao.etc.globalcfg.lazy_reload;
				pydao.etc.globalcfg.lazy_reload=True;
				pydao.gohome();
				ofile1=ofile.copy2mem();
				ofile1.name=absfname
				ofile.close();
				ofile=ofile1;
				pydao.etc.globalcfg.lazy_reload=lazy_reload;
			ofile.read2memory();
			self.opages.append(ofile);
			self.uiinfo.opages.selected=ofile;
		print "Time taken:",time.time()-time0,'seconds'
		
	def do_file_open(self):
		from enthought.traits.ui.api import FileEditor,Item,View;
		view1=View(Item(name='file2open',editor=FileEditor(),style="custom"),buttons = ['OK', 'Cancel'],resizable=True,width=.5,height=.5,kind='livemodal');
		ok=self.configure_traits(view=view1);
		if ok:
			self.open_ofile(self.file2open);
			import os;
			self.history_file.set('path_open',os.path.dirname(self.file2open).encode('ascii'),flush=True);
			files_opened=self.history_file.get('files_opened');
			if files_opened is None:
				files_opened=[self.file2open.encode('ascii')];
			elif files_opened.count(self.file2open.encode('ascii'))==0:
				files_opened.append(self.file2open.encode('ascii'));
			self.history_file.set('files_opened',files_opened,flush=True);
			
	def do_file_open_recent(self):
		from enthought.traits.ui.api import EnumEditor,View,Item;
		from enthought.traits.api import Enum;
		
		files_opened=self.history_file.get('files_opened');
		#print "files_opened:",files_opened
		if files_opened is not None:
			#files_opened=[];
		#print "files_opened",files_opened
		#print "recentfilelist",self.recentfilelist
			enum=Enum(files_opened);
		#values=dict(enum);
		#values={};
		#for k in self.recentfilelist:
		#	values[k]=k;
			view1=View(Item(name='file2open',editor=EnumEditor(values=enum),style="custom"),buttons = ['OK', 'Cancel'],resizable=True,kind='livemodal');
			ok=self.configure_traits(view=view1);
			if ok:
				self.open_ofile(self.file2open);
		else:
			print "No file history."

	def do_file_close(self):
		print "click 2 close"
		info=self.uiinfo;
		selected=info.opages.selected;
		if selected is not None:
			selected.close();
			try:
				self.opages.remove(selected);
				print "File:",selected.name," closed."
				
			except:
				print "no file to close"
			#print "L opages:",len(self.opages)
			if len(self.opages)>0:
				info.opages.selected=self.opages[0];
			#print info.opages.selected.name,'is now selected.'
		else:
			print "Selected a file first !"

	def do_file_save(self,fname=None):
		import pydao;
		from pydao.tools import file_backup;
		info=self.uiinfo;
		selected=info.opages.selected;
		if selected is not None:
			import tables,os;
			swpfname=selected.name+".swp";
			absfname=selected.name;
			if fname is not None:
				absfname=fname;
			file_backup(absfname);

			if selected.is_ondisk():
			#print "selected:",selected,selected.hdf
				if fname is None or fname==selected.name:
					selected.flush();
					tables.copyFile(swpfname,absfname,overwrite=True);
					print selected.name," saved."
				#elif fname==selected.name:
				#	selected.flush();
				#	tables.copyFile(swpfname,absfname,overwrite=True);
				#	print selected.name," saved."
				else:
					#newswpfname=fname+".swp";
					tables.copyFile(swpfname,absfname,overwrite=True);
					self.do_file_close();
					self.open_ofile(fname);
					print "saved to",absfname;
			else:
				lazy_reload=pydao.etc.globalcfg.lazy_reload;
				pydao.etc.globalcfg.lazy_reload=True;
				pydao.gohome();
				if fname is None or fname==selected.name:
					selected.save2disk();
				else:
					#oldname=selected.name;
					#selected.name=fname;
					selected.save2disk();
					self.opages.remove(selected);
					self.opages.append(selected);
					#page=self.get_page(fname);
					#print "found page newname:",page;
					#page=self.get_page(oldname);
					#print "found page oldname:",page;
				import shutil;
				shutil.copy2(swpfname,absfname);
				#tables.copyFile(swpfname,absfname,overwrite=True);
				pydao.etc.globalcfg.lazy_reload=lazy_reload;
			if fname is None:
				print "Saved to",selected.name
			else:
				print "Saved to ",fname
			self.history_file.set('path_save',\
			os.path.dirname(self.file2open).encode('ascii'),flush=True);
		else:
			print "Selected a file first !"

	def do_file_save_as(self):
		from enthought.traits.ui.api import FileEditor,View,Item;
		info=self.uiinfo;
		selected=info.opages.selected;
		if selected is not None:
			self.file2save=selected.name;
			view1=View(Item(name='file2save',editor=FileEditor(),style="simple"),buttons = ['OK', 'Cancel'],resizable=True,width=.5,kind='livemodal');
			ok=self.configure_traits(view=view1);
			if ok:
				#self.file2save=str(self.file2save);
				self.do_file_save(self.file2save);
				#index=self.opages.index(selected);
				#self.opages.remove(selected);
				#self.opages.insert(index,selected);
		else:
			print "Selected a file first !"
	
	def do_go_up(self):
		explorer=self.current_explorer;
		explorer.tree_goup();
		
	def do_go_back(self):
		explorer=self.current_explorer;
		explorer.tree_goback();
		
	def do_refresh(self):
		explorer=self.current_explorer;
		explorer.refresh(True);
		
	# def do_select_all(self):
		# explorer=self.current_explorer;
		# explorer.list_selected_all();
		
	def do_about(self):
		print "pydao: python data analyzer and organizer."
		
	def do_analyze(self):
		og=self.current_explorer.get_current_ogroup();
		from analyzable import Analyzable;
		agroup=og.typecast(Analyzable());
		agroup.OnOpen();
		
	def do_undo(self):
		info=self.uiinfo;
		selected=info.opages.selected;
		selected.get_hdf().undo();
		#print "undo"
		
	def do_redo(self):
		info=self.uiinfo;
		selected=info.opages.selected;
		selected.get_hdf().redo();
		
	def get_data_of_link(self,linkstr):
		from pydao.ohdf import link_parse;
		data=None;
		if type(linkstr) is not tuple:
			link_tuple=eval(linkstr);
		else:
			link_tuple=linkstr;
		for opage in self.opages:
			if opage.name.encode('ascii')==link_tuple[0]:
				ldir,lname=link_parse(link_tuple);
				ogroup=opage.get_withpath(ldir);
				#pass;
				#for name in link_tuple[1]:
				#	data_dict[name]=ogroup.get(name);
				
				data=ogroup.get(lname);
		return data;
		
class OTable_List_Viewer(HasTraits):
	# The list offiles  being browsed:
	tablepages = List( OTable )
	table2open = '';
	table2save = '';
	recenttablelist=[];

	def __init__(self):
		self.status_txt='status'
		pass;
		
	def tabbed_spreadsheet_view(self):
		from views import get_spreadsheetview_otable;
		from enthought.traits.ui.menu import Menu, MenuBar;
		from mvc_controls import OTable_Viewer_Handler;
		expview=get_spreadsheetview_otable();
		self.setmenubar();
		self.settoolbar();
		
		self.editor=ListEditor(use_notebook=True, deletable=False, dock_style   = 'tab',export='DockWindowShell',page_name= '.tablename',view=expview);
		
		item=Item( 'tablepages',show_label = False,style= 'custom',editor=self.editor);
		item_status=Item( 'status_txt',show_label = True,style= 'readonly');
		self.tabview = View(item,item_status,width=.65,height=.65,resizable = True,kind="live",menubar = self.menubar,toolbar=self.toolbar,handler=OTable_Viewer_Handler());
		
		return self.configure_traits(view=self.tabview);
		
	def setmenubar(self):
		#from enthought.traits.ui.api import Menu
		#from wx import MenuBar
		from enthought.traits.ui.menu import Menu, MenuBar, Action;
		table_open = Action(name = "Open",action = "do_table_open")
		filemenu=Menu(table_open,name = 'Table');
		self.menubar = MenuBar(filemenu);
		
	def settoolbar(self):
		from enthought.traits.ui.menu import Menu, ToolBar, Action;
		from enthought.pyface.api import ImageResource;
		#from dfunction import imagefilename;
		table_open = Action(name = "Open",action = "do_table_open",image=ImageResource('fopen.png'))
		self.toolbar=ToolBar(table_open);
		
	def pagenames(self):
		names=[];
		for page in self.tablepages:
			s=page.name.encode('ascii');
			names.append(s);
		return names;
		
	def has_tablepage(self,absfilename):
		answer=False;
		names=self.pagenames();
		#print "names:",names
		#print "absfilename",absfilename
		if names.count(absfilename)>0:
			answer=True;
		return answer;
		
	def get_uiroot(self):
		return self.uiinfo.ui.control;
		
	def append_table(self,otable):
		self.tablepages.append(otable);
