from pylab import *;

def langevin(x):
	y = 1/tanh(x) - 1./x;
	return y;