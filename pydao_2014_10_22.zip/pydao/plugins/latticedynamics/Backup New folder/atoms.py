from pylab import *;
from pydao.ohdf import OGroup, OTable;
from functions import *;


class Atom(OGroup):
	def __init__(self,mass=1.,charge=1.,type=None,intrapos=None,coordinate='cartesian'):
		OGroup.__init__(self);
		#self.set('name',name);
		self.set('mass',mass);
		self.set('charge',charge);
		self.set('type',type);
		self.set('intrapos',array(intrapos));
		self.set('coordinate',coordinate);
		self.set('lattice_index',zeros(3));
	
	def distancefrom(self,atom2):
		dist= vlen(array(self.get('position')-array(atom2.get('position'))));
		return dist;
	
	def set_abs_intrapos(self,basis):
		import copy;
		intrapos=copy.deepcopy(self.get('intrapos'));
		coordinate=self.get('coordinate');
		if coordinate=='direct':
			abs_intrapos=zeros(3);
			for i in range(len(basis)):
				abs_intrapos=abs_intrapos+basis[i]*intrapos[i];
		else:
			abs_intrapos=copy.deepcopy(self.get('intrapos'));
		self.set('abs_intrapos',abs_intrapos);
		
	def set_position(self,basis,lattice_index=None):
		import copy;
		abs_intrapos=self.get('abs_intrapos');
		if lattice_index is None:
			lattice_index=self.get('lattice_index');
		else:
			self.set('lattice_index',lattice_index);
		position=copy.deepcopy(abs_intrapos);
		i=0;
		for i in range(len(basis)):
			position=position+lattice_index[i]*array(basis[i]);
		self.set('position',position); 

	
	def translate_cart(self,vector):
		position=self.get('position');
		position=position+vector;
		self.set('position',position);
		return position;
	
	def find_neighbor_sampleatom_1d(self,atoms,basis,katom,index,idim,nei_distance):
		import copy;
		#print self.get('name'),atom1.get('name')
		atom0=atoms.get(katom);
		atom1=atom0.copy2mem();
		#atom=atom1.copy2mem();
		nei_atom_list=[];
		dist0=self.distancefrom(atom1);
		#if idim==2:
			#print "dist0:",dist0,"nei_dist:",nei_distance
		if dist0<=nei_distance and dist0>1e-3:
			#atom.set('i'+str(idim),0)
			index1=copy.deepcopy(index);
			nei_atom_list.append((copy.deepcopy(katom),index1));
		for i in range(1,100):
			atom=atom1.copy2mem();
			lattice_index=zeros(3);
			lattice_index[idm]=i;
			atom.set_position(basis,lattice_index);
			dist=self.distancefrom(atom);
			#print "dist:",dist
			#print "dist0:",dist0
			if dist>dist0 and dist>nei_distance:
				break;
			elif dist<=nei_distance and dist>1e-3:
				#atom.set('i'+str(idim),i);
				index1=copy.deepcopy(index);
				index1[idim]=index1[idim]+i;
				nei_atom_list.append((copy.deepcopy(katom),index1));
				#print "dist:",dist,"i:",i,"idim:",idim
			dist0=dist;
		dist0=self.distancefrom(atom1);
		for i in range(-1,-100,-1):
			#print "pos0:",atom.get('position'),atom1.get('position')
			atom=atom1.copy2mem();
			lattice_index=zeros(3);
			lattice_index[idm]=i;
			atom.set_position(basis,lattice_index);
			#atom.translate_cart(basis[idim]*i);
			#print "pos1:",atom.get('position'),atom1.get('position')
			dist=self.distancefrom(atom);
			if dist>dist0 and dist>nei_distance:
				break;
			elif dist<=nei_distance and dist>1e-3:
				#atom.set('i'+str(idim),i)
				index1=copy.deepcopy(index);
				index1[idim]=index1[idim]+i;
				nei_atom_list.append((copy.deepcopy(katom),index1));
				#print "dist:",dist,"i:",i,"idim:",idim
			dist0=dist;
		#print "find ",len(nei_atom_list)," neis"
		return nei_atom_list;
		
	def find_neighbor_sampleatom_3d(self,atoms,basis,katom,index,nei_distance,pack_max_indices):
		#print self.get('name'),atom1.get('name')
		atom1=atoms.get(katom);
		nei_atom_list=[];
		nei_atom_list_1=self.find_neighbor_sampleatom_1d(atoms,basis,katom,index,0,nei_distance);
		#print "find x ",len(nei_atom_list_1)," neis"
		for nei_atom in nei_atom_list_1:
			nei_list=self.find_neighbor_sampleatom_1d(atoms,basis,nei_atom[0],nei_atom[1],1,nei_distance);
			nei_atom_list=nei_atom_list+nei_list;
		nei_atom_list_1=nei_atom_list;
		nei_atom_list=[];
		#print "find x y",len(nei_atom_list_1)," neis"
		for nei_atom in nei_atom_list_1:
			nei_list=self.find_neighbor_sampleatom_1d(atoms,basis,nei_atom[0],nei_atom[1],2,nei_distance);
			nei_atom_list=nei_atom_list+nei_list;
		#print "find x y z",len(nei_atom_list)," neis"
		return nei_atom_list;
		
	def find_neighbor_sampleatom(self,atom,atomname,basis,index0,nei_distance,pack_max_indices):
		atom_list=[];
		atom1=atom.copy2mem();
		for i0 in range(-pack_max_indices[0],pack_max_indices[0]+1):
			for i1 in range(-pack_max_indices[1],pack_max_indices[1]+1):
				for i2 in range(-pack_max_indices[2],pack_max_indices[2]+1):
					index=index0+array([i0,i1,i2]);
					atom1.set_position(basis,index);
					dist=self.distancefrom(atom1);
					if dist<=nei_distance and dist>1e-3:
						atom_list.append((atomname,index));
						#print atomname,index
		return atom_list;
		
		
	def find_nearest_index(self,atom,basis):
		import copy;
		n1=1;
		n2=3;
		atom1=atom.copy2mem();
		delta=self.get('position')-atom1.get('position');
		frac_index=find_lattice_index(basis,delta);
		int_index=[int(frac_index[0]),int(frac_index[1]),int(frac_index[2])];
		int_index=array(int_index);
		lattice_index0=int_index-n1;
		lattice_index1=copy.deepcopy(lattice_index0);
		atom1.set_position(basis,lattice_index0);
		#atom1.index2position(basis);
		dist0=self.distancefrom(atom1);
		#print "index:",frac_index,int_index,lattice_index0
		for i0 in range(lattice_index1[0], lattice_index1[0]+n2):
			for i1 in range(lattice_index1[1], lattice_index1[1]+n2):
				for i2 in range(lattice_index1[2], lattice_index1[2]+n2):
					lattice_index=array([i0,i1,i2]);
					#atom1=atom.copy2mem();
					atom1.set_position(basis,lattice_index);
					#atom1.index2position(basis);
					dist=self.distancefrom(atom1);
					if dist<dist0:
						#print lattice_index,dist,dist0,vlen(delta)
						dist0=dist;
						lattice_index0=copy.deepcopy(lattice_index);
		return lattice_index0;
		
	def register_nearest_kind_tb(self,atoms,basis):
		from tables import StringCol,Int16Col;
		Record_Desc={};
		Record_Desc['name']=StringCol(itemsize=16);
		Record_Desc['i0']=Int16Col();
		Record_Desc['i1']=Int16Col();
		Record_Desc['i2']=Int16Col();
		nearest_table=OTable();
		nearest_table.create(self,'nearest_table',Record_Desc);
		row=nearest_table.row();
		for k in atoms.keys():
			print "-",k,
			atom=atoms.get(k);
			lattice_index0=self.find_nearest_index(atom,basis);
			row['name']=k;
			row['i0']=lattice_index0[0];
			row['i1']=lattice_index0[1];
			row['i2']=lattice_index0[2];
			row.append();
			print lattice_index0
		#raw_input();
		nearest_table.flush();
		
	def register_nearest_kind(self,atoms,basis):
		from tables import StringCol,Int16Col;
		from pydao.math import WorkSheet;
		ws=WorkSheet();
		#nearest_table=OTable();
		#nearest_table.create(self,'nearest_table',Record_Desc);
		row={};
		for k in atoms.keys():
			print "-",k,
			atom=atoms.get(k);
			lattice_index0=self.find_nearest_index(atom,basis);
			row['name']=k;
			row['i0']=lattice_index0[0];
			row['i1']=lattice_index0[1];
			row['i2']=lattice_index0[2];
			ws.append_row(row);
			print lattice_index0
		self.set('nearest_table',ws);
		#raw_input();
		#nearest_table.flush();
		
	def register_neighbor_tb(self,atoms,basis,nei_distance,pack_max_indices):
		from tables import StringCol,Int16Col;
		nei_atom_list=[];
		Record_Desc={};
		Record_Desc['name']=StringCol(itemsize=16);
		Record_Desc['i0']=Int16Col();
		Record_Desc['i1']=Int16Col();
		Record_Desc['i2']=Int16Col();
		nearest_table=self.get('nearest_table');
		for row in nearest_table.get_ondisk().iterrows():
			atomname=row['name'];
			index=array([row['i0'],row['i1'],row['i2']]);
			atom=atoms.get(atomname);
			atom_list=self.find_neighbor_sampleatom(atom,atomname,basis,index,nei_distance,pack_max_indices);
			nei_atom_list=nei_atom_list+atom_list;
		nei_table=OTable();
		nei_table.create(self,'neighbor_table',Record_Desc);
		row=nei_table.row();
		for atomtuple in nei_atom_list:
			row['name']=atomtuple[0];
			row['i0']=atomtuple[1][0];
			row['i1']=atomtuple[1][1];
			row['i2']=atomtuple[1][2];
			row.append();
		nei_table.flush();
		return nei_table.get_ondisk().nrows;
		#print "atom:",self.get('type')
		#print "#nei",len(nei_atom_list)
		
	def register_neighbor(self,atoms,basis,nei_distance,pack_max_indices):
		from tables import StringCol,Int16Col;
		from pydao.math import WorkSheet;
		#ws=WorkSheet();
		nei_atom_list=[];
		#Record_Desc={};
		#Record_Desc['name']=StringCol(itemsize=16);
		#Record_Desc['i0']=Int16Col();
		#Record_Desc['i1']=Int16Col();
		#Record_Desc['i2']=Int16Col();
		nearest_table=self.get('nearest_table');
		for irow in range(nearest_table.nrows()):
			row=nearest_table.get_row(irow);
			atomname=row['name'];
			index=array([row['i0'],row['i1'],row['i2']]);
			atom=atoms.get(atomname);
			atom_list=self.find_neighbor_sampleatom(atom,atomname,basis,index,nei_distance,pack_max_indices);
			nei_atom_list=nei_atom_list+atom_list;
		nei_table=WorkSheet();
		#nei_table.create(self,'neighbor_table',Record_Desc);
		#row=nei_table.row();
		row={};
		for atomtuple in nei_atom_list:
			row['name']=atomtuple[0];
			row['i0']=atomtuple[1][0];
			row['i1']=atomtuple[1][1];
			row['i2']=atomtuple[1][2];
			nei_table.append_row(row);
		self.set('neighbor_table',nei_table);
		#nei_table.flush();
		return nei_table.nrows();
		#print "atom:",self.get('type')
		#print "#nei",len(nei_atom_list)

		
	def neighbor_matPhi_tb(self,lattice,atoms=None,basis=None):
		if atoms is None:
			atoms=lattice.get('atoms');
		if basis is None:
			basis=lattice.get('basis');
		neighbor_table=self.get('neighbor_table');
		nei_distance=lattice.get('nei_distance');
		
		matPhi_list=[];
		ndims=len(basis);
		for row in neighbor_table.get_ondisk().iterrows():
			nei=atoms.get(row['name']);
			nei=nei.copy2mem();
			lattice_index=array([row['i0'],row['i1'],row['i2']]);
			nei.set_position(basis,lattice_index);
			strength=lattice.find_force_constant(self,nei,forcetype="Coulomb");
			delta=nei.get('position')-self.get('position');
			#delta_len=sqrt(sum(delta**2));
			phi=zeros([ndims,ndims]);
			for idim in range(ndims):
				ei=zeros(3);
				ei[idim]=1.;
				if vlen(delta)==0:
					cosi=1.;
				else:
					cosi=vcos(delta,ei);
				for jdim in range(ndims):
					ej=zeros(3);
					ej[jdim]=1.;
					if vlen(delta)==0:
						cosj=1.;
					else:
						cosj=vcos(delta,ej);
					phi[idim][jdim]=-strength*cosi*cosj;
			matPhi_list.append(phi);
		self.set('matPhi_list',array(matPhi_list));
		return matPhi_list;
		
	def neighbor_matPhi(self,lattice,atoms=None,basis=None):
		if atoms is None:
			atoms=lattice.get('atoms');
		if basis is None:
			basis=lattice.get('basis');
		neighbor_table=self.get('neighbor_table');
		nei_distance=lattice.get('nei_distance');
		
		matPhi_list=[];
		ndims=len(basis);
		for irow in range(neighbor_table.nrows()):
			row=neighbor_table.get_row(irow);
			nei=atoms.get(row['name']);
			nei=nei.copy2mem();
			lattice_index=array([row['i0'],row['i1'],row['i2']]);
			nei.set_position(basis,lattice_index);
			strength=lattice.find_force_constant(self,nei,forcetype="Coulomb");
			delta=nei.get('position')-self.get('position');
			#delta_len=sqrt(sum(delta**2));
			phi=zeros([ndims,ndims]);
			for idim in range(ndims):
				ei=zeros(3);
				ei[idim]=1.;
				if vlen(delta)==0:
					cosi=1.;
				else:
					cosi=vcos(delta,ei);
				for jdim in range(ndims):
					ej=zeros(3);
					ej[jdim]=1.;
					if vlen(delta)==0:
						cosj=1.;
					else:
						cosj=vcos(delta,ej);
					phi[idim][jdim]=-strength*cosi*cosj;
			matPhi_list.append(phi);
		self.set('matPhi_list',array(matPhi_list));
		return matPhi_list;

	def plot3d(self,color=None,text=None,textwidth=None):
		atom=self;
		position=atom.get('position');
		x,y,z=position;
		if color is None:
			color1=atom.get('color');
		if color1 is None:
			frac=(-atom.get('charge')+5)/8.;
			if frac>1:
				frac=1;
			elif frac<0:
				frac=0;
			color1=frac2color(frac);

		sc_factor=1.0-0.1/100*atom.get('mass');
		from enthought.mayavi import mlab;
		mlab.points3d([x], [y], [z],color=color1,scale_factor=sc_factor);
		
		if text is not None and type(text) is list:
			textstr='';
			for k in text:
				textstr=textstr+";"+k
				v=self.get(k);
				if v is not None:
					textstr=textstr+":"+str(v);
				
			if textwidth is None:
				textwidth=0.1;
			if len(textstr)>1:
				mlab.text(x,y,textstr,z=z,width=textwidth);
