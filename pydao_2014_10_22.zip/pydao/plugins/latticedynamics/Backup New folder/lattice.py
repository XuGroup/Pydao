from pylab import *;
from pydao.ohdf import OGroup;
from pydao.ohdfvi import Application; 
from functions import *;
from enthought.traits.api import List;
#from tables import *;

from lattice_controls import *;

class Lattice(OGroup,Application):
	#work_space_list=List( OGroup );
	def __init__(self,atoms=None,basis=None,force_constant_list=None):
		OGroup.__init__(self);
		Application.__init__(self);
		self.set('atoms',atoms);
		self.set('basis',basis);
		self.set('force_constant_list',force_constant_list);
		
	def contextmenu(self,parentmenu):
		#Application.contextmenu(self,parentmenu);
		import wx;
		item=parentmenu.Append(wx.NewId(),"Analyze","Analyze");
		parentmenu.Bind(wx.EVT_MENU,self.OnAnalyze,item);
		
		item=parentmenu.Append(wx.NewId(),"Open","Open");
		parentmenu.Bind(wx.EVT_MENU,self.OnOpen,item);
		
		item=parentmenu.Append(wx.NewId(),"Open Group","Open Group");
		parentmenu.Bind(wx.EVT_MENU,self.OnOpenGroup,item);
		
		item=parentmenu.Append(wx.NewId(),"Open Group List","Open List");
		parentmenu.Bind(wx.EVT_MENU,self.OnOpenGroupList,item);
		
		#item=parentmenu.Append(wx.NewId(),"filter_atoms_primitivecell","filter_atoms_primitivecell");
		#parentmenu.Bind(wx.EVT_MENU,self.On_filter_atoms_primitivecell,item);
		
#=====================================methods========================================
	lazy=False;

	def OnAnalyze(self,event):
		from lattice_views import lattice_analysis_view;
		view=lattice_analysis_view(self);
		#view=lattice_program_view_modify(self);
		self.configure_traits(view=view);
		
	def OnOpen(self,event):
		from lattice_views import lattice_program_view_modify;
		#view=lattice_program_view(self);
		view=lattice_program_view_modify(self);
		#print "OnOpen",view
		self.configure_traits(view=view);
		
	def OnOpenGroup(self,event):
		from lattice_views import lattice_program_group_view_modify;
		#view=lattice_program_view(self);
		view=lattice_program_group_view_modify(self);
		#print "OnOpen",view
		self.configure_traits(view=view);
		
	def OnOpenGroupList(self,event):
		from lattice_views import lattice_program_group_list_view_modify;
		#view=lattice_program_view(self);
		view=lattice_program_group_list_view_modify(self);
		#print "OnOpen",view
		self.configure_traits(view=view);
		
	def import_basis_fromcif(self,cif_filename):
		from ciffile import CifFile,ReadCif
		#cif_filename=self.cif_filename;
		if cif_filename.find('\\')!=-1:
			cif_filename="file:\\\\"+cif_filename;
		cf=ReadCif(cif_filename);
		block=cf.first_block();
		la=eval(block['_cell_length_a']);
		lb=eval(block['_cell_length_b']);
		lc=eval(block['_cell_length_c']);
		alpha=eval(block['_cell_angle_alpha'])/180.*pi;
		beta=eval(block['_cell_angle_beta'])/180.*pi;
		gamma=eval(block['_cell_angle_gamma'])/180.*pi;
		print la,lb,lc,alpha,beta,gamma
		b0=[la,0,0];
		b1=[lb*cos(gamma),lb*sin(gamma),0];
		b20=lc*cos(alpha);
		b21=(cos(beta)*lb*lc-b1[0]*b20)/b1[1];
		b22=sqrt(lc**2-b20**2-b21**2);
		b2=[b20,b21,b22];
		# if abs(cos(alpha))<1e-5 and abs(cos(beta))<1e-5:
			# b2=[0,0,lc];
		# else:
			# t1=(cos(alpha)*cos(gamma)-cos(beta))/sin(gamma);
			# t2=cos(alpha);
			# theta=arcsin((t1*t1+t2*t2)**0.5);
			# if abs(theta-pi/2)<1e-5:
				# b2=[0,0,lc];
			# else:
				# phisin=arcsin(t1/sin(theta));
				# phicos=arccos(t2/sin(theta));
				# if phicos<0:
					# phi=phisin+pi;
				# else:
					# phi=phisin;
				# b2=[lc*sin(theta)*cos(phi),lc*sin(theta)*sin(phi),lc*cos(theta)];
		basis=array([b0,b1,b2]);
		self.set('basis_imported_fromcif',basis);
			
	def import_atoms_fromxyz(self,xyz_filename):
		from atoms import Atom;
		from pydao.ohdf import OGroup;
		import pydao.chemistry as chem;
		atoms=OGroup();
		f = open(xyz_filename, "r");
		for line in f:
			line_strs=line.split();
			print "line_strs",line_strs
			if len(line_strs)==4:
				pos_str=str(line_strs[1:]).replace("'","");
				print pos_str
				try:
					atom_pos=array(eval(pos_str));
				except:
					atom_pos=None;
				if atom_pos is not None:
					print "atom_pos:",atom_pos
					atom_type=line_strs[0];
					mass=chem.PTable[atom_type]['mass'];
					charge=chem.PTable[atom_type]['charge'];
					atom=Atom(mass,charge,atom_type,atom_pos);
					i=0;
					atomstr=atom_type+str(i);
					atom0=atoms.get(atomstr);
					while atom0 is not None:
						i=i+1;
						atomstr=atom_type+str(i);
						atom0=atoms.get(atomstr);
					atoms.set(atomstr,atom);
		f.close();
		self.set('atom_imported_fromxyz',atoms);
		
	def filter_atoms_primitivecell(self,atoms=None,basis=None):
		if atoms is None:
			atoms=self.get('atoms');
		if basis is None:
			basis=self.get('basis');
		
		print "copy atoms...",atoms,basis
		newatoms=atoms.copy2mem();
		for k in newatoms.keys():
			print "atom:",k,
			atom=newatoms.get(k);
			direct=self.cartesian2direct(atom.get('position'),basis=basis);
			outofbox=False;
			for b in direct:
				if b>=0.99 or b<-0.01:
					outofbox=True;
			if outofbox:
				newatoms.remove(k);
				print "removed"
			else:
				print
		self.set('newatoms',newatoms);
		
	def cal_kbasis(self,basis=None):
		if basis is None:
			basis=self.get('basis');
		self.cal_basis3d(basis);
		basis3d=self.get('basis3d');
		vol=volume(basis3d);
		k0max=2*pi*vXprod(array(basis3d[1]),basis3d[2])/vol;
		k1max=2*pi*vXprod(basis3d[2],array(basis3d[0]))/vol;
		k2max=2*pi*vXprod(basis3d[0],array(basis3d[1]))/vol;
		self.set('kbasis3d',array([k0max,k1max,k2max]));
		if len(basis)<3:
			self.set('kbasis',self.get('kbasis3d')[0:len(basis)]);
		else:
			self.set('kbasis',self.get('kbasis3d'));
					
	def cal_basis3d(self,basis):
		if len(basis)==3:
			basis3d=basis;
		elif len(basis)==1:
			basis3d=list(basis)+[(0,1,0),(0,0,1)];
		elif len(basis)==2:
			base3=vXprod(basis[0],basis[1]);
			base3=vnorm(base3);
			basis3d=list(basis)+[base3];
			basis3d=array(basis3d);
		self.set('basis3d',basis3d);

	def direct2cartesian(self,direct,basis=None):
		if basis is None:
			basis=self.get('basis');
		cartpos=zeros(3);
		for i in range(3):
			cartpos=cartpos+direct[i]*basis[i];
			#print "cartpos",cartpos
		return cartpos;
			
	def cartesian2direct(self,cartesian,basis=None):
		if basis is None:
			basis=self.get('basis');
		return find_lattice_index(basis,cartesian);
			
	def centerofmass(self):
		atoms=self.get('atoms');
		cm=zeros(3);
		mass=0;
		for k in atoms.keys():
			atom=atoms.get(k);
			mass=mass+atom.get('mass');
			cm=cm+atom.get('position')*atom.get('mass');
		cm=cm/mass;
		return cm;
			
	def find_pack_max_indices_withindistance(self,nei_distance):
		basis=self.get('basis');
		intercept0=faceintercept(basis[0],[basis[1],basis[2]],nei_distance);
		intercept1=faceintercept(basis[1],[basis[0],basis[2]],nei_distance);
		intercept2=faceintercept(basis[2],[basis[1],basis[0]],nei_distance);
		index0=int(ceil(abs(intercept0)/vlen(basis[0])));
		index1=int(ceil(abs(intercept1)/vlen(basis[1])));
		index2=int(ceil(abs(intercept2)/vlen(basis[2])));
		max_indices=array([index0,index1,index2]);
		return max_indices;
			
	def find_pack_max_indices_withinparallelepiped(self,basis1):
		basis=self.get('basis');
		a0=zeros(3);
		for i0 in [0,1]:
			for i1 in [0,1]:
				for i2 in [0,1]:
					b=i0*basis1[0]+i1*basis1[1]+i2*basis1[2];
					a=cartesian2direct(basis,b);
					for i in [0,1,2]:
						if a[i]>a0[i]:
							a0[i]=a[i];
		max_indices=a0;
		return max_indices;
			
	def register_nearest_kind(self,atoms=None,basis=None):
		if atoms is None:
			atoms=self.get('atoms');
		if basis is None:
			basis=self.get('basis');
		for k in atoms.keys():
			print k
			#if k=='Bi1':
			atom=atoms.get(k);
			atom.register_nearest_kind(atoms,basis);
		print "registered nearest kind"

	def register_neighbors(self,atoms=None,basis=None,nei_distance=None):
		if nei_distance is None:
			nei_distance=self.get('nei_distance');
		if atoms is None:
			atoms=self.get('atoms');
		if basis is None:
			basis=self.get('basis');
		pack_max_indices=self.find_pack_max_indices_withindistance(nei_distance);
		print "pack_max_indices:",pack_max_indices
		from pydao.tools import Progress_Teller;
		pt=Progress_Teller(len(atoms.keys()));
		iatom=0;
		for k in atoms.keys():
			pt.tell(iatom);
			iatom=iatom+1;
			atom=atoms.get(k);
			nei=atom.register_neighbor(atoms,basis,nei_distance,pack_max_indices);
			print "atom name:",k
			print "number of neis:",nei
			
	def fill_parallepiped(self,basis1):
		max_indices=find_pack_max_indices_withinparallelepiped(basis1);
		print "pack_max_indices:",pack_max_indices
		atoms=self.get('atoms');
		basis=self.get('basis');
		for k in atoms.keys():
			atom=atoms.get(k);
			nei=atom.register_neighbor(atoms,basis,nei_distance,pack_max_indices);
			print "atom name:",k
			print "number of neis:",nei
		
	def find_force_constant(self,atom1,atom2,forcetype='Coulomb'):
		force_constant_list=self.get('force_constant_list');
		strength=None;
		#force=None;
		if forcetype=='Coulomb':
			distance=atom1.distancefrom(atom2);
			strength=atom1.get('charge')*atom2.get('charge')/distance**3;
			strength=abs(strength);
		else:
			for force_constant in force_constant_list:
				atom_type1=force_constant.atomtypes[0];
				atom_type2=force_constant.atomtypes[1];
				distance=atom1.distancefrom(atom2);
				#print "atom1:",atom_type1,
				#print "atom2:",atom_type2,
				if (atom_type1==atom1.get_type() and atom_type2==atom2.get_type()) or (atom_type1==atom2.get_type() and atom_type2==atom1.get_type()):
				#print "distance:",distance
					if abs(distance-force_constant.distance)<1e-3*force_constant.distance:
						if type(force_constant.strength) is not str:
							strength=force_constant.strength;
						elif force_constant.strength=='Coulomb':
							strength=atom1.charge*atom2.charge/distance**3;
							strength=abs(strength);
				
		if strength is None:
			print "wrong! no foce constant found!"
			print "atom1:",atom1.get_type(),
			print "atom2:",atom2.get_type(),
			#print "distance:",distance
			print "\n"
			atom1.disp();
			atom2.disp();
		return strength;
			
	def plot3d_basis(self,basis=None,color=(0,0,1)):
		if basis is None:
			basis=self.get('basis')
		for b in basis:
			b0=zeros(3);
			plot3d_vector(b0,b,color);

	def plot3d_primitive_cell(self,basis=None,color=(0,1,0)):
			#self.plot3d_basis();
		if basis is None:
			basis=self.get('basis');
		b0=zeros(3);
			
		plot3d_vector(b0,basis[0],color,mode='2ddash');
		plot3d_vector(basis[1],basis[0],color,mode='2ddash');
		plot3d_vector(basis[2],basis[0],color,mode='2ddash');
		plot3d_vector(basis[1]+basis[2],basis[0],color,mode='2ddash');
		
		plot3d_vector(b0,basis[1],color,mode='2ddash');
		plot3d_vector(basis[0],basis[1],color,mode='2ddash');
		plot3d_vector(basis[2],basis[1],color,mode='2ddash');
		plot3d_vector(basis[0]+basis[2],basis[1],color,mode='2ddash');
		
		plot3d_vector(b0,basis[2],color,mode='2ddash');
		plot3d_vector(basis[1],basis[2],color,mode='2ddash');
		plot3d_vector(basis[0],basis[2],color,mode='2ddash');
		plot3d_vector(basis[1]+basis[0],basis[2],color,mode='2ddash');
			
	def plot3d_Brillouin_zone(self,kbasis=None,color=(0,1,0)):
			#self.plot3d_basis();
		if kbasis is None:
			kbasis=self.get('kbasis');
		basis=kbasis;
		b0=(-basis[0]-basis[1]-basis[2])/2;
			
		plot3d_vector(b0,basis[0],color,mode='2ddash');
		plot3d_vector(basis[1]+b0,basis[0],color,mode='2ddash');
		plot3d_vector(basis[2]+b0,basis[0],color,mode='2ddash');
		plot3d_vector(basis[1]+basis[2]+b0,basis[0],color,mode='2ddash');
		
		plot3d_vector(b0,basis[1],color,mode='2ddash');
		plot3d_vector(basis[0]+b0,basis[1],color,mode='2ddash');
		plot3d_vector(basis[2]+b0,basis[1],color,mode='2ddash');
		plot3d_vector(basis[0]+basis[2]+b0,basis[1],color,mode='2ddash');
		
		plot3d_vector(b0,basis[2],color,mode='2ddash');
		plot3d_vector(basis[1]+b0,basis[2],color,mode='2ddash');
		plot3d_vector(basis[0]+b0,basis[2],color,mode='2ddash');
		plot3d_vector(basis[1]+basis[0]+b0,basis[2],color,mode='2ddash');
		
	def plot3d_kbasis(self,color=(1,0,0)):
		for b in self.get('kbasis'):
			b0=zeros(3);
			plot3d_vector(b0,b,color);

	def plot3d_atoms(self,atoms=None,color=None,text=None,textwidth=None):
		if atoms is None:
			atoms=self.get('atoms');
		import copy;
		for k in atoms.keys():
			atom=atoms.get(k);
			text1=copy.deepcopy(text);
			if text is not None:
				if text1.count('name')==1:
					text1.remove('name');
					text1.append(k);
			#print k,text1
			atom.plot3d(color,text=text1,textwidth=textwidth);

	def plot3d_nearest(self,atom_name,color=None):
		atoms=self.get('atoms');
		basis=self.get('basis');
		atom=atoms.get(atom_name);
		atom.plot3d(textwidth=atom_name);
		nearest_table=atom.get('nearest_table');
		for row in nearest_table.get_ondisk().iterrows():
			nei=atoms.get(row['name']);
			nei=nei.copy2mem();
			lattice_index=array([row['i0'],row['i1'],row['i2']]);
			nei.set_position(basis,lattice_index);
			nei.plot3d();
				
	def plot3d_neighbors(self,atom_name,color=None):
		atoms=self.get('atoms');
		basis=self.get('basis');
		atom=atoms.get(atom_name);
		atom.plot3d(textwidth=atom_name);
		neighbor_table=atom.get('neighbor_table');
		for row in neighbor_table.get_ondisk().iterrows():
			nei=atoms.get(row['name']);
			nei=nei.copy2mem();
			lattice_index=array([row['i0'],row['i1'],row['i2']]);
			nei.set_position(basis,lattice_index);
			nei.plot3d();

	def unify_coordinates(self,atoms=None,basis=None):
		if atoms is None:
			atoms=self.get('atoms');
		if basis is None:
			basis=self.get('basis');
		for k in atoms.keys():
			atom=atoms.get(k);
			if atom.get('lattice_index') is not None:
				atom.set_abs_intrapos(basis);
				atom.set_position(basis);
			
	def translate_atoms(self,atoms,basis,displacement,coordinate,displace_intrapos):
		from pydao.ohdf import get_empty_instance;
		#basis=self.get('basis');
		if coordinate[0]=="direct":
			cart_disp=self.direct2cartesian(displacement,basis);
		else:
			cart_disp=displacement;
		print "displacement:",displacement
		print "cart_disp:",cart_disp
		newatoms=get_empty_instance(atoms);
		for k in atoms.keys():
			atom=atoms.get(k);
			newatom=atom.copy2mem();
			newatom.translate_cart(cart_disp);
			newatoms.set(k,newatom);
			if displace_intrapos:
				newatom.set('intrapos',newatom.get('position'));
				newatom.set('coordinate','cartesian');
		return newatoms;
			
	def DynamicMat(self,veck):
		nei_distance=self.get('nei_distance');
		atoms=self.get('atoms');
		basis=self.get('basis');
			
		ndims=len(basis);
		natoms=len(atoms.keys());
		Dynamicmat=zeros([ndims*natoms,ndims*natoms],'complex');
		#self.neighbor_matPhi_withindistance(nei_distance);
		iatom=-1;
		for katom in atoms.keys():
			iatom=iatom+1;
			atom1=atoms.get(katom);
			#print atom.name
			atomname1=katom;
			atommass1=atom1.get('mass');
			neighbor_table=atom1.get('neighbor_table');
			matPhi_list=atom1.get('matPhi_list');
			phi00=zeros([ndims,ndims],'complex');
				
			i_nei=-1;
			#print katom, matPhi_list.shape
			for irow in range(neighbor_table.nrows()):
				row=neighbor_table.get_row(irow);
			#for row in neighbor_table.get_ondisk().iterrows():
				i_nei=i_nei+1;
				atomname2=row['name'];
				nei=atoms.get(atomname2);
				#print i_nei
				#print i_nei
				matPhi=matPhi_list[i_nei];
				phi00=phi00-matPhi;
				lattice_index=array([row['i0'],row['i1'],row['i2']]);
				atommass2=nei.get('mass');
				jatom=atoms.keys().index(atomname2);
				delta=zeros(3);
				for dim in range(ndims):
					delta=delta+array(basis[dim])*lattice_index[dim];
				deltadotk=vdotprod(delta,veck);
				jj=complex(0,1);
				for i_v in range(ndims):
					for i_h in range(ndims):
						temp=matPhi[i_v][i_h]*exp(jj*deltadotk)/sqrt(atommass1*atommass2);
						Dynamicmat[iatom*ndims+i_v][jatom*ndims+i_h]=Dynamicmat[iatom*ndims+i_v][jatom*ndims+i_h]+temp;

			for i_v in range(ndims):
				for i_h in range(ndims):
					Dynamicmat[iatom*ndims+i_v][iatom*ndims+i_h]+=phi00[i_v][i_h]/atommass1;
		#print "Dynamicmat:\n",real(Dynamicmat)
		return Dynamicmat;
		
	#=====================================================
	# Heisenberg model
	#=====================================================
	def find_exchange_interaction(self,atom1,atom2):
		sz1=atom1.get('sz');
		sz2=atom2.get('sz');
		strength=sz1*sz2;
		return strength;
		
	def NNIsingHamiltonian(self,strength=1,atoms=None):
		import pydao.physics.Heisenberg_model as hm;
		if atoms is None:
			atoms=self.get('atoms');
		atomkeys=atoms.keys();
		neighbor_table_list=[];
		for katom in atomkeys:
			atom1=atoms.get(katom);
			neighbor_table=atom1.get('neighbor_table');
			record=[];
			for row in neighbor_table.get_ondisk().iterrows():
				atomname=row['name'];
				i_atom=atomkeys.index(atomname);
				record.append(i_atom);
			neighbor_table_list.append(record);
		hmo=hm.H_Model(len(atomkeys),0.5,neighbor_table_list);
		IMat=strength*hmo.H_mat();
		#print hmat
		SzMat=hmo.Sz_mat();
		#print szmat
		return (IMat,SzMat);
		
	def ET(self,TRange,strength=1,atoms=None):
		IMat,SzMat=self.NNIsingHamiltonian(strength,atoms);
		ERange=TRange-TRange;
		i=-1;
		for T in TRange:
			i=i+1;
			ERange[i]=diag(IMat*exp(-IMat/T)).sum()/diag(exp(-IMat/T)).sum();
		return ERange;
		
	def MT(self,T,BRange,strength=1,atoms=None):
		IMat,SzMat=self.NNIsingHamiltonian(strength,atoms);
		SzRange=BRange-BRange;
		i=-1;
		for B in BRange:
			i=i+1;
			HMat=IMat-SzMat*B;
			SzRange[i]=diag(SzMat*exp(-HMat/T)).sum()/diag(exp(-HMat/T)).sum();
		return SzRange;

	#=====================================================
	# Madelong energy
	#=====================================================
	def Madelung(self,atoms=None):
		from pydao.math import vlen;
		from pydao.tools import Progress_Teller;
		if atoms is None:
			atoms=self.get('atoms');
		atomkeys=atoms.keys();
		basis=self.get('basis');
		
		neighbor_table_list=[];
		Energy=0;
		pt=Progress_Teller(len(atomkeys));
		iatom=0;
		for katom in atomkeys:
			pt.tell(iatom);
			iatom=iatom+1;
			atom1=atoms.get(katom);
			pos1=atom1.get('position');
			charge1=atom1.get('charge');
			neighbor_table=atom1.get('neighbor_table');
			for irow in range(neighbor_table.nrows()):
				row=neighbor_table.get_row(irow);
				atomname=row['name'];
				atom2=atoms.get(atomname).copy2mem();
				lattice_index=array([row['i0'],row['i1'],row['i2']]);
				atom2.set_position(basis,lattice_index)
				pos2=atom2.get('position');
				charge2=atom2.get('charge');
				#print charge1,charge2,pos1,pos2
				Energy=Energy+charge1*charge2/vlen(pos1-pos2);
		print "Madelung Energy:",Energy;
		return Energy;
