from pydao.ohdfvi import OGroup_Property_ModelView;
from pylab import *;

class RHEED_ModelView(OGroup_Property_ModelView):
	def init_info(self,info):
		OGroup_Property_ModelView.init_info(self,info);
		self.preprocess(self.model);
		
	def preprocess(self,model):
		from enthought.traits.api import Button;
		model.bu_rotate_kspace=Button();
		model.bu_cal_list_theta_phi=Button();
		model.bu_cal_cal_list_theta_phi_island=Button();
		model.bu_cal_spectrum=Button();
		model.bu_plot3d_rheed=Button();
		model.bu_plot3d_rheed_island=Button();
		model.bu_plot_mode=Button();
		model.bu_plot_primitive_cell=Button();
		model.bu_plot_polarization=Button();
		model.bu_plot_spectrum=Button()
	
	def _bu_rotate_kspace_fired(self,app):
		config=app.get('config');
		phi0=config.get('phi0');
		theta0=config.get('theta0');
		hklface=config.get('hklface');
		hklbeam=config.get('hklbeam');
		result=app.rotate_kspace(theta0,phi0,hklface,hklbeam);
		app.set('result',result);
		
	def _bu_cal_list_theta_phi_fired(self,app):
		config=app.get('config');
		Nk=config.get('Nk');
		Ebeam=config.get('Ebeam');
		theta0=config.get('theta0');
		marker=config.get('marker');
		result=app.cal_list_theta_phi(Nk,Ebeam,theta0,marker);
		app.set('result',result);
		
	def _bu_cal_cal_list_theta_phi_island_fired(self,app):
		config=app.get('config');
		Nk=config.get('Nk');
		Ebeam=config.get('Ebeam');
		theta0=config.get('theta0');
		result_island=app.cal_list_theta_phi_island(Nk,Ebeam,theta0);
		app.set('result_island',result_island);
		
	def _bu_plot3d_rheed_fired(self,app):
		from enthought.mayavi import mlab;
		result=app.get('result');
		config=app.get('config');
		k_list=result.get('k_list');
		theta_list=result.get('theta_list');
		phi_list=result.get('phi_list');
		k_origin_eward=result.get('k_origin_eward');
		k_in=result.get('k_in');
		theta0=config.get('theta0');
		
		#Here is the k points
		for i in range(len(k_list)):
			mlab.points3d([k_list[i][0]], [k_list[i][1]], [k_list[i][2]],color=(0,1,0),scale_factor=1);
			theta=theta_list[i];
			phi=phi_list[i];
			sphere_project_x=k_in*cos(theta-theta0)*cos(phi)+k_origin_eward[0];
			sphere_project_y=k_in*cos(theta-theta0)*sin(phi)+k_origin_eward[1];
			sphere_project_z=k_in*sin(theta-theta0)+k_origin_eward[2];
			mlab.points3d([sphere_project_x], [sphere_project_y], [sphere_project_z],color=(1,0,0),scale_factor=1,mode='2dcross');
			mlab.plot3d([k_list[i][0],sphere_project_x],[k_list[i][1],sphere_project_y],[k_list[i][2],sphere_project_z],line_width=4);
			
		# here is the Eward sphere
		R=k_in;
		NR=100;
		dR=R/NR;
		xsp=arange(-R,R+dR,dR);
		ysp=arange(-R,R+dR,dR);
		zsp=zeros([len(xsp),len(ysp)]);
		ix=-1;
		for x in xsp:
			ix=ix+1;
			iy=-1;
			for y in ysp:
				iy=iy+1;
				R0=(x**2+y**2)**0.5;
				if R>R0:
					zsp[ix,iy]=(R**2-R0**2)**0.5;
				else:
					zsp[ix,iy]=0;
		
		mlab.surf(xsp+k_origin_eward[0], ysp+k_origin_eward[1], zsp+k_origin_eward[2], opacity=0.5,color=(0,0,1));
		
		# Here is the white circle
		anglerange=arange(0,2*pi,pi/1000);
		x_list=zeros(len(anglerange));
		y_list=zeros(len(anglerange));
		i=-1;
		for angle in anglerange:
			i=i+1;
			x_list[i]=k_in*sin(angle);
			y_list[i]=k_in*cos(angle);
		mlab.plot3d(x_list+k_origin_eward[0],y_list+k_origin_eward[1],zeros(len(anglerange)),line_width=2);
		
	def _bu_plot3d_rheed_island_fired(self,app):
		from enthought.mayavi import mlab;
		result_island=app.get('result_island');
		k_list=result_island.get('k_list');
		k_origin_eward=result_island.get('k_origin_eward');
		k_in=result_island.get('k_in');
		
		for i in range(len(k_list)):
			mlab.points3d([k_list[i][0]], [k_list[i][1]], [k_list[i][2]],color=(0,1,0),scale_factor=1);
		
		R=k_in;
		NR=100;
		dR=R/NR;
		xsp=arange(-R,R+dR,dR);
		ysp=arange(-R,R+dR,dR);
		zsp=zeros([len(xsp),len(ysp)]);
		ix=-1;
		for x in xsp:
			ix=ix+1;
			iy=-1;
			for y in ysp:
				iy=iy+1;
				R0=(x**2+y**2)**0.5;
				if R>R0:
					zsp[ix,iy]=(R**2-R0**2)**0.5;
				else:
					zsp[ix,iy]=0;
		
		mlab.surf(xsp+k_origin_eward[0], ysp+k_origin_eward[1], zsp+k_origin_eward[2], opacity=0.5,color=(0,0,1));
		
		anglerange=arange(0,2*pi,pi/1000);
		x_list=zeros(len(anglerange));
		y_list=zeros(len(anglerange));
		i=-1;
		for angle in anglerange:
			i=i+1;
			x_list[i]=k_in*sin(angle);
			y_list[i]=k_in*cos(angle);
		mlab.plot3d(x_list+k_origin_eward[0],y_list+k_origin_eward[1],zeros(len(anglerange)),line_width=2);