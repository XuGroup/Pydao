from pydao.math.worksheet_controls import WorkSheet_ModelView;
from pylab import *;

class EAS_WorkSheet_ModelView(WorkSheet_ModelView):
	def init_info(self,info):
		WorkSheet_ModelView.init_info(self,info);
		#self.preprocess(self.model);
		print "info:",info
		
	def On_filter(self,info=None):
		import pydao,sys;
		from pydao.ohdf import OGroup;
		from pydao.ohdfvi import OGroup_Analyzer_Group_List_ModelView;
		if info is not None:
			work_sheet=self.model;
			func_name=sys._getframe().f_code.co_name
			ana_method=eval("self."+func_name);
			ana_name=func_name;
			
			work_space_list=work_sheet.work_space_list;
			print work_space_list,type(work_space_list)
			found_work_space=False;
			for ws in work_space_list:
				if ws.name==ana_name:
					found_work_space=True;
			if found_work_space:
				print "found_work_space",ana_name
			else:
				work_space=OGroup_Analyzer_Group_List_ModelView().get_default_work_space(work_sheet);
#=============================================================================================
# make change between the two lines
				work_space.get('config').remove('_0group');
				#work_space.get('config').remove('inputs');
				#work_space.remove('intermediate');
				
				parameters=OGroup();
				var_list=['AOT_440','AOT_500','_440_675Angstrom',\
				'Date_dd_mm_yy_','Time_hh_mm_ss_'];
				parameters.set('var_list',var_list)
				
				condition_list=["self.test_month(Date_dd_mm_yy_,'==5')"];
				parameters.set('condition_list',condition_list);
				work_space.get('config').set('_2analysis',parameters);
				
# make change between the two lines
#==============================================================================================
				work_space.name=ana_name;
				work_sheet.work_space_list.selected=work_space;
				work_sheet.work_space_list.append(work_space);
				work_sheet.ana_method_list.append(ana_method);
		else:
			work_sheet=self.model;
			#group=work_sheet.current_group;
			work_space=work_sheet.work_space_list.selected;
			parameters=work_space.get('config').get('_2analysis');
			
			condition_list=parameters.get('condition_list');
			var_list=parameters.get('var_list');
			
			work_sheet.init_chosen_indices();
			work_sheet.multi_filter_index(var_list,condition_list);
			
			from pydao.math import WorkSheet;
			ws1=WorkSheet();
			ws1=work_sheet.savechosen2worksheet(var_list,ws1);
			ready4output=work_space.get('data').get('_3ready4output');
			ready4output.set('ws1',ws1);
			