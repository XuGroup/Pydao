from pylab import *;
from pydao.ohdf import OGroup;
from functions import *;
#from tables import *;

def eos_data_analysis_view_modify(eos_ana):
	from enthought.traits.ui.api import \
	Item,Group,Tabbed,VGroup,HGroup,View,\
	ArrayEditor,ButtonEditor,CheckListEditor,BooleanEditor,FileEditor,TextEditor;
	from eos_data_analysis_controls import EOS_Data_Analysis_ModelView;
	import pydao;
	from pydao.ohdfvi import analyzable_view_modify;
	
	print eos_ana
	title=str(eos_ana.get_link());
	handler=EOS_Data_Analysis_ModelView(eos_ana);
	view=analyzable_view_modify(eos_ana);
	view.handler=handler;
	view.title=title;
	
	menubar=view.menubar;
	menubar=eos_data_analysis_menubar(menubar);
	toolbar=eos_data_analysis_toolbar(view.toolbar);
	
	view.menubar=menubar;
	view.toolbar=toolbar;
	return view;

def eos_data_analysis_menubar(menubar):
	from enthought.traits.ui.menu import Menu, MenuBar, Action;
	
	aeronnet_batchimport= Action(name = "Batch Import",action = "On_Aeronet_BatchImport")
	aeronnet_monthlymean= Action(name = "Batch Monthly Mean",action = "On_Aeronet_MonthlyMean")
	aeronnet_hourlymean= Action(name = "Batch Hourly Mean",action = "On_Aeronet_HourlyMean")
	aeronetmenu=Menu(aeronnet_batchimport,aeronnet_monthlymean,aeronnet_hourlymean,name = 'Aeronet');
	
	menubar.append(aeronetmenu);
	return menubar;

def eos_data_analysis_toolbar(toolbar=None):
	from enthought.traits.ui.menu import Menu, ToolBar, Action;
	from enthought.pyface.api import ImageResource;
	disp = Action(name = "Filter",action = "On_filter")
	#if toolbar is None:
	#	toolbar=ToolBar(disp);
	#else:
	#	toolbar.append(disp);
	return toolbar;