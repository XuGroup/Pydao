from pylab import *;
#from functions import *;
lazy=False;

def init_chosen_indices(self,shape=None):
	from pydao.ohdf import dget,dset;
	if shape is None:
		shape=dget(self,'shape');
		#print "shape:",shape
		if shape is None or len(shape)==0:
			self.data_list=self.data_survey();
			self.shape=self.data_shape(self.data_list);
		for idim in range(len(self.shape)):
			ndim=self.shape[idim];
			x=ones(ndim);
			dset(self,'I_'+str(idim)+"_chosen",x==x);
			#x=ones(self.shape)
			#self.element_chosen=x==x;
		if len(self.shape)==2:
			x=ones(self.shape);
			dset(self,'IJ_0_1_chosen',x==x);
		elif len(self.shape)==3:
			for idim in range(len(self.shape)):
				dim_shape=range(len(self.shape));
				lshape=list(self.shape);
				lshape.remove(lshape[idim]);
				x=ones(lshape);
			#dimstr=str(range(len(lshape)));
				dim_shape=range(len(self.shape));
				dim_shape.remove(idim)
				dimstr=str(dim_shape);
				dimstr=dimstr.replace('[','');
				dimstr=dimstr.replace(']','');
				dimstr=dimstr.replace(',','');
				dimstr=dimstr.replace(' ','_');
				chosen_str='IJ_'+dimstr+"_chosen";
				chosen_indices=x==x;
			#print "chosen_str",chosen_str,chosen_indices.shape
				dset(self,chosen_str,chosen_indices);
			x=ones(self.shape);
			name='IJK_0_1_2_chosen';
			dset(self,name,x==x);
	

def multi_filter_index(self,datapathlist,condition_list):
	for condition in condition_list:
		print "filter condition:",condition
		tof=self.filter_index(datapathlist,condition);
		if tof is None:
			print "variable not found in condition",condition
	print "Data filtered."
			
def filter_index(self,datapathlist,condition):
	from pydao.ohdf import dget,dset;
	from ..ohdf import natural_name;
	#import eas_hdf_filter_functions;
	#reload(eas_hdf_filter_functions);
	#from eas_hdf_filter_functions import *;
	tof=True;
	for idim in range(len(self.shape)):
		I=arange(self.shape[idim]);
		cmd="I_"+str(idim)+"=I";
		exec(cmd);
			
	if type(datapathlist) is list:
		for i in range(len(datapathlist)):
			datapath=datapathlist[i];
			if self.alias.has_key(datapath):
				datapath=self.alias[datapath];
			name=natural_name(datapath);
			cmd=name+"=self.get_data_array(datapath,True)";
			print "listcmd",cmd;
			exec(cmd);
			if eval(name+" is None"):
				return None;
	elif type(datapathlist) is dict:
		for k in datapathlist.keys():
			datapath=datapathlist[k];
			alias=k;
			cmd=k+"=self.get_data_array(datapath,True)";
			#print "datapath:",datapath
			#print "aliascmd",cmd,datapath
			exec(cmd);
			self.alias[k]=datapath;
			#cmd="print type("+k+")"
			#print cmd;
			exec(cmd);
			#print "type:",type(v1)
			if eval(name+" is None"):
				return None;
	cmd="tof="+condition;
	exec(cmd);
	#print "tof:",tof,tof.shape
		
	if len(tof.shape)==1:
		for idim in range(len(self.shape)):
			if len(tof)==self.shape[idim]:
				name="I_"+str(idim)+"_chosen";
				chosen=dget(self,name);
				#print "chosen:",chosen
				#print "tof:",tof
				chosen=logical_and(tof,chosen);
				dset(self,name,chosen);
	elif len(tof.shape)==2:
		if len(self.shape)==2:
			name='IJ_0_1_chosen';
			chosen=dget(self,name);
			#print "chosen",type(chosen),chosen.shape
			chosen=logical_and(tof,chosen);
			dset(self,name,chosen);
		elif len(self.shape)>2:
			for idim in range(len(self.shape)):
				lshape=list(self.shape);
				lshape.remove(lshape[idim]);
				if tof.shape==tuple(lshape):
				#dimstr=str(range(len(lshape)));
					dim_shape=range(len(self.shape));
					dim_shape.remove(idim)
					dimstr=str(dim_shape);
					dimstr=dimstr.replace('[','');
					dimstr=dimstr.replace(']','');
					dimstr=dimstr.replace(',','');
					dimstr=dimstr.replace(' ','_');
					name='IJ_'+dimstr+"_chosen";
					chosen=dget(self,name);
				#print name,chosen.shape,tof.shape
					chosen=logical_and(tof,chosen);
					dset(self,name,chosen);
	elif len(tof.shape)==3:
		name="IJK_0_1_2_chosen"
		chosen=dget(self,name);
		#print "chosen:",chosen
		chosen=logical_and(tof,chosen);
		dset(self,name,chosen);
	return tof;
	
def savechosen2worksheet(self,pathlist,work_sheet=None):
	from pydao.tools import Progress_Teller;
	if work_sheet is None:
		from pydao.math import WorkSheet;
		work_sheet=WorkSheet();
		
	if len(self.shape)==1:
		print "saving 1d data in a fast way."
		self.savechosen2worksheet_fast1d(pathlist,work_sheet);
	else:
		pt=Progress_Teller(self.shape[0]);
		for i in range(self.shape[0]):
			pt.tell(i);
			self.savechosen2worksheet_idims([i],pathlist,work_sheet);
		#print "\n"
	return work_sheet;
	
def savechosen2worksheet_fast1d(self,pathlist,work_sheet):
	from pydao.ohdf import dget,dset;
	row={};
	chosen=dget(self,'I_0_chosen');
	#print "chosen:",len(chosen),chosen.all()
	indices=array(range(self.shape[0]));
	for path in pathlist:
		path1=self.interp_alias(path);
		data_array=self.get_data_array(path1);
		if data_array is None:
			print "Error, data path",path1,'not found.'
		else:
			data=data_array[chosen];
			row[path]=data;
		#print path,data
	row['I_0']=indices[chosen];
	#print "row['I_0']",row['I_0']
	work_sheet.append_row(row);
	
def savechosen2worksheet_idims(self,idims,pathlist,work_sheet):
	from pydao.ohdf import dget,dset;
	#from work_sheet import WorkSheet;
	row={};
	i=idims[0];
	if len(idims)==1:
		chosen=dget(self,'I_0_chosen');
		if chosen[idims[0]]:
			if len(self.shape)==1:
				for path in pathlist:
					path1=self.interp_alias(path);
					data_array=self.get_data_array(path1);
					data=data_array[idims[0]];
					row[path]=data;
				row['I_0']=i;
				work_sheet.append_row(row)
			else:
				for j in range(self.shape[len(idims)]):
					self.savechosen2worksheet(idims+[j],pathlist,work_sheet);
	elif len(idims)==2:
		chosen1=dget(self,'I_1_chosen');
		chosen2=dget(self,'IJ_0_1_chosen');
		#print "chosen1",chosen1
		#print "chosen2",chosen2
		i=idims[0];
		j=idims[1];
		if chosen1[j] and chosen2[i][j]:
			if len(self.shape)==2:
				for path in pathlist:
					path1=self.interp_alias(path);
					data_array=self.get_data_array(path1);
					#data=data_array[idims[0]];
					if len(data_array.shape)==2:
						data=data_array[i][j];
					elif data_array.shape[0]==self.shape[0]:
						data=data_array[i];
					elif data_array.shape[0]==self.shape[1]:
						data=data_array[j];
					row[path]=data;
				row['I_0']=i;
				row['I_1']=j;
				work_sheet.append_row(row)
			else:
				for k in range(self.shape[len(idims)]):
					self.savechosen2worksheet(idims+[k],pathlist,work_sheet);
	elif len(idims)==3:
		chosen1=dget(self,'I_2_chosen');
		chosen21=dget(self,'IJ_0_2_chosen');
		chosen22=dget(self,'IJ_1_2_chosen');
		chosen3=dget(self,'IJK_0_1_2_chosen');
		i=idims[0];
		j=idims[1];
		k=idims[2];
		if chosen1[k] and chosen3[i,j,k] and chosen21[i,k] and chosen22[j,k]:
			if len(self.shape)==3:
				for path in pathlist:
					path1=self.interp_alias(path);
					data_array=self.get_data_array(path1);
					data=data_array[idims[0]];
					if len(data_array.shape)==3:
						data=data_array[i][j][k];
					else:
						for idim in range(3):
							lshape=list(self.shape);
							lshape.remove(lshape[idim]);
							if data_array.shape==tuple(lshape):
								if idim==0:
									data=data_array[j][k];
								elif idim==1:
									data=data_array[i][k];
								elif idim==2:
									data=data_array[i][j];
							elif len(data_array.shape)==1:
								if	data_array.shape[0]==self.shape[idim]:
									data=data_array[idims[idim]];
					row['I_0']=i;
					row['I_1']=j;
					row['I_2']=k;
					#print "data:",data,type(data),data.shape
					print i,j,k
					row[path]=data;
				work_sheet.append_row(row)
			else:
				for i in range(self.shape[len(idims)]):
					self.savechosen2worksheet(idims+[i],pathlist,work_sheet);
					
def data_survey(self,path=None):
	import copy;
	data_intro={}; 
	# here we assume the simplest case: data set is a work_sheet
	for col_name in self.col_names():
		col=self.get_col(col_name);
		if col is None:
			print "None col_name:",col_name
			data=None;
			data_intro[col_name]=();
		else:
			data=col.get('data');
			data_intro[col_name]=data.shape;
	#print "data_intro:",data_intro
	return data_intro;
	
def data_shape(self,dintro=None):
	shape=None;
	if dintro is None:
		dintro=self.data_survey();
	ndim=0;
	for k in dintro.keys():
		v=dintro[k];
		toassign=True;
		if len(v)>=ndim :
			if self.Ndim is not None and len(v)>self.Ndim:
				toassign=False;
		if toassign:
			shape=v;
			ndim=len(v);
			#print "shape,ndim:",shape,ndim
	print "data shape:",shape
	return shape;

def get_data_array(self,data_desc,copy2mem=False):
	# here we assume the simplest case: data set is a work_sheet
	#print "data_desc:",data_desc
	col=self.get_col(data_desc);
	if col is not None:
		data=col.get('data');
	else:
		data=None;
	return data;
	
def interp_alias(self,varname):
	if self.alias.has_key(varname):
		path=self.alias[varname];
	else:
		path=varname;
	return path;