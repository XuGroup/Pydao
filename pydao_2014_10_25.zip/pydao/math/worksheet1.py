from pylab import *;
from ..ohdf import OGroup;
from ..ohdf import Application;


class WorkSheet(OGroup,Application):
	def __init__(self):
		OGroup.__init__(self);
		OGroup.set(self,'columns',OGroup());
		OGroup.set(self,'chosen',[]);
		
	def contextmenu(self,parentmenu):
		import wx;
		item=parentmenu.Append(wx.NewId(),"TableView","TableView");
		parentmenu.Bind(wx.EVT_MENU,self.OnTableView,item);
		
	def OnTableView(self):
		from pydao.ohdfvi import OTable_Viewer;
		viewer=OTable_Viewer(self);
		viewer.main();
		
	def set_col(self,name,col):
		columns=self.get('columns');
		columns.set(name,col);
		
	def del_col(self,name):
		columns=self.get('columns');
		columns.remove(name);
		chosen=self.get('chosen');
		if chosen.count(name)>0:
			chosen.remove(name);
			self.set('chosen',chosen);
		
	def set_coordinate(self,name,coordinate):
		columns=self.get('columns');
		col=columns.get(name);
		col.set('coordinate',coordinate);
		
	def get_corrdinate(self,coordinate):
		col=None;
		co_name=self.find_chosen_coordinate(coordinate);
		if co_name is not None:
			columns=self.get('columns');
			col=columns.get(co_name);
		return col;
		
	def get_nrows(self):
		columns=self.get('columns');
		nrows=0;
		for k in columns.keys():
			col=columns.get(k);
			L=len(col.get('data'));
			if L>nrows:
				nrows=L;
		return nrows;
	
	def find_col_of_coordinate(self,coordinate):
		col_list=None;
		columns=self.get('columns');
		for k in columns.keys():
			col=columns.get(k);
			coord_str=col.get('coordinate');
			if coordinate==coord_str:
				col_list.append(col);
		return col_list;
	
	def find_chosen_coordinate(self,coordinate):
		col1=None;
		columns=self.get('columns');
		chosen=self.get('chosen')
		for k in chosen:
			col=columns.get(k);
			coord_str=col.get('coordinate');
			if coordinate==coord_str:
				col1=col;
		return col1;
		
	def select(self,name):
		columns=self.get('columns');
		found=False;
		for k in columns.keys():
			if k==name:
				chosen=self.get('chosen');
				if chosen.count(name)==0:
					col=columns.get(k);
					coordinate=col.get('coordinate');
					co_name=find_col_of_coordinate(coordinate);
					if co_name is not None:
						chosen.remove(co_name);
					chosen.append(name);
					found=True;
		if not found:
			print name,"not found";
		return found;
		
	def deselect(self,name):
		found=False;
		chosen=self.get('chosen');
		if chosen.count(name)>0:
			chosen.remove(name);
			self.set('chosen',chosen);
			found=True;
		return found;
		
	def deselect_all(self,name):
		self.set('chosen',[]);
		
	def export_ascii(self,filename):
		columns=self.get('columns');
		f=open(filename,'w');
		for k in columns.keys():
			f.write(k+"\t");
		f.write("\n");
		for irow in range(self.get_nrows()):
			for k in columns.keys():
				col=columns.get(k);
				data=col.get('data');
				if len(data)>irow:
					f.write(str(data[irow])+"\t");
				else:
					f.write('-'+"\t");
			f.write("\n");
		f.close();
		print "WorkSheet exported to:",filename;
		
class WorkSheet_Column(OGroup):
	def __init__(self,data=None):
		OGroup.__init__(self);
		if data is None:
			OGroup.set(self,'data',array([]));
		else:
			OGroup.set(self,'data',array(data));
		OGroup.set(self,'unit',None);
		OGroup.set(self,'label','');
		OGroup.set(self,'coordinate','y');
	
class Xy_Discret(WorkSheet):
	def __init__(self):
		WorkSheet.__init__(self);
		
class Xyz_Discret(Xy_Discret):
	def __init__(self):
		Xy_Discret.__init__(self);

	def mesh_indices(self,x_mesh,y_mesh):
		from functions import xyz2index;
		x=self.get_coordinate('x');
		y=self.get_coordinate('y');
		z=self.get_coordinate('z');
		xnew,ynew,znew=xyz2index(x,y,z,x_mesh,y_mesh);
		return xnew,ynew,znew;
		