from pylab import *;
from enthought.traits.api import HasTraits;
import wx;
from ..ohdfvi import SpreadSheet_Viewer;

#===================================================================================================
#                Viewer for 
#===================================================================================================

class WorkSheet_Viewer(SpreadSheet_Viewer):
	def __init__(self,object,worksheet,col_names,title=None):
		SpreadSheet_Viewer.__init__(self,object,worksheet,col_names,title);
