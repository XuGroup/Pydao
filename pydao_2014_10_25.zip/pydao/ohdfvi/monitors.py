from pylab import *;
from enthought.traits.api import HasTraits;

class Monitor_to_Fix_TextEditor(HasTraits):
	def __init__(self,obj):
		from ..ohdf.functions import dget,dset,dkeys,isnumeric;
		self.dictlist2correct_namelist=[];
		self.str2correct_namelist=[];
		self.array2correct_namelist=[];

		for k in dkeys(obj):
			v=dget(obj,k);
				
			if (type(v) is dict) or v is None:
				self.dictlist2correct_namelist.append(k);
			elif type(v) is list:
				#print "found list:",k,v
				self.dictlist2correct_namelist.append(k);
			elif type(v) is tuple:
				#print "found list:",k,v
				self.dictlist2correct_namelist.append(k);
			elif type(v) is ndarray:
				if v.shape>2:
					self.array2correct_namelist.append(k);
			elif isnumeric(v):
				self.dictlist2correct_namelist.append(k);
			elif type(v) is str:
				self.str2correct_namelist.append(k);
				
	def correct(self,obj,namelist=None):
		from ..ohdf.models import OGroup; 
		from ..ohdf.functions import dget,dset,isnumeric,dkeys;
		
		if namelist is None:
			namelist=dkeys(obj);
		else:
			v=dget(obj,namelist[0]);
			#print namelist,v
			
		for k in self.dictlist2correct_namelist:
			v=dget(obj,k);
			if type(v) is unicode and namelist.count(k)>0:
				if v!='':
					try:
						v=eval(str(v));
						dset(obj,k,v);
					except:
						pass;
				#print "corrected dict/list:",k,v,type(v)
			
		for k in self.str2correct_namelist:
			v=dget(obj,k);	
			if type(v) is unicode and namelist.count(k)>0:
				v=v.encode('ascii');
				dset(obj,k,v);
				
		for k in self.array2correct_namelist:
			v=dget(obj,k);
			if type(v) is unicode and namelist.count(k)>0:
				v=v.encode('ascii');
				#print "v:",v
				if v!='':
					try:
						v=eval(v);
						v=array(v);
						dset(obj,k,v);
					except:
						pass;

