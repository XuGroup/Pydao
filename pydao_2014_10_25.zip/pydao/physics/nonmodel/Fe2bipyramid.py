import pydao
from pylab import *;
import pydao.math;
reload(pydao.math);
from pydao.physics.wavefunctions import Atomic_WaveFunction;
reload(pydao.physics.wavefunctions);
from pydao.physics.wavefunctions import Atomic_WaveFunction;
import pydao.math as pmath;

def V(x,y,z):
	h=0.251e-10;
	a=3.441e-10;
	e=1.6e-19;
	#r=array([x,y,z]);
	r1=array([0,a*3**0.5/3,-h]);
	r2=array([a/2,-a*3**0.5/6,-h]);
	r3=array([-a/2,-a*3**0.5/6,-h]);
	r4=array([0,0,2.209e-10]);
	r5=array([0,0,1.950e-10]);
	#print r.shape,r1.shape,x.shape,y.shape,z.shape
	v=1/((r1[0]-x)**2+(r1[1]-y)**2+(r1[2]-z)**2)**0.5;
	v=v+1/((r2[0]-x)**2+(r2[1]-y)**2+(r2[2]-z)**2)**0.5;
	v=v+1/((r3[0]-x)**2+(r3[1]-y)**2+(r3[2]-z)**2)**0.5;
	v=v+1/((r4[0]-x)**2+(r4[1]-y)**2+(r4[2]-z)**2)**0.5;
	v=v+1/((r5[0]-x)**2+(r5[1]-y)**2+(r5[2]-z)**2)**0.5;
	#v=v+1/pmath.vlen(r-r2);
	#v=v+1/pmath.vlen(r-r3);
	#v=v+1/pmath.vlen(r-r4);
	#v=v+1/pmath.vlen(r-r5);
	v=-v*2*e**2*9e9;
	return v;
	
	
a1=Atomic_WaveFunction(1,3,2,-2);
a2=Atomic_WaveFunction(1,3,2,2);
b=a1.innerproduct(a2);
#print "inner product:",b
#print "inner product/pi/4",b/pi/4

H=zeros([5,5]);
for i in range(5):
	phi_i=Atomic_WaveFunction(8,3,2,i-2);
	for j in range(5):
		ph_j=Atomic_WaveFunction(8,3,2,j-2);
		H[i,j]=phi_i.innerproduct(ph_j,[V]);
		
E,V=eigh(H)
print "E:\n",E
print "V:\n",V
print "diff(E) (eV)\n",diff(E)/1.6e-19