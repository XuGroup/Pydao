from pylab import *;
from pydao.ohdf import OGroup,isnumeric;
import pydao.math,copy;
from qmvariable import WaveFunction, Operator;

class Base_Xyz(OGroup):
	def __init__(self):
		#OGroup.__init__(self);
		self.set2xyzzero();
	
	def __call__(self,x,y,z):
		value=1.*x*y*z/x/y/z;
		wfunction=self.get('xyzfun');
		if wfunction is not None:
			value=value*wfunction(x,y,z);
		return value;
		
	def xyzpara_get(self,name):
		xyzparas=self.get('xyzparas');
		return xyzparas.get(name);
		
	def xyzpara_set(self,name,value):
		xyzparas=self.get('xyzparas');
		xyzparas.set(name,value);
		return;
		
	def xyzpara_keys(self):
		xyzparas=self.get('xyzparas');
		return xyzparas.keys();
		
	def set2xyzzero(self):
		self.set('xyzfun',0);
		self.set('xyzparas',OGroup());
		
	# def set2xyzindentity(self):
		# self.set('xyzfun',1);
		
	# def isxyzidentity(self):
		# answer=False;
		# if self.get('xyzfun')==1:
			# answer=True;
		# return answer;
		
	def qmvcopy(self,qmv=None):
		if qmv is None:
			qmv=Base_Xyz();
		qmv.set('xyzfun',self.get('xyzfun'));
		return qmv;
		
	def info(self,indent=0):
		print indent*"|_","<Base_Xyz>"
		print indent*"|_",
		if self.qmvkind()=='base':
			print "xyz function:",self.get('xyzfun')
		
	def basemultiply_xyz(self,multiplier):
		# print "in Base_Xyz multiply"
		# Here the coefficient of the "multiplier" is inherited.
		# The coefficient of the "self" is taken care of in the baseopwfmultiply() method in qmvariable.py
		self_fun=self.get('xyzfun');
		multiplier_fun=multiplier.get('xyzfun');
		new_fun=lambda x,y,z:self_fun(x,y,z)*multiplier_fun(x,y,z);
		
		new_funobj=multiplier.qmvcopy();
		#new_funobj.turnbase();
		new_funobj.set('xyzfun',new_fun);
		# print "new_funobj before invalidate:"
		#new_funobj.info();
		if isinstance(multiplier,Base_Sym):
			new_funobj.invalidatesym();
		#new_funobj.function_modified();
		# print "new_funobj after invalidate:"
		#new_funobj.info();
		return new_funobj;

	def baseiproduct_xyz(self,wf):
		# print "in Base_Xyz->baseiproduct_xyz:"
		# print wf
		# wf.info();
		if isinstance(wf,Base_Xyz):
			r_max=self.rrange();
			# print "r_max:",r_max
			xmin=-r_max;
			xmax=r_max;
			ymin=-r_max;
			ymax=r_max;
			zmin=-r_max;
			zmax=r_max;
			Np=self.xyzpara_get('Np');
			if Np is None:
				Np=20;
			dx=1.*(xmax-xmin)/(Np-1);
			dy=1.*(ymax-ymin)/(Np-1);
			dz=1.*(zmax-zmin)/(Np-1);
			x, y, z = mgrid[xmin:xmax:Np*1j,ymin:ymax:Np*1j,zmin:zmax:Np*1j];
			self_fun=self.get('xyzfun');
			wf_fun=wf.get('xyzfun');
			self_fun_xyz=self_fun(x,y,z);
			wf_fun_xyz=wf_fun(x,y,z);
			product=(self_fun_xyz*conjugate(wf_fun_xyz)).sum()*dx*dy*dz;
			# print "selfmax:",self_fun_xyz.max()
			# print "wfmax:",wf_fun_xyz.max();
			# print "product:",product
		return product;
		
	def base_braopket_mate_xyz(self,bra,ket,Np):
		bra_fun=bra.get('xyzfun');
		ket_fun=ket.get('xyzfun');
		op_fun=self.get('xyzfun');
			
		# print "rpeaks",bra.rpeak(),ket.rpeak()
		# print "r_sigma",bra.rspread(),ket.rspread()
		
		r_max=self.rrange();
		
		xmin=-r_max;
		xmax=r_max;
		ymin=-r_max;
		ymax=r_max;
		zmin=-r_max;
		zmax=r_max;
						
		#print r_max,Np
		dx=1.*(xmax-xmin)/(Np-1);
		dy=1.*(ymax-ymin)/(Np-1);
		dz=1.*(zmax-zmin)/(Np-1);
		x,y,z= mgrid[xmin:xmax:Np*1j,ymin:ymax:Np*1j,zmin:zmax:Np*1j];
		
		mate=0;
		gket=ket_fun(x,y,z);
		gop=op_fun(x,y,z);
		gbra=bra_fun(x,y,z);
		I=isfinite(gop);
		num_grid=conjugate(gbra[I])*gop[I]*gket[I];
		mate=num_grid.sum()*(dx*dy*dz);		
		return mate;
	
	def rpeak(self):
		return 1;
		
	def rspread(self):
		return 1;
		
	def rrange(self):
		rmax=self.xyzpara_get('rrange');
		if rmax is None:
			rmax=self.rpeak()+2.*self.rspread();
		return rmax;
	
	def isosurface(self,xmin=None,xmax=None,ymin=None,ymax=None,zmin=None,zmax=None,Np=20,Ns=5):
		from  enthought.mayavi import mlab;
		if xmin is None:
			r_scale=self.rrange();
			xmin=-r_scale;
			xmax=r_scale;
			ymin=-r_scale;
			ymax=r_scale;
			zmin=-r_scale;
			zmax=r_scale;
		x, y, z = mgrid[xmin:xmax:Np*1j,ymin:ymax:Np*1j,zmin:zmax:Np*1j];
		s=real(self.__call__(x,y,z));
		src = mlab.pipeline.scalar_field(s);
		smax=s.max();
		smin=s.min();
		ds=(smax-smin)/(Ns+1);
		values=arange(smin,smax+ds,ds);
		mlab.pipeline.iso_surface(src, contours=list(values), opacity=0.3);
		return s,x,y,z;
		
class Base_Mat(OGroup):
	def __init__(self):
		#OGroup.__init__(self);
		self.set2matzero();
		
	def set2matzero(self):
		self.set('matrix',matrix([0]));
	
	def qmvcopy(self,qmv=None):
		#print "in Base_Mat qmvcopy:"
		if qmv is None:
			qmv=Base_Mat();
		mat=self.get('matrix');
		#print "self mat:",mat;
		mat=matrix(array(mat));
		qmv.set('matrix',mat);
		#print "qmv mat:",qmv.get('matrix');
		return qmv;
		
	def info(self,indent=0):
		print indent*"|_","<Base_Mat>"
		print indent*"|_",
		if self.qmvkind()=='base':
			print "matrix:",str(self.get('matrix')).replace("\n","")
		
	def basemultiply_mat(self,multiplier):
		#print "in Base_Mat multiply"
		# Here the coefficient of the "multiplier" is inherited.
		# The coefficient of the "self" is taken care of in the baseopwfmultiply() method in qmvariable.py
		self_mat=self.get('matrix');
		matfun_mat=multiplier.get('matrix');
		#print "self:",self_mat
		#print "multiplier:",matfun_mat
		new_matrix=self_mat*matfun_mat;
		#print "new mat:",new_matrix
		
		new_matobj=multiplier.qmvcopy();
		#new_matobj.turnbase();
		new_matobj.set('matrix',new_matrix);
		#print "multiplier info:",multiplier.info();
		#print "new_matobj info:",new_matobj.info();
		return new_matobj;
		
	def spinop2mat(self,soperator):
		if soperator=="Sp":
			mat=matrix([[0,1.],[0,0]]);
		elif soperator=="Sm":
			mat=matrix([[0,0],[1.0,0]]);
		elif soperator=="Sz":
			mat=matrix([[1,0],[0,-1]])*0.5;
		elif soperator=="Sx":
			mat=(matrix([[0,1.],[0,0]])+matrix([[0,0],[1.0,0]]))/2;
		elif soperator=="Sy":
			mat=(matrix([[0,1.],[0,0]])-matrix([[0,0],[1.0,0]]))/2j;
		#self.set('soperator',soperator);
		return mat;
	
	def hassamemat(self,wf):
		bra=self.get('matrix');
		ket=wf.get('matrix');
		answer=(bra==ket).all();
		return answer;
	
	def baseiproduct_mat(self,wf):
		if isinstance(wf,Base_Mat):
			bra=self.get('matrix');
			ket=wf.get('matrix');
			product=transpose(bra)*ket;
			product=array(product)[0][0];
		return product;
		
class Base_Sym(OGroup):
	def __init__(self):
		#OGroup.__init__(self);
		self.set('symparas',OGroup());
		#self.invalidatesym();
		
	def invalidatesym(self):
		self.sympara_set('invalidsym',True);
		#self.set('symparas',OGroup());
		
	def isvalidsym(self):
		answer=True;
		#if len(self.sympara_keys())==0:
		if self.sympara_get('invalidsym')==True:
			answer=False;
		return answer;
		
	def sympara_get(self,name):
		symparas=self.get('symparas');
		return symparas.get(name);
		
	def sympara_set(self,name,value):
		symparas=self.get('symparas');
		symparas.set(name,value);
		return;
		
	def sympara_keys(self):
		symparas=self.get('symparas');
		return symparas.keys();
	
	def qmvcopy(self,qmv=None):
		#print "in Base_Sym qmvcopy"
		if qmv is None:
			qmv=Base_Sym();
		qmv.set('symparas',OGroup());
		#qmv.invalidatesym();
		for k in self.sympara_keys():
			v=self.sympara_get(k);
			qmv.sympara_set(k,v);
			#print "k,v",k,v
		return qmv;
		
	def info(self,indent=0):
		print indent*"|_","<Base_Sym>"
		print indent*"|_",
		if self.qmvkind()=='base':
			for k in self.sympara_keys():
				v=self.sympara_get(k);
				print k,":",v,",",
			print
		return;
			
	def isidentical_sym(self,bsym):
		answer=True;
		for k in self.sympara_keys():
			self_v=self.sympara_get(k);
			bsym_v=bsym.sympara_get(k);
			if self_v!=bsym_v:
				answer=False;
		return answer;
		
#############################
class OnePWaveFunction_Xyz(WaveFunction,Base_Xyz):
	def __init__(self):
		WaveFunction.__init__(self);
		Base_Xyz.__init__(self);
		
	def set2zero(self):
		self.set2qmvzero();
		self.set2xyzzero();
		return;

	def __call__(self,x,y,z):
		wf_subs=self.get('subs');
		coefficient=self.get('coefficient');
		if self.qmvkind()=='base':
			value=Base_Xyz.__call__(self,x,y,z);
			value=value*coefficient;
		else:
			value=0;
			for wf in wf_subs:
				value=value+wf(x,y,z);
		return value;
		
	def info(self,indent=0):
		print indent*"|_","<OnePWaveFunction_Xyz>"
		WaveFunction.info(self,indent+1);
		if self.qmvkind()=='base':
			Base_Xyz.info(self,indent+1);
		
	def baseiproduct(self,wf): #baseinnerproduct
		#self_cft=self.get('coefficient');
		#wf_cft=wf.get('coefficient');
		product=self.baseiproduct_xyz(wf); #*self_cft*wf_cft;
		return product;
	
	def qmvcopy(self,qmv=None):
		if qmv is None:
			qmv=OnePWaveFunction_Xyz();
			qmv.initqmvkind(self.qmvkind());
		qmv=WaveFunction.qmvcopy(self,qmv);
		if self.qmvkind()=='base':
			qmv=Base_Xyz.qmvcopy(self,qmv);
		return qmv;
		
class OnePOperator_Xyz(Operator,Base_Xyz):
	def __init__(self):
		Operator.__init__(self);
		Base_Xyz.__init__(self);
		#self.set('coefficient',1);

	def info(self,indent=0):
		print indent*"|_","<OnePOperator_Xyz>"
		Operator.info(self,indent+1);
		Base_Xyz.info(self,indent+1);
		
	def __call__(self,x,y,z):
		wf_subs=self.get('subs');
		coefficient=self.get('coefficient');
		if self.qmvkind()=='base':
			value=Base_Xyz.__call__(self,x,y,z);
			value=value*coefficient;
		else:
			value=0;
			for wf in wf_subs:
				value=value+wf(x,y,z);
		return value;
		
	def baseopwfmultiply(self,multiplier):
		return self.basemultiply_xyz(multiplier);
		
	def qmvcopy(self,qmv=None):
		if qmv is None:
			qmv=OnePOperator_Xyz();
			qmv.initqmvkind(self.qmvkind());
		qmv=Operator.qmvcopy(self,qmv);
		if self.qmvkind()=='base':
			qmv=Base_Xyz.qmvcopy(self,qmv);
		return qmv;
		
##############################################		
class OnePWaveFunction_Mat(WaveFunction,Base_Mat):
	def __init__(self):
		WaveFunction.__init__(self);
		Base_Mat.__init__(self);
		#self.set('coefficient',1);
		
	def info(self,indent=0):
		print indent*"|_","<OnePWaveFunction_Mat>"
		WaveFunction.info(self,indent+1);
		if self.qmvkind()=='base':
			Base_Mat.info(self,indent+1),
		# print ">"
		
	def baseiproduct(self,wf): #baseinnerproduct
		#self_cft=self.get('coefficient');
		#wf_cft=wf.get('coefficient');
		product=self.baseiproduct_mat(wf); #*self_cft*wf_cft;
		return product;
		
	def qmvcopy(self,qmv=None):
		if qmv is None:
			qmv=OnePWaveFunction_Mat();
			qmv.initqmvkind(self.qmvkind());
		qmv=WaveFunction.qmvcopy(self,qmv);
		if self.qmvkind()=='base':
			qmv=Base_Mat.qmvcopy(self,qmv);
		return qmv;
		
class OnePOperator_Mat(Operator,Base_Mat):
	def __init__(self):
		Operator.__init__(self);
		Base_Mat.__init__(self);
		#self.set('coefficient',1);
		
	def info(self,indent=0):
		print indent*"|_","<OnePOperator_Mat>"
		Operator.info(self,indent+1);
		if self.qmvkind()=='base':
			Base_Mat.info(self,indent+1);

	def baseopwfmultiply(self,multiplier):
		return self.basemultiply_mat(multiplier);

	def qmvcopy(self,qmv=None):
		if qmv is None:
			qmv=OnePOperator_Mat();
			qmv.initqmvkind(self.qmvkind());
		qmv=Operator.qmvcopy(self,qmv);
		if self.qmvkind()=='base':
			qmv=Base_Mat.qmvcopy(self,qmv);
		return qmv;
		
#######################################################		
class OnePWaveFunction_XyzSpin(OnePWaveFunction_Xyz,Base_Mat):
	def __init__(self):
		OnePWaveFunction_Xyz.__init__(self);
		Base_Mat.__init__(self);
		#self.set('coefficient',1);
		
	def set2zero(self):
		OnePWaveFunction_Xyz.set2zero(self);
		self.set2matzero();
		
	def qmvcopy(self,qmv=None):
		if qmv is None:
			qmv=OnePWaveFunction_XyzSpin();
			qmv.initqmvkind(self.qmvkind());
		qmv=OnePWaveFunction_Xyz.qmvcopy(self,qmv);
		if self.qmvkind()=='base':
			qmv=Base_Mat.qmvcopy(self,qmv);
		return qmv;
		
	def info(self,indent=0):
		print indent*"|_","<OnePWaveFunction_XyzSpin>"
		OnePWaveFunction_Xyz.info(self,indent+1);
		if self.qmvkind()=='base':
			Base_Mat.info(self,indent+1);
		
	def turnspinup(self):
		self.set('matrix',transpose(matrix([1,0])));
		
	def turnspindown(self):
		self.set('matrix',transpose(matrix([0,1])));
		
	def isspinup(self):
		answer=True;
		mat=self.get('matrix');
		try:
			product=array(matrix([0,1])*mat)[0][0];
			if product!=0:
				answer=False;
		except:
			answer=False;
		return answer;
		
	def isspindown(self):
		answer=True;
		mat=self.get('matrix');
		try:
			product=array(matrix([1,0])*mat)[0][0];
			if product!=0:
				answer=False;
		except:
			answer=False;
		return answer;
		
	def baseiproduct(self,wf): #baseinnerproduct
		#bracft=self.get('coefficient');
		#ketcft=wf.get('coefficient');
		product_xyz=self.baseiproduct_xyz(wf);
		#print "xyz baseiproduct:",product_xyz
		product_mat=self.baseiproduct_mat(wf);
		#print "mat baseiproduct:",product_mat
		product=product_xyz*product_mat;
		#product=product*(bracft*ketcft);
		return product;
		