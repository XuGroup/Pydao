from pylab import *;
from pydao.ohdf import OGroup,isnumeric;
import pydao.math;
from qmvariable import Operator;
from oneparticle import OnePWaveFunction_XyzSpin;
from oneparticle import OnePOperator_Mat,OnePOperator_Xyz;
from oneparticle import Base_Xyz,Base_Mat,Base_Sym;
import copy;
from pydao.io import Savable_MethodResultdBase;

##########################################################
class Atomic_WaveFunction(OnePWaveFunction_XyzSpin,Base_Sym):
	def __init__(self,Z=1,n=1,l=0,m=0,Sz=1):
		OnePWaveFunction_XyzSpin.__init__(self);
		Base_Sym.__init__(self);
		#self.set('coefficient',1);
		self.sympara_set('Z',Z);
		self.sympara_set('n',n);
		self.sympara_set('l',l);
		self.sympara_set('m',m);
		self.orbit_init();
		self.spin_init(Sz);
		if n<l+1:
			raise Exception('In atomic wave function, n can not be less than l+1!');
		
	def qmvcopy(self,qmv=None):
		if qmv is None:
			qmv=Atomic_WaveFunction();
			qmv.initqmvkind(self.qmvkind());
		qmv=OnePWaveFunction_XyzSpin.qmvcopy(self,qmv);
		if self.qmvkind()=='base':
			qmv=Base_Sym.qmvcopy(self,qmv);
			qmv.orbit_init();
		return qmv;
		
	def info(self,indent=0):
		print indent*"|_","<Atomic_WaveFunction>"
		OnePWaveFunction_XyzSpin.info(self,indent+1);
		#print indent*"|_",
		if self.qmvkind()=='base':
			Base_Sym.info(self,indent+1);
		
	def spin_init(self,Sz=1):
		if Sz==0.5:
			self.turnspinup();
		elif Sz==-0.5:
			self.turnspindown();
		else:
			self.set2qmvzero();
		return;
		
	def get_Sz(self):
		if self.isspinup():
			Sz=0.5;
		elif self.isspindown():
			Sz=-0.5;
		return Sz;
	
	def orbit_init(self,Z=None,n=None,l=None,m=None):
		#print "in Atomic_WaveFunction orbit_init:"
		from pydao.physics import e_mass,e_charge,hbar;
		m_e=e_mass;
		e=e_charge;
		
		if Z is None:
			Z=self.sympara_get('Z');
			n=self.sympara_get('n');
			l=self.sympara_get('l');
			m=self.sympara_get('m');
		#print "qmnumbers:",self.qmnumbers();
		self.xyzpara_set('exp_n',n);
		self.xyzpara_set('x_m',n-1);

		a0=hbar**2/m_e/e**2/9e9/Z;
		self.sympara_set('a0',a0);
		
		# exp_n=self.xyzpara_get('exp_n');
		# x_m=self.xyzpara_get('x_m');
		# print Z,n,l,m
		# print self.qmnumbers()
		# print a0,n,exp_n,x_m
			
		if l>n-1 or l<0 or abs(m)>l:
			#print "quantum numbers does not match, meaning zero function"
			#print self.qmnumbers();
			self.set2qmvzero();
		else:
			if self.isvalidsym():
				func=lambda x,y,z:self.radial(x,y,z)*self.angular(x,y,z);
				self.set('xyzfun',func);
			self.sympara_set('Z',Z);
			self.sympara_set('n',n);
			self.sympara_set('l',l);
			self.sympara_set('m',m);
		return;
		
	def baseiproduct_xyz(self,wf):
		#print "in Atomic_WaveFunction baseiproduct_xyz:"
		if isinstance(wf,Atomic_WaveFunction) and self.isvalidsym() and wf.isvalidsym():
			#print "quantum innerproduct"
			product=self.baseiproduct_sym(wf);
			#print self.qmnumbers(),wf.qmnumbers();
			#print "product:",product
		else:
			product=OnePWaveFunction_XyzSpin.baseiproduct_xyz(self,wf);
		return product;
		
	def baseiproduct_sym(self,wf):
		if self.isidentical_sym(wf):
			product=1;#self.get('coefficient')*wf.get('coefficient');
		else:
			product=0;
		return product;
		
	def qmnumbers(self):
		Z=self.sympara_get('Z');
		n=self.sympara_get('n');
		l=self.sympara_get('l');
		m=self.sympara_get('m');
		return Z,n,l,m;
		
	def hassameqmnumbers(self,wf):
		answer=False;
		Z,n,l,m=self.qmnumbers();
		#print self.qmnumbers()
		if isinstance(wf,Atomic_WaveFunction):
			Z1,n1,l1,m1=wf.qmnumbers();
			if Z==Z1 and n==n1 and l==l1 and m==m1:
				answer=True;
			#print wf.qmnumbers()
		elif type(wf) is tuple:
			if (Z,n,l,m)==wf:
				answer=True;
			#print wf
		#print "answer:",answer
		return answer;
		
	def isidentical(self,wf):
		answer=False;
		if isinstance(wf,Atomic_WaveFunction):
			if self.hassameqmnumbers(wf) and self.hassamemat(wf):
				answer=True;
		return answer;
		
	def rpeak(self):
		# print "in Atomic_WaveFunction rpeak:"
		a0=self.sympara_get('a0');
		n=self.sympara_get('n');
		peakpos=self.xyzpara_get('peakpos');
		if peakpos is None:		
			exp_n=self.xyzpara_get('exp_n');
			x_m=self.xyzpara_get('x_m');
			peakpos=a0*exp_n*x_m;
			# print self.qmnumbers()
			# print a0,n,exp_n,x_m,peakpos
		return peakpos;
			
	def rspread(self):
		a0=self.sympara_get('a0');
		n=self.sympara_get('n');
		#sigma=(n*n*n-n*n)*a0;
		sigma=self.xyzpara_get('sigma');
		if sigma is None:
			sigma=a0*self.xyzpara_get('exp_n')*self.xyzpara_get('x_m');
		return sigma;
		
	def radial(self,x,y,z):
		n=self.sympara_get('n');
		l=self.sympara_get('l');
		a0=self.sympara_get('a0');
		r=(x*x+y*y+z*z)**0.5;
		rho=r/a0;
		if n==1:
			R=2./a0**1.5*exp(-rho);
		elif n==2 and l==0:
			R=1./2**0.5/a0**1.5*(1-rho/2)*exp(-rho/2);
		elif n==2 and l==1:
			R=1./2/6**0.5/a0**1.5*rho*exp(-rho/2);
		elif n==3 and l==0:
			R=2./81/3**0.5/a0**1.5*(27-18.*rho+2*rho**2)*exp(-rho/3);
		elif n==3 and l==1:
			R=8./27/6**0.5/a0**1.5*rho*(1-rho/6)*exp(-rho/3);
		elif n==3 and l==2:
			R=4./81/30**0.5/a0**1.5*rho**2*exp(-rho/3);
		return R;
		
	def angular(self,x,y,z):
		from scipy.special import sph_harm;
		l=self.sympara_get('l');
		m=self.sympara_get('m');
		r,theta,phi=pydao.math.xyz2rthetaphi(x,y,z);
		jj=complex(0,1);
		if l==0 and m==0:
			Y = sqrt(1/(4*pi))                       # Y(0,0)
		elif l==1 and m==0:
			Y = sqrt(3/(4*pi)) * (cos(theta))                # Y(1,0)
			#print "l,m",l,m
		elif l==1 and  m==1:
			Y= sqrt(3/(8*pi)) * sin(theta) * exp(jj*phi)             # Y(1, +1)
		elif l==1 and m==-1:
			Y = sqrt(3/(8*pi)) * sin(theta) * exp(-jj*phi)     # Y(1, -1)
		elif l==2 and m==0:
			Y = sqrt(5/(16*pi)) * ( 3 * pow(cos(theta), 2) -1 )     # Y (2,0)
		elif l==2 and m==1:
			Y = sqrt(15/(8*pi)) * cos(theta) * sin(theta) * exp(jj*phi)  # Y (2,+1)
		elif l==2 and m==-1:
			Y = sqrt(15/(8*pi)) *  cos(theta) * sin(theta) * exp(-jj*phi)    # Y (2,-1)
		elif l==2 and m==2:
			Y = sqrt(15/(32*pi)) * pow(sin(theta),2)*exp(2*jj*phi)           # Y(2,+2)
		elif l==2 and m==-2:
			Y = sqrt(15/(32*pi)) * pow(sin(theta),2)*exp(-jj*2*phi)       # Y(2,-2)
		#Y=sph_harm(m,l,theta,phi);
		#Y=1;
		return Y;
		
class Orbital_AngularMomentum(Operator,Base_Sym):
	def __init__(self,loperator='Lz'):
		Operator.__init__(self);
		Base_Sym.__init__(self);
		#self.set2xyzindentity();
		self.sympara_set('loperator',loperator);
		#self.set('coefficient',1);
		
	def info(self,indent=0):
		print indent*"|_","<Orbital_AngularMomentum>"
		Operator.info(self,indent+1);
		#print indent*"|_",
		if self.qmvkind()=='base':
			Base_Sym.info(self,indent+1);
		
	def qmvcopy(self,qmv=None):
		if qmv is None:
			qmv=Orbital_AngularMomentum();
			qmv.initqmvkind(self.qmvkind());
		qmv=Operator.qmvcopy(self,qmv);
		if self.qmvkind()=='base':
			qmv=Base_Sym.qmvcopy(self,qmv);
		return qmv;
		
	def baseopwfmultiply(self,multiplier):
		if isinstance(multiplier,Atomic_WaveFunction):
			if multiplier.isvalidsym():
				product=self.baseopwfmultiply_sym(multiplier);
			else:
				print "Error: not valid sym"
		else:
			print "Error: not a Atomic_WaveFunction."
		return product;
				
	def baseopwfmultiply_sym(self,multiplier):
		# print "in baseopwfmultiply_sym:"
		operator=self.sympara_get('loperator');
		#print "loperator:",operator
		#print "op info"
		#self.info();
		#print "wf info"
		#multiplier.info();
		
		Z=multiplier.sympara_get('Z');
		n=multiplier.sympara_get('n');
		l=multiplier.sympara_get('l');
		m=multiplier.sympara_get('m');
		#multi_cft=multiplier.get('coefficient');
		product=multiplier.qmvcopy();
		if operator=="Lp":
			pdt=sqrt((l-m)*(l+m+1));
			product.orbit_init(Z,n,l,m+1);
			product.times(pdt);
		elif operator=='Lm':
			pdt=sqrt((l+m)*(l-m+1));
			product.orbit_init(Z,n,l,m-1)
			product.times(pdt);
			#print "in Lm",n,l,m,pdt
		elif operator=='Lz':
			pdt=m;
			product.times(pdt);
			#print "in Lz",product.qmnumbers(),pdt
		elif operator=='L2':
			# print "l2"
			# multiplier.info();
			pdt=l*(l+1);
			product.times(pdt);
			# multiplier.info();
			# product.info();
			#print "in Lz",product.qmnumbers(),pdt
		elif operator=='Lx':
			pdtp=sqrt((l-m)*(l+m+1));
			product.orbit_init(Z,n,l,m+1);
			pdtm=sqrt((l+m)*(l-m+1));
			productm=multiplier.qmvcopy();
			productm.orbit_init(Z,n,l,m-1);
			#product=product.times(pdtp)+productm.times(pdtm);
			product.times(pdtp);
			productm.times(pdtm);
			product=product.plus(productm);
			product.times(0.5);
			# print "in Lx"
			# print "pdtp,pdtm:",pdtp,pdtm
			# print "product:"
			# product.info();
		elif operator=="Ly":
			pdtp=sqrt((l-m)*(l+m+1));
			product.orbit_init(Z,n,l,m+1);
			pdtm=sqrt((l+m)*(l-m+1));
			productm=multiplier.qmvcopy();
			productm.orbit_init(Z,n,l,m-1);
			product.times(pdtp);
			productm.times(pdtm);
			#product=product.times(pdtp)-productm.times(pdtm)
			product=product.plus(-1*productm);
			product.times(-0.5j);
		return product;
		
class Spin_AngularMomentum(OnePOperator_Mat):
	def __init__(self,spinop='Sz'):
		OnePOperator_Mat.__init__(self);
		mat=OnePOperator_Mat.spinop2mat(self,spinop);
		self.set('matrix',mat);
		#self.set('coefficient',1);
		
	def info(self,indent=0):
		print indent*"|_","<Spin_AngularMomentum>"
		OnePOperator_Mat.info(self,indent+1);

	def qmvcopy(self,qmv=None):
		#print "in Spin_AngularMomentum qmvcopy:"
		if qmv is None:
			qmv=Spin_AngularMomentum();
			qmv.initqmvkind(self.qmvkind());
		#print "init qmv:"
		#qmv.info();
		qmv=OnePOperator_Mat.qmvcopy(self,qmv);
		#print "after OnePOperator_Mat"
		#qmv.info();
		return qmv;

class Xi_SO(Operator,Base_Sym):
	def __init__(self):
		Operator.__init__(self);
		Base_Sym.__init__(self);
		
	def info(self,indent=0):
		print indent*"|_","<Xi_SO>"
		Operator.info(self,indent+1);
		if self.qmvkind()=='base':
			Base_Sym.info(self,indent+1);
		
	def qmvcopy(self,qmv=None):
		if qmv is None:
			qmv=Xi_SO();
			qmv.initqmvkind(self.qmvkind());
		qmv=Operator.qmvcopy(self,qmv);
		if self.qmvkind()=='base':
			qmv=Base_Sym.qmvcopy(self,qmv);
		return qmv;
		
	def baseopwfmultiply(self,multiplier):
		if isinstance(multiplier,Atomic_WaveFunction):
			if multiplier.isvalidsym():
				product=self.baseopwfmultiply_sym(multiplier);
			else:
				print "Error: not valid sym"
		else:
			print "Error: not a Atomic_WaveFunction."
		return product;
				
	def baseopwfmultiply_sym(self,multiplier):
		#print "in Xi_SO->baseopwfmultiply_sym:"
		from pydao.physics import e_mass,e_charge,hbar,k_E,v_light;
		
		Z=multiplier.sympara_get('Z');
		n=multiplier.sympara_get('n');
		l=multiplier.sympara_get('l');
		m=multiplier.sympara_get('m');
		
		
		A=k_E*Z*e_charge**2/2./e_mass**2/v_light**2;
		a=hbar**2/k_E/e_mass/e_charge**2;
		I=A*Z**3/n**3/l/(l+0.5)/(l+1)/a**3*hbar**2;
		#notice the positive sign. it comes from the d(-1/r)/dr=1/r**2
		product=multiplier.qmvcopy();
		product.times(I);
		return product;
		
class Spin_Orbit_Coupling(Operator,Savable_MethodResultdBase):
	#This is actually a operator wrapper
	def __init__(self,particle_index=0):
		from atomic_wavefunction_method import get_spin_orbit_coupling;
		Operator.__init__(self);
		op=get_spin_orbit_coupling(particle_index);
		self.set('operator',op);
		self.set('particle_index',particle_index);
		self.set('savedresult_dbasename','spin_orbit_coupling');
			
	def basebraket_basestack_op_mate(self,bra,ket):
		parameters=OGroup();
		parameters.set('varname','Eso');
		Z0,n0,l0,m0=bra.qmnumbers();
		Sz0=bra.get_Sz();
		Z1,n1,l1,m1=ket.qmnumbers();
		Sz1=ket.get_Sz();
		parameters.set('bra_ZnlmSz',(Z0,n0,l0,m0,Sz0));
		parameters.set('ket_ZnlmSz',(Z1,n1,l1,m1,Sz1));
		value=self.find_resultrecord_fromdbase(parameters);
		#print "to find spin_orbit_coupling",bra.qmnumbers(),ket.qmnumbers(),
		if value is None:
			parameters.set('ket_ZnlmSz',(Z0,n0,l0,m0,Sz0));
			parameters.set('bra_ZnlmSz',(Z1,n1,l1,m1,Sz1));
			value=self.find_resultrecord_fromdbase(parameters);
			if value is not None:
				value=conjugate(value);
				#print ', conjugate record found.';
			else:
				wfR=self*ket;
				# print "bra.info"
				# bra.info()
				# print "wfR.info"
				# wfR.info()
				value=bra.innerproduct(wfR);
				record=OGroup();
				record.set('bra_ZnlmSz',(Z0,n0,l0,m0,Sz0));
				record.set('ket_ZnlmSz',(Z1,n1,l1,m1,Sz1));
				record.set('varname','Eso');
				record.set('value',value);
				self.store_resultrecord_2dbase(record)
		else:
			#print ', record found.'
			pass;
		mate=value;
		return mate;
		
	def baseopwfmultiply(self,multiplier):
		op=self.get('operator');
		return op*multiplier;
		
		
class Dipole_Transition(Operator,Base_Xyz,Savable_MethodResultdBase):
	def __init__(self,dipole_operator='x',particle_index=0):
		Operator.__init__(self);
		Base_Xyz.__init__(self);
		self.set('dipole_operator',dipole_operator);
		self.set('particle_index',particle_index);
		self.set('savedresult_dbasename','dipole_transition');
		if dipole_operator=='x':
			self.set('xyzfun',lambda x,y,z:x);
		elif dipole_operator=='y':
			self.set('xyzfun',lambda x,y,z:y);
		elif dipole_operator=='z':
			self.set('xyzfun',lambda x,y,z:z);
		
	def info(self,indent=0):
		print indent*"|_","<Dipole_Transition>"
		Operator.info(self,indent+1);
		if self.qmvkind()=='base':
			Base_Xyz.info(self,indent+1);
				
	def base_braket_base_op_mate(self,bra,ket): # base_braopket_mate
		Np=self.xyzpara_get('Np');
		if Np is None:
			Np=50;
		if isinstance(bra,Base_Mat):
				mate=bra.baseiproduct_mat(ket);
				# print "mate spin:",mate,
		if mate!=0:
			dipole_operator=self.get('dipole_operator');
			parameters=OGroup();
			parameters.set('varname',dipole_operator);
			Z0,n0,l0,m0=bra.qmnumbers();
			Z1,n1,l1,m1=ket.qmnumbers();
			# print (Z0,n0,l0,m0),(Z1,n1,l1,m1),
			parameters.set('bra_Znlm',(Z0,n0,l0,m0));
			parameters.set('ket_Znlm',(Z1,n1,l1,m1));
			parameters.set('Np',Np);
			tr=self.find_resultrecord_fromdbase(parameters);
			#print "to find dipole transition",bra.qmnumbers(),ket.qmnumbers(),
			if tr is None:
				parameters.set('ket_Znlm',(Z0,n0,l0,m0));
				parameters.set('bra_Znlm',(Z1,n1,l1,m1));
				tr=self.find_resultrecord_fromdbase(parameters);
				if tr is not None:
					tr=conjugate(tr);
					#print ', conjugate record found.';
				else:
					# selection rules
					selection_rule_passed=False;
					if abs(l0-l1)==1:
						if (dipole_operator=='x' or dipole_operator=='y') and abs(m0-m1)==1:
							selection_rule_passed=True;
						elif dipole_operator=='z' and abs(m0-m1)==0:
							selection_rule_passed=True;
					if selection_rule_passed:
						tr=self.base_braopket_mate_xyz(bra,ket,Np);
					else:
						tr=0;
					record=OGroup();
					record.set('bra_Znlm',(Z0,n0,l0,m0));
					record.set('ket_Znlm',(Z1,n1,l1,m1));
					record.set('varname',dipole_operator);
					record.set('value',tr);
					record.set('Np',Np);
					# print "new tr:",tr,
					self.store_resultrecord_2dbase(record)
			else:		
				#print ', record found.'
				pass;
			bra_cft=bra.get('coefficient');
			ket_cft=ket.get('coefficient');
			mate=tr*bra_cft*ket_cft;
		return mate;
		
class Crystal_Field(Operator,Base_Xyz,Savable_MethodResultdBase):
	def __init__(self,symmetry='oh',parameters=None,particle_index=0,Ncharge=1):
		Operator.__init__(self);
		Base_Xyz.__init__(self);
		self.set('symmetry',symmetry);
		self.set('parameters',parameters);
		self.set('particle_index',particle_index);
		self.set('Ncharge',Ncharge);
		self.set('savedresult_dbasename','crystal_field');
		self.set_pointcharges(symmetry,parameters);
		self.set('xyzfun',lambda x,y,z:self.xyzfun(x,y,z));
		self.xyzpara_set('rrange',2.0e-10);
		
	def xyzfun(self,x,y,z):
		from pydao.physics import e_mass,e_charge,hbar,k_E,v_light;
		value=0;
		pointcharges=self.get('pointcharges');
		Ncharge=self.get('Ncharge');
		for pos in pointcharges:
			value=value+Ncharge*e_charge**2*k_E/((x-pos[0])**2+(y-pos[1])**2+(z-pos[2])**2)**0.5;
			#value=value-value;
		return value;
		
	def set_pointcharges(self,symmetry,parameters):
		pointcharges=[];
		if symmetry=='oh' or symmetry=='cubic':
			distance=parameters;
			for x in [-1,0,1]:
				for y in [-1,0,1]:
					for z in [-1,0,1]:
						if abs(x)+abs(y)+abs(z)==1:
							position=array([x,y,z])*distance;
							pointcharges.append(position);
		elif symmetry=='d3h':
			dxy=parameters[0];
			dz=parameters[1];
			pos1=array([dxy,0,0]);
			pos2=array([-dxy/2.,dxy/2.*3**0.5,0]);
			pos3=array([-dxy/2.,-dxy/2.*3**0.5,0]);
			pos4=array([0,0,dz]);
			pos5=array([0,0,-dz]);
			pointcharges=[pos1,pos2,pos3,pos4,pos5];
		self.set('pointcharges',pointcharges);
		return pointcharges;
		
	def shift_pointcharges(self,shift):
		pointcharges=self.get('pointcharges');
		for i in range(len(pointcharges)):
			pos=pointcharges[i];
			pointcharges[i]=pos+shift;
		self.set('pointcharges',pointcharges);
		return pointcharges;
		
	def base_braket_base_op_mate(self,bra,ket):
		Np=self.xyzpara_get('Np');
		if Np is None:
			Np=30;
		if isinstance(bra,Base_Mat):
				mate=bra.baseiproduct_mat(ket);
				# print "mate spin:",mate,
		if mate!=0:
			symmetry=self.get('symmetry');
			paras=self.get('parameters');
			parameters=OGroup();
			parameters.set('varname',symmetry);
			parameters.set('paras',paras);
			Z0,n0,l0,m0=bra.qmnumbers();
			Z1,n1,l1,m1=ket.qmnumbers();
			# print (Z0,n0,l0,m0),(Z1,n1,l1,m1),
			parameters.set('bra_Znlm',(Z0,n0,l0,m0));
			parameters.set('ket_Znlm',(Z1,n1,l1,m1));
			parameters.set('Np',Np);
			tr=self.find_resultrecord_fromdbase(parameters);
			#print "to find crystal field",bra.qmnumbers(),ket.qmnumbers(),
			if tr is None:
				parameters.set('ket_Znlm',(Z0,n0,l0,m0));
				parameters.set('bra_Znlm',(Z1,n1,l1,m1));
				tr=self.find_resultrecord_fromdbase(parameters);
				if tr is not None:
					tr=conjugate(tr);
					#print ', conjugate record found.';
				else:
					tr=self.base_braopket_mate_xyz(bra,ket,Np);
					record=OGroup();
					record.set('bra_Znlm',(Z0,n0,l0,m0));
					record.set('ket_Znlm',(Z1,n1,l1,m1));
					record.set('varname',symmetry);
					record.set('paras',paras);
					record.set('value',tr);
					record.set('Np',Np);
					# print "new tr:",tr,
					self.store_resultrecord_2dbase(record)
			else:		
				#print ', record found.'
				pass;
			bra_cft=bra.get('coefficient');
			ket_cft=ket.get('coefficient');
			mate=tr*bra_cft*ket_cft;
		return mate;
		
	def baseopwfmultiply(self,multiplier):
		op=self.get('operator');
		return op*multiplier;