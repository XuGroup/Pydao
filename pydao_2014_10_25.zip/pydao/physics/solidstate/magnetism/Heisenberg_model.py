
from pylab import *;
from pydao.ohdf import OGroup;
import copy;

class H_Model(OGroup):
	def __init__(self,Nsite=None,S=None,neighbor_table=None):
		OGroup.__init__(self);
		self.set('Nsite',Nsite);
		self.set('S',S);
		basis,Nbase=self.cal_basis(Nsite,S);
		self.set('basis',basis);
		self.set('Nbase',Nbase);
		if neighbor_table is None:
			self.set('neighbor_table',self.get_neighbor_table());
		else:
			self.set('neighbor_table',neighbor_table);
		self.set('Hmat',None);
		#return self.basis
		
	def get_neighbor_table(self):
		neighbor_table=[];
		Nsite=self.get('Nsite')
		for isite in range(Nsite):
			neis=range(Nsite);
			neis.remove(isite);
			neighbor_table.append(neis);
		return neighbor_table;
	
	def cal_basis(self,Nsite,S):
		NS=int(2*S+1);
		Nbase=NS**Nsite;
		basis=zeros([Nsite,Nbase]);
		for ibase in range(Nbase):
			for isite in range(Nsite):
				basis[isite,ibase]=floor(mod(ibase,NS**(isite+1))/NS**isite)-S;
		return (basis,Nbase);
		
	def H_element(self,base1,base2):
		element=0;
		Nsite=self.get('Nsite');
		neighbor_table=self.get('neighbor_table');
		for isite in range(Nsite):
			for jsite in neighbor_table[isite]:
				temp=base1.Sz(isite).Sz(jsite).dotproduct(base2);
				#print element
				temp=temp+base1.s_plus(isite).s_minus(jsite).dotproduct(base2)/2;
				#print element
				temp=temp+base1.s_minus(isite).s_plus(jsite).dotproduct(base2)/2;
				#print element
				#if isite + jsite==3:
				#	temp=temp*1.001;
				#elif isite + jsite==2:
				#	temp=temp*1.002;
				element=element+temp;
		element=element/2;
		return element;
		
	def H_mat(self):
		import pydao.tools;
		Nbase=self.get('Nbase');
		S=self.get('S');
		Hmat=zeros([Nbase,Nbase])
		basis=self.get('basis');
		pt=pydao.tools.Progress_Teller(Nbase*Nbase);
		for ibase in range(Nbase):
			base1=Base(basis[:,ibase],S);
			for jbase in range(Nbase):
				pt.tell(jbase+ibase*Nbase);
				#print "ibase,jbase:",ibase,jbase
				base2=Base(basis[:,jbase],S);
				Hmat[ibase,jbase]=self.H_element(base1,base2);
		self.set('H_mat',Hmat);
		return Hmat;

	def Sz_mat(self):
		Nbase=self.get('Nbase');
		Sz_mat=zeros([Nbase,Nbase])
		basis=self.get('basis');
		for ibase in range(Nbase):
			Sz_mat[ibase,ibase]=basis[:,ibase].sum();
		return Sz_mat;
		
		
class Base(OGroup):
	def __init__(self,base_array=None,S=None):
		OGroup.__init__(self);
		self.set('factor',1.);
		
		if base_array is not None:
			#print "base_array",base_array
			self.set('array',copy.deepcopy(base_array));
			Nsite=base_array.shape[0];
			#self.set('Nbase',Nbase);
			self.set('Nsite',Nsite);
			self.set('S',S);
		
		
	def s_plus(self,isite):
		newbase=self.copy2mem();
		S=self.get('S');
		barray=newbase.get('array');
		factor=newbase.get('factor');
		if barray[isite]==S:
			newbase.set('factor',0.);
		else:
			m=barray[isite];
			barray[isite]+=1;
			factor=factor*((S-m)*(S+m+1))**0.5;
			#print "+factor:",factor,S,m
			newbase.set('array',barray);
			newbase.set('factor',factor);
		return newbase;
		
	def s_minus(self,isite):
		newbase=self.copy2mem();
		S=self.get('S');
		barray=newbase.get('array');
		factor=newbase.get('factor');
		if barray[isite]==-S:
			newbase.set('factor',0.);
		else:
			m=barray[isite];
			barray[isite]+=-1;
			factor=factor*((S+m)*(S-m+1))**0.5;
			#print "-factor:",factor,S,m
			newbase.set('array',barray);
			newbase.set('factor',factor);
		return newbase;
		
	def Sz(self,isite):
		newbase=self.copy2mem();
		barray=newbase.get('array');
		factor=newbase.get('factor');
		m=barray[isite];
		newbase.set('factor',factor*m);
		return newbase;
		
	def dotproduct(self,base1):
		if self.match(base1):
			product=self.get('factor')*base1.get('factor');
		else:
			product=0.;
		#print self.get('array');
		#print base1.get('array');
		#print "product:",product
		return product;
	
	def match(self,base1):
		same=True;
		array0=self.get('array');
		array1=base1.get('array');
		Nsite=len(array0);
		for isite in range(Nsite):
			if array0[isite]!=array1[isite]:
				same=False;
		return same;
		
def test():
	hm=H_Model(3,0.5);
	print hm.get('basis')
	hmat=hm.H_mat();
	print hmat
	szmat=hm.Sz_mat();
	print szmat
	E,V=eigh(hmat);
	print E
	print V