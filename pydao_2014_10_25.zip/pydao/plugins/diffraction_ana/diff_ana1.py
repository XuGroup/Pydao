#import pydao.physics as physics;
#reload(physics);
from pydao.io import ANLAPSSPEC_DataFile, ANLAPSSPEC_Sequence;
from pylab import *;

#====================Setting for the while data file=========================================================
# data file name
filename=r'C:\Home\Xiaoshan\LabORNL\Projects\LuFeO3\vT-XRD\ANL\2013_03\lfo_alo_01.spc';
filename=r'C:\Home\Xiaoshan\LabORNL\Projects\LuFeO3\vT-XRD\ANL\2013_03\lfo_al2o3_02.spc';

# the first real scan
Iscan_start=2; #16
Iscan_end=-1; # -1 means the last scan is good, otherwise the value should be -2

# numer of total scan for one T
Nperiod=10; #17; 

# the scan number difference between the first scan for a peak to the first real scan
Discan_004=0;
Discan_102=5;
Discan_104=5; #9 for scan01 5 for scan02
Discan_106=13;

# the scan number differece between the first scan for a variable to the first real scan
Discan_004_eta=0;
Discan_004_chi=1;
Discan_004_del=2
Discan_004_z=3;
Discan_004_L=4;

Discan_104_eta=0;
Discan_104_chi=1;
Discan_104_del=2;
Discan_104_L=3;
Discan_104_H=4;


#====================Settings for the choosing a specific scan=========================
# choose peak
dscan_peak_list=array([Discan_004,Discan_102,Discan_104,Discan_106]);
dscan_peak_list=array([Discan_104]);

# specify peak names
peak_name_list=['004','102','104','106'];
peak_name_list=['104',];

#choose scan variables
discan_var=Discan_104_H;
#specify angle name
scan_var_name='H';

#=============Settings for the analysis of a specific scan=============================
#choose x variable, 0 means the same as the scan variable; specify name for covariable 
scan_covar='H';

#============================start running============================================
# load the whole data file
dfile=ANLAPSSPEC_DataFile(filename);
dfile.read_file_to_mem();
Nscan=dfile.n_scans();
print "Total number of scans:", Nscan;

#analyze individual peak
iscan_peak_list=Iscan_start+discan_var+dscan_peak_list;
i=0;
for iscan_peak in iscan_peak_list:
	print "iscan_peak:",iscan_peak
	iscanlist=range(iscan_peak,Nscan+Iscan_end-2,Nperiod);
	sequence=dfile.get_scansequence(iscanlist);
	
	timestamps=sequence.get_timestamps();
	Ts=sequence.get_Ts();
	
	xmat=sequence.get_col_mat(scan_covar);
	ymat=sequence.get_col_mat('Detector');
	
	monmat=sequence.get_col_mat('Ion_Ch_2');
	
	Intmat=ymat/monmat;
	
	#0th moment
	Ints0=Intmat.sum(1);
	Ints0=Ints0/Ints0[0];
	subplot(2,2,1);
	plot(Ts,Ints0,'-o');
	xlabel('T(K)');ylabel('0th_moment');
	
	#1th moment
	Ints1=(Intmat*xmat).sum(1)/Ints0;
	Ints1=Ints1/Ints1[0];
	subplot(2,2,2);
	plot(Ts,Ints1,'-p');
	xlabel('T(K)');ylabel('1th_moment');
	
	#2nd moment
	Nrow,Ncol=xmat.shape;
	Ints2=zeros(Nrow);
	for irow in range(Nrow):
		Ints2[irow]=((Intmat[irow,:]-Ints1[irow])**2*xmat).sum()/Ints0[irow];
	Ints2=Ints2/Ints2[0];
	subplot(2,2,3);
	plot(Ts,Ints2,'-p');
	xlabel('T(K)');ylabel('2nd_moment');
	
	subplot(2,2,4);
	plot(Ts,timestamps,'o-');
	xlabel('T(K)');ylabel('timestamp');
	
	fout_name=peak_name_list[i];
	savetxt('Ts.asc',Ts);
	savetxt(scan_var_name+'_'+str(scan_covar)+'_'+fout_name+'_0.asc',Ints0);
	savetxt(scan_var_name+'_'+str(scan_covar)+'_'+fout_name+'_1.asc',Ints1);
	savetxt(scan_var_name+'_'+str(scan_covar)+'_'+fout_name+'_2.asc',Ints2);
	i=i+1;
subplot(2,2,1);	
legend(peak_name_list)
show();