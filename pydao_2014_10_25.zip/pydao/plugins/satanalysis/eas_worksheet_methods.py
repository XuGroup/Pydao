from pylab import *;
from functions import *;
lazy=False;

def OnOpen(self,event):
	from eas_worksheet_views import eas_worksheet_view_modify;
	view=eas_worksheet_view_modify(self);
	#from pydao.math.worksheet_views import worksheet_view_modify;
	#view=worksheet_view_modify(self);
	self.configure_traits(view=view);

def test_month(self,datestr_array,condition):
	L=len(datestr_array);
	index_array=zeros(L)==zeros(L);
	for i in range(L):
		datestr=datestr_array[i];
		datestr_list=datestr.split(':');
		month=int(datestr_list[1]);
		tof=eval("month"+condition);
		index_array[i]=tof;
	return index_array;
	
def monthly_mean(self,var_name_list,condition_list,date_var_name,time_var_name):
	import pydao;
	import mx.DateTime;
	#og=pydao.cog();
	#ws=og.get('gsfc'); #worksheet name
	#var_name_list=['a440_675','a440_870','a675_870','a675_1020'];
	#var_name_list=var_name_list+['AOT_1020', 'AOT_870', 'AOT_675', 'AOT_440', 'SSA441_T', 'SSA673_T', 'SSA873_T', 'SSA1022_T', 'AOTAbsp441_T', 'AOTAbsp673_T', 'AOTAbsp873_T', 'AOTAbsp1022_T', 'RadiativeForcing_BOA_', 'RadiativeForcing_TOA_']
	ws=self;
	#date_var_name='Date_dd_mm_yyyy_';
	#time_var_name='Time_hh_mm_ss_';
	
	date_array=ws.get_col(date_var_name).get('data');
	time_array=ws.get_col(time_var_name).get('data');
	
	N=12
	for var_name in var_name_list:
		_col=eval("ws.get_col('"+var_name+"')");
		if _col is None:
			print "Error! no column with name:",var_name;
			_cmd=var_name+"=None;"
			exec(_cmd);
		else:
			_cmd=var_name+"=_col.get('data');"
			exec(_cmd);
			_cmd=var_name+"_month_num=zeros(N)";
			exec(_cmd);
			_cmd=var_name+"_month_mean=zeros(N)";
			exec(_cmd);
			_cmd=var_name+"_month_std=zeros(N)";
			exec(_cmd);
			
	print "month:"
	for month in range(12):
		print month+1,
		for var_name in var_name_list:
			_cmd=var_name+"_month_list=[]";
			exec(_cmd);
		for irow in range(len(date_array)):
			date_list=date_array[irow].split(':')
			time_list=time_array[irow].split(':')
			rowdate=mx.DateTime.Date(int(date_list[2]),int(date_list[1]),int(date_list[0]));
			rowtime=mx.DateTime.Time(int(date_list[0]),int(date_list[1]),int(date_list[2]));
			rowdatetime=rowdate+rowtime;
			if rowdatetime.month==month+1:
				for var_name in var_name_list:
					if eval(var_name+" is not None"):
						value=eval(var_name+"["+str(irow)+"]");
						if not isnan(value):
							passed = True;
							for condition in condition_list:
								condition1=condition.replace(var_name,'value');
								try:
									tof=eval(condition1);
									if not tof:
										passed = False;
								except:
									pass;
							if passed:
								_cmd=var_name+"_month_list.append(value)";
								exec(_cmd);
		for var_name in var_name_list:
			mlist=eval(var_name+"_month_list");
			if eval(var_name+" is not None"):
				_cmd=var_name+"_month_num["+str(month)+"]=len(mlist)";
				exec(_cmd);
				_cmd=var_name+"_month_mean["+str(month)+"]=mean(mlist)";
				exec(_cmd);
				_cmd=var_name+"_month_std["+str(month)+"]=std(mlist)";
				exec(_cmd);
	print 
	
	from pydao.math import WorkSheet,WorkSheet_Column;
	from pydao.ohdf import get_empty_instance;
	#ws1=WorkSheet();
	ws1=get_empty_instance(self);
	wsk=WorkSheet_Column(array(range(12))+1);
	ws1.set_col('month',wsk);
	for var_name in var_name_list:
		if eval(var_name+" is not None"):
			dataname=var_name+"_month_num"
			data=eval(dataname);
			wsk=WorkSheet_Column(data);
			ws1.set_col(dataname,wsk);
		
			dataname=var_name+"_month_mean"
			data=eval(dataname);
			wsk=WorkSheet_Column(data);
			ws1.set_col(dataname,wsk);
			
			dataname=var_name+"_month_std"
			data=eval(dataname);
			wsk=WorkSheet_Column(data);
			ws1.set_col(dataname,wsk);
	return ws1;
	#og.set('ws_month',ws1);

def hourly_mean_amonth(self,ws_monthlymean,month,var_name_list,condition_list,date_var_name,time_var_name):
	import pydao;
	import mx.DateTime;
	#og=pydao.cog();
	#ws0=og.get('ws_month'); #worksheet name
	
	#ws=og.get('gsfc');
	#var_name_list=['a440_675','a440_870','a675_870','a675_1020'];
	#var_name_list=var_name_list+['AOT_1020', 'AOT_870', 'AOT_675', 'AOT_440', 'SSA441_T', 'SSA673_T', 'SSA873_T', 'SSA1022_T', 'AOTAbsp441_T', 'AOTAbsp673_T', 'AOTAbsp873_T', 'AOTAbsp1022_T', 'RadiativeForcing_BOA_', 'RadiativeForcing_TOA_']
	
	#date_var_name='Date_dd_mm_yyyy_';
	#time_var_name='Time_hh_mm_ss_';
	ws=self;
	ws0=ws_monthlymean;
	date_array=ws.get_col(date_var_name).get('data');
	time_array=ws.get_col(time_var_name).get('data');
	
	N=24;
	for var_name in var_name_list:
		_col=eval("ws.get_col('"+var_name+"')");
		if _col is None:
			print "Error! no column with name:",var_name;
			_cmd=var_name+"=None;"
			exec(_cmd);
		else:
			_cmd=var_name+"=_col.get('data');"
			exec(_cmd);
			_cmd=var_name+"_hour_num=zeros(N)";
			exec(_cmd);
			_cmd=var_name+"_hour_mean=zeros(N)";
			exec(_cmd);
			_cmd=var_name+"_hour_std=zeros(N)";
			exec(_cmd);
			_cmd=var_name+"_hour_diff=zeros(N)";
			exec(_cmd);
	
	print "hour:",
	for hour in range(N):
		print hour,
		for var_name in var_name_list:
			_cmd=var_name+"_hour_list=[]";
			exec(_cmd);
		for irow in range(len(date_array)):
			date_list=date_array[irow].split(':')
			time_list=time_array[irow].split(':')
			rowdate=mx.DateTime.Date(int(date_list[2]),int(date_list[1]),int(date_list[0]));
			rowtime=mx.DateTime.Time(int(time_list[0]),int(time_list[1]),int(time_list[2]));
			rowdatetime=rowdate+rowtime;
			if rowdatetime.hour==hour and rowdatetime.month==month:
				for var_name in var_name_list:
					if eval(var_name+" is not None"):
						value=eval(var_name+"["+str(irow)+"]");
						if not isnan(value):
							passed = True;
							for condition in condition_list:
								condition1=condition.replace(var_name,'value');
								try:
									tof=eval(condition1);
									if not tof:
										passed = False;
								except:
									pass;
							if passed:
								_cmd=var_name+"_hour_list.append(value)";
								exec(_cmd);
								
							#_cmd=var_name+"_hour_list.append(value)";
							#exec(_cmd);
		for var_name in var_name_list:
			if eval(var_name+" is not None"):
				mlist=eval(var_name+"_hour_list");
			
				_cmd=var_name+"_hour_num["+str(hour)+"]=len(mlist)";
				exec(_cmd);
				_cmd=var_name+"_hour_mean["+str(hour)+"]=mean(mlist)";
				exec(_cmd);
				_cmd=var_name+"_hour_std["+str(hour)+"]=std(mlist)";
				exec(_cmd);
	print 
	
	from pydao.math import WorkSheet,WorkSheet_Column;
	from pydao.ohdf import get_empty_instance;
	ws1=WorkSheet();
	ws1=get_empty_instance(self);
	wsk=WorkSheet_Column(array(range(N)));
	ws1.set_col('hour',wsk);
	for var_name in var_name_list:
		if eval(var_name+" is not None"):
			dataname=var_name+"_hour_num"
			data=eval(dataname);
			wsk=WorkSheet_Column(data);
			ws1.set_col(dataname,wsk);
			
			dataname=var_name+"_hour_std"
			data=eval(dataname);
			wsk=WorkSheet_Column(data);
			ws1.set_col(dataname,wsk);
		
			dataname=var_name+"_hour_mean"
			data=eval(dataname);
			wsk=WorkSheet_Column(data);
			ws1.set_col(dataname,wsk);
		
			dataname=var_name+"_hour_diff"
			monthlymean_name=var_name+"_month_mean"
			monthlymean_data=ws0.get_col(monthlymean_name).get('data')[month-1];
			datadiff=(data-monthlymean_data)/monthlymean_data;
			wsk=WorkSheet_Column(datadiff);
			ws1.set_col(dataname,wsk);
	
	#og.set('ws_'+str(month)+'_hour',ws1);
	return ws1;
	
def hourly_mean_allmonth(self,ws_monthlymean,var_name_list,condition_list,date_var_name,time_var_name):
	print "month:"
	ws_list=range(12);
	for i_month in range(12):
		month=i_month+1;
		print month,
		ws_list[i_month]=self.hourly_mean_amonth(ws_monthlymean,month,var_name_list,condition_list,date_var_name,time_var_name);
	print "done."
	return ws_list;