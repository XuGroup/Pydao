from pylab import *;

def plotyy(x1,y1,x2,y2,marker1='b-',marker2='r-'):
	import numpy as np
	import matplotlib.pyplot as plt

	fig = plt.figure()
	ax1 = gca();
	ax1.plot(x1, y1, marker1)
	#ax1.set_xlabel('time (s)')
	# Make the y-axis label and tick labels match the line color.
	#ax1.set_ylabel('exp', color='b')
	for tl in ax1.get_yticklabels():
		tl.set_color('b')

	ax2 = ax1.twinx()
	ax2.plot(x2, y2,marker2)
	#ax2.set_ylabel('sin', color='r')
	for tl in ax2.get_yticklabels():
		tl.set_color('r')
	plt.show()
	return (ax1,ax2);