from functions import *;
import etc;
import ohdf;
import database;
import physics;
import chemistry;
import tools;
setpath();

global viewer;
viewer=None;
homedir=wherepackageis();
#print "homedir:",homedir

def main():
	#import inspect;
	#print "name:",__name__
	#print inspect.stack()[0][3]
	#print who
	from ohdfvi import OFile_List_Viewer;
	from etc import version,application_list,memory_mode;
	global viewer;
	viewer=OFile_List_Viewer();
	for app in application_list:
		viewer.registry.application_list.append(app);
	viewer.version=etc.version;
	if memory_mode:
		viewer.version=viewer.version+' (memory mode)';
	print viewer.main();
