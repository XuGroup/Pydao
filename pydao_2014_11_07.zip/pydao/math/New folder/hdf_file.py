from pylab import *;
from pydao.ohdf import OGroup;
from multidim_dataset import MultiDim_DataSet;

#from eas_hdf_filter_functions import *;
#=========================================================================
class HDF_File(OGroup,MultiDim_DataSet):
	def __init__(self,filename=None, Ndim=None,shape=None):
		OGroup.__init__(self);
		self.mem_cache={};
		self.filename=filename;
		#self.alias={};
		#self.shape=shape;
		#self.Ndim=Ndim;
		self.co_file_list=[];
		MultiDim_DataSet.__init__(self,Ndim,shape);
		
	def open(self):
		from pydao.rhdf import RFile4,RFile5;
		from pydao.ohdf import dget,dset;
		if self.filename is not None:
			print "Which format?"
			print self.filename
			print "HDF5?",
			self.rfile=RFile5(self.filename);
			success=self.rfile.open();
			if success:
				print "Yes! It's an HDF5."
			else:
				print "No, not an HDF5."
				print "HDF4?",
				self.rfile=RFile4(self.filename);
				success=self.rfile.open();
				if success:
					print "Yes! it's an HDF4."
			if success:
				shape=dget(self,'shape');
				#print "shape:",shape
				if shape is None or len(shape)==0:
					self.data_list=self.data_survey();
					self.shape=self.data_shape(self.data_list);
					print "shape found from survey:",self.shape;
				else:
					print "designated shape:",self.shape
				for idim in range(len(self.shape)):
					ndim=self.shape[idim];
					x=ones(ndim);
					dset(self,'I_'+str(idim)+"_chosen",x==x);
			#x=ones(self.shape)
			#self.element_chosen=x==x;
				if len(self.shape)==2:
					x=ones(self.shape);
					dset(self,'IJ_0_1_chosen',x==x);
				elif len(self.shape)==3:
					for idim in range(len(self.shape)):
						dim_shape=range(len(self.shape));
						lshape=list(self.shape);
						lshape.remove(lshape[idim]);
						x=ones(lshape);
					#dimstr=str(range(len(lshape)));
						dim_shape=range(len(self.shape));
						dim_shape.remove(idim)
						dimstr=str(dim_shape);
						dimstr=dimstr.replace('[','');
						dimstr=dimstr.replace(']','');
						dimstr=dimstr.replace(',','');
						dimstr=dimstr.replace(' ','_');
						chosen_str='IJ_'+dimstr+"_chosen";
						chosen_indices=x==x;
					#print "chosen_str",chosen_str,chosen_indices.shape
						dset(self,chosen_str,chosen_indices);
					x=ones(self.shape);
					name='IJK_0_1_2_chosen';
					dset(self,name,x==x);
					#print "chosen name:",name,dget(self,name).shape
				#print "set: ",name
				from pydao.ohdf import get_empty_instance;
				for co_filename in self.co_file_list:
					co_file=get_empty_instance(self);
					co_file.filename=co_filename;
					co_file.Ndim=self.Ndim;
					#co_file=HDF_File(filename=co_filename,Ndim=self.Ndim);
					ok=co_file.open();
					if ok:
						self.co_file_list.append(co_file);
					else:
						success=False;
						print "cofile not found:",co_filename
						break;
		else:
			print "Error! File name is None!."
			success=False;
		return success;
		
	def get_data_array(self,data_desc,copy2mem=False):
		data_array=self.get_data_with_path(data_desc,copy2mem);
		return data_array;
		
	def get_data_with_path(self,path,copy2mem=False):
		data=None;
		if self.mem_cache.has_key(str(path)):
			data=self.mem_cache[str(path)];
		else:
			data=self.get_data_with_path_cofiles(path);
			if copy2mem:
				data=array(data);
				self.mem_cache[str(path)]=data;
		return data;
		
	def get_data_with_path_cofiles(self,path,copy2mem=False):
		data = None;
		#print "get_data_with_path_cofiles:",path
		try:
			data=self.rfile.get_data_with_path(path);
			#print "found in main file:",self.filename;
		except:
			#print "can not found in main file:",self.filename,path;
			pass;
		if len(array(data).shape)==0:
		#except:
			for co_file in self.co_file_list:
				try:
					data=co_file.get_data_with_path(path);
					#print "found in co_file:\n",co_file.filename;
				except:
					pass;
		if len(array(data).shape)==0:
			import sys;
			#print "can not find:",path
			#sys.exit();
			pass;
		return data;
		
	def isgroup(self,path):
		answer=True;
		try:
			keys=self.rfile.list_path(path);
		except:
			#import traceback;
			#traceback.print_exc();
			answer=False;
		return answer;
		
	def data_survey(self,path=None):
		import copy;
		data_intro={};
		#print "data_survey path:",path
		if path is None:
			path=[];
		for k in self.rfile.list_path(path):
			path1=copy.deepcopy(path);
			path1.append(k);
			#print "path1:",path1
			if self.isgroup(path1):
				dintro=self.data_survey(path1);
				for k in dintro:
					data_intro[k]=dintro[k];
			else:
				data=self.get_data_with_path(path1);
				#print data
				try:
					data_intro[str(path1)]=data.shape;
				except:
					data_intro[str(path1)]=(1,);
		#print "data_intro:",data_intro
		#print "number of data:",len(data_intro)
		return data_intro;
		
	def close(self):
		self.rfile.close();
		for co_file in self.co_file_list:
			co_file.close();

	def list(self,path=None):
		if path is None:
			path=[];
		return self.rfile.list_path(path);