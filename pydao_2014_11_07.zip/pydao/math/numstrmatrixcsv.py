from ..ohdf import OGroup;
import csv;

class NumStrMatrixCSV(OGroup):
	def __init__(self,filename=None,delimeter=None,row_width_chosen=None):
		OGroup.__init__(self);
		self.set('filename',filename);
		self.set('delimeter',delimeter);
		self.set('row_width_chosen',row_width_chosen);
		self.set('numstr_matrix',None);
		self.set('header',[]);
			
	def importcsv(self,filename=None):
		#print "filename:",filename
		if filename is not None:
			self.set('filename',filename);
		
		# prescan rows
		numstr_rows,header,numstr_rows_width=self.read_numstr_rows(filename);
		row_width_kind=list(set(numstr_rows_width));
		row_width_chosen=self.get('row_width_chosen');
		print len(numstr_rows),"total"
		try:
			index=row_width_kind.index(row_width_chosen);
			self.set('row_width_chosen',row_width_kind[index]);
		except:
			if row_width_chosen is None:
				count=0;
				chosen=-1;
				for kind in row_width_kind:
					print "column kind:",kind,"count:",numstr_rows_width.count(kind)
					if numstr_rows_width.count(kind)>count:
						count=row_width_kind.count(kind);
						chosen=kind;
				self.set('row_width_chosen',chosen);
			elif row_width_chosen=="max":
				self.set('row_width_chosen',max(row_width_kind));
			elif row_width_chosen=="min":
				self.set('row_width_chosen',min(row_width_kind));
		print "row_width_chosen",self.get('row_width_chosen')

		# real scan rows
		numstr_rows,header,numstr_rows_width=self.read_numstr_rows\
		(filename,self.get('row_width_chosen'));
		self.set('header',header);
		print len(header),"header rows:",
		print len(numstr_rows),"numstr rows:",
		#print "header:",header
		
		numstr_matrix_list=self.get_numstr_matrix(numstr_rows,self.get('row_width_chosen'));
		#NrowNcol=self.findNcolNrow(NumCols);
		#dptablelist=self.formdptable(numstr_rows,self['row_width_chosen']);
		import numpy;
		numstr_matrix_array=numpy.array(numstr_matrix_list);
		self.set('numstr_matrix',numstr_matrix_array);
		print self.get('filename'),'imported.'
		print 'Found arrary with shape:',numstr_matrix_array.shape;

	def read_numstr_rows(self,filename,Ncol=None):
		delimeter=self.get('delimeter');
		f=open(self.get('filename'),"rU");
		header=[];
		numstr_rows=[];
		numstr_rows_width=[];
		nrow=0;
		for line in f:
			#print line
			line=line.replace('\n','')
			if delimeter is not None: #forced delimeter
				valid_numstr_row,n_num=self.analyze_row(line,delimeter);
			else: # otherwise try other normal delimiters
				valid_numstr_row,n_num=self.analyze_row(line);
				if len(valid_numstr_row)==0 or n_num==0:
					valid_numstr_row,n_num=self.analyze_row(line,'\t');
				if len(valid_numstr_row)==0 or n_num==0:
					valid_numstr_row,n_num=self.analyze_row(line,',');
			if 	len(valid_numstr_row)>0 and n_num>0: # has some numbers in there
				if Ncol is None: 
					numstr_rows.append(valid_numstr_row);
					numstr_rows_width.append(len(valid_numstr_row));
				elif len(valid_numstr_row)==Ncol: # forced Ncol
					numstr_rows.append(valid_numstr_row);
				else:
					header.append(line);
			else:
				header.append(line);
			nrow=nrow+1;
		f.close();
		return (numstr_rows,header,numstr_rows_width);
		
	
	def getfromheader(self,condition,method="pattern",npattern=None):
		resultstr=None;
		#f=open(self.get('filename',"rU"));
		#flist=list(f);
		header=self.get('header');
		#f.close();	
		#print "len(f)",len(flist)
		#print "method:",method
		if method=="pattern":
			import re;
			for line in header:
				g=re.search(condition,line);
				try: 	
					resultstr=g.group(npattern);
					break;
				except:
					pass;
		elif method=="lineNo":
			if len(header)>condition:
				resultstr=header[condition];
			else:
				resultstr="";
		elif method=="tokenline":
			import string;
			foundtoken=False;
			for line in header:
				#print line,condition
				if foundtoken:
					resultstr=line;
					break;
				if string.strip(line)==condition:
					foundtoken=True;
					#print "foundtoken"
		else:
			print "wrong method:",method
		if isinstance(resultstr,str):
			resultstr=resultstr.replace("\n",'');
		return resultstr;
	
	def findNcolNrow(self,NumCols):
		NumColskind=list(set(NumCols));
		Nrows=[];
		for NCol in NumColskind:
			Nrows.append(NumCols.count(NCol));
		Nrowmax=max(Nrows);
		#print Nrows,Nrowmax
		#print type(Nrows),type(Nrowmax),
		index=Nrows.index(Nrowmax);
		Ncol=NumColskind[index];
		#print "Nrow:",Nrowmax,"Ncol:",Ncol
		NN=[Nrowmax,Ncol];
		return NN;
		
	def get_numstr_matrix(self,Numlines,Ncol):
		import numpy;
		dptable=[];
		# print numpy.shape(Numlines);
		for row in Numlines:
			# print "row:",row,type(row);
			if len(row)==Ncol:
				dptable.append(row);
		return dptable;
	
	def analyze_row(self,row,sep=None):
		ele0=row;
		#ele0=line;
		if sep is None:
			row0=ele0.split();
		else:
			row0=ele0.split(sep);
		#print "ele0",ele0,"row0",row0;
		valid_numstr_row=[];
		n_num=0;
		for element in row0:
			try:
				f=float(element);
				n_num=n_num+1;
			except:
				f=element;
			valid_numstr_row.append(f);
			#print valid_numstr_row
		#print "sep:",sep,"len",len(valid_numstr_row)
		if row[0]=='#':
			n_num=0;
			valid_numstr_row=[];
		return (valid_numstr_row,n_num);