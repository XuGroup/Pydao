from pylab import *;

def xyz2rthetaphi(x,y,z):
	if type(x) is ndarray:
		I=x!=0;
		phi=x-x;
		phi[I]=arctan(y[I]/x[I]);
		I=x<0;
		phi[I]=phi[I]+pi;
	elif x==0:
		phi=pi/2;
	else:
		phi=arctan(y/x);
		if x<0:
			phi=phi+pi;
			
	r2=x**2+y**2;
	if type(r2) is ndarray:
		theta=r2-r2;
		I=r2>0;
		theta[I]=arctan(r2[I]**0.5/z[I]);
		I=theta<0
		theta[I]=theta[I]+pi;
	elif z==0:
		theta=pi/2;
	else:
		theta=arctan(r2**0.5/z);
		if theta<0:
			theta=theta+pi;
	r=(x**2+y**2+z**2)**0.5;
	return (r,theta,phi);
	
	
def rthetaphi2xyz(r,theta,phi):
	x=r*sin(theta)*cos(phi);
	y=r*sin(theta)*sin(phi);
	z=r*cos(theta);
	return (x,y,z);