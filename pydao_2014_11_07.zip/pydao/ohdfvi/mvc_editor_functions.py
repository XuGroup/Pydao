from pylab import *;
from mvc_editor_frames import dExplorer;

def get_ogroup_explorer_editor( parent, editor, name=None ):
	import wx;
	try:
		dobj  = editor.object;
		dexp=dExplorer();
		dexp.create(parent,wx.ID_ANY)
		if name is None:
			dexp.data=dobj;
		else:
			dexp.data=dobj.get(name);
		dexp.rootview();
		return dexp.widget;
	except:
		import traceback
		traceback.print_exc()
		raise
