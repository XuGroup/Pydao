from pylab import *;
from pydao.ohdf import OGroup,isnumeric;
import pydao.math,copy;
from qmvariable import Operator;
from oneparticle import Base_Mat;

class Base_Xyz2B(OGroup):
	def __init__(self):
		#OGroup.__init__(self);
		self.set2xyz2bzero();
	
	def __call__(self,x,y,z,x1,y1,z1):
		value=1.*x*y*z/x/y/z*x1/x1*y1/y1*z1/z1;
		wfunction=self.get('xyz2bfun');
		if wfunction is not None:
			value=value*wfunction(x,y,z,x1,y1,z1);
		return value;
		
	def xyz2bpara_get(self,name):
		xyz2bparas=self.get('xyz2bparas');
		return xyz2bparas.get(name);
		
	def xyz2bpara_set(self,name,value):
		xyz2bparas=self.get('xyz2bparas');
		xyz2bparas.set(name,value);
		return;
		
	def xyz2bpara_keys(self):
		xyz2bparas=self.get('xyz2bparas');
		return xyz2bparas.keys();
		
	def set2xyz2bzero(self):
		self.set('xyz2bfun',0);
		self.set('xyz2bparas',OGroup());
		
	def qmvcopy(self,qmv=None):
		if qmv is None:
			qmv=Base_Xyz();
		qmv.set('xyz2bfun',self.get('xyz2bfun'));
		return qmv;
		
	def info(self,indent=0):
		print indent*"|_","<Base_Xyz2B>"
		print indent*"|_",
		if self.qmvkind()=='base':
			print "xyz2b function:",self.get('xyz2bfun')

	def baseiproduct_xyz2b(self,wf):
		if isinstance(wf,Base_Xyz2B):
			r_max=self.rrange();
			xmin=-r_max;
			xmax=r_max;
			ymin=-r_max;
			ymax=r_max;
			zmin=-r_max;
			zmax=r_max;
			Np=self.xyz2bpara_get('Np');
			if Np is None:
				Np=12;
			dx=1.*(xmax-xmin)/(Np-1);
			dy=1.*(ymax-ymin)/(Np-1);
			dz=1.*(zmax-zmin)/(Np-1);
			x,y,z,x1,y1,z1= mgrid[xmin:xmax:Np*1j,ymin:ymax:Np*1j,zmin:zmax:Np*1j,xmin:xmax:Np*1j,ymin:ymax:Np*1j,zmin:zmax:Np*1j];
			self_fun=self.get('xyz2bfun');
			wf_fun=wf.get('xyz2bfun');
			product=(self_fun(x,y,z,x1,y1,z1)*conjugate(wf_fun(x,y,z,x1,y1,z1))).sum()*(dx*dy*dz)**2;
		return product;
		
	def base_braopketiproduct_xyz2b(self,bra0,bra1,ket0,ket1):
		bra_fun0=bra0.get('xyzfun');
		bra_fun1=bra1.get('xyzfun');
		ket_fun0=ket0.get('xyzfun');
		ket_fun1=ket1.get('xyzfun');
		bra_2bfun=lambda x,y,z,x1,y1,z1: bra_fun0(x,y,z)*bra_fun1(x1,y1,z1);
		ket_2bfun=lambda x,y,z,x1,y1,z1: ket_fun0(x,y,z)*ket_fun1(x1,y1,z1);
		op_2bfun=self.get('xyz2bfun');
			
		#bra0.info();
		#print bra0.rpeak(),bra1.rpeak(),ket0.rpeak(),ket1.rpeak()
		r_peak=max([bra0.rpeak(),bra1.rpeak(),ket0.rpeak(),ket1.rpeak()]);
		#print bra0.rspread(),bra1.rspread(),ket0.rspread(),ket1.rspread()
		r_sigma=max([bra0.rspread(),bra1.rspread(),ket0.rspread(),ket1.rspread()]);
		r_max=r_peak+2*r_sigma;
		
		xmin=-r_max;
		xmax=r_max;
		ymin=-r_max;
		ymax=r_max;
		zmin=-r_max;
		zmax=r_max;
			
			
		#print r_max,Np
		dx=1.*(xmax-xmin)/(Np-1);
		dy=1.*(ymax-ymin)/(Np-1);
		dz=1.*(zmax-zmin)/(Np-1);
		#x,y,z,x1,y1,z1= mgrid[xmin:xmax:Np*1j,ymin:ymax:Np*1j,zmin:zmax:Np*1j,xmin:xmax:Np*1j,ymin:ymax:Np*1j,zmin:zmax:Np*1j];
		X=mgrid[xmin:xmax:Np*1j];
		y,z,x1,y1,z1= mgrid[ymin:ymax:Np*1j,zmin:zmax:Np*1j,xmin:xmax:Np*1j,ymin:ymax:Np*1j,zmin:zmax:Np*1j];
		
		from pydao.tools import Progress_Teller;
		pt=Progress_Teller(len(X));
		
		mate=0;
		i=0;
		for x in X: 
			gket=ket_2bfun(x,y,z,x1,y1,z1);
			gop=op_2bfun(x,y,z,x1,y1,z1);
			gbra=bra_2bfun(x,y,z,x1,y1,z1);
			I=isfinite(gop);
			#print gop,I
			num_grid=conjugate(gbra[I])*gop[I]*gket[I];
			#num_grid_finite=num_grid[I];
			#print gop.shape,num_grid.shape
			mate=mate+num_grid.sum()*(dx*dy*dz)**2;		
			i=i+1;
			pt.tell(i);
		return mate;
		
class Operator_Xyz2B(Operator,Base_Xyz2B):
	def __init__(self):
		Operator.__init__(self);
		Base_Xyz2B.__init__(self);
		self.set('coefficient',1);
		self.set('particle_list',[0]);
		
	def matrix_element(self,bra,ket):
		if self.qmvkind()=='super':
			self_subs=self.get('subs');
			mate=0;
			for self_sub in self_subs:
				mate=mate+self_sub.basestackop_mate(bra,ket);
		else:
			mate=self.basestackop_mate(bra,ket);
		return mate;
		
	def basestackop_mate(self,bra,ket):
		if bra.qmvkind()=="super":
			bra_subs=bra.get('subs');
			mate=0;
			for bra_sub in bra_subs:
				mate=mate+self.basestackopbra_mate(bra_sub,ket);
		else:
			mate=self.basestackopbra_mate(bra,ket);
		return mate;
		
	def basestackopbra_mate(self,bra,ket):
		if ket.qmvkind()=="super":
			ket_subs=ket.get('subs');
			mate=0;
			for ket_sub in ket_subs:
				mate=mate+self.basestackopbraket_mate(bra,ket_sub);
		else:
			mate=self.basestackopbraket_mate(bra,ket);
		return mate;
		
	def basestackopbraket_mate(self,bras,kets):
		plist=self.get('particle_list');
		if len(plist)==1:
			mate=Operator.matrix_element(self,bras,kets);
		else:
			mate=1;
			bra_stack=bras.get('stack');
			ket_stack=kets.get('stack');
			bra0=bra_stack[0];
			bra1=bra_stack[1];
			ket0=ket_stack[0];
			ket1=ket_stack[1];
			if isinstance(bra0,Base_Mat):
				mate=mate*bra0.baseiproduct_mat(ket0);
			if isinstance(bra1,Base_Mat):
				mate=mate*bra1.baseiproduct_mat(ket1);
			if mate!=0:
				mate=mate*self.base_braopketiproduct(bras,kets);
		return mate;
			
	def qmvcopy(self,qmv=None):
		if qmv is None:
			qmv=MBOperator();
		qmv.set('particle_list',self.get('particle_list'));
		return qmv;

class Coulomb_Interaction(Operator_Xyz2B):
	def __init__(self):
		Operator_Xyz2B.__init__(self);
		self.set('coulomb_integral_records',None);
		self.set('exchange_integral_records',None);
		from pydao.physics import e_mass,e_charge,hbar,k_E;
		fun2b=lambda x,y,z,x1,y1,z1: k_E*e_charge**2/((x-x1)**2+(y-y1)**2+(z-z1)**2)**0.5;
		self.set('xyz2bfun',fun2b);
		self.xyz2bpara_set('Np',10);
		self.set('particle_list',[0,1]);

	def get_integralfile_fullname(self):
		from pydao.physics import coulomb_integral_file,exchange_integral_file;
		import os,pydao;
		ps=os.path.abspath(__file__);
		#print "__file__:",ps;
		curdir=os.path.abspath(os.path.curdir);
		#print "curdir:",curdir
		ps=ps.replace(curdir,pydao.homedir);
		#print "__file_ after replace:",ps
		ps=os.path.dirname(ps);
		#print "ps:",ps
		ci_file=os.path.join(ps,coulomb_integral_file);
		ex_file=os.path.join(ps,exchange_integral_file);
		return ci_file,ex_file;
		
	def get_coulomb_integral_records(self):
		cir=self.get('coulomb_integral_records');
		if cir is None:
			from pydao.ohdf import OFile;
			ci_file,ex_file=self.get_integralfile_fullname();
			cir=OFile(ci_file);
			cir.open();
			self.set('coulomb_integral_records',cir);
		elif not cir.is_ondisk():
			cir.open();
		return cir;
		
	def get_exchange_integral_records(self):
		cir=self.get('exchange_integral_records');
		if cir is None:
			from pydao.ohdf import OFile;
			ci_file,ex_file=self.get_integralfile_fullname();
			cir=OFile(ex_file);
			cir.open();
			self.set('exchange_integral_records',cir);
		elif not cir.is_ondisk():
			cir.open();
		return cir;
			
	def save_integral_records(self):
		cir=self.get_coulomb_integral_records();
		cir.close();
		eir=self.get_exchange_integral_records();
		eir.close();
	
	def find_integral_from_records(self,bras,kets,Np):
		value=None;
		bra_stack=bras.get('stack');
		ket_stack=kets.get('stack');
		bra0=bra_stack[0];
		bra1=bra_stack[1];
		ket0=ket_stack[0];
		ket1=ket_stack[1];
		if bra0.hassameqmnumbers(ket0) and bra1.hassameqmnumbers(ket1):
			#this is case of coulomb integral
			# print "to find coulomb integral",bra0.qmnumbers(),bra1.qmnumbers(),Np
			cir=self.get_coulomb_integral_records();
			#records=cir.get('records');
			ks=cir.keys();
			for k in ks:
				r=cir.get(k);
				Z0,n0,l0,m0=r.get('Znlm0');
				Z1,n1,l1,m1=r.get('Znlm1');
				v=r.get('value');
				rNp=r.get('Np');
				mb0=bra0.sympara_get('m');
				mb1=bra1.sympara_get('m');
				if Np==rNp:
					# print bra0.qmnumbers(),bra1.qmnumbers()
					# print (Z0,n0,l0,mb0),(Z1,n1,l1,mb1)
					# print bra0.hassameqmnumbers((Z1,n1,l1,mb0)),bra1.hassameqmnumbers((Z0,n0,l0,mb1))
					# print bra1.hassameqmnumbers((Z1,n1,l1,mb1)),bra0.hassameqmnumbers((Z0,n0,l0,mb0))
					if bra0.hassameqmnumbers((Z1,n1,l1,mb0)) and bra1.hassameqmnumbers((Z0,n0,l0,mb1)) or \
					bra1.hassameqmnumbers((Z1,n1,l1,mb1)) and bra0.hassameqmnumbers((Z0,n0,l0,mb0)):
						# print "value:",v
						value=v;
		elif bra0.hassameqmnumbers(ket1) and bra1.hassameqmnumbers(ket0):
			#this is the case exchange integral
			# print "to find exchange integral",bra0.qmnumbers(),bra1.qmnumbers(),Np
			cir=self.get_exchange_integral_records();
			#records=cir.get('records');
			ks=cir.keys();
			for k in ks:
				r=cir.get(k);
				Z0,n0,l0,m0=r.get('Znlm0');
				Z1,n1,l1,m1=r.get('Znlm1');
				v=r.get('value');
				rNp=r.get('Np');
				if Np==rNp:
					# print bra0.qmnumbers(),bra1.qmnumbers()
					# print (Z0,n0,l0,m0),(Z1,n1,l1,m1)
					# print bra0.hassameqmnumbers((Z1,n1,l1,m1)),bra1.hassameqmnumbers((Z0,n0,l0,m0))
					# print bra1.hassameqmnumbers((Z1,n1,l1,m1)),bra0.hassameqmnumbers((Z0,n0,l0,m0))
					if bra0.hassameqmnumbers((Z1,n1,l1,m1)) and bra1.hassameqmnumbers((Z0,n0,l0,m0)) or \
					bra1.hassameqmnumbers((Z1,n1,l1,m1)) and bra0.hassameqmnumbers((Z0,n0,l0,m0)):
						# print "value:",v
						value=v;
		# if value is not None:
			# print "record found:",value
		# else:
			# print "record not found"
		return value;		
	
	def store_integral_to_records(self,bras,kets,Np,value):
		import time;
		bra_stack=bras.get('stack');
		ket_stack=kets.get('stack');
		bra0=bra_stack[0];
		bra1=bra_stack[1];
		ket0=ket_stack[0];
		ket1=ket_stack[1];
		if bra0.hassameqmnumbers(ket0) and bra1.hassameqmnumbers(ket1):
			#this is case of coulomb integral
			print "to store coulomb integral",bra0.qmnumbers(),bra1.qmnumbers(),Np
			cir=self.get_coulomb_integral_records();
			#records=cir.get('records');
			r=OGroup();
			r.set('Znlm0',bra0.qmnumbers());
			r.set('Znlm1',bra1.qmnumbers());
		elif bra0.hassameqmnumbers(ket1) and bra1.hassameqmnumbers(ket0):
			#this is the case exchange integral
			print "to store exchange integral",bra0.qmnumbers(),bra1.qmnumbers(),Np
			cir=self.get_exchange_integral_records();
			#records=cir.get('records');
			r=OGroup();
			r.set('Znlm0',bra0.qmnumbers());
			r.set('Znlm1',bra1.qmnumbers());
		r.set('Np',Np);
		r.set('value',value);
		r.set("r"+str(len(cir.keys())),r);
		return;		
		
	def base_braopketiproduct(self,bras,kets):
		Np=self.xyz2bpara_get('Np');
		if Np is None:
			Np=10;
		bra_stack=bras.get('stack');
		ket_stack=kets.get('stack');
		bra0=bra_stack[0];
		bra1=bra_stack[1];
		ket0=ket_stack[0];
		ket1=ket_stack[1];
		if bra0.hassameqmnumbers(ket0) and bra1.hassameqmnumbers(ket1) or \
		bra0.hassameqmnumbers(ket1) and bra1.hassameqmnumbers(ket0): 
			I=self.find_integral_from_records(bras,kets,Np);
			if I is None:
				I=self.base_braopketiproduct_xyz2b(bra0,bra1,ket0,ket1);
				self.store_integral_to_records(bras,kets,Np,I);
			
			mate=I;	
			wfs=bra_stack+ket_stack;
			for wf in wfs:
				mate=mate*wf.get('coefficient');
		else:
			mate=0;
		return mate;