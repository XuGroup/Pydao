from pylab import *;
from  pydao.ohdfvi import Application;
from  pydao.ohdf import OGroup;

def ldc_analysis_view(ldc):
	from ldc_controls import LDC_ModelView;
	from enthought.traits.ui.api import \
	Item,Group,Tabbed,VGroup,HGroup,View,\
	ArrayEditor,ButtonEditor,CheckListEditor,BooleanEditor;
	
	handler=LDC_ModelView(ldc);
	
	ldc.i_polar=1;
	group_cal=VGroup(\
	Item('i_polar',show_label=True),\
	Item('bu_cal_1d_dispersion',editor=ButtonEditor(label='1d_dispersion')),\
	Item('bu_cal_2d_dispersion',editor=ButtonEditor(label='2d_dispersion')),\
	Item('bu_cal_polarization',editor=ButtonEditor(label='polarization')),\
		#Item('bu_cal_spectrum',editor=ButtonEditor(label='spectrum')),\
	show_labels=False,show_border = True,label='Analysis');
		
	editor1=CheckListEditor(values=ldc.keys());
	ldc.color=zeros(3);
	ldc.mode_index=3;
	ldc.k_index=0;
	ldc.atom_displacement_factor=50;
	ldc.center_of_mass_displacement_factor=1;
	ldc.i_polar=1;
	ldc.new_figure=True;
	group_view=VGroup(\
	Item('k_index',show_label=True),\
	Item('bu_plot_energy',editor=ButtonEditor(label='plot_energy')),\
	Item('i_polar',show_label=True),\
	Item('bu_plot_polarization',editor=ButtonEditor(label='plot_polarization')),\
	Item('mode_index',show_label=True),\
	Item('color',show_label=True,editor=ArrayEditor()),\
	Item('atom_displacement_factor',show_label=True),\
	Item('center_of_mass_displacement_factor',show_label=True),\
	Item('bu_plot_mode',editor=ButtonEditor(label='plot_mode')),\
	Item('bu_plot_spectrum',editor=ButtonEditor(label='plot_spectrum')),\
	Item('bu_plot_primitive_cell',editor=ButtonEditor(label='plot_primitive_cell')),\
	Item('new_figure',editor=BooleanEditor(),show_label=True),\
	show_labels=False,show_border = True,label='View');
	
	view=View(Tabbed(group_cal,group_view),handler=handler,kind='live',\
	title=ldc.string()+'OnAnalysis');
	#ldc.configure_traits(view=view);
	return view;