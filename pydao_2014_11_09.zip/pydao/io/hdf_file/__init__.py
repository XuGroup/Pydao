from pylab import *;
from pydao.ohdf import OGroup;
 
class Savable_MethodResultdBase(OGroup):
	def __init__(self):
		#OGroup.__init__(self);
		pass;
		
	def get_savedresultdbase_fullfilename(self):
		import os,pydao,inspect;
		savedresult_dbasename=self.get('savedresult_dbasename');
		ps=os.path.abspath(inspect.getfile(self.__class__));
		curdir=os.path.abspath(os.path.curdir);
		ps=ps.replace(curdir,pydao.homedir);
		ps=os.path.dirname(ps);
		savedresult_fullfilename=os.path.join(ps,savedresult_dbasename)+'.hdf';
		return savedresult_fullfilename;
		
	def get_savedresultdbase_filehandle(self):
		cir=self.get('savedresult_dbasehandle');
		if cir is None:
			from pydao.ohdf import OFile;
			savedresult_fullfilename=self.get_savedresultdbase_fullfilename();
			cir=OFile(savedresult_fullfilename);
		 	cir.open();
			self.set('savedresult_dbasehandle',cir);
		elif not cir.is_ondisk():
			cir.open();
		#cir=cir.copy2mem();
		return cir;
			
	def save_resultdbase_2disk(self):
		cir=self.get_savedresultdbase_filehandle();
		cir.close();
		
	def remove_diskfile(self):
		import os;
		savedresult_fullfilename=self.get_savedresultdbase_fullfilename();
		try:
			os.remove(savedresult_fullfilename);
		except:
			print "can not remove",savedresult_fullfilename
		
	def store_resultrecord_2dbase(self,record):
		import time;
		cir=self.get_savedresultdbase_filehandle();
		time_r=time.time();
		tstr1=str(int(floor(time_r)));
		tstr2=str(int((time_r-floor(time_r)+1)*1000));
		tstr2=tstr2[1:];
		# print tstr1,tstr2
		rname="r"+tstr1+tstr2;
		cir.set(rname,record);
		return;		
	
	def find_resultrecord_fromdbase(self,parameters):
		cir=self.get_savedresultdbase_filehandle();
		value=None;
		for k in cir.keys():
			match=True;
			# print "record:",k
			record=cir.get(k);
			for kr in parameters.keys():
				vdbase=record.get(kr);
				vpara=parameters.get(kr);
				# print "kr,vdbase,vpara:",kr,vdbase,vpara
				if vdbase!=vpara:
					match=False;
					break;
			if match:
				value=record.get('value');
				break;
		# print "value:",value
		return value;		
	