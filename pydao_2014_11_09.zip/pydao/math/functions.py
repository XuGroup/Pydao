from pylab import *;

def isnumeric(a):
	isornot=True;
	try:
		b=a+1;
	except:
		isornot=False;
	return isornot;

def xy2_meshindex(x_list,y_list,x_mesh):
	Lx=len(x_mesh);
	x_indexed=(x_mesh[0:len(x_mesh)-1]+x_mesh[1:])/2;
	y_indexed=zeros(Lx-1)+nan;
	y_indexed_err=zeros(Lx-1)+nan;
	y_indexed_count=zeros(Lx-1);
	
	for i in range(len(x_list)):
		x=x_list[i];
		index=mesh_index(x,x_mesh);
		if not isnan( y_indexed[index]):
			y_indexed[index]=y_indexed[index]+y_list[i];
		else:
			y_indexed[index]=y_list[i];
		y_indexed_count[index]+=1;
	#I=y_indexed!=nan;
	I=isfinite(y_indexed);
	y_indexed[I]=y_indexed[I]/y_indexed_count[I];
	
	
	for i in range(len(x_list)):
		x=x_list[i];
		index=mesh_index(x,x_mesh);
		if not isnan(y_indexed_err[index]):
			y_indexed_err[index]+=(y_list[i]-y_indexed[index])**2;
		else:
			y_indexed_err[index]=(y_list[i]-y_indexed[index])**2;
	#print y_indexed_err
	y_indexed_err[I]=(y_indexed_err[I]/y_indexed_count[I])**0.5;
	
	#print "I:",I
	#print x_indexed,y_indexed,y_indexed_err
	xnew=x_indexed[I];
	ynew=y_indexed[I];
	ynew_err=y_indexed_err[I];
	
	result={};
	result['xnew']=xnew;
	result['ynew']=ynew;
	result['ynew_err']=ynew_err;
	result['I']=I;
	result['x_indexed']=x_indexed;
	result['y_indexed']=y_indexed;
	result['y_indexed_err']=y_indexed_err;
	result['y_indexed_count']=y_indexed_count;
	return result;

def xyz2_meshindex(x_list,y_list,z_list,x_mesh,y_mesh):
	Lx=len(x_mesh);
	Ly=len(y_mesh);
	
	x_indexed=arange(Lx-1);
	y_indexed=arange(Ly-1);
	
	y_mesh_indexed,x_mesh_indexed=meshgrid(y_mesh[1:],x_mesh[1:]);

	z_mesh_indexed=zeros([Lx-1,Ly-1])+nan;
	z_mesh_indexed_count=zeros([Lx-1,Ly-1]);
	
	for i in range(len(x_list)):
		x=x_list[i];
		x_index=mesh_index(x,x_mesh);
		y=y_list[i];
		y_index=mesh_index(y,y_mesh);
		#print "indices:",x_index,y_index
		if not isnan(z_mesh_indexed[x_index,y_index]):
			z_mesh_indexed[x_index,y_index]+=z_list[i];
		else:
			z_mesh_indexed[x_index,y_index]=z_list[i];
		z_mesh_indexed_count[x_index,y_index]+=1;
		if z_mesh_indexed_count[x_index,y_index]==0:
			print 'count:',z_mesh_indexed_count[x_index,y_index]
			print x_index,y_index;
			
	I=isfinite(z_mesh_indexed);
	z_mesh_indexed[I]=z_mesh_indexed[I]/z_mesh_indexed_count[I];
	

	xnew=x_mesh_indexed[I];
	ynew=y_mesh_indexed[I];
	znew=z_mesh_indexed[I];
	
	result={};
	result['xnew']=xnew;
	result['ynew']=ynew;
	result['znew']=znew;
	result['I']=I;
	result['x_mesh_indexed']=x_mesh_indexed;
	result['y_mesh_indexed']=y_mesh_indexed;
	result['z_mesh_indexed']=z_mesh_indexed;
	result['z_mesh_indexed_count']=z_mesh_indexed_count;

	return result;

	
def mesh_index(x,x_mesh):
	indices=arange(0,len(x_mesh)-1);
	x_mesh_left=x_mesh[1:];
	x_mesh_right=x_mesh[0:len(x_mesh)-1];
	Ileft=x<=x_mesh_left;
	Iright=x>x_mesh_right;
	I=logical_and(Ileft,Iright);
	index=indices[I];
	if len(index)==0:
		index=-1;
		print "mesh_index: out of range."
	else:
		index=index[0];
	return index;
	
def strarray_to_numarray(strarray):
	numarray=zeros(strarray.shape);
	i=0;
	n_nan=0;
	for s in strarray:
		try:
			df=eval(s);
		except:
			df=eval('nan');
			n_nan=n_nan+1;
		numarray[i]=df;
		i=i+1;
	return (numarray,n_nan);