from pylab import *;

def int1d(xs,fs):
	dxs=diff(xs);
	# print dxs.shape
	result=sum(dxs*fs[0:-1])+dxs[-1]*fs[-1];
	return result;

def int2d(xs,ys,fxys):
	N,M=fxys.shape;
	fys=zeros(M);
	for iy in range(M):
		fys[iy]=int1d(xs,fxys[:,iy]);
	result=int1d(ys,fys);
	return result;