from pylab import *;
from pydao.physics.solidstate import Lattice;
from pydao.math import direct2cartesian,vdot,vlen,vXprod;

def reflection_condition(kpoint_direct,spacegroupnumber):
	h=kpoint_direct[0];
	k=kpoint_direct[1];
	l=kpoint_direct[2];
	reflection=False;
	if spacegroupnumber==62:
		if k==0 and l==0:
			if mod(h,2)==0:
				reflection=True;
		elif h==0 and l==k:
			if mod(l,2)==0:
				reflection=True;
		elif k==0 and l==0:
			if mod(h,2)==0:
				reflection=True;
		elif h==0:
			if mod(k,2)==0:
				reflection=True;
		elif k==0:
			if mod(h+l,2)==0:
				reflection=True;
		elif mod(h+k,2)==0 and mod(l,2)==0:
			reflection=True;
	elif spacegroupnumber==166:
		if l==0 and h==-k:
			if mod(h,3)==0:
				reflection=True;
		elif h==0 and k==0:
			if mod(l,3)==0:
				reflection=True;
		elif h==-k:
			if mod(h+l,3)==0:
				reflection=True;
		elif h==k:
			if mod(l,3)==0:
				reflection=True;
		elif l==0:
			if mod(-h+k,3)==0:
				reflection=True;
		elif mod(-h+k+l,3)==0:
			reflection=True;
	elif spacegroupnumber==167:
		if h==0 and k==0:
			if mod(l,6)==0:
				reflection=True;
		elif h==-k and l==0:
			if mod(h,3)==0:
				reflection=True;
		elif h==-k:
			if mod(h+l,3)==0 and mod(l,2)==0:
				reflection=True;
		elif h==k:
			if mod(l,3)==0:
				reflection=True;
		elif l==0:
			if mod(-h+k,3)==0:
				reflection=True;
		elif mod(-h+k+l,3)==0 and mod(l,2)==0:
			reflection=True;
	elif spacegroupnumber==185:
		if h==-k:
			if mod(l,2)==0:
				reflection=True;
		else:
			if mod(l,2)==0:
				reflection=True;
	elif spacegroupnumber==194:
		if h==k:
			if mod(l,2)==0:
				reflection=True;
		else:
			if mod(l,2)==0 :#or mod(h-k,3)==1 or mod(h-k,3)==2:
				reflection=True;
	elif spacegroupnumber==206:
		if k==0 and l==0:
			if mod(h,2)==0:
				reflection=True;
		elif k==0 and h==0:
			if mod(l,2)==0:
				reflection=True;
		elif l==0 and h==0:
			if mod(k,2)==0:
				reflection=True;
		elif h==k:
			if mod(l,2)==0:
				reflection=True;
		elif h==l:
			if mod(k,2)==0:
				reflection=True;
		elif l==k:
			if mod(h,2)==0:
				reflection=True;
		elif h==0:
			if mod(k,2)==0 and mod(l,2)==0:
				reflection=True;
		elif k==0:
			if mod(h,2)==0 and mod(l,2)==0:
				reflection=True;
		elif l==0:
			if mod(h,2)==0 and mod(k,2)==0:
				reflection=True;	
		elif mod(k,2)==0 and mod(l,2)==0 and mod(h,2)==0:
			reflection=True;
	elif spacegroupnumber==213:
		if k==0 and l==0:
			if mod(h,4)==0:
				reflection=True;
		elif h==0 and l==0:
			if mod(k,4)==0:
				reflection=True;
		elif k==0 and h==0:
			if mod(l,4)==0:
				reflection=True;
		elif h==0:
			if mod(k,2)==1 or mod(l,2)==1 or mod(k+l,4)==0:
				reflection=True;
		elif k==0:
			if mod(l,2)==1 or mod(h,2)==1 or mod(h+l,4)==0:
				reflection=True;
		elif l==0:
			if mod(h,2)==1 or mod(k,2)==1 or mod(h+k,4)==0:
				reflection=True;
		elif mod(h,2)==1 and mod(k,2)==1:
			reflection=True;
		elif mod(l,2)==1 and mod(k,2)==1:
			reflection=True;	
		elif mod(l,2)==1 and mod(h,2)==1:
			reflection=True;			
		elif mod(h,2)==1 and mod(k,4)==0 and mod(l,4)==2:
			reflection=True;
		elif mod(k,2)==1 and mod(l,4)==0 and mod(h,4)==2:
			reflection=True;
		elif mod(l,2)==1 and mod(h,4)==0 and mod(k,4)==2:
			reflection=True;
		elif mod(h,4)==2 and mod(k,4)==2 and mod(l,4)==2:
			reflection=True;
		elif mod(h,4)==0 and mod(k,4)==0 and mod(l,4)==0:
			reflection=True;
	elif spacegroupnumber==225:
		if k==0 and l==0:
			if mod(h,2)==0:
				reflection=True;
		elif h==k:
			if mod(h+l,2)==0:
				reflection=True;
		elif h==0:
			if mod(k,2)==0 and mod(l,2)==0:
				reflection=True;
		elif mod(h+k,2)==0 and mod(h+l,2)==0 and mod(k+l,2)==0 and mod(h,2)==0:
			reflection=True;
	elif spacegroupnumber==227:
		if k==0 and l==0:
			if mod(h,4)==0:
				reflection=True;
		elif h==0 and l==0:
			if mod(k,4)==0:
				reflection=True; 
		elif k==0 and h==0:
			if mod(l,4)==0:
				reflection=True; 
		elif h==0:
			if mod(k+l,4)==0 and mod(k,2)==0 and mod(l,2)==0:
				reflection=True;
		elif k==0:
			if mod(h+l,4)==0 and mod(h,2)==0 and mod(l,2)==0:
				reflection=True;
		elif l==0:
			if mod(k+h,4)==0 and mod(k,2)==0 and mod(h,2)==0:
				reflection=True;
		elif h==k:
			if mod(h+l,2)==0:
				reflection=True;
		elif h==l:
			if mod(h+k,2)==0:
				reflection=True;
		elif l==k:
			if mod(h+l,2)==0:
				reflection=True;
		elif mod(h+k,2)==0 and mod(h+l,2)==0 and mod(k+l,2)==0:
			if (mod(h,2)==1 and mod(h+k+l,4)==0) \
			or (mod(k,2)==1 and mod(h+k+l,4)==0) \
			or (mod(l,2)==1 and mod(h+k+l,4)==0):
				if (mod(h,2)==1) or (mod(h,4)==0 and mod(k,4)==0 and mod(l,4)==0) or (mod(h,4)==2 and mod(k,4)==2 and mod(l,4)==2)\
				or (mod(k,2)==1) or (mod(h,4)==0 and mod(k,4)==0 and mod(l,4)==0) or (mod(h,4)==2 and mod(k,4)==2 and mod(l,4)==2)\
				or (mod(h,2)==1) or (mod(h,4)==0 and mod(k,4)==0 and mod(l,4)==0) or (mod(h,4)==2 and mod(k,4)==2 and mod(l,4)==2):
					if (mod(h,2)==1) or mod(h+k+l,4)==0\
					or (mod(k,2)==1) or mod(h+k+l,4)==0\
					or (mod(l,2)==1) or mod(h+k+l,4)==0:
						reflection=True;
	else:
		reflection=True;
	return reflection;
