from pylab import *;
lazy=False;
from pydao.ohdf import OGroup;

def OnNewLattice(ldc,event):
	from lattice import Lattice;
	from atoms import Atom;
	#print "in OnNewConfiguration"
	a=5.35;
	a1=array([a, a, 0.])
	a2=array([a, 0,  a])
	a3=array([0., a, a]);
	basis=array([a1,a2,a3]);
	
	
	atoms=OGroup();
	print Atom
	AtomBi = Atom(mass=209.,charge=3.,intrapos=array([0.01,0.01,0.01]),\
	coordinate='direct',type='Bi');
	atoms.set('Bi1',AtomBi);
	
	AtomBi = Atom(mass=209.,charge=3.,intrapos=array([0.51,0.51,0.51]),\
	coordinate='direct',type='Bi');
	atoms.set('Bi2',AtomBi);
	
	AtomFe = Atom(mass=56.,charge=3.,intrapos=array([0.25,0.25,0.25]),\
	coordinate='direct',type='Fe');
	atoms.set('Fe1',AtomFe);

	AtomFe = Atom(mass=56.,charge=3.,intrapos=array([0.75,0.75,0.75]),\
	coordinate='direct',type='Fe');
	atoms.set('Fe2',AtomFe);
	
	AtomO1 = Atom(mass=16.,charge=-2.,intrapos=array([0.5,0.,0.]),\
	coordinate='direct',type='O');
	atoms.set('O1',AtomO1);
	
	AtomO2 = Atom(mass=16.,charge=-2.,intrapos=array([0.,0.5,0.]),\
	coordinate='direct',type='O');
	atoms.set('O2',AtomO2);

	AtomO3 = Atom(mass=16.,charge=-2.,intrapos=array([0.,0.,0.5]),\
	coordinate='direct',type='O');
	atoms.set('O3',AtomO3);
	
	AtomO1 = Atom(mass=16.,charge=-2.,intrapos=array([0.5,0.5,0.]),\
	coordinate='direct',type='O');
	atoms.set('O4',AtomO1);
	
	AtomO2 = Atom(mass=16.,charge=-2.,intrapos=array([0.,0.5,0.5]),\
	coordinate='direct',type='O');
	atoms.set('O5',AtomO2);

	AtomO3 = Atom(mass=16.,charge=-2.,intrapos=array([0.5,0.,0.5]),\
	coordinate='direct',type='O');
	atoms.set('O6',AtomO3);
		
	lattice=Lattice();
	lattice.set('atoms',atoms);
	lattice.set('basis',basis);
	lattice.set('nei_distance',2**0.5*a/2*1.1);
	ldc.set('lattice',lattice);
	print "default lattice constructed"
		
def OnNewConfig(ldc,event):
	config=OGroup();
	config.set('norm_krange',arange(0.0,0.5,0.5));
	config.set('k_direction',array([1,0,0]));
	#config.set('k_direction_list',
	ldc.set('config',config);
	print "new ldc done."

def OnAnalyze(ldc,event):
	from ldc_view import ldc_analysis_view;
	view=ldc_analysis_view(ldc);
	ldc.configure_traits(view=view);

def dispersion_1d(ldc,k_direction,norm_krange,marker=None):
	from functions import find_vectorlen_inCell,eigsort;
	from pydao.tools import Progress_Teller;
	result=OGroup();
	lattice=ldc.get('lattice');
	atoms=lattice.get('atoms');
	force_constant_list=lattice.get('force_constant_list');
	basis=lattice.get('basis');
	k_basis=lattice.get('kbasis');
				
	klen=find_vectorlen_inCell(k_basis,k_direction);
	kmax=klen*array(k_direction);
	Nmode=len(basis)*len(atoms.keys());
	Nk=len(norm_krange);
	Emat=zeros([Nmode,Nk]);
	Vmat=zeros([Nmode, Nmode, Nk]);
	FirstEmat=True;
	
	pt=Progress_Teller(Nk,0.1);
	print "Begin calculating 1D dispersion.."
	for ik in range(Nk):
		k=norm_krange[ik]*kmax;
		dmat=lattice.DynamicMat(k);
		E2,V=eigh(dmat);
		E2,V=eigsort(E2,V);
		E=sign(E2)*abs(E2)**0.5;
		if FirstEmat:
			#result.set('firstE',E);
			#result.set('firstV',V);
			result.set('firstdmat',dmat);
			#FirstEmat=False;
		#print "E:\n",E#,V
		#for i in range(len(E)):
		Emat[:,ik]=E;
		Vmat[:,:,ik]=V;
		pt.tell(ik+1);
	if marker is not None:
		for i in range(len(basis)*len(atoms.keys())):
			plot(norm_krange,Emat[i][:],marker);
	#disper={};
	result.set('Emat',Emat);
	result.set('Vmat',Vmat);
	print "Done calculating 1D dispersion.."
	return result;
	
def dispersion_2d(ldc,nei_distance,k_direction_list,norm_krange,marker=None):
	result=OGroup();
	lattice=ldc.get('lattice');
	atoms=lattice.get('atoms');
	force_constant_list=lattice.get('force_constant_list');
	basis=lattice.get('basis');
	k_basis=lattice.get('kbasis');
	
	kmax_list=[];
	for k_direction in k_direction_list:
		klen=find_vectorlen_inCell(k_basis,k_direction);
	#print "klen:",klen
		kmax_list.append(k_direction*klen);
	
	Emat=zeros([len(basis)*len(atoms.keys()),len(norm_krange),len(norm_krange)])
	for ik in range(len(norm_krange)):
		for jk in range(len(norm_krange)):
			k1=norm_krange[ik]*kmax_list[0];
			k2=norm_krange[jk]*kmax_list[1];
			k=k1+k2;
			i_nei=0;
			#for nei_distance in nei_distance_list:
			#	if i_nei==0:
			dmat=lattice.DynamicMat(k);
			#		i_nei=i_nei+1;
			#	else:
			#		dmat+=ldc.DynamicMat_withindistance(nei_distance,k);
#			dmat=DynamicMat_atdistance(atoms,force_constant_list,basis,nei_distance,k);
			E,V=eig(dmat);
			E,V=eigsort(E,V);
			for i in range(len(E)):
				Emat[i][ik][jk]=E[i];
	if marker is not None:
		xk,yk=mgrid[0:len(norm_krange),0:len(norm_krange)];
		xk=xk*vlen(kmax_list[0]);
		yk=yk*vlen(kmax_list[1]);
		extent=[xk.min(),xk.max(),yk.min(),yk.max(),Emat.min(),Emat.max()];
		for iE in range(len(basis)*len(atoms.keys())):
			s=mlab.surf(xk,yk,Emat[iE][:][:],warp_scale=(xk.max()-xk.min())/Emat.max(),extent=extent);
			mlab.outline();
		mlab.show();

	ldc.set('Emat',Emat);
	ldc.set('lastE',E);
	ldc.set('lastV',V);
	ldc.set('lastdmat',dmat);

def mode_polarizations(ldc,modes_array,n_multiple,atoms=None,basis=None):
	if atoms is None:
		lattice=ldc.get('lattice');
		atoms=lattice.get('atoms');
	if basis is None:
		lattice=ldc.get('lattice');
		basis=lattice.get('basis');
		
	shape=modes_array.shape;
	Nmod=shape[0]
	Nk=shape[2];
	Ndim=len(basis);
	multiple=zeros([Nmod,Ndim]);
	for iv in range(Nmod):
		print "mode:",iv,"/",Nmod
		#expr="ldc.mode_"+multiple+"(real(modes_array[:,iv]))";
		#polar[iv,:]=ldc.mode_multiple(real(modes_array[:,iv]));
		#multiple[iv,:]=eval(expr);
		marray=real(modes_array[:,iv,0]);
		marray=reshape(marray,Nmod,1);
		multiple[iv,:]=ldc.mode_multiple(marray,n_multiple,atoms,basis)
	return multiple;
		
def mode_realdisp(ldc,mode,atoms=None,basis=None):
	if atoms is None:
		lattice=ldc.get('lattice');
		atoms=lattice.get('atoms');
	if basis is None:
		lattice=ldc.get('lattice');
		basis=lattice.get('basis');
	import copy;
	mode1=copy.deepcopy(mode);
	Ndim=len(basis);
	iatom=0;
	for k in atoms.keys():
		atom=atoms.get(k);
		for ibasis in range(Ndim):
			mode1[iatom*Ndim+ibasis]=mode1[iatom*Ndim+ibasis]/sqrt(atom.get('mass'));
		iatom=iatom+1;
	return mode1;
		
def mode_centerofmass(ldc,mode,atoms=None,basis=None):
	if atoms is None:
		lattice=ldc.get('lattice');
		atoms=lattice.get('atoms');
	if basis is None:
		lattice=ldc.get('lattice');
		basis=lattice.get('basis');
	
	mode1=ldc.mode_realdisp(mode,atoms,basis);
	Ndim=len(basis);
	centerofmass=zeros(3);
	for ibasis in range(Ndim):
		iatom=0;
		for k in atoms.keys():
			atom=atoms.get(k);
			centerofmass[ibasis]+=mode1[iatom*Ndim+ibasis]*atom.get('mass');
			iatom=iatom+1;
	return centerofmass;

def mode_multiple(ldc,mode,n_multiple=1,atoms=None,basis=None):
	if atoms is None:
		lattice=ldc.get('lattice');
		atoms=lattice.get('atoms');
	if basis is None:
		lattice=ldc.get('lattice');
		basis=lattice.get('basis');
	
	mode1=ldc.mode_realdisp(mode,atoms,basis);
	Ndim=len(basis);
	#multiple=zeros(3);
	multiple=zeros(Ndim);
	for ibasis in range(Ndim):
		iatom=0;
		for k in atoms.keys():
			atom=atoms.get(k);
			multiple[ibasis]+=mode1[iatom*Ndim+ibasis]**n_multiple*atom.get('charge');
		#print multiple
			iatom=iatom+1;
	return multiple;
		
def plot_multiple(ldc,multiple,plotstyle='o-'):
	Nmod,Ndim=multiple.shape;
	I=range(Nmod);
	plot(I,abs(multiple),plotstyle);
	xlabel('Mode index');
	#ylabel(str(n_multiple)+'th multiple');
	legend(['x','y','z'],2)
	grid(True);
			
def plot3d_mode(ldc,mode,color=(1,1,0)):
	from functions import plot3d_vector;
	import copy;
	lattice=ldc.get('lattice');
	atoms=lattice.get('atoms');
	basis=lattice.get('basis');
	
	lattice.plot3d_atoms();
	iatom=0;
	Ndim=len(basis);
	#mode1=vnorm(mode);
	mode1=copy.deepcopy(mode);
	for k in atoms.keys():
		atom=atoms.get(k);
		atom_v=zeros(3);
		for ibasis in range(Ndim):
			atom_v[ibasis]=mode1[iatom*Ndim+ibasis];
		#print "atom_v:",atom_v
		iatom=iatom+1;
		plot3d_vector(atom.get('position'),real(atom_v),color);
		
def plot3d_modereal(ldc,mode,color=(1,1,0)):
	mode1=ldc.mode_realdisp(mode);
	ldc.plot3d_mode(mode1,color);

def plot3d_modecm(ldc,mode,color=(0,0,1)):
	from functions import plot3d_vector;
	lattice=ldc.get('lattice');
	mode_multiple=ldc.mode_multiple(mode,1);
	centerofmass=lattice.centerofmass();
	#mode_multiple=max(abs(mode1))*mode_multiple/max(abs(mode_multiple));
	#compcolor=tuple(compliment_color(color))
	plot3d_vector(centerofmass,mode_multiple,color);
	print "cm mode:",mode_multiple
		
def get_spectrum(ldc,i_dim):
	i_polar=1;
	multiplename='multiple'+str(i_polar);
	result=ldc.get('result');
	multiple=result.get(multiplename);
	Emat=result.get('Emat');
		
	shape=multiple.shape;
	#plot(Emat[:,0],abs(multiple[:,i_polar]),'o-');
	spectrum=(Emat[:,0],abs(multiple[:,i_dim]))
	result.set('spectrum'+str(i_dim),spectrum)
	return spectrum;