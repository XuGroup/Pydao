from pylab import *;
from pydao.ohdf import OGroup;

from pydao.math import HDF_File;

from eas_hdf_filter_functions import *;
#=========================================================================
class EAS_HDF_File(HDF_File):
	def __init__(self, filename=None, Ndim=None,shape=None): 
		HDF_File.__init__(self, filename, Ndim,shape);
		self.co_filename_list=[];
		self.co_file_list=[];
		
	def get_ymd(self,fname=None):
		import mx.DateTime;
		yymmdd=mx.DateTime.Date(0,1,1);
		#print yymmdd
		return yymmdd
#=================================================
		
class CloudSat_File(EAS_HDF_File):
	def __init__(self, filename=None,Ndim=None,shape=None): 
		EAS_HDF_File.__init__(self,filename,Ndim,shape);
		
	def open(self):
		success=EAS_HDF_File.open(self);
		#path=["2B-CLDCLASS","Geolocation Fields","UTC_start"];
		#self.UTC_start=self.get_data_with_path(path,copy2mem=True);
		from pydao.ohdf import dget;
		if dget(self,'data_list') is not None:
			for dpath in self.data_list.keys():
				if dpath.count('UTC_start'):
					self.UTC_start=self.get_data_with_path(dpath,copy2mem=True);
		return success;
		
	def get_ymd(self,fname=None):
		import mx.DateTime;
		if fname is None:
			import os;
			fname=os.path.split(self.filename)[-1];
		year_str=fname[0:4];
		day_str=fname[4:7];
#	print strings
		yymmdd=mx.DateTime.Date(int(year_str),1,1)+int(day_str)-1;
	#print yymmdd
		return yymmdd
	
	def time2ymd(self,offset_second):
		import mx.DateTime;
		yymmdd=self.get_ymd();
		t=mx.DateTime.Time(0,0,self.UTC_start+offset_second);
		yymmdd1=yymmdd+t; 
		#print "ymd adjusted",yymmdd
		return yymmdd1;
		
		
class MLS_File(EAS_HDF_File):
	def __init__(self, filename=None,Ndim=None,shape=None): 
		EAS_HDF_File.__init__(self,filename,Ndim,shape);
		#self.filename=filename;

	def get_ymd(self,fname=None):
		import mx.DateTime;
		if fname is None:
			import os;
			fname=os.path.split(self.filename)[-1];
		strings=fname.split("_")
		strings=strings[-1].split(".")
		strings=strings[0].split("d")
		#print strings
		yymmdd=mx.DateTime.Date(int(strings[0]),1,1)+int(strings[-1])-1
		#print yymmdd
		return yymmdd
	
	def time2ymd(self,mls_time):
		import mx.DateTime;
		ymd=mx.DateTime.Date(1993);
		t=mx.DateTime.Time(0)+array(mls_time);
		ymd=ymd+t;
		return ymd;

class AIRS_File(EAS_HDF_File):
	def __init__(self, filename=None,Ndim=None,shape=None): 
		EAS_HDF_File.__init__(self,filename,Ndim,shape);
		#self.filename=filename;

	def get_ymd(self,fname=None):
		import mx.DateTime;
		if fname is None:
			import os;
			fname=os.path.split(self.filename)[-1];
		strings=fname.split(".")
		#strings=strings[-1].split(".")
		#strings=strings[0].split("d")
		#print strings
		yymmdd=mx.DateTime.Date(int(strings[1]),int(strings[2]),int(strings[3]));
		#print yymmdd
		return yymmdd
	
	def time2ymd(self,mls_time):
		import mx.DateTime;
		ymd=mx.DateTime.Date(1993);
		t=mx.DateTime.Time(0)+array(mls_time);
		ymd=ymd+t;
		return ymd;
#=============================================================================
def get_datetime(yymmdd,lst_list,lon_list):
	i=0;
	datetime_list=[];
	for lst in lst_list:
		#print "ymd file",yymmdd
		lon=lon_list[i];
		h_int,mm,ss,ddoffset=lst2gmt(lst,lon);
		#print "gmt:",h_int,mm,ss,ddoffset
		t=mx.DateTime.Time(h_int,mm,ss);
		yymmdd1=yymmdd+ddoffset; 
		datetime_list.append(yymmdd1+t);
		i=i+1;
		#print "ymd adjusted",yymmdd
	return datetime_list;

