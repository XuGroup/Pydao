from pylab import *;

PTable={};

Li={};
Li['mass']=6.941;
Li['charge']=1;
PTable['Li']=Li;

O={};
O['mass']=16.;
O['charge']=-2;
xsfactor={};
xsfactor['0']=array([3.0485,13.2771,2.2868,5.7011,1.5463,0.3239,0.867,32.9089,0.2508]);
xsfactor['-2']=array([4.1916,12.8573,1.63969,4.17236,1.52673,47.0179,-20.307,-0.01404,21.9412]);
O['x-ray scattering factor']=xsfactor;
PTable['O']=O;

Na={};
Na['mass']=23.;
Na['charge']=1;
PTable['Na']=Na;

Ti = {};
Ti['mass'] = 47.867;
Ti['charge'] = 4;
xsfactor={};
xsfactor['4']=array([19.5114,0.178847,8.23473,6.67018,2.01341,-0.29263,1.5208,12.9464,-13.28]);
Ti['x-ray scattering factor']=xsfactor;
PTable['Ti'] = Ti;

Fe={};
Fe['mass']=56.;
Fe['charge']=3;
xsfactor={};
xsfactor['0']=array([11.7695,4.7611,7.3573,0.3072,3.5222,15.3535,2.3045,76.8805,1.0369]);
xsfactor['2']=array([11.0424,4.6538,7.374,0.3053,4.1346,12.0546,0.4399,31.2809,1.0097]);
xsfactor['3']=array([11.1764,4.6147,7.3863,0.3005,3.3948,11.6729,0.0724,38.5566,0.9707]);
Fe['x-ray scattering factor']=xsfactor;
PTable['Fe']=Fe;

Co={};
Co['mass']=58.93;
Co['charge']=3;
PTable['Co']=Co;

Cu={};
Cu['mass']=63.5;
Cu['charge']=1;
PTable['Cu']=Cu;

Se={};
Se['mass']=78.96;
Se['charge']=6;
PTable['Se']=Se;

Sr={};
Sr['mass']=87.62;
Sr['charge']=2;
xsfactor={};
xsfactor['2']=array([18.0874,1.4907,8.1373,12.6963,2.5654,24.5651,-34.193,-0.0138,41.4025]);
Sr['x-ray scattering factor']=xsfactor;
PTable['Sr']=Sr;

Br={};
Br['mass']=79.904;
Br['charge']=-1;
PTable['Br']=Br;

I={};
I['mass']=126.90;
I['charge']=-1;
PTable['I']=I;

Te={};
Te['mass']=127.60;
Te['charge']=-2;
PTable['Te']=Te;


Yb={};
Yb['mass']=173.054;
Yb['charge']=3;
xsfactor={};
xsfactor['0']=array([28.6641,1.9889,15.4345,   0.257119,   15.3087,   10.6647,   2.98963,   100.417,   7.56672]);
xsfactor['2']=array([28.1209,1.78503,17.6817,   0.15997,   13.3335,   8.18304,   5.14657,   20.39,   3.70983 ]);
xsfactor['3']=array([27.8917,1.73272,   18.7614,   0.13879,   12.6072,   7.64412,   5.47647,   16.8153,   2.26001   ]);
Yb['x-ray scattering factor']=xsfactor;
PTable['Yb']=Yb;

Lu={};
Lu['mass']=175.;
Lu['charge']=3;
xsfactor={};
xsfactor['0']=array([28.9476,1.90182,15.2208,9.98519,15.1,0.261033,3.71601,84.3298,7.97628]);
xsfactor['3']=array([28.4628,1.68216,18.121,0.142292,12.8429,7.33727,5.59415,16.3535,2.97573 ]);
Lu['x-ray scattering factor']=xsfactor;
PTable['Lu']=Lu;

Ir={};
Ir['mass']=192.217;
Ir['charge']=4;
PTable['Ir']=Ir;

Bi={};
Bi['mass']=209.;
Bi['charge']=3;
PTable['Bi']=Bi;

