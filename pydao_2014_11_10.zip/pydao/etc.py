#---------------------------------------------static config-------------------------------------------
plugindir="plugins";
thirdpartydir="thirdparties";

imagedir="dimages";

version="pydao 1.0 build 1" #added relational database based on OGroup.

#----------static parameters---------------
memory_mode = False;
#lazy_reload = True;
N_Backup_File=5;

progress_teller=None;
#----------static parameters---------------

history_file_name="history.hdf";

application_list=[];
satanalysis={"module":"satanalysis","class":"EOS_Data_Analysis"};
application_list.append(satanalysis);
ldc={"module":"latticedynamics","class":"Lattice_Dynamics"};
application_list.append(ldc);
ldc={"module":"rheed","class":"RHEED"};
application_list.append(ldc);
#---------------------------------------------dynamic config-------------------------------------------
#lazy_reload = True;

class GlobalCfg():
	def __setattr__(self, attr, val):
		GlobalCfg.__dict__[attr] = val;
		
	def __getattr__(self, attr,): 
		val = None;
		if GlobalCfg.__dict__.keys().count(attr)>0:
			val=GlobalCfg.__dict__[attr];
		return val;

globalcfg = GlobalCfg()
globalcfg.lazy_reload = True;
globalcfg.empty_instances = {};
globalcfg.add_extended_methods_count = {};
globalcfg.reload_extended_methods_count = {}
globalcfg.OCommon_created_count = {};
#----------------------------------------------------------------------------------------------------------
