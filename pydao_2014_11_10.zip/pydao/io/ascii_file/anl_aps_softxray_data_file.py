from pylab import *;
from scipy.optimize import fmin;
import scipy;
from pydao.ohdf import OGroup;
from nummatrixcsv import NumMatrixCSV;

# For the XAS datafile: one file contains one scans
# So here we load multiple datafiles (scans) and combine them into a sequence.

class ANLAPSXAS_DataFile(NumMatrixCSV): # an individual scan
	def __init__(self,filename=None, Ndim=None,shape=None,dilimiter='\t'):
		NumMatrixCSV.__init__(self,filename=filename,dilimiter=dilimiter,row_width_chosen=None);
		# self.mem_cache={};
		# self.filename=filename;
		# self.work_sheet=None;
		
	def analyze(self):
		self.convertcsv();
		self.get_exp_parameters();
		return;
		
	def get_exp_parameters(self):
		filecontent=self.get('filecontent');
		for line in filecontent:
			strs=line.split(':');
			if len(strs)>=3:
				substrs=strs[-1].split(',');
				#print "substrs:",substrs
				if len(substrs)>=3:
					para_name=substrs[1].strip();
					para_value=substrs[2].replace('"',"");
					para_value=para_value.replace('\n',"");
					try:
						para_value=float(para_value);
					except:
						pass;
					if para_name!="":
						self.set(para_name,para_value);
		
	def get_scan_time(self):
		import time;
		filecontent=self.get('filecontent');
		scan_T=None;
		for line in scan_content:
			fields=line.split("=");
			if len(fields)>1:
				if fields[0]=="# Scan time ":
					scan_time=fields[1].strip('\n');
					scan_time=time.strptime(scan_time);
					scan_time=time.mktime(scan_time);
					#print jscan,iscan,jscan>iscan
		self.set('Scan time',scan_time);
		return scan_time;
		
	def get_T(self):
		return self.get('7T T sample');
		
	def get_x(self):
		mat=self.get('num_matrix');
		return mat[:,1];
		
	def get_i0(self):
		mat=self.get('num_matrix');
		return mat[:,3];
		
	def get_tey(self):
		mat=self.get('num_matrix');
		return mat[:,5];
	
	def get_tfy(self):
		mat=self.get('num_matrix');
		return mat[:,6];
		
	def renormalize(self,pre,after,Npre=3,Nafter=10,spect='tfy'):
		if spect=='tfy':
			ntey=self.get_tfy()/self.get_i0();
		elif spect=='tey':
			ntey=self.get_tey()/self.get_i0();
		N=len(ntey);
		pre0=ntey[0:Npre].mean();
		after0=ntey[N-Nafter:N].mean();
		k=(pre-after)/(pre0-after0);
		b=pre-k*pre0;
		re_ntey=ntey*k+b;
		#print N,ntey[N-Nafter:N],pre0,after0,k,b;
		return re_ntey;
	
	
	def sumrule(self,pre,after,Npre=3,Nafter=10,spect='tfy'):
		re_ntey=self.renormalize(pre,after,Npre,Nafter,spect='tfy');
		eVs=self.get_x();
		Imax=where(re_ntey==re_ntey.max())[0][0];
		sumr=sum(diff(eVs)*re_ntey[1:]);
		bg1=sum(diff(eVs)[0:Imax]*pre);
		bg2=sum(diff(eVs)[Imax:]*after);
		sumr=sumr-bg1-bg2;
		return sumr;
		
		
	# data columns	
	#XMCD  
	# ('x',data[:,1]);
	# ('I01_raw',data[:,3]);
	# ('EY1_raw',data[:,4]);
	# ('FY1_raw',data[:,5]);
	# ('I02_raw',data[:,7]);
	# ('EY2_raw',data[:,8]);
	# ('FY2_raw',data[:,9]);		
	# ('EY_norm_sum',data[:,11]);
	# ('FY_norm_sum',data[:,12]);
	# ('EY_norm_diff',data[:,14]);
	# ('FY_norm_diff',data[:,15]);
	
	#XMLD	
	# ('x',data[:,1]);
	# ('I0_raw',data[:,3]);
	# ('EY_raw',data[:,5]);
	# ('FY_raw',data[:,6]);
	# ('EY',data[:,10]);
	# ('FY',data[:,11]);
			
	def xmcd_normalize(self,I0name1,I0name2,yname1,yname2,ynamenew1,ynamenew2):
		I01=self.work_sheet.get_col(I0name1);
		I02=self.work_sheet.get_col(I0name2);
		y1=self.work_sheet.get_col(yname1);
		y2=self.work_sheet.get_col(yname2);
		y1norm, y2norm=normalize_twoprofiles(I01,I02,y1,y2);
		self.work_sheet.set_col(ynamenew1,y1norm);
		self.work_sheet.set_col(ynamenew2,y2norm);
		return;
		
	def normalize_xmxdfile(self,xmxdfile2,I0name,yname,ynamenew):
		I01=self.work_sheet.get_col(I0name);
		I02=xmxdfile2.work_sheet.get_col(I0name);
		y1=self.work_sheet.get_col(yname);
		y2=xmxdfile2.work_sheet.get_col(yname);
		self.work_sheet.set_col(ynamenew,y1norm);
		self.work_sheet.set_col(ynamenew,y2norm);
		y1norm, y2norm=normalize_twoprofiles(I01,I02,y1,y2);
		self.work_sheet.set_col(ynamenew,y1norm);
		xmxdfile2.work_sheet.set_col(ynamenew,y2norm);
		
	def normalize_twoprofiles(I01,I02,y1,y2):
		y1norm=y1/I01;
		y2norm=y2/I02;
		shift=mean(y1norm[0:2]-y2norm[0:2]);
		y2norm=y2norm+shift-mean(y1norm[0:2]);
		y1norm=y1norm-mean(y1norm[0:2]);
		factor=mean(y1norm[range(-2,0)])/mean(y2norm[range(-2,0)]);
		y2norm=y2norm*factor;
		return y1norm, y2norm;
	
	def find_plateau(self,dxname,dyname,xmin,xmax,Xwidth):
		import scipy.optimize;
		x=self.work_sheet.get_col(dxname);
		y=self.work_sheet.get_col(dyname);
		I=logical_and(x>xmin,x<xmax);
		x1=x[I];
		y1=y[I];
		paras0=[mean(x1),max(y1)];
		print "paras0:",paras0
		paras=scipy.optimize.fmin(self.match_plateau_chi2,paras0,args=(x1,y1,Xwidth));
		Xcenter=paras[0];
		Y=paras[1];
		return Xcenter,Y;
		
	def match_plateau_chi2(self,paras,x,y,Xwidth):
		#Xwidth=5;
		Xcenter=paras[0];
		Y=paras[1];
		yave=mean(y);
		I=logical_and(x<Xcenter+Xwidth/2,x>Xcenter-Xwidth/2);
		ycomp=y[I];
		yfit=ycomp-ycomp+Y;
		chi2=sum((yfit-ycomp)**2);
		if Y<yave or Xcenter+Xwidth/2>max(x) or Xcenter-Xwidth/2<min(x):
			chi2=chi2+1e100;
		return chi2;
		
#===================================================================
# The following section is to renormalize the XAS to get the 
# absolute values using the standard background profile 
# from www-cxro.lbl.gov		
#===================================================================

	def alpha2XAS(self,paras,eVBG,alphaBGint):
		# a1,a2,b1,b2,b3=paras;
		a1,b1,b2,b3=paras;
		# a1,b1,b2=paras;
		# XASfit=a1*(1-exp(-(b1*alphaBGint+b2*eVBG+b3)))+a2;
		# b1=0.02;
		XASfit=a1*(1-exp(-(b1*alphaBGint+b2*eVBG+b3)));
		# XASfit=a1*(1-exp(-(b1*alphaBGint+b2*eVBG)));
		return XASfit;
	
	def XAS2alpha(self,paras,eVXAS,XAS):
		a1,b1,b2,b3=paras;
		# a1,b1,b2=paras;
		# b1=0.02;
		alpha=-log(1-(XAS)/a1)-b2*eVXAS-b3;
		# alpha=-log(1-(XAS)/a1)-b2*eVXAS;
		alpha=alpha/b1;
		return alpha;
	
	def chi2_XAS_alpha_BGfit(self,paras,eValphaBG,alphaBG,eVBG,XASBG):
		import scipy;
		alphaBGint=scipy.interp(eVBG,eValphaBG,alphaBG);
		XASfit=self.alpha2XAS(paras,eVBG,alphaBGint);
		# chi2=sum((XASBG-XASfit)**2/abs(XASfit+XASBG));
		chi2=sum((XASBG-XASfit)**2);
		return chi2;
	
	def XAS_alpha_BGfit(self,eValphaBG,alphaBG,eVBG,XASBG,paras0=None):
		import scipy;
		if paras0 is None:
			a1=0.5;
			a2=0.;
			b1=0.01;
			b2=2e-4;
			b3=-0.2;
			# paras0=[a1,a2,b1,b2,b3];
			paras0=[a1,b1,b2,b3];
			# paras0=[a1,b1,b2];
		paras=scipy.optimize.fmin(self.chi2_XAS_alpha_BGfit,paras0,args=(eValphaBG,alphaBG,eVBG,XASBG));
		return paras;
	
	def renormalize_standard(self,iXAS=6,\
	eVprestart=680,eVpreend=700,eVpoststart=790,eVpostend=820,eVL3end=718.4,eVL3endwidth=5,paras0=None,plotresults=True):
		eValphaBG=self.get('eValphaBG');
		alphaBG=self.get('alphaBG');
		
		eVXAS=self.get_x();
		mat=self.get('num_matrix');
		XAS=mat[:,iXAS]/self.get_i0();
		
		Ipre=logical_and(eVXAS<eVpreend,eVXAS>eVprestart);
		Ipoststart=logical_and(eVXAS>eVpoststart,eVXAS<eVpostend);
		IL3min=logical_and(eVXAS>eVL3end-1,eVXAS<eVL3end+1);
		eVL3min=eVXAS[IL3min];
		XASL3min=XAS[IL3min];
		absL3min0=min(XASL3min);
		iL3min=list(XAS).index(absL3min0);
		IL3min=range(iL3min-eVL3endwidth+1,iL3min+eVL3endwidth+1);

		Nint=1;
		eVBG=list(eVXAS[Ipre])+list(eVXAS[IL3min])*Nint+list(eVXAS[Ipoststart]);
		eVBG=array(eVBG);
		XASBG=list(XAS[Ipre])+list(XAS[IL3min])*Nint+list(XAS[Ipoststart]);
		XASBG=array(XASBG);

		

		# to fit the two curves and get the renormalized XAS
		paras=self.XAS_alpha_BGfit(eValphaBG,alphaBG,eVBG,XASBG,paras0);
		chi2=self.chi2_XAS_alpha_BGfit(paras,eValphaBG,alphaBG,eVBG,XASBG);

		alphaBGint=scipy.interp(eVBG,eValphaBG,alphaBG);
		XASfit=self.alpha2XAS(paras,eVBG,alphaBGint);
		
		alpha=self.XAS2alpha(paras,eVXAS,XAS);
		self.set('alpha',alpha);
		self.set('XASfit',XASfit);
		
		if plotresults:
			print "paras:",paras;
			print "chi2:",chi2;
			
			subplot(2,1,1);
			plot(eVXAS,XAS,'+-')
			plot(eVBG,XASBG,'o-')
			plot(eVBG,XASfit,'-');
			
			subplot(2,1,2);
			I=logical_and(eValphaBG>min(eVXAS),eValphaBG<max(eVXAS));
			plot(eValphaBG[I],alphaBG[I],'-');
			plot(eVXAS,alpha,'-');
			
			show();			
		return alpha,XASfit,paras,chi2;
		
	def alpha2Nholes(self,eVstart=700,eVL3=709.5,eVend=730):
		import scipy;
		eVXAS=self.get_x();
		alpha=self.get('alpha');
		
		eValphaBG=self.get('eValphaBG');
		alphaBG=self.get('alphaBG');
		
		Ialphalow=logical_and(eVXAS>eVstart,eVXAS<eVL3);
		Ialphahigh=logical_and(eVXAS>eVL3,eVXAS<eVend);

		IalphaBGlow=eValphaBG<eVL3;
		IalphaBGhigh=eValphaBG>eVL3;
		alphaBGBGlow=scipy.interp(eVXAS[Ialphalow],eValphaBG[IalphaBGlow],alphaBG[IalphaBGlow]);
		alphaBGBGhigh=scipy.interp(eVXAS[Ialphahigh],eValphaBG[IalphaBGhigh],alphaBG[IalphaBGhigh]);
		# plot(eVXAS[Ialphalow],alphaBGBGlow,'-');
		# plot(eVXAS[Ialphahigh],alphaBGBGhigh,'-');
		# plot(eVXAS[Ialphalow],alpha[Ialphalow],'-');
		# plot(eVXAS[Ialphahigh],alpha[Ialphahigh],'-');
		# show();

		Nholes=sum(alpha[Ialphalow]-alphaBGBGlow)*mean(diff(eVXAS));
		Nholes=Nholes+sum(alpha[Ialphahigh]-alphaBGBGhigh)*mean(diff(eVXAS));

		# subplot(2,2,4);
		# plot(eVXAS[Ialphalow],alpha[Ialphalow]-alphaBGBGlow);
		# plot(eVXAS[Ialphahigh],alpha[Ialphahigh]-alphaBGBGhigh);
		# show();
		
		#print sumrule,cft1,cft2;
		#sumrule=sumrule*cft1*cft2*cft3;
		#print "sumrule:",sumrule
		return Nholes;
		
class ANLAPSXAS_Sequence(OGroup):
	def __init__(self):
		OGroup.__init__(self);
		self.set('sequence',[]);
		
	def append(self,scan):
		scansequence=self.get('sequence');
		scansequence.append(scan);
		self.set('sequence',scansequence);
		
	def get_col_mat(self,colname):
		scansequence=self.get('sequence');
		i=0;
		for scan in scansequence:
			col=scan.get_col(colname);
			if i==0:
				col_mat=col;
			else:
				col_mat=vstack((col_mat,col));
			i=i+1;
			#print "i:",i
		return col_mat;
		
	def get_Ts(self):
		scansequence=self.get('sequence');
		Ts=[];
		for scan in scansequence:
			T=scan.get_T();
			Ts.append(T);
		return array(Ts);
	
	def get_timestamps(self):
		scansequence=self.get('sequence');
		timestamps=[];
		for scan in scansequence:
			timestamp=scan.get_timestamp();
			timestamps.append(timestamp);
		return timestamps;
	
	def merge_T(self):
		scansequence=self.get('sequence');
		newseq=[];
		newTs=[];
		Ts=self.get_Ts();
		IT=arange(len(Ts));
		for scan in scansequence:
			T=scan.get_T();
			InewT=arange(len(newTs));
			IL=abs(array(newTs)-T)<2;
			# print "IL",IL
			Tmerged=True;
			if len(IL)==0:
				Tmerged=False;
			elif len(InewT[IL])==0:
				Tmerged=False;
			if not Tmerged:
				IL=abs(T-Ts)<2;
				# print IL,IT
				I=IT[IL];
				matall=None;
				for i in I:
					scan=scansequence[i];
					mat=scan.get('num_matrix');
					if matall is None:
						matall=mat;
					else:
						matall=matall+mat;
				scan.set('num_matrix',matall/len(I));
				newTs.append(T);
				newseq.append(scan);
		# print "merged: scans changed from ",len(Ts),'to',len(newTs)
		self.set('sequence',newseq);