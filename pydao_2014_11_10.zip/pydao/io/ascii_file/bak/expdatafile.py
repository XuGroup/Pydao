from pylab import *;
from scipy.optimize import fmin;
from pydao.ohdf import OGroup;
from pydao.math import NumMatrixCSV;

class ANLAPSXAS_DataFile(NumMatrixCSV):
	def __init__(self,filename=None, Ndim=None,shape=None):
		WorkSheet.__init__(self);
		self.mem_cache={};
		self.filename=filename;
		#self.alias={};
		#self.shape=shape;
		#self.Ndim=Ndim;
		self.co_file_list=[];
		self.work_sheet=None;
		
	def loaddata(self):
		from pydao.math import WorkSheet;
		if self.filename is not None:
			ws=WorkSheet();
			data=loadtxt(self.filename);
			ws.set_col('x',data[:,1]);
			ws.set_col('I01_raw',data[:,3]);
			ws.set_col('EY1_raw',data[:,4]);
			ws.set_col('FY1_raw',data[:,5]);
			ws.set_col('I02_raw',data[:,7]);
			ws.set_col('EY2_raw',data[:,8]);
			ws.set_col('FY2_raw',data[:,9]);
			
			ws.set_col('EY_norm_sum',data[:,11]);
			ws.set_col('FY_norm_sum',data[:,12]);
			ws.set_col('EY_norm_diff',data[:,14]);
			ws.set_col('FY_norm_diff',data[:,15]);
			
			
			f=open(self.filename,"rU");
			import re;
			for line in f:
				strs=line.split(',');
				if len(strs)>3:
					if strs[1]==' 7T field (T)':
						value=strs[2].replace('"',"");
						value=float(value);
						self.set('MField',value);
					elif strs[1]==' 7T T setpoint':
						value=strs[2].replace('"',"");
						value=float(value);
						self.set('T',value);
			self.work_sheet=ws;
		else:
			print "filename does not exist."
		#return success;

	def xmcd_normalize(self,I0name1,I0name2,yname1,yname2,ynamenew1,ynamenew2):
		I01=self.work_sheet.get_col(I0name1);
		I02=self.work_sheet.get_col(I0name2);
		y1=self.work_sheet.get_col(yname1);
		y2=self.work_sheet.get_col(yname2);
		y1norm, y2norm=normalize_twoprofiles(I01,I02,y1,y2);
		self.work_sheet.set_col(ynamenew1,y1norm);
		self.work_sheet.set_col(ynamenew2,y2norm);
		return;
		
	def normalize_xmxdfile(self,xmxdfile2,I0name,yname,ynamenew):
		I01=self.work_sheet.get_col(I0name);
		I02=xmxdfile2.work_sheet.get_col(I0name);
		y1=self.work_sheet.get_col(yname);
		y2=xmxdfile2.work_sheet.get_col(yname);
		self.work_sheet.set_col(ynamenew,y1norm);
		self.work_sheet.set_col(ynamenew,y2norm);
		y1norm, y2norm=normalize_twoprofiles(I01,I02,y1,y2);
		self.work_sheet.set_col(ynamenew,y1norm);
		xmxdfile2.work_sheet.set_col(ynamenew,y2norm);
		
	def normalize_twoprofiles(I01,I02,y1,y2):
		y1norm=y1/I01;
		y2norm=y2/I02;
		shift=mean(y1norm[0:2]-y2norm[0:2]);
		y2norm=y2norm+shift-mean(y1norm[0:2]);
		y1norm=y1norm-mean(y1norm[0:2]);
		factor=mean(y1norm[range(-2,0)])/mean(y2norm[range(-2,0)]);
		y2norm=y2norm*factor;
		return y1norm, y2norm;
	
	def find_plateau(self,dxname,dyname,xmin,xmax,Xwidth):
		import scipy.optimize;
		x=self.work_sheet.get_col(dxname);
		y=self.work_sheet.get_col(dyname);
		I=logical_and(x>xmin,x<xmax);
		x1=x[I];
		y1=y[I];
		paras0=[mean(x1),max(y1)];
		print "paras0:",paras0
		paras=scipy.optimize.fmin(self.match_plateau_chi2,paras0,args=(x1,y1,Xwidth));
		Xcenter=paras[0];
		Y=paras[1];
		return Xcenter,Y;
		
	def match_plateau_chi2(self,paras,x,y,Xwidth):
		#Xwidth=5;
		Xcenter=paras[0];
		Y=paras[1];
		yave=mean(y);
		I=logical_and(x<Xcenter+Xwidth/2,x>Xcenter-Xwidth/2);
		ycomp=y[I];
		yfit=ycomp-ycomp+Y;
		chi2=sum((yfit-ycomp)**2);
		if Y<yave or Xcenter+Xwidth/2>max(x) or Xcenter-Xwidth/2<min(x):
			chi2=chi2+1e100;
		return chi2;
		
class ANLAPSSPEC_DataFile(NumMatrixCSV):
	def __init__(self,filename=None, Ndim=None,shape=None,dilimiter='\t'):
		NumMatrixCSV.__init__(self,filename=filename,dilimiter=dilimiter,row_width_chosen=None);
		self.set('nscan',0);
		self.set('scan_content',None);
		self.set('scan_num_matrix',None);
		
	def n_scans(self):
		fstr=self.get('filecontent');
		nscan=0;
		for line in fstr:
			fields=line.split();
			if len(fields)>1:
				if fields[0]=="#S":
					nscan=nscan+1;
		self.set('nscan',nscan);
		return nscan;
	
	def get_scan(self,iscan):
		filecontent=self.get('filecontent');
		scan=ANLAPSSPEC_Scan();
		scan_content=[]
		jscan=0;
		for line in filecontent:
			fields=line.split();
			if len(fields)>1:
				if fields[0]=="#S":
					jscan=int(fields[1]);
					#print jscan,iscan,jscan>iscan
			if jscan==iscan:
				scan_content.append(line);
			elif jscan>iscan:
				break;
		scan.set('filecontent',scan_content);
		scan.set('iscan',iscan);
		scan.analyze();
		return scan;
		
class ANLAPSSPEC_Scan(NumMatrixCSV):
	def __init__(self,filename=None, Ndim=None,shape=None,dilimiter='\t'):
		NumMatrixCSV.__init__(self,filename=filename,dilimiter=dilimiter,row_width_chosen=None);
		self.set('iscan',0);
		
	def analyze(self):
		self.convertcsv();
		self.get_colnames();
		return;
		
	def get_colnames(self):
		scan_content=self.get('filecontent');
		scan_colnames=[];
		for line in scan_content:
			fields=line.split();
			if len(fields)>1:
				if fields[0]=="#L":
					scan_colnames=fields[1:];
		self.set('col_names',scan_colnames);
		return scan_colnames;
		
	def get_col(self,colname):
		scan_colnames=self.get('col_names');
		if type(colname) is str:
			if scan_colnames.count(colname)==1:
				icol=scan_colnames.index(colname);
		elif type(colname) is int:
			if colname<len(scan_colnames):
				icol=colname;
		scan_num_matrix=self.get('num_matrix');
		scan_col=scan_num_matrix[:,icol];
		return scan_col;
			
	def get_T(self):
		scan_content=self.get('filecontent');
		scan_T=None;
		for line in scan_content:
			fields=line.split();
			if len(fields)>1:
				if fields[0]=="#X":
					scan_T=float(fields[1]);
					#print jscan,iscan,jscan>iscan
		self.set('scan_T',scan_T);
		return scan_T;
		
	def get_timestamp(self):
		import time;
		scan_content=self.get('filecontent');
		scan_T=None;
		for line in scan_content:
			fields=line.split();
			if len(fields)>1:
				if fields[0]=="#D":
					scan_time=line.strip('#D ');
					scan_time=scan_time.strip('\n');
					scan_time=time.strptime(scan_time);
					scan_time=time.mktime(scan_time);
					#print jscan,iscan,jscan>iscan
		self.set('scan_time',scan_time);
		return scan_time;