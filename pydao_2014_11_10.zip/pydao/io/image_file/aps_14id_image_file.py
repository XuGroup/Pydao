from pylab import *;
from pydao.tools import mccd2array,int_filter,Progress_Teller;
from scipy.signal import convolve;

from scipy.optimize import fmin;
from pydao.database import Relation_Table;
from imgarray import ImgArray;

class Img14ID_AngleScan(Relation_Table):
	def __init__(self,directory=None,roi=None):
		Relation_Table.__init__(self,rows=None,idname=None);
		if directory is not None:
			self.set('directory',directory);
		if roi is not None:
			self.set('roi',roi);
		
	def read_scan(self):
		import os;
		directory = self.get('directory');
		roi = self.get('roi');
		# print "in read_scan, roi:",roi
		files=os.listdir(directory);
		pt = Progress_Teller(len(files));

		i=0;
		for file in files:
			i=i+1;
			pt.tell(i);
			fullfile=os.path.join(directory,file);
			if not os.path.isdir(fullfile):
				fs = file.split('.');
				if fs[-1]=='png':
					print "\n file#:",i
					print "fullfile:",fullfile;
					img = Img14ID(fullfile);
					img.read(roi=roi);
					self.append(img);
		return;

	
class Img14ID(ImgArray):
	def __init__(self,filename=None,dilimiter='\t',row_width_chosen=None):
		ImgArray.__init__(self,filename=None,dilimiter=dilimiter,row_width_chosen=None);
		if filename is not None:
			self.analyze_filename(filename);
			self.set('filename',filename);
			
	def analyze_filename(self,filename):
		import os;
		# S003_0.6mj_-1ns1_001
		# print "fullname:",filename
		fs = os.path.split(filename);
		# print "path fs:",fs
		fname = fs[-1];
		fs = fname.split('.');
		# print "suffix fs:",fs
		fname = fname.replace('.'+fs[-1],'');
		
		fs = fname.split('_');
		# print "file fs:",fs
		sample_name = fs[0];
		
		fluencestr = fs[1].replace('mj','');
		fluence = float(fluencestr);
		
		pulsedelaystr = fs[2];
		if pulsedelaystr.count('ns')==1:
			pulsedelayunit = 'ns';
		elif pulsedelaystr.count('ps')==1:
			pulsedelayunit = 'ps';
		
		ss = pulsedelaystr.split(pulsedelayunit);
		pulsedelay = float(ss[0]);
		iscan = int(ss[1]);
		
		iangle = int(fs[3]);
		
		self.set('sample_name',sample_name);
		self.set('fluence',fluence);
		self.set('pulsedelay',pulsedelay);
		self.set('pulsedelayunit',pulsedelayunit);
		self.set('iscan',iscan);
		self.set('iangle', iangle);
		print "sample_name:",sample_name
		print "fluence:",fluence
		print "pulsedelay:",pulsedelay
		print "pulsedelayunit:",pulsedelayunit
		print "iscan:",iscan
		print "iangle:",iangle
		return ;
		
	def read(self,roi,filename=None):
		if filename is None:
			filename = self.get('filename');
		# print "filename:",filename
		success = ImgArray.read(self,filename);
		if success:
			img_array = self.get('img_array');
			print "original image shape:",img_array.shape;
			print "roi:",roi
			img_array = img_array[roi[0]:roi[1],roi[2]:roi[3]];
			self.set('img_array',img_array);
			self.set('fromroi',roi);
		return success;
		