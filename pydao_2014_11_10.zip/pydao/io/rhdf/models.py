from enthought.traits.api import HasTraits;
from pyhdf.SD import *
from pyhdf.HDF import *
from pyhdf.V   import *
from pyhdf.VS  import *
from h5py import *;
from numpy import *;

class RFile4(HasTraits):
	def __init__(self,filename=None):
		self.filename=filename;
		self.cache={};
		
	def open(self):
		self.hdf=HDF4(self.filename);
		try:
			self.hdf.open();
			success=True;
		except:
			#import traceback;
			#traceback.print_exc();
			success=False;
		return success;
		
	def close(self):
		self.hdf.close();
		
	def getdata(self,path):
		i=0;
		for field in path:
			if i==0:
				d=self.get_fromroot(field);
			else:
				d=self.get_fromvg(d,field);
			i=i+1;
		return d;

	def get_data_with_path(self,path=None):
		if self.cache.has_key(str(path)):
			d=self.cache[str(path)];
		else:
			if len(path)==1:
				d=self.hdf.get_data_fromroot(path[0]);
			else:
				i=0;
				for field in path:
					if i==0:
						d=self.hdf.get_fromroot(field);
					#print "d from root:",d
					else:
						d=self.hdf.get_fromvg(d,field);
					#print "d from group:",d
				i=i+1;
			self.cache[str(path)]=d;
		return d;

	def list_path(self,group_path):
		i=0;
		path=group_path;
		if len(group_path)==0:
			dlist=self.hdf.listroot();
		else:
			d=self.get_data_with_path(group_path);
			dlist=self.hdf.listvg(d);
		#print "group_path:",path
		#print "dlist:",dlist
		klist=[];
		for d in dlist:
			klist.append(d['name']);
		#dlist=dlist['name']
		return klist;
		
#=========================================================================
class RFile5(HasTraits):
	def __init__(self, filename=None): 
		self.filename=filename;
		#print "RFile5 filename:",self.filename
		
	def open(self):
		from h5py import File;
		if self.filename is not None:
			try:
				self.hdf=File(self.filename,'r');
				self.cur_group=self.hdf;
				success=True;
			except:
				success=False;
		else:
			print "Error! File name is None!."
			success=False;
		return success;
			
	def get_data_with_path(self,path=None):
		data=self.hdf;
		for field in path:
			data=data[field];
		return (data);

	def list_path(self,group_path):
		groupdata=self.get_data_with_path(group_path);
		keys=groupdata.listnames();
		return keys;
			
	def close(self):
		self.hdf.close();

class HDF4():
	def __init__(self, filename=None): 
		self.filename=filename;
		
	def open(self):
		from pyhdf.SD import SD;
		from pyhdf.HDF import HDF;
		#from pyhdf.V   import *
		#from pyhdf.VS  import *
		if self.filename is not None:
			FILE_NAME=self.filename;
			self.Hdf =HDF(FILE_NAME);
			self.Sd=SD(FILE_NAME);
			self.VStart = self.Hdf.vstart();
			self.VgStart  = self.Hdf.vgstart();
			success=True;
			#print "datases:",self.Sd.datasets();
		else:
			print "Error! File name is None!."
			success=False;
		return success;

	def close(self):
		self.VgStart.end()
		self.VStart.end()
		self.Sd.end()
		self.Hdf.close()
 
	def attachvg(self,refindex):
		vg = self.VgStart.attach(refindex);
		return vg;

	def listroot(self):
		dlist=[];
		ref = -1;
		while 1:
			record={};
			try:
				ref = self.VgStart.getid(ref)
				vg=self.attachvg(ref);
				#print "listroot",str(dir(vg))
				record['name']=vg._name;
				record['tag']=vg._tag;
				#record['tag']=vg.inqtagref();
				#record['isvg']=vg.isvg();
				#record['isvs']=vg.isvs();
				record['refindex']=ref;
				#record['attr']=vg.attrinfo();
				#record['tagref']=vg.tagrefs();
				#vgdict[vg._name]=ref;
				vg.detach();
				dlist.append(record);
			except HDF4Error,msg:    # no more vgroup
				break;
		dlist=self.filter_dlist(dlist);
		return dlist;

	def listvg(self,refindex):
		dlist=[];
		vg=self.attachvg(refindex);
		members = vg.tagrefs();
		for tag, ref in members:
			record={};
			if tag == HC.DFTAG_VH: #vdata
				vd = self.VStart.attach(ref)
				nrecs, intmode, fields, size, name = vd.inquire()
				#sds = self.Sd.select(self.Sd.reftoindex(ref))
				#print "  vdata:",name, "tag,ref:",tag, ref
				#print "    fields:",fields
				#print "    nrecs:",nrecs
				
				record['name']=name;
				record['tag']=tag;
				record['refindex']=ref;
				record['fields']=fields;
				record['nrecs']=nrecs;
				record['intmode']=intmode;
				record['size']=size;
				vd.detach()
# SDS tag
			elif tag == HC.DFTAG_NDG: #dataset
				sds = self.Sd.select(self.Sd.reftoindex(ref))
				name, rank, dims, type, nattrs = sds.info()
				#print "  dataset:",name, "tag,ref:", tag, ref
				#print "    dims:",dims
				#print "    type:",type
 				record['name']=name;
				record['tag']=tag;
				record['refindex']=ref;
				record['rank']=rank;
				record['dims']=dims;
				record['type']=type;
				record['nattrs']=nattrs;
				sds.endaccess();
            # VS tag
			elif tag == HC.DFTAG_VG: #vgroup
				vg0 = self.VgStart.attach(ref)
				#print "  vgroup:", vg0._name, "tag,ref:", tag, ref
 				record['name']=vg0._name;
				record['tag']=tag;
				record['refindex']=ref;
				vg0.detach();
			dlist.append(record);
		vg.detach();
		dlist=self.filter_dlist(dlist);
		return dlist;
		
	def get_fromroot(self,fieldname):
		refindex=None;
		dlist=self.listroot();
		for r in dlist:
			#print "root r:",r
			if r['name']==fieldname:
				refindex=r['refindex'];
		return refindex;
	
	def get_data_fromroot(self,fieldname):
		dlist=self.listroot();
		for r in dlist:
			#print "root r:",r
			if r['name']==fieldname:
				data=self.Sd.select(fieldname);	
				data=data.get();
		return data;
		
	def get_fromvg(self,refindex,fieldname):
		result=None;
		dlist=self.listvg(refindex);
		vg=self.attachvg(refindex);
		for r in dlist:
			#print "group r:",r
			if r['name']==fieldname:
				#print "found field:",r
				if r['tag'] == HC.DFTAG_VG:
					result=r['refindex'];
				elif r['tag'] == HC.DFTAG_NDG :
					ref=r['refindex'];
					ref1=self.Sd.reftoindex(ref);
					sds = self.Sd.select(ref1);
					#sds=self.Sd.select(fieldname)
					result=sds.get();
					sds.endaccess();
				elif r['tag'] == HC.DFTAG_VH:
					#t=time.time();
					ref=r['refindex'];
					vd = self.VStart.attach(ref);
					nrecs=r['nrecs'];
					data=vd.read(nrecs);
					#print time.time()-t;
					data=array(data).reshape(nrecs);
					#print time.time()-t;
					result=data;
					#result=vd;
					vd.detach();
		return result; 

	def filter_dlist(self,dlist):
		dlist1=[];
		for d in dlist:
			if d['name'].count(':')==0 and d['name'].count('\\')==0 and d['name'].count('.')==0:
				dlist1.append(d);
		return dlist1;