from ..database import Relation_Table;
from pylab import *;
from ..physics import Unit;

import pylab;
import scipy.interpolate;
import scipy.optimize;
import scipy;
import numpy;
import copy;
import os;

from pydao.math import XyDiscreteFun

class XyDiscreteFun_dBase(Relation_Table):
	def __init__(self,rows=None,idname=None):
		Relation_Table.__init__(self,rows,idname);
		
	def common_baseline(self,method='min'):
		rows=self.get('rows');
		result=None;
		if method=="min":
			for row in rows:
				y=row.get('y');
				if result is None:
					result=min(y);
				elif result>min(y):
					result=min(y);
		return result;
		
	def group_intensity(self):
		# Here we are concerned with the calculation of a group of xyfun with different range of x. 
		# One of them is the broadest and covers the whole range.
		# The idea is to 1) calculate the area of the broadest xyfun 
		#                2) calculate the difference between the broadest xyfun and others.
		# The final intensity all the xyfun is calculated as the sum of the intensity of the broadest xyfun and the differences.
		# In this way, the "tails" that the narrow xyfun misses will be automatically included, using the part in the broadest xyfun.
		self.update('_tmp','max(x)-min(x)');
		maxrange,iscanmax=self.max('_tmp');
		broadest_xyfun=self.get_row(iscanmax).typecast(XyDiscreteFun());
		
		broadest_xyfun_extend=broadest_xyfun.copyxy();
		x=broadest_xyfun_extend.get('x');
		# print "xrange:",min(x),max(x);
		for row in self.get('rows'):
			xy=row.typecast(XyDiscreteFun());
			broadest_xyfun_extend.extend(xy);
			x=broadest_xyfun_extend.get('x');
			# print "xrange:",min(x),max(x),max(x)-min(x)
		
		Nxyfun=self.get_Nrow();
		areas_wtail=range(Nxyfun);
		areas_wotail=range(Nxyfun);
		basearea=broadest_xyfun.nthmoment(0);
		
		areas_wtail_extend=range(Nxyfun);
		basearea_extend=broadest_xyfun_extend.nthmoment(0);
		# print "area extended:",basearea_extend-basearea
		
		irow=0;
		for row in self.get('rows'):
			# print "irow:",irow
			xy=row.typecast(XyDiscreteFun());
			xydiff=xy.minus(broadest_xyfun); 
			areas_wotail[irow]=xy.nthmoment(0);
			areas_wtail[irow]=xydiff.nthmoment(0)+basearea;
			xy.set('area_wtail',areas_wtail[irow]);
			xy.set('area_wotail',areas_wotail[irow]);
			
			# print "before extend"
			xydiff_extend=xy.minus(broadest_xyfun_extend); 
			areas_wtail_extend[irow]=xydiff_extend.nthmoment(0)+basearea_extend;
			xy.set('area_wtail_extend',areas_wtail_extend[irow]);
			# print "area_wtail:",areas_wtail[irow]
			# print "area_wotail:",areas_wotail[irow]
			# print "area_wtail_extend:",areas_wtail_extend[irow]
			
			irow=irow+1;
			
		# self.update('_tmp','max(x)');
		# xmax_group,imax=self.max('_tmp');
		# self.update('_tmp','min(x)');
		# xmin_group,imin=self.min('_tmp');
		# self.update('_tmp','abs(mean(diff(x)))');
		# xdiffmin_group,imin=self.min('_tmp');
		
		return areas_wtail,areas_wotail,areas_wtail_extend;