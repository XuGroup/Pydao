from pydao.ohdfvi import OGroup_Property_ModelView;
from pydao.ohdfvi import OGroup_Analyzer_ModelView,\
OGroup_Analyzer_Group_ModelView,OGroup_Analyzer_Group_List_ModelView;
from pylab import *;

class Analyzable_ModelView(OGroup_Analyzer_Group_List_ModelView):
	def init_info(self,info):
		OGroup_Analyzer_Group_List_ModelView.init_info(self,info);
		#self.preprocess(self.model);
		print "info:",info
		
	def On_OGroupElement_Set(self,info=None):
		import pydao,sys;
		from pydao.ohdf import OGroup;
		from pydao.ohdfvi import ogroup_analyzer_view,OGroup_Analyzer_Group_List_ModelView;
		if info is not None:
			model=self.model;
			func_name=sys._getframe().f_code.co_name
			ana_method=eval("self."+func_name);
			ana_name=func_name;
			
			work_space_list=model.work_space_list;
			print work_space_list,type(work_space_list)
			found_work_space=False;
			for ws in work_space_list:
				if ws.name==ana_name:
					found_work_space=True;
			if found_work_space:
				print "found_work_space",ana_name
			else:
				#work_space=OGroup_Analyzer_Group_List_ModelView().get_default_work_space(model);
				work_space=self.get_default_work_space(self.model);
				
				#group=work_space.get('group');
				#group=self.model.current_group;
				config=work_space.get('config');
				group=config.get('_0group');
				outputs=config.get('_3outputs');
				group.set('criteria',['mass']);
				#work_space.remove('group');
				
				#inputs=OGroup();
				#inlink=model.get_link();
				#inputs.set('current_ogroup',inlink);
				#config.set('_1inputs',inputs);
				
				parameters=OGroup();
				parameters.set('key','charge');
				parameters.set('value',2.5);
				config.set('_2analysis',parameters);
			
				#outputs.set('dir_link',str(lattice.get_link()));
				work_space.name=ana_name;
				
				model.work_space_list.selected=work_space;
				model.work_space_list.append(work_space);
				model.ana_method_list.append(ana_method);
		else:
			model=self.model;
			group=model.current_group;
			work_space=model.work_space_list.selected;
			config=work_space.get('config');
			parameters=config.get('_2analysis');
			
			key=parameters.get('key');
			value=parameters.get('value');
			
			dbases=group.get('dbases');
			for kdbase in dbases.keys():
				print "kdbase:",kdbase
				dbase=dbases.get(kdbase);
				for k in dbase.keys():
					print "kitem:",k
					atom=dbase.get(k);
					atom.set(key,value);
			
			outgroup=group.copy2mem();
			#outgroup.get('dbases').set('atoms',newatoms);

			return outgroup;
			
	def On_WorkSheet_CalculateNewColumn(self,info=None):
		import pydao,sys;
		from pydao.ohdf import OGroup;
		from pydao.ohdfvi import Analyzable_ModelView;
		if info is not None:
			eos_ana=self.model;
			func_name=sys._getframe().f_code.co_name
			ana_method=eval("self."+func_name);
			ana_name=func_name;
			
			work_space_list=eos_ana.work_space_list;
			print work_space_list,type(work_space_list)
			found_work_space=False;
			for ws in work_space_list:
				if ws.name==ana_name:
					found_work_space=True;
			if found_work_space:
				print "found_work_space",ana_name
			else:
				work_space=Analyzable_ModelView().get_default_work_space(eos_ana);
#=============================================================================================
# make change between the two lines
				config=work_space.get('config');
				#config.remove('_0group');
				inputs=OGroup();
				inputs.set('source_dir',eos_ana.get_link());
				config.set('_1inputs',inputs);
				
				parameters=OGroup();
				parameters.set('formula','AOT_500/AOT_500');
				parameters.set('new_colname','newcol');
				config.set('_2analysis',parameters);
				#input=config.get('_1inputs');
				#output=config.get('_3outputs');
				#config.set('_2analysis',ws.get('parameters'));
				
# make change between the two lines
#==============================================================================================
				work_space.name=ana_name;
				eos_ana.work_space_list.selected=work_space;
				eos_ana.work_space_list.append(work_space);
				eos_ana.ana_method_list.append(ana_method);
		else:
			import os;
			from pydao.math import WorkSheet;
			eos_ana=self.model;
			work_space=eos_ana.work_space_list.selected;
			config=work_space.get('config');
			source_dir=config.get('_1inputs').get('source_dir');
			formula=config.get('_2analysis').get('formula');
			new_colname=config.get('_2analysis').get('new_colname');
			
			group=eos_ana.current_group;
			source_dir=group.get('dbases').get('source_dir');
			for k in source_dir.keys():
				ws=source_dir.get(k);
				if isinstance(ws,WorkSheet):
					print k,ws
					ws.calculate_new_col(formula,new_colname);
				
			outgroup=group.copy2mem();
			return outgroup;