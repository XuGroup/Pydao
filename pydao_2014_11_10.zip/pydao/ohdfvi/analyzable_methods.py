from pylab import *;
lazy=False;

def OnOpen(analyzable,event=None):
	from analyzable_views import analyzable_view_modify;
	view=analyzable_view_modify(analyzable);
	analyzable.configure_traits(view=view);

