from pylab import *;

def get_dview(obj):
	#from dfunction import importcmd,dkeys,isa,dget;
	from enthought.traits.api import HasTraits;
	#from __init__ import isa as isa;
	traitname_list2disp=obj.keys();
	viewcmd="view=View(Group(";
	myitem=[];
	i=0;
	
	keys=obj.keys();
	for traitname in keys:
		#print "traitname:",traitname
		v=obj.get(traitname);
		if isinstance(v,HasTraits):
			vstr="Item('"+traitname+"',editor = InstanceEditor(editable = True ,view=view"+str(i)+"),style='simple'),";
			exec("view"+str(i)+"=get_dview(v)");
			i=i+1;
			viewcmd=viewcmd+vstr;
			#print traitname,"vstr:\n",vstr
		else:
			vstr="Item('"+traitname+"',style='custom',resizable=True),"
			viewcmd=viewcmd+vstr;
		
	viewcmd=viewcmd+"show_labels=True),buttons = ['OK', 'Cancel'],kind='subpanel')";
	#print "viewcmd:\n",viewcmd;
	exec(viewcmd);
	#print "dview ok:",view
	return view;

def get_view(obj,viewkeys=None,buttons=None,editors=None,groupstyple='Tabbed',title='Edit '):
	from ..ohdf.functions import dget,dset,dkeys;
	from enthought.traits.api import HasTraits;
	from enthought.traits.ui.api import \
	Item,View,Group,VGroup,HGroup,Tabbed,\
	InstanceEditor,ArrayEditor,BooleanEditor,ListEditor,TextEditor;
	from controls import Hanlder_to_Fix_TextEditor;
	
	if groupstyple=='Tabbed':
		show_labels=False;
	else:
		show_labels=True;
		
	
	if buttons is None:
		buttons=['Apply','Revert','Undo', 'OK', 'Cancel' ];
	i=0;
	if viewkeys is None:
		vkeys=dkeys(obj);
	else:
		vkeys=viewkeys;

	item_list=[];
	for traitname in vkeys:
		v=dget(obj,traitname);
		if editors is not None:
			if editors.has_key(traitname):
				item=Item(traitname,editor =editors['"+traitname+"']);
		elif isinstance(v,HasTraits):
			item=Item(traitname,editor = InstanceEditor(editable = True),style='readonly');
		elif type(v) is ndarray:
			if len(v.shape)<=2:
				item=Item(traitname,editor = ArrayEditor(),resizable = True);
			else:
				item=Item(traitname);
		elif type(v) is bool:
			item=Item(traitname,editor = BooleanEditor(),resizable = True);
		elif type(v) is list and type(v) is None:
			print "found list"
			isstr=True;
			for k in v:
				print k,type(k)
				if type(k) is not str and type(k) is not string_:
					isstr=False;
			if isstr:
				item=Item(traitname,editor = ListEditor());
			else:
				item=Item(traitname,resizable = True,editor=TextEditor(multi_line=True));
		else:
			#item=Item(traitname,resizable = True,editor=TextEditor(multi_line=True));
			item=Item(traitname,resizable = True);
		item.resizable=True;
		item_list.append(item);
		
	viewcmd="view=View("+groupstyple+"("
	for i in range(len(item_list)):
		viewcmd=viewcmd+"item_list["+str(i)+"],";
	viewcmd=viewcmd+"show_labels=";
	viewcmd=viewcmd+str(show_labels)+",orientation='vertical')";
	viewcmd=viewcmd+",buttons = "+str(buttons)+",kind='livemodal',resizable = True,handler=Hanlder_to_Fix_TextEditor(),title=title)";
	#print "viewcmd:\n",viewcmd;
	#print "title:",title
	exec(viewcmd);
	return view;
	