from pylab import *;
from enthought.traits.api import HasTraits;
import wx;

#=============================================================s======================================
#                View for 
#===================================================================================================
def get_ogroup_explorer_view():
	from controls import OGroup_Exporler_Editor_Handler;
	from oeditors import get_ogroup_explorer_editor;
	from enthought.traits.ui.api import Item,View,Group,CustomEditor;
	
	editor=CustomEditor(get_ogroup_explorer_editor);
	view=View(Group(Item('dname',editor=editor,resizable = True,id='expeditorid'),show_labels=False),kind='subpanel',width=.8,height=.8,resizable = True,handler=OGroup_Exporler_Editor_Handler());
	return view;
	
#========================================================================
def configure_ogroup(ogroup,view=None,viewkeys=None,buttons=None,editors=None,groupstyle='Tabbed',title=None):
	from ..ohdf.functions import dget,dset,dkeys;
	from miscviews import get_view;
	
	if title is None:
		title=str(ogroup._ondisk);
		
	dictlist2correct_namelist=[];
	str2correct_namelist=[];
	array2correct_namelist=[];
	ht=HasTraits();
	nog_keys=ogroup.nog_keys();
	for k in nog_keys:
		v=ogroup.get(k);
		dset(ht,k,v);
	if view is None:
		view=get_view(ht,viewkeys,buttons,editors,groupstyle,title=title);
	ok=ht.configure_traits(view=view);
	if ok:
		for k in nog_keys:
			v=dget(ht,k);
			ogroup.set(k,v);
	return ok;