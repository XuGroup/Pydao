from pylab import *;
#from pydao.ohdf.models import OGroup,OFile,OTable; 
from mvc_editor_widgets import Page;
from enthought.traits.ui.api import *;

class dExplorer(Page):
	columnnames=['Name','Dir','Type','Size','Intro','Time modified'];
	columnwidth=[100,20,50,60,100,200];
	
	def __init__(self, *args, **kwargs):
		Page.__init__(self, *args, **kwargs);
		self.widgetclass="wx.SplitterWindow";
		
	def create(self, *args, **kwargs):
		import wx;
		Page.create(self, *args, **kwargs);
		self.tree = wx.TreeCtrl(self.widget, wx.NewId(), wx.DefaultPosition, (-1,-1), wx.TR_HAS_BUTTONS)#wx.TR_HIDE_ROOT|
		self.list=wx.ListCtrl(self.widget, wx.NewId(), style=wx.LC_REPORT|wx.LC_VRULES|wx.LC_HRULES)
		
		self.tree.Bind(wx.EVT_TREE_SEL_CHANGED,self.OnTree_Click_Item,id=self.tree.GetId());
		
		self.list.Bind(wx.EVT_LIST_ITEM_ACTIVATED,self.OnList_DoubleClick_Item,id=self.list.GetId());
		self.list.Bind(wx.EVT_LIST_ITEM_RIGHT_CLICK,self.OnList_RightClick_Item,id=self.list.GetId());
		self.list.Bind(wx.EVT_LIST_ITEM_SELECTED,self.OnList_SelectItem,id=self.list.GetId());
		self.list.Bind(wx.EVT_LIST_ITEM_DESELECTED,self.OnList_Deselect_Item,id=self.list.GetId());
		
		self.list.Bind(wx.EVT_RIGHT_DOWN,self.OnList_RightDown,id=self.list.GetId())
		
		self.widget.SplitVertically(self.tree, self.list);
		self.widget.SetMinimumPaneSize(50);
		
		for i in range(len(self.columnnames)):
			self.list.InsertColumn(i, self.columnnames[i])
			
		for i in range(len(self.columnwidth)):
			self.list.SetColumnWidth(i, self.columnwidth[i]);
			
		self.treeroot = self.tree.AddRoot('/');
		self.current_treeitem=self.treeroot;
		#self.root.SetData(self['data']);

		sashpos=self.widget.GetSashPosition();
		#print "sashpos:",sashpos
		self.widget.SetSashPosition(sashpos*15);
		
		self.currentlistitems=[];

		win1=self.widget.GetWindow1();
		win1.Bind(wx.EVT_SET_FOCUS,self.OnFocus,id=win1.GetId());
		win2=self.widget.GetWindow2();
		win2.Bind(wx.EVT_SET_FOCUS,self.OnFocus,id=win2.GetId());
		
		#font1 = wx.Font(10, wx.SWISS, wx.NORMAL, wx.NORMAL, False, u'Comic Sans MS 15')
		#self.list.SetFont(font1);
		#self.tree.SetFont(font1);

	def OnFocus(self,event):
		oroot=self.get_oroot();
		if oroot is not None:
			oroot.current_explorer=self;
		#print self,"Focusd"
		
	def rootview(self):
		self.tree.SetPyData(self.treeroot,self.data);
		self.tree_choose(self.treeroot);
	
	def refresh(self,lazy=False):
		import time;
		self.list_update();
		if lazy:
			self.tree_branch_update_lazy();
		else:
			self.tree_branch_update();
		
	def OnTree_Click_Item(self, event):
		item =  event.GetItem();
		self.tree_choose(item);
		
	def tree_get(self,itemname,parent_item=None):
		if parent_item is None:
			current_item=self.current_treeitem;
		else:
			current_item=parent_item;
		founditem=None;
		nsubitem=self.tree.GetChildrenCount(current_item,recursively=False);
		#print "childcount:",nsubitem
		if nsubitem>0:
			firstsubitemT=self.tree.GetFirstChild(current_item);
			firstsubitem=firstsubitemT[0];
			#print "firstsubitem",type(firstsubitem),firstsubitem
			if self.tree.GetItemText(firstsubitem)==itemname:
				founditem=firstsubitem;
			for i in range(nsubitem-1):
				subitemT=self.tree.GetNextChild(current_item,firstsubitemT[1]);
				subitem=subitemT[0];
				firstsubitemT=subitemT;
				subitemtext=self.tree.GetItemText(subitem);
				if subitemtext==itemname:
					founditem=subitem;
		return founditem;
		
	def tree_list(self,parent_item=None):
		if parent_item is None:
			current_item=self.current_treeitem;
		else:
			current_item=parent_item;
		keys=[];
		nsubitem=self.tree.GetChildrenCount(current_item,recursively=False);
		#print "childcount:",nsubitem
		if nsubitem>0:
			firstsubitemT=self.tree.GetFirstChild(current_item);
			firstsubitem=firstsubitemT[0];
			k=self.tree.GetItemText(firstsubitem);
			k=k.encode('ascii');
			keys.append(k);
			for i in range(nsubitem-1):
				subitemT=self.tree.GetNextChild(current_item,firstsubitemT[1]);
				subitem=subitemT[0];
				firstsubitemT=subitemT;
				k=self.tree.GetItemText(subitem);
				k=k.encode('ascii')
				keys.append(k);
		return keys;
		
	def tree_choose(self,item):
		import wx;
		self.previous_treeitem=self.current_treeitem;
		self.current_treeitem=item;
		#data=self.get_current_ogroup();
		self.refresh(lazy=True);
		self.tree.SetItemBackgroundColour(self.previous_treeitem,None)
		self.tree.SetItemBackgroundColour(self.current_treeitem,wx.Color(128, 128,128))
		#self.tree.SelectItem(item);
		
	def tree_goup(self):
		parent_item=self.tree.GetItemParent(self.current_treeitem)
		#print self.current_treeitem,parent_item,self.treeroot
		if self.current_treeitem!=self.treeroot:
			self.tree_choose(parent_item);
		
	def tree_goback(self):
		self.tree_choose(self.previous_treeitem);
		
	def tree_branch_clear(self,parent_item=None):
		keys=self.tree_list();
		for k in keys:
			self.tree_delete(k,parent_item);
		
	def tree_branch_populate(self,parent_item=None):
		from pydao.ohdf import OGroup; 
		ogroup=self.get_current_ogroup();
		for k in ogroup.keys():
			v=ogroup.get(k);
			if isinstance(v,OGroup):
				self.tree_append(k,v,parent_item);
		
	def tree_branch_update(self,parent_item=None):
		self.tree_branch_clear(parent_item);
		self.tree_branch_populate(parent_item);
		if parent_item is None:
			current_item=self.current_treeitem;
		else:
			current_item=parent_item; 
		self.tree.Expand(current_item);
		#print "tree brand clear and repopulated."
		
	def tree_branch_update_lazy(self,parent_item=None):
		oldkeys=self.tree_list(parent_item);
		ogroup=self.get_current_ogroup();
		
		newkeys=ogroup.og_keys();
		
		#print "oldkeys",oldkeys
		#print "newkeys",newkeys
		for okey in oldkeys:
			if newkeys.count(okey)==0:
				self.tree_delete(okey);
				#print "delete okey:",okey,newkeys
		
		from pydao.tools import Progress_Teller;
		pt=Progress_Teller(len(newkeys),0.01);
		if len(newkeys)>20:
			print "tree_branch_update_lazy",len(newkeys)
		i=0;
		for nkey in newkeys:
			if len(newkeys)>20:
				pt.tell(i);
				i=i+1;
			v=ogroup.get(nkey);
			if oldkeys.count(nkey)==0:
				self.tree_append(nkey,v,parent_item);
				#print "appended:",nkey, oldkeys
		
		if parent_item is None:
			current_item=self.current_treeitem;
		else:
			current_item=parent_item; 
			
		self.tree.Expand(current_item);
		
	def tree_append(self,itemname,itemdata,parent_item=None):
		if parent_item is None:
			current_item=self.current_treeitem;
		else:
			current_item=parent_item;
		founditem=self.tree_get(itemname);
		if founditem is None:
			newitem=self.tree.AppendItem(current_item,itemname);
			itemdata.editor=self;
			self.tree.SetPyData(newitem,itemdata);
		else:
			newitem=founditem;
		return newitem;
	
	def tree_delete(self,itemname,parent_item=None):
		item=self.tree_get(itemname,parent_item);
		ok=False;
		#print "in tree delete, got item:",item
		if item is not None:
			self.tree.Delete(item);
			#print "deleted: ",itemname
			ok=True;
		return ok;
		
	def get_current_ogroup(self):
		item=self.current_treeitem;
		#print "item:",item
		data=self.tree.GetPyData(item);
		#print "get_current_ogroup:",type(data);
		return data;
		
	def OnList_DoubleClick_Item(self,event):
		from pydao.ohdf import OGroup,OTable; 
		item=event.GetItem();
		itemname=item.GetText();
		datadict=self.get_current_ogroup();
		data=datadict.get(itemname);
		if isinstance(data,OGroup):
			tree_item=self.tree_append(itemname,data);
			self.tree_choose(tree_item);
		elif isinstance(data,OTable):
			oroot=self.get_oroot();
			pathanme=datadict._ondisk._v_pathname+"/"+itemname;
			try:
				fname=oroot.uiinfo.opages.selected.name;
				pathname=fname+pathname;
			except:
				pass;
			from oviewers import SpreadSheet_Viewer;
			viewer=SpreadSheet_Viewer(data,data.read2memory(),data.get_fieldnames(),pathanme)
			viewer.main();
			oroot=self.get_oroot();
			oroot.tableviewer=viewer;
			#ok=data.oview(pathanme);
		else:
			self.OnList_Edit_Properties(event);
		#print "Double clicked data:",data;
		#self.currentlistitems=[];
		#print "ondoubleclick",self.currentlistitems
		return;
	
	def OnList_View(self,event):
		from pydao.ohdf import OGroup,OTable; 
		#item=event.GetItem();
		#itemname=item.GetText();
		itemname=self.currentlistitems[0];
		datadict=self.get_current_ogroup();
		#item=datadict.get(itemname);
		datadict=self.get_current_ogroup();
		data=datadict.get(itemname);
		if isinstance(data,OGroup):
			pass;
		elif isinstance(data,OTable):
			pass;
		else:
			from pydao.ohdf import dset;
			from enthought.traits.api import HasTraits;
			from enthought.traits.ui.api import Item,View,ValueEditor,Group;
			ht=HasTraits();
			dset(ht,itemname,data);
			title=datadict.string()+itemname;
			item=Item(itemname,editor=ValueEditor())
			group=Group(item,show_labels=False);
			htview=View(group,buttons = [ 'OK'],kind='subpanel',width=.5,height=0.5,resizable = True,title=title);
			ht.configure_traits(view=htview);
#	def OnList_LeftUp(self,event):
#		oroot=self.get_oroot();
#		oroot.current_explorer=self;
		
	def OnList_RightDown(self,event):
		import wx;
		#from __init__ import isa;
		itemnames=self.currentlistitems;
		datadict=self.get_current_ogroup();
		#print self.get_rootframe().Title
		#print "itemnames:",itemnames
		if len(itemnames)==0:
			menu=wx.Menu();
			
			item=menu.Append(wx.NewId(),"Refresh","Refresh");
			self.widget.Bind(wx.EVT_MENU, self.OnList_Refresh, item);
		
			item=menu.Append(wx.NewId(),"Paste","Paste");
			self.widget.Bind(wx.EVT_MENU, self.OnList_Paste, item)
		
			newmenu=wx.Menu();
			menu.AppendMenu(-1, 'New', newmenu);
			
			# new python buildins
			newmenu_python=wx.Menu();
			newmenu.AppendMenu(-1, 'Python', newmenu_python);
			
			id=wx.NewId();
			self.EventIdDict[str(id)]="bool()";
			item=newmenu_python.Append(id,self.EventIdDict[str(id)]);
			self.widget.Bind(wx.EVT_MENU, self.OnList_NewItem_BuildIn, item);

			
			id=wx.NewId();
			self.EventIdDict[str(id)]="int()";
			item=newmenu_python.Append(id,self.EventIdDict[str(id)]);
			self.widget.Bind(wx.EVT_MENU, self.OnList_NewItem_BuildIn, item);

			id=wx.NewId();
			self.EventIdDict[str(id)]="float()";
			item=newmenu_python.Append(id,self.EventIdDict[str(id)]);
			self.widget.Bind(wx.EVT_MENU, self.OnList_NewItem_BuildIn, item);
			
			id=wx.NewId();
			self.EventIdDict[str(id)]="str()";
			item=newmenu_python.Append(id,self.EventIdDict[str(id)]);
			self.widget.Bind(wx.EVT_MENU, self.OnList_NewItem_BuildIn, item);
			
			id=wx.NewId();
			self.EventIdDict[str(id)]="list()";
			item=newmenu_python.Append(id,self.EventIdDict[str(id)]);
			self.widget.Bind(wx.EVT_MENU, self.OnList_NewItem_BuildIn, item);

			id=wx.NewId();
			self.EventIdDict[str(id)]="tuple()";
			item=newmenu_python.Append(id,self.EventIdDict[str(id)]);
			self.widget.Bind(wx.EVT_MENU, self.OnList_NewItem_BuildIn, item);
			id=wx.NewId();
			
			self.EventIdDict[str(id)]="dict()";
			item=newmenu_python.Append(id,self.EventIdDict[str(id)]);
			self.widget.Bind(wx.EVT_MENU, self.OnList_NewItem_BuildIn, item);
			
			# new pydao buildins
			newmenu_pydao=wx.Menu();
			newmenu.AppendMenu(-1, 'Pydao', newmenu_pydao);
			
			id=wx.NewId();
			self.EventIdDict[str(id)]="OGroup()";
			item=newmenu_pydao.Append(id,self.EventIdDict[str(id)]);
			self.widget.Bind(wx.EVT_MENU, self.OnList_NewItem_BuildIn, item);
			
			id=wx.NewId();
			self.EventIdDict[str(id)]="WorkSheet()";
			item=newmenu_pydao.Append(id,self.EventIdDict[str(id)]);
			self.widget.Bind(wx.EVT_MENU, self.OnList_NewItem_BuildIn, item);
			
			# new Advanced
			id=wx.NewId();
			self.EventIdDict[str(id)]="Advanced";
			item=newmenu.Append(id,self.EventIdDict[str(id)]);
			self.widget.Bind(wx.EVT_MENU, self.OnList_NewItem_BuildIn, item);
			newmenu.AppendSeparator();
			
			# new Applications
			newmenu1=wx.Menu();
			newmenu.AppendMenu(-1, 'Application', newmenu1);
			
			# shell
			item=menu.Append(wx.NewId(),"Shell","Shell");
			self.widget.Bind(wx.EVT_MENU, self.OnList_Shell_Edit, item);
			
			# application menu
			oroot=self.get_oroot();
			try:
				for app in oroot.registry.application_list:
					id=wx.NewId();
					self.EventIdDict[str(id)]=app;
					item=newmenu1.Append(id,app['class']);
					self.widget.Bind(wx.EVT_MENU, self.OnList_NewItem_Custom_Application, item);
			except:
				pass;
			from applications import Application
			#print "datadict type:",type(datadict)
			if isinstance(datadict,Application):
			#try:
				menu.AppendSeparator();
				datadict.contextmenu(menu);
			#except:
			#	pass;
			self.list.PopupMenu(menu,event.GetPosition());
		else:
			event.Skip();
			#self.OnList_RightClick_Item(event);

		
	def OnList_RightClick_Item(self,event):
		import wx;
		from pydao.ohdf import OCommon,dset;
		#item=event.GetItem();
		#from dfunction import dget;
		#from __init__ import isa;
		itemnames=self.currentlistitems;
		
		menu=wx.Menu();

		item=menu.Append(wx.NewId(),"Copy","Copy");
		self.widget.Bind(wx.EVT_MENU, self.OnList_Copy, item)
		item=menu.Append(wx.NewId(),"Copy Link");
		self.widget.Bind(wx.EVT_MENU, self.OnList_CopyLink, item)
		item=menu.Append(wx.NewId(),"Cut","Cut");
		self.widget.Bind(wx.EVT_MENU, self.OnList_Cut, item);
		item=menu.Append(wx.NewId(),"Delete");
		self.widget.Bind(wx.EVT_MENU, self.OnList_Delete, item)
		item=menu.Append(wx.NewId(),"Export Ascii");
		self.widget.Bind(wx.EVT_MENU, self.OnList_Export_Ascii, item)
			
		datadict=self.get_current_ogroup();
		if len(itemnames)==1:
			itemname=self.currentlistitems[0];
			itemname=itemname.encode('ascii');
			objitem=datadict.get(itemname);
			
			item=menu.Append(wx.NewId(),"Rename");
			self.widget.Bind(wx.EVT_MENU, self.OnList_Rename, item)
			
			item=menu.Append(wx.NewId(),"View");
			self.widget.Bind(wx.EVT_MENU, self.OnList_View, item)
			
			if type(objitem) is str:
				editomenu=wx.Menu();
				menu.AppendMenu(wx.NewId(), 'Edit', editomenu);
				
				id=wx.NewId();
				self.EventIdDict[str(id)]=TextEditor();
				item=editomenu.Append(id,'Text');
				self.widget.Bind(wx.EVT_MENU, self.OnList_Edit_Properties, item);
				
				id=wx.NewId();
				self.EventIdDict[str(id)]=FileEditor();
				item=editomenu.Append(id,'Filename');
				self.widget.Bind(wx.EVT_MENU, self.OnList_Edit_Properties, item);
				
			else:
				item=menu.Append(wx.NewId(),"Edit");
				self.widget.Bind(wx.EVT_MENU, self.OnList_Edit_Properties, item)
			
			item=menu.Append(wx.NewId(),"Set as");
			self.widget.Bind(wx.EVT_MENU, self.OnList_Set_As, item)
			
			#item=menu.Append(wx.NewId(),"Export Ascii");
			#self.widget.Bind(wx.EVT_MENU, self.OnList_Export_Ascii, item)
			
			if isinstance(objitem,OCommon):
				item=menu.Append(wx.NewId(),"Meta_Properties");
				self.widget.Bind(wx.EVT_MENU, self.OnList_Meta_Properties, item)
			
			try:
				objitem.contextmenu
			#if isa(objitem,'Application'):
				menu.AppendSeparator();
				objitem.contextmenu(menu);
			except:
				pass;
		#menu.widget.AppendSeparator();
		else:
			try:
				menu.AppendSeparator();
				dset(datadict,'member_name_selected',self.currentlistitems);
				datadict.contextmenu_members(menu);
			except:
				pass;
		
		#print "right click:",itemnames
		datadict=self.get_current_ogroup();
		datadictselected={};
		for name in itemnames:
			datadictselected[name]=datadict.get(name);
		if len(datadictselected)==1:
			data=datadictselected[datadictselected.keys()[0]];
			#data.contextmenu(menu);
			#except:
			#	pass;
		self.list.PopupMenu(menu,event.GetPosition());
		return;
	
	def OnList_SelectItem(self,event):
		item=event.GetItem();
		itemname=item.GetText();
		#print "selected:",itemname
		if self.currentlistitems.count(itemname)==0:
			self.currentlistitems.append(itemname);
		
		
	def OnList_Deselect_Item(self,event):
		item=event.GetItem();
		itemname=item.GetText();
		#print "deselected:",itemname
		if self.currentlistitems.count(itemname)>0:
			i=self.currentlistitems.index(itemname)
			self.currentlistitems.pop(i);
		
	def OnList_Copy(self,event):
		from enthought.traits.api import HasTraits;
		from pydao.ohdf import dset;
		#from dfunction import dget,dset;
		itemnames=self.currentlistitems;
		datadict=self.get_current_ogroup();
		oroot=self.get_oroot();
		oroot.clipboard=HasTraits();
		for name in itemnames:
			print "name:'"+name+"'"
			data=datadict.get(name);
			dset(oroot.clipboard,name,data);
		print itemnames," copied to clipboard"
		return;
		
	def OnList_CopyLink(self,event):
		from enthought.traits.api import HasTraits;
		from pydao.ohdf import dset;
		from pydao.ohdf import link;
		import wx;
		#from dfunction import dget,dset;
		itemnames=self.currentlistitems;
		datadict=self.get_current_ogroup();
		oroot=self.get_oroot();
		# file_page=oroot.uiinfo.opages.selected;
		# file_name=file_page.name.encode('ascii');
		# if datadict.str().find("(RootGroup)")<-1:
			# opath_name=datadict.str().replace(" (RootGroup) ''","");
		# else:
			# opath_name=datadict.str().replace(" (Group) ''","");
		# member_name_list=[];
		link_tuple=datadict.get_link();
		link_tuple_list=[];
		for name in itemnames:
			link_tuple_list.append(link.join(link_tuple,name.encode('ascii')));
			#member_name_list.append(name.encode('ascii'));
		
		if len(link_tuple_list)==1:
			link_tuple_list=link_tuple_list[0];
		clipstr=str(link_tuple_list);
		print "clipstr:",clipstr
		clipdata = wx.TextDataObject();
		clipdata.SetText(clipstr);
		wx.TheClipboard.Open()
		wx.TheClipboard.SetData(clipdata)
		wx.TheClipboard.Close()
		return;
				
	def OnList_Cut(self,event):
		print "code not ready."
		return;
		
	def OnList_Delete(self,event):
		from enthought.traits.api import HasTraits;
		itemnames=self.currentlistitems;
		datadict=self.get_current_ogroup();
		for name in itemnames:
			datadict.remove(name);
			print datadict.keys()
		print itemnames," deleted."
		self.refresh(lazy=True);
		return;


	def OnList_Paste(self,event):
		from pydao.ohdf import OGroup,OTable;
		from pydao.ohdf import dget,dset,dkeys;
		import copy;
		oroot=self.get_oroot();
		clipdata=oroot.clipboard;
		datadict=self.get_current_ogroup();
		if clipdata is not None:
			for dataname in dkeys(clipdata):
				print "pasting",dataname
				data=dget(clipdata,dataname);
				i=0;
				dataname1=dataname;
				while datadict.keys().count(dataname1)>0:
					i=i+1;
					dataname1=dataname+str(i);
				if isinstance(data,OGroup):
					data1=data.copy2mem(deep=True);
					datadict.set(dataname1,data1);
					#data.copyto_newparent(datadict,dataname1);
				elif isinstance(data,OTable):
					data1=data.copy2mem(deep=True);
					datadict.set(dataname1,data1);
					#data.copyto_newparent(datadict,dataname1);
				else:
					data1=copy.deepcopy(data);
					datadict.set(dataname1,data1);
			self.refresh(lazy=True);
		return;
		
	def OnList_Rename(self,event):
		from pydao.ohdf import dget,dset,ddel,natural_name;
		import wx;
		itemname=self.currentlistitems[0];
		item=self.list.FindItem(-1,itemname);
		datadict=self.get_current_ogroup();
		print "rename:",item
		self.list.EditLabel(item);
		dlg = wx.TextEntryDialog(self.getframe(), "new name",'renaming')
		dlg.SetValue(itemname)
		if dlg.ShowModal() == wx.ID_OK:
			newname=dlg.GetValue();
			print "rename from:",itemname," to ",newname
			ok=datadict.rename(itemname,natural_name(newname));
			#print "ok:",ok
			dlg.Destroy()
		self.refresh(lazy=True);
		return;
		
	def OnList_Edit_Properties(self,event):
		from pydao.ohdf import OGroup; 
		from enthought.traits.api import HasTraits;
		from enthought.traits.ui.api import TextEditor;
		#from oviews import configure_ogroup;
		from mvc_views import ogroup_property_view;
		itemname=self.currentlistitems[0];
		datadict=self.get_current_ogroup();
		item=datadict.get(itemname);
		print "item:",item
		print "itemname:",itemname
		if isinstance(item,OGroup):
			#configure_ogroup(item);
			view=ogroup_property_view(item);
			item.configure_traits(view=view);
		else:
			if type(item) is str:
				id=event.GetId();
				#editortypestr=self.EventIdDict[str(id)];
				#editor=eval(editortypestr);
				try:
					editor=self.EventIdDict[str(id)];
				except:
					editor=TextEditor();
				editors={itemname.encode('ascii'):editor};
				view=ogroup_property_view(datadict,viewkeys=[itemname.encode('ascii')],editors=editors);
			else:
				view=ogroup_property_view(datadict,viewkeys=[itemname]);
			datadict.configure_traits(view=view);
			#configure_ogroup(datadict,viewkeys=[itemname]);
		return;
		
	def OnList_Set_As(self,event):
		from pydao.ohdf import OGroup; 
		from enthought.traits.api import HasTraits;
		from enthought.traits.ui.api import TextEditor;
		#from oviews import configure_ogroup;
		from mvc_views import ogroup_property_view;
		itemname=self.currentlistitems[0];
		datadict=self.get_current_ogroup();
		item=datadict.get(itemname);
		#print "item:",item
		print "itemname:",itemname
		ht=HasTraits();
		ht.expression='range(10)';
		view=View('expression',kind='panel',title='set as expression...',buttons=['OK','Cancel']);
		ok=ht.configure_traits(view=view);
		if ok:
			value=eval(ht.expression);
			datadict.set(itemname,value);
			print itemname,'set as',value;
		return;
		
	def OnList_Export_Ascii(self,event):
		from pydao.ohdf import OGroup,OTable; 
		from enthought.traits.api import HasTraits;
		from pydao.ohdfvi import Hanlder_to_Fix_TextEditor;
		from enthought.traits.ui.api import Item,Group,VGroup,View,FileEditor,BooleanEditor;
		
		datadict=self.get_current_ogroup();
		
		ht=HasTraits();
		ht.filename='';
		ht.transpose=False;
		group=VGroup(\
		Item('filename',editor=FileEditor(),style="simple",show_label=True),\
		Item('transpose',editor=BooleanEditor(),show_label=True),\
		show_labels=False,show_border = True,label='Please choose file');
		
		view=View(group,handler=Hanlder_to_Fix_TextEditor(),buttons=['OK','Cancel'],resizable=True,width=.5,kind='livemodal');
		ok=ht.configure_traits(view=view);
		if ok:
			import os;
			filename=ht.filename;
			absfname= os.path.abspath(filename.encode('ascii'));
			print "exporting to:",absfname;
		
			for itemname in self.currentlistitems:
				item=datadict.get(itemname);
				#print "item:",item
				print "itemname:",itemname
				ps=os.path.dirname(absfname);
				
				if isinstance(item,OGroup) or isinstance(item,OTable):
					fname=os.path.split(absfname)[-1];
					absfname1=os.path.join(ps,itemname+'_'+fname);
					item.export_ascii(absfname1);
				elif type(item) is ndarray:
					if ht.transpose:
						np.savetxt(absfname,transpose(item));
					else:
						np.savetxt(absfname,item);
				else:
					print "can not export this type yet."
		return;

	def OnList_Export_Ascii1(self,event):
		from pydao.ohdf import OGroup,OTable; 
		from enthought.traits.api import HasTraits;
		from pydao.ohdfvi import Hanlder_to_Fix_TextEditor;
		from enthought.traits.ui.api import Item,Group,VGroup,View,FileEditor;
		
		itemname=self.currentlistitems[0];
		datadict=self.get_current_ogroup();
		item=datadict.get(itemname);
		print "item:",item
		print "itemname:",itemname
		
		datadict.filename='';
		group=VGroup(\
		Item('filename',editor=FileEditor(),style="simple",show_label=True),\
		show_labels=False,show_border = True,label='Please choose file');
		
		view=View(group,handler=Hanlder_to_Fix_TextEditor(),buttons=['OK','Cancel'],resizable=True,width=.5,kind='livemodal');
		ok=datadict.configure_traits(view=view);
		if ok:
			import os;
			filename=datadict.filename;
			absfname= os.path.abspath(filename);
			print "exporting to:",absfname;
			if isinstance(item,OGroup) or isinstance(item,OTable):
				item.export_ascii(absfname);
			elif type(item) is ndarray:
				save(absfname,item);
			else:
				print "can not export this type yet."
		return;
		
	def OnList_Meta_Properties(self,event):
		from pydao.ohdf import OGroup,OCommon; 
		itemname=self.currentlistitems[0];
		datadict=self.get_current_ogroup();
		item=datadict.get(itemname);
		print "Meta properties of:",itemname
		if isinstance(item,OCommon):
			for k in item.meta_keys():
				v=item.get_meta(k);
				print k,":",v
		#if isinstance(item,OGroup):
		#	print item._ondisk._v_attrs._f_list('all')
		#else:
		#	print item._ondisk.attrs._f_list('all')
		
	def OnList_Shell_Edit(self,event):
		#objname=self.currentlistitems[0];
		parent=self.get_current_ogroup();
		for k in parent.keys():
			cmd=k+'=parent.get(k)';
			exec(cmd);
		from IPython.Shell import IPShellEmbed
		ipshell = IPShellEmbed();
		ipshell();
	
	def OnList_NewItem_BuildIn(self,event):
		#from __init__ import deval,dkeys,dset,dget;
		from enthought.traits.api import HasTraits;
		from pydao.ohdf import OGroup;
		from pydao.math import WorkSheet
		newitem=None;
		id=event.GetId();
		newtypestr=self.EventIdDict[str(id)];
		if newtypestr=="Advanced":
			ht=HasTraits();
			ht.importcmd='';
			ht.expr='';
			view=View('importcmd','expr',buttons=['OK','Cancel'],kind='modal');
			ok=ht.configure_traits(view=view);
			if ok:
				exec(ht.importcmd);
				newitem=eval(ht.expr);
		else:
			newitem=eval(newtypestr);
			
		self.list_add_newitem(newitem,newtypestr);
		
	def OnList_NewItem_Custom_Application(self,event):
		from enthought.traits.api import HasTraits;
		newitem=None;
		id=event.GetId();
		newtypedict=self.EventIdDict[str(id)];
		cmd="from "+newtypedict['module']+" import "+newtypedict['class'];
		exec(cmd);
		newitem=eval(newtypedict['class']+"()");
		self.list_add_newitem(newitem,newtypedict['class']);
		
	def OnList_Refresh(self,event):
		self.refresh(lazy=False);
		#import detc;
		#print detc.registry.packages
		#event.GetPosition()

	# def list_selected_all(self):
		# import wx;
		# datadict=self.get_current_ogroup();
		# for k in datadict.keys():
			# item=self.tree_get(k)
			# self.tree.SetItemBackgroundColour(item,wx.Color(128, 128,128));
		# self.currentlistitems=datadict.keys();
		
	def list_add_newitem(self,newitem,newtypestr):
		from pydao.ohdf import natural_name;
		if newitem is not None:
			datadict=self.get_current_ogroup();
			dataname='new'+newtypestr;
			dataname=dataname.replace("()","");
			dataname=dataname.encode('ascii');
			i=0;
			dataname1=dataname;
			while datadict.keys().count(dataname1)>0:
				dataname1=dataname+str(i);
				i=i+1;
			datadict.set(natural_name(dataname1),newitem);
			self.refresh(lazy=True);
			
	def list_update(self,datadict=None):
		if datadict is None:
			datadict=self.get_current_ogroup();
		self.list_update_withdata(datadict);
		oroot=self.get_oroot();
		if oroot is not None:
			oroot.set_title(datadict.string());
		return
		
	def list_update_withdata(self,data):
		from pydao.ohdf import OGroup,OCommon; 
		from pydao.ohdf import classdict;
		from numpy import ndarray;
		import time;
		#from dfunction import dkeys,dget;
		self.currentlistitems=[];
		self.list.DeleteAllItems()
		ks=data.keys();
		#ks.sort();
		if len(ks)>20:
			print "list_update_withdata",len(ks)
		from pydao.tools import Progress_Teller;
		pt=Progress_Teller(len(ks),0.01);
		for i in range(len(ks)):
			if len(ks)>20:
				pt.tell(i);
			#print "k:",k
			k=ks[i];
			v=data.get(k);
			
			t=type(v);
			num_items = self.list.GetItemCount();
			self.list.InsertStringItem(num_items, k);
			if isinstance(v,OGroup):
				itemid=self.list.SetStringItem(num_items,1, "*");
			else:
				itemid=self.list.SetStringItem(num_items,1, "");
				
			#self.list.InsertStringItem(num_items, k);
			#self.list.SetStringItem(num_items, 2, k);
			#if isinstance(v,OCommon):
			cdict=classdict(t);
			#print "cdict:",cdict
			typestr=cdict['classname'];#+str(cdict['modlist'])
			#else:
			#	typestr=str(t);
			self.list.SetStringItem(num_items, 2,typestr);
			#intro=str(v)[:40];
			intro=str(v);
			
			if type(v) is ndarray:
				size=str(v.shape);
			else:
				try:
					#print "size type:",type(v)
					size=str(v.size());
				except:
					#import traceback
					#traceback.print_exc()
					try:
						size=str(len(v));
					except:
						size="NA";
						
			time_stamp='';
			if isinstance(v,OGroup):
				import time;
				t_stamp=v.get_time_stamp('modified');
				if type(t_stamp) is tuple:
					time_stamp=time.ctime(time.mktime(t_stamp));
				elif type(t_stamp) is float:
					time_stamp=time.ctime(t_stamp);
			else:
				t_stamp=data.get_member_time_stamp(k);
				time_stamp=time.ctime(t_stamp);
			
			self.list.SetStringItem(num_items, 3, size);
			self.list.SetStringItem(num_items, 4, intro);
			self.list.SetStringItem(num_items, 5, time_stamp);
			
			#item=self.list.GetItem(itemid);
			#print "item type:",type(item),id(item),itemid;
			#item.data=v;

#=========================================================

def get_ogroup_explorer_editor( parent, editor, name=None ):
	import wx;
	try:
		dobj  = editor.object;
		dexp=dExplorer();
		dexp.create(parent,wx.ID_ANY)
		if name is None:
			dexp.data=dobj;
		else:
			dexp.data=dobj.get(name);
		dexp.rootview();
		return dexp.widget;
	except:
		import traceback
		traceback.print_exc()
		raise
		