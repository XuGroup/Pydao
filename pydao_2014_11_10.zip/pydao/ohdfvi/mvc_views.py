from pylab import *;
from enthought.traits.api import HasTraits;
import wx;

#=============================================================s======================================
#                View for application
#====================================================================================================
def application_view(buttons=None):
	from enthought.traits.ui.api import \
	Item,View,Group,VGroup,HGroup,Tabbed,ListEditor,InstanceEditor,ButtonEditor,TitleEditor;
	from enthought.traits.ui.tabular_adapter import TabularAdapter;
	from mvc_modelviews import OGroup_Analyzer_ModelView;
	#from mvc_views import ogroup_explorer_view;
		
	#if buttons is None:
	#	buttons=[];
	
	ana_name_item=Item('ana_name',editor=TitleEditor(),show_label=False);
	editor=InstanceEditor(view=ogroup_explorer_view());
	configure_item=Item('ana_configure',editor=editor,style='custom',\
	show_label=False,width=.35,height=.35,resizable = True)
	analyze_item=Item('bu_analyze',editor=ButtonEditor(label='run'),show_label=False);
	
	width=0.5;
	height=0.5;
	x=1-width-0.01;
	y=1-height-0.05;
	appview = View(ana_name_item,Group(configure_item,show_border = True,label='Configure'),\
	analyze_item,resizable = True,kind="live",\
	width=width,height=height,x=x,y=y);
	#width=.35,height=.35
	if buttons is not None:
		appview.buttons=buttons;
	return appview;
	
def application_view_modify(ogroup,buttons=None,handler=None,title=None):
	view=ogroup.app_view;
	view.handler=handler;
	if buttons is not None:
		view.buttons=buttons;
	view.title=title;
	return view;

def application_group_view(buttons=None):
	from enthought.traits.ui.api import \
	Item,View,Group,VGroup,HGroup,Tabbed,ListEditor,InstanceEditor,ButtonEditor,TitleEditor;
	from enthought.traits.ui.tabular_adapter import TabularAdapter;
	from mvc_modelviews import OGroup_Analyzer_ModelView;
	#from mvc_views import ogroup_explorer_view;
		
	#if buttons is None:
	#	buttons=['OK', 'Cancel' ];
	
	ana_name_item=Item('ana_name',editor=TitleEditor(),show_label=False);
	editor=InstanceEditor(view=ogroup_explorer_view());
	configure_item=Item('work_space',editor=editor,style='custom',\
	show_label=False,width=.35,height=.35,resizable = True)
	
	preprocess_item=Item('bu_preprocess',editor=ButtonEditor(label='sort_group'),show_label=False,padding=-15);
	nextgroup_item=Item('bu_nextgroup',editor=ButtonEditor(label='>>'),show_label=False,padding=-15);
	previousgroup_item=Item('bu_previousgroup',editor=ButtonEditor(label='<<'),show_label=False,padding=-15);
	dispcurrentgroup_item=Item('bu_dispcurrentgroup',editor=ButtonEditor(label='disp'),show_label=False,padding=-15);
	analyze_item=Item('bu_analyze',editor=ButtonEditor(label='analyze'),show_label=False,padding=-15);
	pass_item=Item('bu_pass',editor=ButtonEditor(label='pass'),show_label=False,padding=-15);
	reset_item=Item('bu_reset',editor=ButtonEditor(label='reset'),show_label=False,padding=-15);
	resetall_item=Item('bu_resetall',editor=ButtonEditor(label='reset_all'),show_label=False,padding=-15);
	joindata_item=Item('bu_joindata',editor=ButtonEditor(label='join_data'),show_label=False,padding=-15);
	save_item=Item('bu_save',editor=ButtonEditor(label='save'),show_label=False,padding=-15);
	
	actiongroup1=HGroup(preprocess_item,nextgroup_item,previousgroup_item,dispcurrentgroup_item);
	actiongroup2=HGroup(analyze_item,pass_item,reset_item,resetall_item);
	actiongroup3=HGroup(joindata_item,save_item);
	
	width=0.5;
	height=0.5;
	x=1-width-0.01;
	y=1-height-0.05;
	appview = View(ana_name_item,\
	Group(configure_item,show_border = True,label='Work Space'),\
	actiongroup1,actiongroup2,actiongroup3,\
	resizable = True,kind="live",\
	width=width,height=height,x=x,y=y);
	#width=.35,height=.35
	if buttons is not None:
		appview.buttons=buttons;
	return appview;
	
def application_group_view_modify(ogroup,buttons=None,handler=None,title=None):
	view=ogroup.app_group_view;
	view.handler=handler;
	if buttons is not None:
		view.buttons=buttons;
	view.title=title;
	return view;
	
def application_group_list_view(buttons=None):
	from enthought.traits.ui.api import \
	Item,View,Group,VGroup,HGroup,Tabbed,ListEditor,InstanceEditor,ButtonEditor,TitleEditor;
	from enthought.traits.ui.tabular_adapter import TabularAdapter;
	from mvc_modelviews import OGroup_Analyzer_ModelView;
	from mvc_views import ogroup_explorer_view;
	from enthought.traits.ui.api import Item, Group,View,ListEditor,TitleEditor;
		#from miscviews import 
	
	ana_name_item=Item('ana_name',editor=TitleEditor(),show_label=False);
	#editor=InstanceEditor(view=ogroup_explorer_view());
	
	editor=ListEditor(use_notebook=True, deletable=False, dock_style   = 'tab',export='DockWindowShell',page_name= '.name',view=ogroup_explorer_view());
	configure_item_list=Item('work_space_list',editor=editor,style='custom',\
	show_label=False,width=.35,height=.35,resizable = True,padding=-15)
	
	preprocess_item=Item('bu_preprocess',editor=ButtonEditor(label='Preprocess'),\
	show_label=False,padding=-15,visible_when=\
	"object.work_space_list.selected.get('config').get('_0group') is not None");
	
	nextgroup_item=Item('bu_nextgroup',editor=ButtonEditor(label='>>'),\
	show_label=False,padding=-15,visible_when=\
	"object.work_space_list.selected.get('config').get('_0group') is not None");
	
	previousgroup_item=Item('bu_previousgroup',editor=ButtonEditor(label='<<'),\
	show_label=False,padding=-15,visible_when=\
	"object.work_space_list.selected.get('config').get('_0group') is not None");
	
	dispcurrentgroup_item=Item('bu_dispcurrentgroup',editor=ButtonEditor(label='disp'\
	),show_label=False,padding=-15,visible_when=\
	"object.work_space_list.selected.get('config').get('_0group') is not None");
	
	analyze_item=Item('bu_analyze',editor=ButtonEditor(label='analyze'),show_label=False,padding=-15);
	
	pass_item=Item('bu_pass',editor=ButtonEditor(label='pass'),\
	show_label=False,padding=-15,visible_when=\
	"object.work_space_list.selected.get('config').get('_0group') is not None");
	
	reset_item=Item('bu_reset',editor=ButtonEditor(label='reset'),\
	show_label=False,padding=-15,visible_when=\
	"object.work_space_list.selected.get('config').get('_0group') is not None");
	
	resetall_item=Item('bu_resetall',editor=ButtonEditor(label='reset_all'),\
	show_label=False,padding=-15,visible_when=\
	"object.work_space_list.selected.get('config').get('_0group') is not None");
	
	joindata_item=Item('bu_joindata',editor=ButtonEditor(label='join_data'),\
	show_label=False,padding=-15,visible_when=\
	"object.work_space_list.selected.get('config').get('_0group') is not None");
	
	save_item=Item('bu_save',editor=ButtonEditor(label='save'),show_label=False,padding=-15,\
	visible_when="object.isgrouped()",enabled_when="object.isgrouped()");
	
	actiongroup1=HGroup(preprocess_item,nextgroup_item,previousgroup_item,dispcurrentgroup_item);
	actiongroup2=HGroup(analyze_item,pass_item,reset_item,resetall_item);
	actiongroup3=HGroup(joindata_item,save_item);
	
	width=0.5;
	height=0.5;
	x=1-width-0.01;
	y=1-height-0.05;
#	appview = View(ana_name_item,\
#	Group(configure_item_list,show_border = True,label='Work Space'),\
	appview=View(configure_item_list,\
	actiongroup1,actiongroup2,actiongroup3,\
	resizable = True,kind="live",\
	width=width,height=height,x=x,y=y);
	#width=.35,height=.35
	if buttons is not None:
		appview.buttons=buttons;
	return appview;
	
def application_group_list_view_modify(ogroup,buttons=None,handler=None,title=None):
	from enthought.traits.ui.menu import Menu, MenuBar;
	view=ogroup.app_group_list_view;
	view.handler=handler;
	view.menubar=application_group_list_view_menubar();
	view.toolbar=application_group_list_view_toolbar();
	if buttons is not None:
		view.buttons=buttons;
	if title is not None:
		view.title=title;
	return view;
	
def application_group_list_view_menubar():
	from enthought.traits.ui.menu import Menu, MenuBar, Action;
	load= Action(name = "load",action = "On_WorkSpace_Load")
	save= Action(name = "save",action = "On_WorkSpace_Save")
	close= Action(name = "close",action = "On_WorkSpace_Close")
	workspace_menu=Menu(load,save,close,name = 'WorkSpace');
	return MenuBar(workspace_menu);
	
def application_group_list_view_toolbar():
	from enthought.traits.ui.menu import Menu, ToolBar, Action;
	from enthought.pyface.api import ImageResource;
	load= Action(name = "load",action = "On_WorkSpace_Load")
	save= Action(name = "save",action = "On_WorkSpace_Save")
	close= Action(name = "close",action = "On_WorkSpace_Close")
	return ToolBar(load,save,close);
#=============================================================s======================================
#                View for ogroup
#====================================================================================================
def ogroup_explorer_view():
	from mvc_controls import OGroup_Exporler_Editor_Handler;
	from mvc_editor_functions import get_ogroup_explorer_editor;
	from enthought.traits.ui.api import Item,View,Group,CustomEditor;
	
	editor=CustomEditor(get_ogroup_explorer_editor);
	view=View(Group(Item('dname',editor=editor,resizable = True,id='expeditorid'),show_labels=False),kind='subpanel',width=.8,height=.8,resizable = True,handler=OGroup_Exporler_Editor_Handler());
	return view;
	
def ogroup_property_view(obj,viewkeys=None,buttons=None,editors=None,groupstyple='Tabbed',title='Edit '):
	from ..ohdf.functions import dget,dset,dkeys;
	from enthought.traits.api import HasTraits;
	from enthought.traits.ui.api import \
	Item,View,Group,VGroup,HGroup,Tabbed,VFlow,VFold,\
	InstanceEditor,ArrayEditor,BooleanEditor,ListEditor,TextEditor;
	from mvc_modelviews import OGroup_Property_ModelView;

	handler=OGroup_Property_ModelView(obj);
	
	if groupstyple=='Tabbed':
		show_labels=False;
	else:
		show_labels=True;
		
	if buttons is None:
		buttons=['Apply','Revert','Undo', 'OK', 'Cancel' ];
	i=0;
	if viewkeys is None:
		vkeys=obj.keys();
	else:
		vkeys=viewkeys;

	item_list=[];
	for traitname in vkeys:
		v=obj.get(traitname);
		if editors is not None:
			if editors.has_key(traitname):
				item=Item(traitname,editor =editors[traitname]);
		elif isinstance(v,HasTraits):
			item=Item(traitname,editor = InstanceEditor(editable = True),style='readonly');
		elif type(v) is ndarray:
			if len(v.shape)<=2:
				if prod(v.shape)<100:
					item=Item(traitname,editor = ArrayEditor(),resizable = True);
				else:
					item=Item(traitname);
			else:
				item=Item(traitname);
		elif type(v) is bool:
			item=Item(traitname,editor = BooleanEditor(),resizable = True);
		elif type(v) is list and type(v) is None:
			print "found list"
			isstr=True;
			for k in v:
				print k,type(k)
				if type(k) is not str and type(k) is not string_:
					isstr=False;
			if isstr:
				item=Item(traitname,editor = ListEditor());
			else:
				item=Item(traitname,resizable = True,editor=TextEditor(multi_line=True));
		else:
			#item=Item(traitname,resizable = True,editor=TextEditor(multi_line=True));
			item=Item(traitname,resizable = True);
		item.resizable=True;
		item_list.append(item);
		
	viewcmd="view=View("+groupstyple+"("
	for i in range(len(item_list)):
		viewcmd=viewcmd+"item_list["+str(i)+"],";
	viewcmd=viewcmd+"show_labels=";
	viewcmd=viewcmd+str(show_labels)+",orientation='vertical')";
	viewcmd=viewcmd+",buttons = "+str(buttons)+",kind='panel',resizable = True,handler=handler,title=title)";
	#print "viewcmd:\n",viewcmd;
	#print "title:",title
	exec(viewcmd);
	return view;
	
def ogroup_tabular_view(ogroup,viewkeys=None,buttons=None):
	from enthought.traits.ui.api import \
	Item,View,Group,VGroup,HGroup,Tabbed,TabularEditor;
	from enthought.traits.ui.tabular_adapter import TabularAdapter;
	from modelviews import OGroup_Tabular_ModelView;
	
	adapter=TabularAdapter();
	columns=['name','dir','type','size','intro'];
	adapter.columns=columns;
	
	editor = TabularEditor(adapter=adapter,editable=True,multi_select=True,operations=[ 'delete', 'insert', 'append', 'edit', 'move' ],clicked='clicked',column_clicked='column_clicked',right_clicked='right_clicked',dclicked='dclicked');
	
	ssview=View(Group(Item('tabular',editor=editor,resizable = True,id='expeditorid'),show_labels=False),kind='live',width=.5,height=.5,scrollable=True,handler=OGroup_Tabular_ModelView(ogroup),resizable = True);
	
	return ssview;
		

def ogroup_analyzer_view(ogroup,buttons=None,handler=None,title=None):
	from enthought.traits.ui.api import \
	Item,View,Group,VGroup,HGroup,Tabbed,ListEditor,InstanceEditor,ButtonEditor;
	from enthought.traits.ui.tabular_adapter import TabularAdapter;
	from mvc_modelviews import OGroup_Analyzer_ModelView;
	from oviews import ogroup_explorer_view;
	
	if handler is None:
		handler=OGroup_Analyzer_ModelView(ogroup);
		
	if buttons is None:
		buttons=['OK', 'Cancel' ];
	
	if title is None:
		title = str(ogroup.ana_method);
	#listeditor=ListEditor(use_notebook=True, deletable=False, dock_style   = 'tab',export='DockWindowShell',page_name= '.name',view=expview);
	#input_item=Item('inputs',show_label = True,style= 'custom',editor=listeditor);
	#output_dir_item=Item('output_dir');
	#output_name_item=Item('output_name');
	
	editor=InstanceEditor(view=ogroup_explorer_view());
	configure_item=Item('work_space',editor=editor,style='custom',\
	show_label=False,width=.35,height=.35,resizable = True)
	analyze_item=Item('bu_analyze',editor=ButtonEditor(label='run'),show_label=False);
	anaview = View(Group(configure_item,show_border = True,label='Configure'),\
	analyze_item,resizable = True,kind="live",handler=handler,buttons=buttons,width=.5,height=.35,title=title);
	#width=.35,height=.35
	return anaview;


	
#========================================
#  ogroup view attempt to make faster explorer
#========================================

def ogroup_mytree_view(ogroup,viewkeys=None,buttons=None):
	from enthought.traits.ui.api import \
	Item,View,Group,VGroup,HGroup,Tabbed,TabularEditor;
	from enthought.traits.ui.tabular_adapter import TabularAdapter;
	
	from controls import OGroup_Exporler_Editor_Handler;
	from mvc_editor_functions import ogroup_mytree_editor;
	from enthought.traits.ui.api import Item,View,Group,CustomEditor;
	
	editor=CustomEditor(ogroup_mytree_editor);
	view=View(Group(Item('dname',editor=editor,resizable = True,id='expeditorid'),show_labels=False),kind='subpanel',width=.8,height=.8,resizable = True,handler=OGroup_Exporler_Editor_Handler());
	
	return view;
	
def ogroup_explorer_view_tabular(ogroup,viewkeys=None,buttons=None):
	from enthought.traits.ui.api import \
	Item,View,Group,VGroup,HGroup,HSplit,HFlow,Tabbed,TabularEditor,InstanceEditor;
	from enthought.traits.ui.tabular_adapter import TabularAdapter;
	
	from modelviews import OGroup_Exporler_ModelView;
	from enthought.traits.ui.api import Item,View,Group,CustomEditor;
	
	
	view=View(\
	HSplit(Item('ogroup',editor=InstanceEditor(editable = True,\
	view=ogroup_mytree_view(ogroup)),resizable = True,style='custom'),\
	Item('subogroup',editor=InstanceEditor(editable = True,\
	view=ogroup_tabular_view(ogroup)),resizable = True,style='custom'),show_labels=False),handler=OGroup_Exporler_ModelView(ogroup),kind='subpanel',width=.5,height=.5,resizable = True);
	
	return view;