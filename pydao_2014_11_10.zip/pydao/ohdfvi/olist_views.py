def get_tabbed_explorer_view():
	from mvc_views import ogroup_explorer_view;
	from enthought.traits.ui.menu import Menu, MenuBar;
	from mvc_controls import OGroup_List_Viewer_Handler;
	from enthought.traits.ui.api import Item, Group,View,ListEditor,TitleEditor;
		#from miscviews import 
	expview=ogroup_explorer_view();
		
	editor=ListEditor(use_notebook=True, deletable=False, dock_style   = 'tab',export='DockWindowShell',page_name= '.name',view=expview);
		
	item=Item( 'opages',show_label = False,style= 'custom',editor=editor,padding=-15);
	item_status=Item( 'status_txt',show_label = False,style= 'readonly',padding=-15);
		
	tabview = View(item,item_status,width=.65,height=.65,resizable = True,kind="live",handler=OGroup_List_Viewer_Handler());
	return tabview;
	