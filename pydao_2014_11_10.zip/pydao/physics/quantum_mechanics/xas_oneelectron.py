from pylab import *;
from oneparticle_special import Dipole_Transition,Crystal_Field,Spin_Orbit_Coupling;
from atomic_wavefunction_method import matrix_element_between_basis;
from pydao.ohdf import OGroup;

class XAS_OneElectron(OGroup):
	def __init__(self):
		OGroup.__init__(self);
	
	def setpara(self,name,value):
		if name=='basis_ground':
			self.set('para_basis_ground',value);
		elif name=='basis_excited':
			self.set('para_basis_excited',value);
		elif name=='operator_spinorbit':
			self.set('para_operator_spinorbit',value);
		elif name=='operator_crystalfield':
			self.set('para_operator_crystalfield',value);
		elif name=='operator_dipoletrans':
			self.set('para_operator_dipoletrans',value);
		return;
		
	def basis_init(self):
		from pydao.physics import atomic_wavefunction_basis;
		Z,n,l=self.get('para_basis_ground');
		basis_ground=atomic_wavefunction_basis(Z,n,l);
		Z,n,l=self.get('para_basis_excited');
		basis_excited=atomic_wavefunction_basis(Z,n,l);
		self.set('basis_ground',basis_ground);
		self.set('basis_excited',basis_excited);
		return basis_ground,basis_excited;
	
	def op_dipoletrans_init(self):
		para_operator_dipoletrans=self.get('para_operator_dipoletrans');
		dipole_operator,Np,rrange=para_operator_dipoletrans;
		op_dipoletrans=Dipole_Transition(dipole_operator=dipole_operator,particle_index=0);
		op_dipoletrans.xyzpara_set('Np',Np);
		op_dipoletrans.xyzpara_set('rrange',rrange);
		self.set('op_dipoletrans',op_dipoletrans);
		return op_dipoletrans;
		
	def op_cf_init(self):
		para_operator_crystalfield=self.get('para_operator_crystalfield');
		symmetry,cf_parameters,Ncharge,Np,rrange,cf_fun=para_operator_crystalfield;
		op_cf=Crystal_Field(symmetry=symmetry,parameters=cf_parameters,particle_index=0,Ncharge=Ncharge);
		op_cf.xyzpara_set('Np',Np);
		op_cf.xyzpara_set('rrange',rrange);
		if cf_fun is not None:
			cf_fun(op_cf);
		self.set('op_crystalfield',op_cf);
		return op_cf;
		
	def op_so_init(self):
		op_so=Spin_Orbit_Coupling(particle_index=0);
		self.set('op_spinorbit',op_so);
		return op_so;
		
	def operator_init(self):
		op_dipoletrans=self.op_dipoletrans_init();
		op_cf=self.op_cf_init();
		op_so=self.op_so_init();
		return op_so,op_cf,op_dipoletrans;
		
	def construct_mat_so(self):
		basis_excited=self.get('basis_excited');
		basis_ground=self.get('basis_ground');
		
		op_so=self.get('op_spinorbit');
		matr_so_ground=op_so.matrix_rep(basis_ground);
		matr_so_excited=op_so.matrix_rep(basis_excited);
		op_so.save_resultdbase_2disk();

		self.set('matr_so_ground',matr_so_ground);
		self.set('matr_so_excited',matr_so_excited);
		return matr_so_ground,matr_so_excited;
		
	def construct_mat_cf(self):
		basis_excited=self.get('basis_excited');
		basis_ground=self.get('basis_ground');
		
		op_cf=self.get('op_crystalfield');
		matr_cf_ground=op_cf.matrix_rep(basis_ground);
		matr_cf_excited=op_cf.matrix_rep(basis_excited);
		op_cf.save_resultdbase_2disk();
		
		self.set('matr_cf_ground',matr_cf_ground);
		self.set('matr_cf_excited',matr_cf_excited);
		return matr_cf_ground,matr_cf_excited;
		
	def construct_mat_tm_basis(self):
		basis_excited=self.get('basis_excited');
		basis_ground=self.get('basis_ground');
		
		op_dipoletrans=self.get('op_dipoletrans');
		tm_basis=matrix_element_between_basis(basis_ground,basis_excited,op_dipoletrans);
		op_dipoletrans.save_resultdbase_2disk();
		
		self.set('matr_dipoletrans',tm_basis);
		return tm_basis;
		
	def construct_matrix(self):
		matr_so_ground,matr_so_excited=self.construct_mat_so();
		matr_cf_ground,matr_cf_excited=self.construct_mat_cf();
		tm_basis=self.construct_mat_tm_basis();
		return matr_so_ground,matr_so_excited,matr_cf_ground,matr_cf_excited,tm_basis;
		
	def diag_matrix(self):
		from pydao.physics import e_charge;
		matr_so_ground=self.get('matr_so_ground');
		matr_so_excited=self.get('matr_so_excited');
		matr_cf_ground=self.get('matr_cf_ground');
		matr_cf_excited=self.get('matr_cf_excited');
		
		
		matr_ground=matr_so_ground+matr_cf_ground;
		Eground,Vground=eigh(matr_ground/e_charge);
		Eground=Eground*e_charge;
		
		matr_excited=matr_so_excited+matr_cf_excited;
		Eexcited,Vexcited=eigh(matr_excited/e_charge);
		Eexcited=Eexcited*e_charge;
		
		self.set('Eground',Eground);
		self.set('Vground',Vground);
		self.set('Eexcited',Eexcited);
		self.set('Vexcited',Vexcited);
		return Eground,Vground,Eexcited,Vexcited
		
	def cal_dipole_trans(self):
		Eground=self.get('Eground');
		Vground=self.get('Vground');
		Eexcited=self.get('Eexcited');
		Vexcited=self.get('Vexcited');
		
		tm_basis=self.get('matr_dipoletrans');
		dipole_trans=conjugate(transpose(matrix(Vground)))*matrix(tm_basis)*matrix(Vexcited);
		self.set('dipole_trans',dipole_trans);
		
		Ng,Ne=dipole_trans.shape;
		E_dipoletrans=zeros(Ng*Ne);
		Mate_dipoletrans=zeros(Ng*Ne)+1j;
		for ig in range(Ng):
			for ie in range(Ne):
				E_dipoletrans[ig*Ne+ie]=real(Eexcited[ie]-Eground[ig]);
				Mate_dipoletrans[ig*Ne+ie]=dipole_trans[ig,ie];
		self.set('E_dipoletrans',E_dipoletrans);
		self.set('Mate_dipoletrans',Mate_dipoletrans);
		return E_dipoletrans,Mate_dipoletrans;
		
	def cal_spect(self,Ewidth,Emin=None,Emax=None,Ne=None,Plot=False):
		from pydao.math import XyDiscreteFun;
		E_dipoletrans=self.get('E_dipoletrans');
		Mate_dipoletrans=self.get('Mate_dipoletrans');
		
		spect=XyDiscreteFun();
		spect.set('x',E_dipoletrans/1.6e-19);
		spect.set('y',abs(Mate_dipoletrans)**2);
		spect.sortx();
		
		spect_conv=spect.gaussconv1(Ewidth,Emin,Emax,Ne);
		
		self.set('spect',spect);
		self.set('spect_conv',spect_conv);
		
		if Plot:
			plot(spect.get('x'),spect.get('y'),'o');
			xnew=spect_conv.get('x');
			ynew=spect_conv.get('y');
			plot(xnew,ynew);
			show();
		return spect,spect_conv;

def xnld_xz(para_basis_ground,para_basis_excited,para_operator_crystalfield,Ewidth=0.2,Emin=-10.,Emax=15.,Np=30):
	Ne=100000;
	rrange_dipoletrans=1.0e-10;
	
	# x transition
	xas_onee=XAS_OneElectron();
	xas_onee.set('para_basis_ground',para_basis_ground);
	xas_onee.set('para_basis_excited',para_basis_excited);
	xas_onee.set('para_operator_dipoletrans',('x',Np,rrange_dipoletrans));
	xas_onee.set('para_operator_crystalfield',para_operator_crystalfield);

	xas_onee.basis_init();
	op_so,op_cf,op_dipoletrans=xas_onee.operator_init();
	xas_onee.construct_matrix();
	Eground,Vground,Eexcited,Vexcited=xas_onee.diag_matrix();
	E_dipoletrans,Mate_dipoletrans=xas_onee.cal_dipole_trans();
	spect,spect_convx=xas_onee.cal_spect(Ewidth=Ewidth,Emin=Emin,Emax=Emax,Ne=Ne,Plot=False);

	# z transition
	xas_onee.set('para_operator_dipoletrans',('z',Np,rrange_dipoletrans));
	op_dipoletrans=xas_onee.op_dipoletrans_init();
	tm_basis=xas_onee.construct_mat_tm_basis();
	E_dipoletrans,Mate_dipoletrans=xas_onee.cal_dipole_trans();
	spect,spect_convz=xas_onee.cal_spect(Ewidth=Ewidth,Emin=Emin,Emax=Emax,Ne=Ne,Plot=False);

	Int_x=spect_convx.get('y');
	Int_z=spect_convz.get('y');
	E=spect_convx.get('x');
	Idiff=Int_z-Int_x;

	contrast=sum(abs(Idiff))*mean(diff(E));
	# print "Ewidth,qK1,contrast:",Ewidth,qK1,contrast;
	
	op_so.remove_diskfile();
	op_cf.remove_diskfile();
	op_dipoletrans.remove_diskfile();
	return contrast,E_dipoletrans; 
