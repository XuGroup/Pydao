from pylab import *;
from pydao.math import volume,vXprod,vnorm;

def cal_basis3d(basis):
	if len(basis)==3:
		basis3d=basis;
	elif len(basis)==1:
		basis3d=list(basis)+[(0,1,0),(0,0,1)];
	elif len(basis)==2:
		base3=vXprod(basis[0],basis[1]);
		base3=vnorm(base3);
		basis3d=list(basis)+[base3];
	basis3d=array(basis3d);
	return basis3d;
		
def cal_kbasis(basis):
	vol=volume(basis);
	basis3d=cal_basis3d(basis);
	vol=volume(basis3d);
		
	k0max=2*pi*vXprod(array(basis3d[1]),basis3d[2])/vol;
	k1max=2*pi*vXprod(basis3d[2],array(basis3d[0]))/vol;
	k2max=2*pi*vXprod(basis3d[0],array(basis3d[1]))/vol;
	kbasis3d=array([k0max,k1max,k2max]);
	if len(basis)<3:
		kbasis=kbasis3d[0:len(basis)];
	else:
		kbasis=kbasis3d;
	return kbasis;