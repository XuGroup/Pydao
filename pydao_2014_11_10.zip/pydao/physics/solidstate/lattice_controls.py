from pydao.ohdfvi import OGroup_Property_ModelView;
from pydao.ohdfvi import OGroup_Analyzer_ModelView,\
OGroup_Analyzer_Group_ModelView,OGroup_Analyzer_Group_List_ModelView;
from pylab import *;

class Lattice_ModelView(OGroup_Property_ModelView):
	def init_info(self,info):
		OGroup_Property_ModelView.init_info(self,info);
		self.preprocess(self.model);
		
	def preprocess(self,model):
		from enthought.traits.api import Button;
		model.bu_unify_coordinates=Button();
		model.bu_cal_k_basis=Button();
		model.bu_register_nearest=Button();
		model.bu_register_neighbor=Button();
		model.bu_cal_neighbor_matPhi=Button();
		model.bu_translate_atoms=Button();
		model.bu_transform_basis=Button();
		model.bu_intra_pos_direct2Cartesian=Button();
		model.bu_intra_pos_Cartesian2direct=Button();
		model.bu_plot_atoms=Button();
		model.bu_plot_basis=Button();
		model.bu_plot_primitive_cell=Button();
		model.bu_plot_kbasis=Button();
		model.bu_plot_nearest=Button()
		model.bu_plot_neighbors=Button();
		model.bu_import_basis=Button();
		model.bu_import_atoms_fromxyz=Button();

	def _bu_register_nearest_fired(self,lattice):
		print "bu_register_nearest fired!"
		import pydao;
		atoms=pydao.viewer.get_data_of_link(lattice.atom_list_name);
		basis=pydao.viewer.get_data_of_link(lattice.basis_name);
		#atom_list_name=lattice.atom_list_name[0];
		#basis_name=lattice.basis_name[0];
		#basis=lattice.get(basis_name);
		lattice.register_nearest_kind(atoms,basis);
		print "register_nearest done."
		
	def _bu_register_neighbor_fired(self,lattice):
		print "bu_register_neighbors fired!"
		import pydao;
		atoms=pydao.viewer.get_data_of_link(lattice.atom_list_name);
		basis=pydao.viewer.get_data_of_link(lattice.basis_name);
		
		nei_distance=lattice.get('nei_distance');
		lattice.register_neighbors(atoms,basis,nei_distance);
		print "register_nearest done."

	def _bu_unify_coordinates_fired(self,lattice):
		import pydao;
		atoms=pydao.viewer.get_data_of_link(lattice.atom_list_name);
		basis=pydao.viewer.get_data_of_link(lattice.basis_name);
		print "type:",type(lattice)
		lattice.unify_coordinates(atoms,basis);
		print atom_list_name, " UnifyCoordinates done."
		
	def _bu_cal_k_basis_fired(self,lattice):
		import pydao;
		atoms=pydao.viewer.get_data_of_link(lattice.atom_list_name);
		basis=pydao.viewer.get_data_of_link(lattice.basis_name);
		
		lattice.cal_kbasis(basis);
		print " OnCalKBasis done."

		
	def _bu_cal_neighbor_matPhi_fired(self,lattice):
		import pydao;
		atoms=pydao.viewer.get_data_of_link(lattice.atom_list_name);
		basis=pydao.viewer.get_data_of_link(lattice.basis_name);
		
		for k in atoms.keys():
			print "atom:",k
			atom=atoms.get(k);
			matPhi_list=atom.neighbor_matPhi(lattice,atoms,basis);
		print 'OnCalNeighbor_matPhi done.'
		return ;
		
	def _bu_plot_atoms_fired(self,lattice):
		import pydao;
		atoms=pydao.viewer.get_data_of_link(lattice.atom_list_name);
		basis=pydao.viewer.get_data_of_link(lattice.basis_name);
		lattice.plot3d_atoms(atoms);
		
	def _bu_plot_basis_fired(self,lattice):
		import pydao;
		atoms=pydao.viewer.get_data_of_link(lattice.atom_list_name);
		basis=pydao.viewer.get_data_of_link(lattice.basis_name);
		color=tuple(lattice.color);
		lattice.plot3d_basis(basis,color);
		
	def _bu_plot_primitive_cell_fired(self,lattice):
		import pydao;
		atoms=pydao.viewer.get_data_of_link(lattice.atom_list_name);
		basis=pydao.viewer.get_data_of_link(lattice.basis_name);
		color=tuple(lattice.color);
		lattice.plot3d_primitive_cell(basis,color);
		
	def _bu_plot_kbasis_fired(self,lattice):
		color=tuple(lattice.color);
		lattice.plot3d_kbasis(color=color);

	def _bu_plot_nearest_fired(self,lattice):
		import pydao;
		atoms=pydao.viewer.get_data_of_link(lattice.atom_list_name);
		basis=pydao.viewer.get_data_of_link(lattice.basis_name);
		atom_name=lattice.atom_name;
		if type(atom_name) is unicode:
			atom_name=atom_name.encode('ascii');
		atom=atoms.get(atom_name);
		lattice.plot3d_nearest(atom_name);
		
	def _bu_plot_neighbors_fired(self,lattice):
		import pydao;
		atoms=pydao.viewer.get_data_of_link(lattice.atom_list_name);
		basis=pydao.viewer.get_data_of_link(lattice.basis_name);
		atom_name=lattice.atom_name;
		if type(atom_name) is unicode:
			atom_name=atom_name.encode('ascii');
		atom=atoms.get(atom_name);
		lattice.plot3d_neighbors(atom_name);

	def _bu_translate_atoms_fired(self,lattice):
		displacement=lattice.displacement;
		coordinate=lattice.coordinate;
		displace_intrapos=lattice.displace_intrapos;
		new_atom_list_name=lattice.new_atom_list_name;
		
		import pydao;
		atoms=pydao.viewer.get_data_of_link(lattice.atom_list_name);
		basis=pydao.viewer.get_data_of_link(lattice.basis_name);
		print basis_name,basis
		
		atoms=lattice.get(atom_list_name);
		newatoms=lattice.translate_atoms(atoms,basis,displacement,coordinate,displace_intrapos);
		#print "newatom name:",ht.get('new_atoms_name')
		lattice.set(new_atom_list_name,newatoms);

	def _bu_transform_basis_fired(self,lattice):
		transfomation_matrix_name=lattice.transfomation_matrix[0];
		new_basis_name=lattice.new_basis_name;
		
		import pydao;
		atoms=pydao.viewer.get_data_of_link(lattice.atom_list_name);
		basis=pydao.viewer.get_data_of_link(lattice.basis_name);
		transfomation_matrix=lattice.get(transfomation_matrix_name);
		#print basis_name,basis
		#print type(basis),type(transfomation_matrix),basis,transfomation_matrix
		
		newabasis=matrix(basis)*matrix(transfomation_matrix);
		newabasis=array(newabasis);
		
		#print "newatom name:",ht.get('new_atoms_name')
		lattice.set(new_basis_name,newabasis);
		
	
	def _bu_intra_pos_direct2Cartesian_fired(self,lattice):
		from pydao.ohdf import get_empty_instance;
		import pydao;
		atoms=pydao.viewer.get_data_of_link(lattice.atom_list_name);
		basis=pydao.viewer.get_data_of_link(lattice.basis_name);
		new_atom_list_name=lattice.new_atom_list_name;
		
		newatoms=get_empty_instance(atoms);
		for k in atoms.keys():
			atom=atoms.get(k);
			newatom=atom.copy2mem();
				#newatom.translate_cart(cart_disp);
			if newatom.get('coordinate')=='direct':
				intrapos=newatom.get('intrapos');
				intrapos=lattice.direct2cartesian(intrapos,basis);
				newatom.set('intrapos',intrapos);
				newatom.set('coordinate','cartesian');
			newatoms.set(k,newatom);
		lattice.set(new_atom_list_name,newatoms);
			
	def _bu_intra_pos_Cartesian2direct_fired(self,lattice):
		from pydao.ohdf import get_empty_instance;
		import pydao;
		atoms=pydao.viewer.get_data_of_link(lattice.atom_list_name);
		basis=pydao.viewer.get_data_of_link(lattice.basis_name);
		new_atom_list_name=lattice.new_atom_list_name;
		
		newatoms=get_empty_instance(atoms);
		for k in atoms.keys():
			atom=atoms.get(k);
			newatom=atom.copy2mem();
				#newatom.translate_cart(cart_disp);
			if newatom.get('coordinate')=='cartesian':
				intrapos=newatom.get('intrapos');
				intrapos=lattice.cartesian2direct(intrapos,basis);
				newatom.set('intrapos',intrapos);
				newatom.set('coordinate','direct');
			newatoms.set(k,newatom);
		lattice.set(new_atom_list_name,newatoms);
		
	def _bu_import_basis_fired(self,lattice):
		cif_filename=lattice.cif_filename;
		print "cif_filename",cif_filename,type(cif_filename)
		lattice.import_basis_fromcif(cif_filename);
		import pydao,os
		pydao.viewer.history_file.set('path_open',os.path.dirname(cif_filename).encode('ascii'));
		
	def _bu_import_atoms_fromxyz_fired(self,lattice):
		xyz_filename=lattice.xyz_filename;
		print "xyz_filename",xyz_filename,type(xyz_filename)
		lattice.import_atoms_fromxyz(xyz_filename);
		import pydao,os
		pydao.viewer.history_file.set('path_open',os.path.dirname(xyz_filename).encode('ascii'));
		
class Lattice_Program_ModelView(OGroup_Analyzer_ModelView):
	def init_info(self,info):
		OGroup_Analyzer_ModelView.init_info(self,info);
		#self.preprocess(self.model);
		print "info:",info
		
#===============================================================================================
#                                  import
#==============================================================================================			
	def On_import_basis(self,info=None):
		import pydao,sys,os;
		from pydao.ohdf import OGroup;
		from pydao.ohdfvi import ogroup_analyzer_view;
		if info is not None:
			lattice=self.model;
			func_name=sys._getframe().f_code.co_name;
			ana_configure=OGroup();
			ana_configure.set('cif_filename',pydao.viewer.history_file.get('path_open'));
			lattice.ana_configure=ana_configure;
			lattice.ana_method=eval("self."+func_name);
			lattice.ana_name=func_name;
			#view=ogroup_analyzer_view(lattice);
			#lattice.configure_traits(view=view);
			lattice.app_view.updated=True;
		else:
			lattice=self.model;
			ana_configure=lattice.ana_configure;
			cif_filename=ana_configure.get('cif_filename');
			lattice.import_basis_fromcif(cif_filename);
			print "cif_filename",cif_filename,type(cif_filename)
			pydao.viewer.history_file.set('path_open',os.path.dirname(cif_filename).encode('ascii'));
		
	def On_import_atoms(self,info=None):
		import pydao,sys,os;
		from pydao.ohdf import OGroup;
		from pydao.ohdfvi import ogroup_analyzer_view;
		if info is not None:
			lattice=self.model;
			func_name=sys._getframe().f_code.co_name
			ana_configure=OGroup();
			ana_configure.set('xyz_filename',pydao.viewer.history_file.get('path_open'));
			lattice.ana_configure=ana_configure;
			lattice.ana_method=eval("self."+func_name);
			lattice.ana_name=func_name;
			#view=ogroup_analyzer_view(lattice);
			#lattice.configure_traits(view=view);
			lattice.app_view.updated=True;
		else:
			lattice=self.model;
			ana_configure=lattice.ana_configure;
			xyz_filename=ana_configure.get('xyz_filename');
			lattice.import_atoms_fromxyz(xyz_filename);
			print "xyz_filename",xyz_filename,type(xyz_filename)
			pydao.viewer.history_file.set('path_open',os.path.dirname(xyz_filename).encode('ascii'));

#===============================================================================================
#                                             modify
#===============================================================================================
	def On_filter_atoms_primitivecell(self,info=None):
		import pydao,sys;
		from pydao.ohdf import OGroup;
		from pydao.ohdfvi import ogroup_analyzer_view;
		if info is not None:
			lattice=self.model;
			func_name=sys._getframe().f_code.co_name
			ana_configure=OGroup();
			ana_configure.set('atoms_link',str(lattice.get('atoms').get_link()));
			ana_configure.set('basis_link',str(lattice.get_link('basis')));
			ana_configure.set('output_dir_link',str(lattice.get_link()));
			lattice.ana_configure=ana_configure;
			lattice.ana_method=eval("self."+func_name);
			lattice.ana_name=func_name;
			#view=ogroup_analyzer_view(lattice);
			#lattice.configure_traits(view=view);
			lattice.app_view.updated=True;
		else:
			lattice=self.model;
			ana_configure=lattice.ana_configure;
			atoms=pydao.viewer.get_data_of_link(ana_configure.get('atoms_link'));
			basis=pydao.viewer.get_data_of_link(ana_configure.get('basis_link'));
			lattice.filter_atoms_primitivecell(atoms,basis);
	
	def On_translate_atoms(self,info=None):
		import pydao,sys;
		from pydao.ohdf import OGroup;
		from pydao.ohdfvi import ogroup_analyzer_view;
		if info is not None:
			lattice=self.model;
			func_name=sys._getframe().f_code.co_name
			ana_configure=OGroup();
			ana_configure.set('atoms_link',str(lattice.get('atoms').get_link()));
			ana_configure.set('basis_link',str(lattice.get_link('basis')));
			ana_configure.set('output_dir_link',str(lattice.get_link()));
			ana_configure.set('displacement',(0,0,0));
			ana_configure.set('displace_intrapos',True);
			ana_configure.set('coordinate','direct');
			lattice.ana_configure=ana_configure;
			lattice.ana_method=eval("self."+func_name);
			lattice.ana_name=func_name;
			#view=ogroup_analyzer_view(lattice);
			#lattice.configure_traits(view=view);
			lattice.app_view.updated=True;
		else:
			lattice=self.model;
			ana_configure=lattice.ana_configure;
			atoms=pydao.viewer.get_data_of_link(ana_configure.get('atoms_link'));
			basis=pydao.viewer.get_data_of_link(ana_configure.get('basis_link'));
			output_dir=pydao.viewer.get_data_of_link(ana_configure.get('output_dir_link'));
			displacement=ana_configure.get('displacement');
			coordinate=ana_configure.get('coordinate');
			displace_intrapos=ana_configure.get('displace_intrapos');
			newatoms=lattice.translate_atoms(atoms,basis,displacement,coordinate,displace_intrapos);
			output_dir.set('atoms_translated',newatoms);
			
	def On_transform_basis(self,info=None):
		import pydao,sys;
		from pydao.ohdf import OGroup;
		from pydao.ohdfvi import ogroup_analyzer_view;
		if info is not None:
			lattice=self.model;
			func_name=sys._getframe().f_code.co_name
			ana_configure=OGroup();
			ana_configure.set('basis_link',str(lattice.get_link('basis')));
			ana_configure.set('output_dir_link',str(lattice.get_link()));
			ana_configure.set('transfomation_matrix_link',str(lattice.get_link()));
			lattice.ana_configure=ana_configure;
			lattice.ana_method=eval("self."+func_name);
			lattice.ana_name=func_name;
			#view=ogroup_analyzer_view(lattice);
			#lattice.configure_traits(view=view);
			lattice.app_view.updated=True;
		else:
			lattice=self.model;
			ana_configure=lattice.ana_configure;
			output_dir=pydao.viewer.get_data_of_link(ana_configure.get('output_dir_link'));
			basis=pydao.viewer.get_data_of_link(ana_configure.get('basis_link'));
			output_dir=pydao.viewer.get_data_of_link(ana_configure.get('output_dir_link'));
			
			transfomation_matrix_link=ana_configure.get('transfomation_matrix_link');
			transfomation_matrix=pydao.viewer.get_data_of_link(transfomation_matrix_link);
			#ana_configure.get('transfomation_matrix');
			print "transfomation_matrix:",type(transfomation_matrix_link),\
			transfomation_matrix_link
			print transfomation_matrix
			newabasis=matrix(basis)*matrix(transfomation_matrix);
			newabasis=array(newabasis);
			output_dir.set('basis_transformed',newabasis);
			print "basis_transformed:"
			print newabasis
			
	def On_intra_pos_direct2Cartesian(self,info=None):
		import pydao,sys;
		from pydao.ohdf import OGroup,get_empty_instance;
		from pydao.ohdfvi import ogroup_analyzer_view;
		if info is not None:
			lattice=self.model;
			func_name=sys._getframe().f_code.co_name
			ana_configure=OGroup();
			ana_configure.set('atoms_link',str(lattice.get_link('atoms')));
			ana_configure.set('basis_link',str(lattice.get_link('basis')));
			ana_configure.set('output_dir_link',str(lattice.get_link()));
			lattice.ana_configure=ana_configure;
			lattice.ana_method=eval("self."+func_name);
			lattice.ana_name=func_name;
			#view=ogroup_analyzer_view(lattice);
			#lattice.configure_traits(view=view);
			lattice.app_view.updated=True;
		else:
			lattice=self.model;
			ana_configure=lattice.ana_configure;
			atoms=pydao.viewer.get_data_of_link(ana_configure.get('atoms_link'));
			basis=pydao.viewer.get_data_of_link(ana_configure.get('basis_link'));
			output_dir=pydao.viewer.get_data_of_link(ana_configure.get('output_dir_link'));
			
			newatoms=get_empty_instance(atoms);
			for k in atoms.keys():
				atom=atoms.get(k);
				newatom=atom.copy2mem();
				#newatom.translate_cart(cart_disp);
				if newatom.get('coordinate')=='direct':
					intrapos=newatom.get('intrapos');
					intrapos=lattice.direct2cartesian(intrapos,basis);
					newatom.set('intrapos',intrapos);
					newatom.set('coordinate','cartesian');
				newatoms.set(k,newatom);
			output_dir.set('atoms_cartesian',newatoms);
	
	def On_intra_pos_Cartesian2direct(self,info=None):
		import pydao,sys;
		from pydao.ohdf import OGroup,get_empty_instance;
		from pydao.ohdfvi import ogroup_analyzer_view;
		if info is not None:
			lattice=self.model;
			func_name=sys._getframe().f_code.co_name
			ana_configure=OGroup();
			ana_configure.set('atoms_link',str(lattice.get_link('atoms')));
			ana_configure.set('basis_link',str(lattice.get_link('basis')));
			ana_configure.set('output_dir_link',str(lattice.get_link()));
			lattice.ana_configure=ana_configure;
			lattice.ana_method=eval("self."+func_name);
			lattice.ana_name=func_name;
			#view=ogroup_analyzer_view(lattice);
			#lattice.configure_traits(view=view);
			lattice.app_view.updated=True;
		else:
			lattice=self.model;
			ana_configure=lattice.ana_configure;
			atoms=pydao.viewer.get_data_of_link(ana_configure.get('atoms_link'));
			basis=pydao.viewer.get_data_of_link(ana_configure.get('basis_link'));
			output_dir=pydao.viewer.get_data_of_link(ana_configure.get('output_dir_link'));
			
			newatoms=get_empty_instance(atoms);
			for k in atoms.keys():
				atom=atoms.get(k);
				newatom=atom.copy2mem();
				#newatom.translate_cart(cart_disp);
				if newatom.get('coordinate')=='cartesian':
					intrapos=newatom.get('intrapos');
					intrapos=lattice.cartesian2direct(intrapos,basis);
					newatom.set('intrapos',intrapos);
					newatom.set('coordinate','direct');
				newatoms.set(k,newatom);
			output_dir.set('atoms_direct',newatoms);
			
#===============================================================================================
#                                             analyze
#===============================================================================================
	def On_unify_coordinates(self,info=None):
		import pydao,sys;
		from pydao.ohdf import OGroup;
		from pydao.ohdfvi import ogroup_analyzer_view;
		if info is not None:
			lattice=self.model;
			func_name=sys._getframe().f_code.co_name
			ana_configure=OGroup();
			ana_configure.set('atoms_link',str(lattice.get_link('atoms')));
			ana_configure.set('basis_link',str(lattice.get_link('basis')));
			ana_configure.set('output_dir_link',str(lattice.get_link()));
			lattice.ana_configure=ana_configure;
			lattice.ana_method=eval("self."+func_name);
			lattice.ana_name=func_name;
			#view=ogroup_analyzer_view(lattice);
			#lattice.configure_traits(view=view);
			lattice.app_view.updated=True;
		else:
			lattice=self.model;
			ana_configure=lattice.ana_configure;
			atoms=pydao.viewer.get_data_of_link(ana_configure.get('atoms_link'));	
			basis=pydao.viewer.get_data_of_link(ana_configure.get('basis_link'));	
			lattice.unify_coordinates(atoms,basis);
			print " UnifyCoordinates done."
			
	def On_register_nearest(self,info=None):
		import pydao,sys;
		from pydao.ohdf import OGroup;
		from pydao.ohdfvi import ogroup_analyzer_view;
		if info is not None:
			lattice=self.model;
			func_name=sys._getframe().f_code.co_name
			ana_configure=OGroup();
			ana_configure.set('atoms_link',str(lattice.get_link('atoms')));
			ana_configure.set('basis_link',str(lattice.get_link('basis')));
			ana_configure.set('output_dir_link',str(lattice.get_link()));
			lattice.ana_configure=ana_configure;
			lattice.ana_method=eval("self."+func_name);
			lattice.ana_name=func_name;
			#view=ogroup_analyzer_view(lattice);
			#lattice.configure_traits(view=view);
			lattice.app_view.updated=True;
		else:
			lattice=self.model;
			ana_configure=lattice.ana_configure;
			atoms=pydao.viewer.get_data_of_link(ana_configure.get('atoms_link'));	
			basis=pydao.viewer.get_data_of_link(ana_configure.get('basis_link'));	
			lattice.register_nearest_kind(atoms,basis);
			print " register_nearest_kind done."
			
	def On_register_neighbor(self,info=None):
		import pydao,sys;
		from pydao.ohdf import OGroup;
		from pydao.ohdfvi import ogroup_analyzer_view;
		if info is not None:
			lattice=self.model;
			func_name=sys._getframe().f_code.co_name
			ana_configure=OGroup();
			ana_configure.set('atoms_link',str(lattice.get_link('atoms')));
			ana_configure.set('basis_link',str(lattice.get_link('basis')));
			ana_configure.set('output_dir_link',str(lattice.get_link()));
			lattice.ana_configure=ana_configure;
			lattice.ana_method=eval("self."+func_name);
			lattice.ana_name=func_name;
			#view=ogroup_analyzer_view(lattice);
			#lattice.configure_traits(view=view);
			lattice.app_view.updated=True;
		else:
			lattice=self.model;
			ana_configure=lattice.ana_configure;
			atoms=pydao.viewer.get_data_of_link(ana_configure.get('atoms_link'));	
			basis=pydao.viewer.get_data_of_link(ana_configure.get('basis_link'));	
			nei_distance=lattice.get('nei_distance');
			lattice.register_neighbors(atoms,basis,nei_distance);
			print " register_neighbor done."
			
	def On_cal_neighbor_matPhi(self,info=None):
		import pydao,sys;
		from pydao.ohdf import OGroup;
		from pydao.ohdfvi import ogroup_analyzer_view;
		if info is not None:
			lattice=self.model;
			func_name=sys._getframe().f_code.co_name
			ana_configure=OGroup();
			ana_configure.set('atoms_link',str(lattice.get_link('atoms')));
			ana_configure.set('basis_link',str(lattice.get_link('basis')));
			ana_configure.set('output_dir_link',str(lattice.get_link()));
			lattice.ana_configure=ana_configure;
			lattice.ana_method=eval("self."+func_name);
			lattice.ana_name=func_name;
			#view=ogroup_analyzer_view(lattice);
			#lattice.configure_traits(view=view);
			lattice.app_view.updated=True;
		else:
			lattice=self.model;
			ana_configure=lattice.ana_configure;
			atoms=pydao.viewer.get_data_of_link(ana_configure.get('atoms_link'));
			basis=pydao.viewer.get_data_of_link(ana_configure.get('basis_link'));
			for k in atoms.keys():
				print "atom:",k
				atom=atoms.get(k);
				matPhi_list=atom.neighbor_matPhi(lattice,atoms,basis);
			print 'OnCalNeighbor_matPhi done.'
			
	def On_cal_k_basis(self,info=None):
		import pydao,sys;
		from pydao.ohdf import OGroup;
		from pydao.ohdfvi import ogroup_analyzer_view;
		if info is not None:
			lattice=self.model;
			func_name=sys._getframe().f_code.co_name
			ana_configure=OGroup();
			ana_configure.set('basis_link',str(lattice.get_link('basis')));
			ana_configure.set('output_dir_link',str(lattice.get_link()));
			lattice.ana_configure=ana_configure;
			lattice.ana_method=eval("self."+func_name);
			lattice.ana_name=func_name;
			#view=ogroup_analyzer_view(lattice);
			#lattice.configure_traits(view=view);
			lattice.app_view.updated=True;
		else:
			lattice=self.model;
			ana_configure=lattice.ana_configure;
			basis=pydao.viewer.get_data_of_link(ana_configure.get('basis_link'));	
			lattice.cal_kbasis(basis);
			print " OnCalKBasis done."
#===============================================================================================
#                                             view
#===============================================================================================

	def On_plot_atoms(self,info=None):
		import pydao,sys,os;
		from pydao.ohdf import OGroup;
		from pydao.ohdfvi import ogroup_analyzer_view;
		if info is not None:
			lattice=self.model;
			func_name=sys._getframe().f_code.co_name
			ana_configure=OGroup();
			ana_configure.set('atoms_link',str(lattice.get('atoms').get_link()));
			ana_configure.set('text',[]);
			ana_configure.set('textwidth',0.1);
			lattice.ana_configure=ana_configure;
			lattice.ana_method=eval("self."+func_name);
			lattice.ana_name=func_name;
			#view=ogroup_analyzer_view(lattice);
			#lattice.configure_traits(view=view);
			if info!=0:
				lattice.app_view.updated=True;
		else:
			lattice=self.model;
			ana_configure=lattice.ana_configure;
			atom_list_link=ana_configure.get('atoms_link');
			text=ana_configure.get('text');
			textwidth=ana_configure.get('textwidth');
			print "atom_list_link:",atom_list_link
			atoms=pydao.viewer.get_data_of_link(atom_list_link);
			lattice.plot3d_atoms(atoms,text=text,textwidth=textwidth);
			
	def On_plot_atoms_button(self,info):
		self.On_plot_atoms(0);
		self.On_plot_atoms();
			
	def On_plot_basis(self,info=None):
		import pydao,sys,os;
		from pydao.ohdf import OGroup;
		from pydao.ohdfvi import ogroup_analyzer_view;
		if info is not None:
			lattice=self.model;
			func_name=sys._getframe().f_code.co_name
			ana_configure=OGroup();
			ana_configure.set('basis_link',str(lattice.get_link('basis')));
			ana_configure.set('color',(0,0,1));
			lattice.ana_configure=ana_configure;
			lattice.ana_method=eval("self."+func_name);
			lattice.ana_name=func_name;
			#view=ogroup_analyzer_view(lattice);
			#lattice.configure_traits(view=view);
			lattice.app_view.updated=True;
		else:
			lattice=self.model;
			ana_configure=lattice.ana_configure;
			basis_link=ana_configure.get('basis_link');
			basis=pydao.viewer.get_data_of_link(basis_link);
			color=tuple(ana_configure.get('color'));
			lattice.plot3d_basis(basis,color);
	
	def On_plot_kbasis(self,info=None):
		import pydao,sys,os;
		from pydao.ohdf import OGroup;
		from pydao.ohdfvi import ogroup_analyzer_view;
		if info is not None:
			lattice=self.model;
			func_name=sys._getframe().f_code.co_name
			ana_configure=OGroup();
			ana_configure.set('basis_link',str(lattice.get_link('basis')));
			ana_configure.set('color',(0,0,1));
			lattice.ana_configure=ana_configure;
			lattice.ana_method=eval("self."+func_name);
			lattice.ana_name=func_name;
			#view=ogroup_analyzer_view(lattice);
			#lattice.configure_traits(view=view);
			lattice.app_view.updated=True;
		else:
			lattice=self.model;
			ana_configure=lattice.ana_configure;
			basis_link=ana_configure.get('basis_link');
			basis=pydao.viewer.get_data_of_link(basis_link);
			color=tuple(ana_configure.get('color'));
			lattice.plot3d_kbasis(color=color);
			
	def On_plot_primitive_cell(self,info=None):
		import pydao,sys,os;
		from pydao.ohdf import OGroup;
		from pydao.ohdfvi import ogroup_analyzer_view;
		if info is not None:
			lattice=self.model;
			func_name=sys._getframe().f_code.co_name
			ana_configure=OGroup();
			ana_configure.set('basis_link',str(lattice.get_link('basis')));
			ana_configure.set('color',(0,0,1));
			lattice.ana_configure=ana_configure;
			lattice.ana_method=eval("self."+func_name);
			lattice.ana_name=func_name;
			#view=ogroup_analyzer_view(lattice);
			#lattice.configure_traits(view=view);
			if info!=0:
				lattice.app_view.updated=True;
		else:
			lattice=self.model;
			ana_configure=lattice.ana_configure;
			basis_link=ana_configure.get('basis_link');
			basis=pydao.viewer.get_data_of_link(basis_link);
			color=tuple(ana_configure.get('color'));
			lattice.plot3d_primitive_cell(basis,color);
			
	def On_plot_Brillouin_zone(self,info=None):
		import pydao,sys,os;
		from pydao.ohdf import OGroup;
		from pydao.ohdfvi import ogroup_analyzer_view;
		if info is not None:
			lattice=self.model;
			func_name=sys._getframe().f_code.co_name
			ana_configure=OGroup();
			ana_configure.set('kbasis_link',str(lattice.get_link('kbasis')));
			ana_configure.set('color',(0,0,1));
			lattice.ana_configure=ana_configure;
			lattice.ana_method=eval("self."+func_name);
			lattice.ana_name=func_name;
			#view=ogroup_analyzer_view(lattice);
			#lattice.configure_traits(view=view);
			if info!=0:
				lattice.app_view.updated=True;
		else:
			lattice=self.model;
			ana_configure=lattice.ana_configure;
			kbasis_link=ana_configure.get('kbasis_link');
			kbasis=pydao.viewer.get_data_of_link(kbasis_link);
			color=tuple(ana_configure.get('color'));
			lattice.plot3d_Brillouin_zone(kbasis,color);
			
	def On_plot_primitive_cell_button(self,info):
		self.On_plot_primitive_cell(0);
		self.On_plot_primitive_cell();
		
	def On_plot_nearest(self,info=None):
		import pydao,sys,os;
		from pydao.ohdf import OGroup;
		from pydao.ohdfvi import ogroup_analyzer_view;
		if info is not None:
			lattice=self.model;
			func_name=sys._getframe().f_code.co_name
			ana_configure=OGroup();
			ana_configure.set('atoms_link',str(lattice.get('atoms').get_link()));
			ana_configure.set('atom_name',lattice.get('atoms').keys()[0]);
			lattice.ana_configure=ana_configure;
			lattice.ana_method=eval("self."+func_name);
			lattice.ana_name=func_name;
			#view=ogroup_analyzer_view(lattice);
			#lattice.configure_traits(view=view);
			lattice.app_view.updated=True;
		else:
			lattice=self.model;
			ana_configure=lattice.ana_configure;
			atom_list_link=ana_configure.get('atoms_link');
			atom_name=ana_configure.get('atom_name')
			atoms=pydao.viewer.get_data_of_link(atom_list_link);
			lattice.plot3d_nearest(atom_name);
			
	def On_plot_neighbors(self,info=None):
		import pydao,sys,os;
		from pydao.ohdf import OGroup;
		from pydao.ohdfvi import ogroup_analyzer_view;
		if info is not None:
			lattice=self.model;
			func_name=sys._getframe().f_code.co_name
			ana_configure=OGroup();
			ana_configure.set('atoms_link',str(lattice.get('atoms').get_link()));
			ana_configure.set('atom_name',lattice.get('atoms').keys()[0]);
			lattice.ana_configure=ana_configure;
			lattice.ana_method=eval("self."+func_name);
			lattice.ana_name=func_name;
			#view=ogroup_analyzer_view(lattice);
			#lattice.configure_traits(view=view);
			lattice.app_view.updated=True;
		else:
			lattice=self.model;
			ana_configure=lattice.ana_configure;
			atom_list_link=ana_configure.get('atoms_link');
			atom_name=ana_configure.get('atom_name')
			atoms=pydao.viewer.get_data_of_link(atom_list_link);
			lattice.plot3d_neighbors(atom_name);
			
class Lattice_Program_Group_ModelView(OGroup_Analyzer_Group_ModelView):
	def init_info(self,info):
		OGroup_Analyzer_Group_ModelView.init_info(self,info);
		#self.preprocess(self.model);
		print "info:",info
		
	def On_group_set_atoms(self,info=None):
		import pydao,sys;
		from pydao.ohdf import OGroup;
		from pydao.ohdfvi import ogroup_analyzer_view;
		if info is not None:
			lattice=self.model;
			func_name=sys._getframe().f_code.co_name
			work_space=lattice.work_space;
			
			group=work_space.get('group');
			#inputs=work_space.get('inputs');
			#parameters=work_space.get('parameters');
			outputs=work_space.get('outputs');
			
			group.set('criteria',['mass']);
			
			inputs=OGroup();
			inputs.set('atoms',str(lattice.get('atoms').get_link()));
			work_space.set('inputs',inputs);
			
			parameters=OGroup();
			parameters.set('key','charge');
			parameters.set('value',2.5);
			work_space.set('parameters',parameters);
			
			outputs.set('dir_link',str(lattice.get_link()));
			#outputs.set('name',output);
			
			#lattice.work_space=work_space;
			lattice.ana_method=eval("self."+func_name);
			lattice.ana_name=func_name;
			#view=ogroup_analyzer_view(lattice);
			#lattice.configure_traits(view=view);
			lattice.app_group_view.updated=True;
		else:
			lattice=self.model;
			group=lattice.current_group;
			work_space=lattice.work_space;
			parameters=work_space.get('parameters');
			
			key=parameters.get('key');
			value=parameters.get('value');
			
			atoms=group.get('dbases').get('atoms');
			newatoms=atoms.copy2mem();
			for k in newatoms.keys():
				print "k:",k
				atom=newatoms.get(k);
				atom.set(key,value);
			
			outgroup=group.copy2mem();
			outgroup.get('dbases').set('atoms',newatoms);

			return outgroup;
			
class Lattice_Program_Group_List_ModelView(OGroup_Analyzer_Group_List_ModelView):
	def init_info(self,info):
		OGroup_Analyzer_Group_List_ModelView.init_info(self,info);
		#self.preprocess(self.model);
		print "info:",info
		
	def On_group_set_atoms(self,info=None):
		import pydao,sys;
		from pydao.ohdf import OGroup;
		from pydao.ohdfvi import ogroup_analyzer_view,OGroup_Analyzer_Group_List_ModelView;
		if info is not None:
			lattice=self.model;
			func_name=sys._getframe().f_code.co_name
			ana_method=eval("self."+func_name);
			ana_name=func_name;
			
			work_space_list=lattice.work_space_list;
			print work_space_list,type(work_space_list)
			found_work_space=False;
			for ws in work_space_list:
				if ws.name==ana_name:
					found_work_space=True;
			if found_work_space:
				print "found_work_space",ana_name
			else:
				work_space=OGroup_Analyzer_Group_List_ModelView().get_default_work_space(lattice);
			
				group=work_space.get('group');
				outputs=work_space.get('outputs');
				group.set('criteria',['mass']);
			
				inputs=OGroup();
				inputs.set('atoms',str(lattice.get('atoms').get_link()));
				work_space.set('inputs',inputs);
			
				parameters=OGroup();
				parameters.set('key','charge');
				parameters.set('value',2.5);
				work_space.set('analysis_parameters',parameters);
			
				outputs.set('dir_link',str(lattice.get_link()));
				work_space.name=ana_name;
				
				lattice.work_space_list.selected=work_space;
				lattice.work_space_list.append(work_space);
				lattice.ana_method_list.append(ana_method);
			#lattice.ana_method=eval("self."+func_name);
			#lattice.ana_name=func_name;
			#view=ogroup_analyzer_view(lattice);
			#lattice.configure_traits(view=view);
			#lattice.app_group_list_view.updated=True;
		else:
			lattice=self.model;
			group=lattice.current_group;
			work_space=lattice.work_space_list.selected;
			parameters=work_space.get('analysis_parameters');
			
			key=parameters.get('key');
			value=parameters.get('value');
			
			atoms=group.get('dbases').get('atoms');
			newatoms=atoms.copy2mem();
			for k in newatoms.keys():
				print "k:",k
				atom=newatoms.get(k);
				atom.set(key,value);
			
			outgroup=group.copy2mem();
			outgroup.get('dbases').set('atoms',newatoms);

			return outgroup;