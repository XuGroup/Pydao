from pylab import *;
from pydao.ohdf import OGroup;
from pydao.math import XyDiscreteFun;
from pydao.physics import Unit;

class Spectrum(XyDiscreteFun):
	def __init__(self):
		XyDiscreteFun.__init__(self);
		
	def convertx(self,tounit):
		xunit=self.get('xunit');
		#print "xunit:",xunit
		x=self.get('x');
		x1=x*xunit.ratio(tounit);
		self.set('x',x1);
		
	