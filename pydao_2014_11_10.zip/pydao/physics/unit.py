from ..ohdf import OGroup;

class Unit(OGroup):
	def __init__(self,shortname='dimless',longname='dimensionless',value=1):
		OGroup.__init__(self);
		self.set('shortname',shortname);
		self.set('longname',longname);
		self.set('reduced_value',1); # in terms of the standard units
		self.set('reduced',OGroup());
		
	def set_reduced(self,unit,power):
		sucess=False;
		if type(unit) is str: 
			reduced=self.get('reduced');
			reduced.set(unit,power);
			self.set('reduced',reduced);
			sucess=True;
		elif type(unit) is list and type(power) is dict:
			for i in range(len(unit)):
				u=unit[i];
				p=power[i];
				reduced.set(u,p);
			sucess=True;
		return;
		
	def get_reduced(self,unit):
		reduced=self.get('reduced');
		power=reduced.get(unit);
		return power;
		
	def keys_reduced(self):
		keys=(self.get('reduced')).keys();
		return keys;
		
	def is_same_dim(self,unit):
		same=True;
		for u in self.keys_reduced():
			p=self.get_reduced(u);
			if p!=unit.get_reduced(u):
				same=False;
				break;
		return same;
		
	def ratio(self,unit):
		if self.is_same_dim(unit):
			r=self.get('reduced_value')/unit.get('reduced_value');
		else:
			r=None
		return r;
	
	def getcurrenttolerance(self):
		unitname=self.get('currentunit');
		return self.get('tolerancedict').get('unitname');
		
	def uisetcurrentunit(self):
		import easygui;
		currentvalues=[self.getcurrentvar(),self.getcurrentunit()];
		answer=easygui.multenterbox("Enter the unit info","Setting units",['Variable name','Unit name'],currentvalues);
		if answer is not None:
			self.setcurrentunit(answer[1],answer[0]);
			
	def contextmenu(self,menu,dataname=None):
		menu=DataObject.contextmenu(self,menu);
		menu.add_separator();
		topwin=menu.gettoplevel();
		menu.add_command(label="Set unit",command=lambda:self.uisetcurrentunit());
		return menu;
		
	def getcurrenttolerance(self):
		tolerance=self.get('tolerance');
		if tolerance is None:
			tolerance=1e-10;
		return tolerance;

		
		
# The SI base units
METER=Unit('m','meter');
SECOND=Unit('s','second');
KILOGRAM=Unit('kg','kilogram');
AMPERE=Unit('A','ampere');
TESLA=Unit('T','tesla');
KELVIN=Unit('K','kelvin');

# useful units
#energy
EV=Unit('eV','electron volts',1.6e-19); EV.set_reduced(['kg','m','s'],[1,2,-2]);
WAVENUMBER=Unit('cm_1','cm_1',1240/1e7); EV.set_reduced(['kg','m','s'],[1,2,-2]);

