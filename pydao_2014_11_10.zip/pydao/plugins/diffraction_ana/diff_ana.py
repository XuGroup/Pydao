#import pydao.physics as physics;
#reload(physics);
from pydao.io import ANLAPSSPEC_DataFile;
from pylab import *;

filename=r'C:\Home\Xiaoshan\LabORNL\Projects\LuFeO3\vT-XRD\ANL\2013_03\lfo_alo_01.spc';
dfile=ANLAPSSPEC_DataFile(filename);
dfile.read_file_to_mem();
nscan=dfile.n_scans();
print nscan;

iT=0;
Ints=[];
Ts=[];
ts=[];
iscan=24;  #19 (004) 24 (102) 28 (104) 32 (106) 
for iscan in range(iscan,nscan,17):
	scan=dfile.get_scan(iscan);
	#scan.analyze();
	x=scan.get_col(0);
	y=scan.get_col('Detector');
	mon=scan.get_col('Ion_Ch_2');
	T=scan.get_T();
	timestamp=scan.get_timestamp();
	
	Ts.append(T);
	Ints.append(sum(y/mon));
	ts.append(timestamp);
	print "T:",T,'time:',timestamp
	#plot(x,y/mon);show()
	
subplot(1,2,1);
plot(Ts,Ints/Ints[0],'-<');
subplot(1,2,2);
plot(Ts,ts,'o-');
show();

#legend(['004','102','104','106'])