from pydao.ohdfvi import OGroup_Property_ModelView;
from pylab import *;

class LDC_ModelView(OGroup_Property_ModelView):
	def init_info(self,info):
		OGroup_Property_ModelView.init_info(self,info);
		self.preprocess(self.model);
		
	def preprocess(self,model):
		from enthought.traits.api import Button;
		model.bu_cal_1d_dispersion=Button();
		model.bu_cal_2d_dispersion=Button();
		model.bu_cal_polarization=Button();
		model.bu_cal_spectrum=Button();
		model.bu_plot_energy=Button();
		model.bu_plot_mode=Button();
		model.bu_plot_primitive_cell=Button();
		model.bu_plot_polarization=Button();
		model.bu_plot_spectrum=Button()
	
	def _bu_cal_1d_dispersion_fired(self,ldc):
		config=ldc.get('config');
		k_direction=config.get('k_direction');
		norm_krange=config.get('norm_krange');
		result=ldc.dispersion_1d(k_direction,norm_krange,marker='o-');
		ldc.set('result',result);
		
	def _bu_cal_2d_dispersion_fired(self,ldc):
		config=ldc.get('config');
		k_direction=config.get('k_direction');
		norm_krange=config.get('norm_krange');
		ldc.dispersion_2d(k_direction,norm_krange,marker='o-');
		
	def _bu_cal_polarization_fired(self,ldc):
		if ldc.new_figure:
			figure();
		i_polar=ldc.i_polar;
		result=ldc.get('result');
		V=result.get('Vmat');
		multiple=ldc.mode_polarizations(V,i_polar);
		
		multiplename='multiple'+str(i_polar);
		result.set(multiplename,multiple);
		ldc.set('result',result);
		ldc.plot_multiple(multiple,'o-');
		ylabel(str(i_polar)+'th multiple');
		print "multiple:",multiple;
		

	def _bu_plot_energy_fired(self,ldc):
		if ldc.new_figure:
			figure();
		Emat=ldc.get('result').get('Emat');
		k_index=ldc.k_index;
		if k_index==-1:
			shape=Emat.shape;
			for ik in range(shape[1]):
				plot(Emat[:,ik],'o-');
		else:
			plot(Emat[:,k_index],'o-');
		grid(True);
		
	def _bu_plot_mode_fired(self,ldc):
		from pydao.physics.solidstate.functions import compliment_color;
		k_index=ldc.k_index;
		mode_index=ldc.mode_index;
		
		V=ldc.get('result').get('Vmat')[:,:,k_index];
		shape=V.shape;
		V=reshape(V,tuple(shape[0:2]));
		
		atom_disp_factor=ldc.atom_displacement_factor;
		cm_disp_factor=ldc.center_of_mass_displacement_factor;
		color=tuple(ldc.color);
		
		mode=real(V[:,mode_index]);
		ldc.plot3d_modereal(atom_disp_factor*mode,color=color);
		ldc.plot3d_modecm(cm_disp_factor*mode,color=compliment_color(color));
		
	def _bu_plot_primitive_cell_fired(self,ldc):
		lattice=ldc.get('lattice');
		color=tuple(ldc.color);
		lattice.plot3d_primitive_cell(color=color);
		
	def _bu_plot_polarization_fired(self,ldc):
		if ldc.new_figure:
			figure();
		i_polar=ldc.i_polar;
		multiplename='multiple'+str(i_polar);
		
		result=ldc.get('result');
		multiple=result.get(multiplename);
		ldc.plot_multiple(multiple,'o-');
		ylabel(str(i_polar)+'th multiple');
		#print "multiple:",multiple;
		
	def _bu_plot_spectrum_fired(self,ldc):
		if ldc.new_figure:
			figure();
		for idim in range(3):
			spectrum=ldc.get_spectrum(idim);
			plot(spectrum[0],spectrum[1],'o-');
		ylabel('Polarization spectrum');
		legend(['x','y','z'],2)
		grid(True);