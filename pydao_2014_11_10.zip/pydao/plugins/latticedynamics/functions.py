from pylab import *;

from pydao.math import *;
	
def frac2color(frac):
	if frac>1:
		frac=1;
	red=frac;
	blue=(1-frac**2)**0.5;
	return (red,0,blue);
	
def frac2color2(frac):
	N=256**3;
	x=N*frac;
	xr=int(x/256**2);
	x=x-xr*256**2;
	xg=int(x/256);
	x=x-xg*256;
	xb=x;
	xr=xr/256.;
	xg=xg/256.;
	xb=xb/256.;
	# to make O red:
	#xr_O=xb;
	#xb_O=xr;
	colortuple=(xr,xg,xb);
	return colortuple;

def folding(A,vfold):
	a0=array(A);
	for i in range(len(a0)):
		a=a0[i]+vfold/2;
		n=int(a/vfold)
		#print "n:",n
		a=a-n*vfold-vfold/2;
		if a<0:
			a=-a;
		a0[i]=a;
	return a0;
	
def find_vectorlen_inCell1(basis,v_direction):
	length=None;
	v=array(v_direction);
	for i in range(len(basis)):
		v_cos=vcos(array(basis[i]),v);
		#print "v_cos:",v_cos
		if abs(v_cos-1)<1e-9:
			length=vlen(array(basis[i]))/vlen(v_direction);
			#print "found like a basis!"
			break;
	if length is None:
		mat=zeros([3,3]);
		mat[:,0]=v;
		for i in range(len(basis)):
			if vcos(array(basis[i]),v)==0:
				length=1;
				break;
			ij=1;
			for j in range(len(basis)):
				if i!=j:
					#print "ij,j",ij,j
					mat[:,ij]=-array(basis[j]);
					ij=ij+1;
			#print "mat:\n",mat
			invmat=inv(mat);
			#print "invmat:\n",invmat
			#b=array(basis[i]).reshape(-1,1);
			b=array(basis[i]);
			#print "trans:\n",b
			#acc=invmat*b;
			#acc=vdot(invmat,b)
			acc=inner(invmat,b);
			#print "acc:",acc
			if acc[1]<=1 and acc[2]<=1:
				length=acc[0];
				#print "found general!"
				#print "mat:\n",mat
				#print "invmat:\n",invmat
				#print inner(mat,transpose(invmat));
				#print "b:\n",b
				#print "acc:\n",acc
				break;
	#print "found length:",length
	return length;

def find_vectorlen_inCell(basis,v_direction):
	#transform,a1new,a2new = rotate2xy(basis[0],basis[1]);
	b=basis[2];
	#b3new=transform*transpose(matrix(b));
	b3distance=facedistance(b,array([basis[0],basis[1]]),vlen(b));
	vdistance1=faceintercept(v_direction,array([basis[0],basis[1]]),b3distance);
	
	#transform,a1new,a2new = rotate2xy(basis[1],basis[2]);
	b=basis[0];
	#b3new=transform*transpose(matrix(b));
	b3distance=facedistance(b,array([basis[1],basis[2]]),vlen(b));
	vdistance2=faceintercept(v_direction,array([basis[1],basis[2]]),b3distance);
	
	#transform,a1new,a2new = rotate2xy(basis[2],basis[0]);
	b=basis[1];
	#b3new=transform*transpose(matrix(b));
	b3distance=facedistance(b,array([basis[2],basis[0]]),vlen(b));
	vdistance3=faceintercept(v_direction,array([basis[2],basis[0]]),b3distance);
	
	vdistance=array([vdistance1,vdistance2,vdistance3]).min();
	print "vdistance",vdistance
	return vdistance;
	
def find_lattice_index(basis,v):
	indices=dot(v,inv(basis));
	return indices;
	
def plot3d_vector(position,vector,color=(1,0,0),mode='2darrow'):
	from enthought.mayavi import mlab;
	x0,y0,z0=position;
	u,v,w=vector;
	mlab.quiver3d([x0],[y0],[z0],[u],[v],[w],color=color,scale_mode="none",scale_factor=vlen(vector),mode=mode);
	
def compliment_color(color):
	color1=zeros(3);
	for i in range(3):
		color1[i]=1-color[i];
	#print "color1:",color1
	return tuple(color1);
#-------------------------------------------------------
#=======================================
def eigsort(Engys,Vctrs):
	Es=sort(Engys);
	Vs=copy(Vctrs);
	Ilist=indexmap(Engys,Es);
	i=0;
	for I in Ilist:
		Vs[:,i]=Vctrs[:,I];
		i=i+1;
	return (Es,Vs);
	
def indexmap(E0,Esorted):
	Ilist=list();
	Es=Esorted;
	Engys=E0;
	for E in Es:
		i=0;
		for E1 in Engys:
			if abs(E-E1)<1e-10:
				if Ilist.count(i)==0:
					Ilist.append(i);
					break;
			i=i+1;
	#print "Ilist:",Ilist
	return Ilist;