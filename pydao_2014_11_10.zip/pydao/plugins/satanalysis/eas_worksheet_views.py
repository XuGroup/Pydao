from pylab import *;
from pydao.ohdf import OGroup;
from functions import *;
#from tables import *;

def eas_worksheet_view_modify(eas_ws):
	from enthought.traits.ui.api import \
	Item,Group,Tabbed,VGroup,HGroup,View,\
	ArrayEditor,ButtonEditor,CheckListEditor,BooleanEditor,FileEditor,TextEditor;
	from eas_worksheet_controls import EAS_WorkSheet_ModelView;
	import pydao;
	from pydao.math.worksheet_views import worksheet_view_modify;
	
	title=str(eas_ws.get_link());
	handler=EAS_WorkSheet_ModelView(eas_ws);
	view=worksheet_view_modify(eas_ws);
	view.handler=handler;
	view.title=title;
	
	menubar=view.menubar;
	menubar=eas_worksheet_menubar(menubar);
	toolbar=eas_worksheet_toolbar(view.toolbar);
	
	view.menubar=menubar;
	view.toolbar=toolbar;
	return view;

def eas_worksheet_menubar(menubar):
	from enthought.traits.ui.menu import Menu, MenuBar, Action;
	
	filter= Action(name = "Filter",action = "On_filter")
	operation_menu=Menu(filter,name = 'Operation');
	
	menubar.append(operation_menu);
	return menubar;

def eas_worksheet_toolbar(toolbar=None):
	from enthought.traits.ui.menu import Menu, ToolBar, Action;
	from enthought.pyface.api import ImageResource;
	disp = Action(name = "Filter",action = "On_filter")
	#if toolbar is None:
	#	toolbar=ToolBar(disp);
	#else:
	#	toolbar.append(disp);
	return toolbar;