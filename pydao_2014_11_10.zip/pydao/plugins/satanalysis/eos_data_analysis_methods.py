from pylab import *;
from functions import *;
lazy=False;

def OnOpen(self,event):
	from eos_data_analysis_views import eos_data_analysis_view_modify;
	view=eos_data_analysis_view_modify(self);
	#from pydao.math.worksheet_views import worksheet_view_modify;
	#view=worksheet_view_modify(self);
	self.configure_traits(view=view);
	
def OnNew_EASWorkSheet(self,event):
	from eas_worksheet import EAS_WorkSheet;
	ews=EAS_WorkSheet();
	print type(ews),ews,ews.keys()
	if self.keys().count('new_ews')==0:
		self.set('new_ews',ews);
	print type(self.get('new_ews'))