from pyhdf.SD import *
from pyhdf.HDF import *
from pyhdf.V   import *
from pyhdf.VS  import *
from numpy import *;
import time;

from h5py import *;
from pylab import *;
import time as Time;
import os;
import mx.DateTime;
from scipy import interpolate;
from scipy.optimize import fmin;
from copy import *;


def lst2gmt(lst,lon):
	gmt=(0-lon)*24./360+lst
	h=int(gmt)
	if h<0:
		hh=h+24
		ddoffset = -1
	elif h>= 24:
		hh=h-24
		ddoffset  = 1
	else:
		hh=h
		ddoffset  = 0
	h_real=gmt-ddoffset*24;
	h_int=int(h_real);
	mm=int((h_real-h_int)*60)
	ss=int(((h_real-h_int)*60-mm)*60);
	#print gmt,ddoffset,h_int,mm
	return (h_int,mm,ss,ddoffset);

def gmt2lst(gmt,lon):
	lst=-(0-lon)*24./360+gmt
	h=int(lst)
	if h<0:
		hh=h+24
		ddoffset = -1
	elif h>= 24:
		hh=h-24
		ddoffset  = 1
	else:
		hh=h
		ddoffset  = 0
	h_real=lst-ddoffset*24;
	h_int=int(h_real);
	mm=int((h_real-h_int)*60)
	ss=int(((h_real-h_int)*60-mm)*60);
	#print lst,ddoffset,h_int,mm
	return (h_int,mm,ss,ddoffset);
	
	
def interp(data,lat,lon):
	#latdiff=(max(lat)-min(lat))/len(lat);
	#londiff=(max(lon)-min(lon))/len(lon);
	latdiff=mean(abs(diff(lat)))/2;
	londiff=mean(abs(diff(lon)))/2;
	latrange=arange(min(lat),max(lat)+latdiff,latdiff);
	lonrange=arange(min(lon),max(lon)+londiff,londiff);
	print len(latrange),len(lonrange),data.shape[1]
	#data3D=None;
	data3D=zeros([len(latrange),len(lonrange),data.shape[1]]);
	
	for i in range(len(lat)):
		lati = lat[i];
		loni = lon[i];
		Ilat=logical_and(lati<=latrange,lati+latdiff>latrange);
		Ilat=array(range(len(latrange)))[Ilat][0];
		Ilon=logical_and(loni<=lonrange,loni+londiff>lonrange);
		Ilon=array(range(len(lonrange)))[Ilon][0];
		#print "Ilat,Ilon",Ilat,Ilon,data3D.shape,type(Ilat)
		for j in range(len(data[i])):
			#A=data[i][j];
			#print "Ilat,Ilon",Ilat,Ilon,data3D.shape
			#print data3D[1][140]
			data3D[Ilat,Ilon,j]=data[i,j];
	return (data3D,latrange,lonrange);
	
def myhist(xdata_array0,ydata_array0,Nbins):
	xmean=xdata_array0.mean();
	I=fabs(xdata_array0-xmean)<xmean*3;
	xdata_array=xdata_array0[I];
	ydata_array=ydata_array0[I];
	
	result=hist(xdata_array,Nbins);
	Ncount=result[0];
	bincenterlist=result[1];
	binwidth=diff(bincenterlist).mean();
	
	ymeanlist=bincenterlist-bincenterlist;
	errorbarlist=bincenterlist-bincenterlist;
	i=0
	for bincenter in bincenterlist:
		I1=xdata_array>bincenter-binwidth/2;
		I2=xdata_array<=bincenter+binwidth/2;
		I=logical_and(I1,I2);
		#print "len(I):",len(I)
		I=array(range(len(xdata_array)))[I];
		#print "len(I):",len(I),max(I);
		if len(I)>1:
			ymeanlist[i]=array(ydata_array)[I].mean();
			errorbarlist[i]=array(ydata_array)[I].std()/sqrt(len(I));
		i=i+1;
	return (bincenterlist,ymeanlist,errorbarlist)

def height2pressure(height):
	height0=[0,1,2,3,4,5,6,7,8,9,10,12,14,16,18,20,24,28,32]; #unit km
	pressure0=[101.325,89.874,79.495,70.108,61.640,54.019,47.181,41.060,35.599,30.742,26.436,19.330,14.101,10.287,7.505,5.475,2.930,1.586,0.868]; #kPa
	height0=1000*array(height0);
	pressure0=array(pressure0)*10;
	f = interpolate.interp1d(height0, pressure0);
	pressure=f(height);
	return pressure;

def find_cloudsatMLS_timelag(time_data0,lons0,lats0,time_data1,lons1,lats1):
	td0=zeros(len(time_data0));
	lons_0=deepcopy(lons0);
	lats_0=deepcopy(lats0);
	td1=zeros(len(time_data1));
	lons_1=deepcopy(lons1);
	lats_1=deepcopy(lats1);
	for i in range(len(time_data0)):
		td0[i]=time_data0[i].abstime;
	for i in range(len(time_data1)):
		td1[i]=time_data1[i].abstime;
	I=list(td0).index(td0.min());
	#print td0.min()
	print list(td0).index(td0.min()),list(td0).index(td0.max()),
	while I >0:
		print "I:",I
		ltd0=list(td0);ltd0.pop(I);td0=array(ltd0);
		llons_0=list(lons_0);llons_0.pop(I);lons_0=array(llons_0);
		llats_0=list(lats_0);llats_0.pop(I);lats_0=array(llats_0);
		#print td0.min()
		#print "I:",I
		#lons_0=array(list(lons_0).pop(I));
		#lats_0=array(list(lats_0).pop(I));
		I=list(td0).index(td0.min());
		
	#print list(td0).index(td0.min()),list(td0).index(td0.max()),
	#if list(td0).index(td0.min())>0:
	#	plot(td0,'+');hold(True);plot(td1,'o')
	flon=interpolate.interp1d(td0,lons_0);
	flat=interpolate.interp1d(td0,lats_0);
	tlag=fmin(chi2_cloudsatMLS_timelag,[0],args=(flon,flat,td1,lons1,lats1));
	return tlag;
	
	
def chi2_cloudsatMLS_timelag(para,flon,flat,td1,lons1,lats1):
	tlag=para[0];
	if min(td1+tlag)>flon.x.min() and max(td1+tlag)<flon.x.max():
		lonsfit=flon(td1+tlag);
		latsfit=flat(td1+tlag);
		chi2=((lonsfit-lons1)**2).sum();
		chi2=chi2+((latsfit-lats1)**2).sum();
	else:
		chi2=1e10;
	return chi2;
	
def oneddataset_to_recordlist(dataset):
	recordlist=[];
	keys=dataset.keys();
	Nlist=len(dataset[keys[0]]);
	for i in range(Nlist):
		r={}
		for k in keys:
			r[k]=dataset[k][i];
		recordlist.append(r);
	return recordlist;

#=====================================================