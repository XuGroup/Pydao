from pylab import *;

def monthly_mean():
	import pydao;
	import mx.DateTime;
	og=pydao.cog();
	ws=og.get('gsfc'); #worksheet name
	varl_name_ist=['a440_675','a440_870','a675_870','a675_1020'];
	varl_name_ist=varl_name_ist+['AOT_1020', 'AOT_870', 'AOT_675', 'AOT_440', 'SSA441_T', 'SSA673_T', 'SSA873_T', 'SSA1022_T', 'AOTAbsp441_T', 'AOTAbsp673_T', 'AOTAbsp873_T', 'AOTAbsp1022_T', 'RadiativeForcing_BOA_', 'RadiativeForcing_TOA_']

	date_var_name='Date_dd_mm_yyyy_';
	time_var_name='Time_hh_mm_ss_';
	
	date_array=ws.get_col(date_var_name).get('data');
	time_array=ws.get_col(time_var_name).get('data');
	
	N=12
	for var_name in varl_name_ist:
		cmd=var_name+"=ws.get_col('"+var_name+"').get('data');"
		exec(cmd);
		cmd=var_name+"_month_num=zeros(N)";
		exec(cmd);
		cmd=var_name+"_month_mean=zeros(N)";
		exec(cmd);
		cmd=var_name+"_month_std=zeros(N)";
		exec(cmd);
		
	for month in range(12):
		print "month:",month+1
		for var_name in varl_name_ist:
			cmd=var_name+"_month_list=[]";
			exec(cmd);
		for irow in range(len(date_array)):
			date_list=date_array[irow].split(':')
			time_list=time_array[irow].split(':')
			rowdate=mx.DateTime.Date(int(date_list[2]),int(date_list[1]),int(date_list[0]));
			rowtime=mx.DateTime.Time(int(date_list[0]),int(date_list[1]),int(date_list[2]));
			rowdatetime=rowdate+rowtime;
			if rowdatetime.month==month+1:
				for var_name in varl_name_ist:
					value=eval(var_name+"["+str(irow)+"]");
					if not isnan(value):
						cmd=var_name+"_month_list.append(value)";
						exec(cmd);
		for var_name in varl_name_ist:
			mlist=eval(var_name+"_month_list");
			
			cmd=var_name+"_month_num["+str(month)+"]=len(mlist)";
			exec(cmd);
			cmd=var_name+"_month_mean["+str(month)+"]=mean(mlist)";
			exec(cmd);
			cmd=var_name+"_month_std["+str(month)+"]=std(mlist)";
			exec(cmd);
				
	from pydao.math import WorkSheet,WorkSheet_Column;
	ws1=WorkSheet();
	wsk=WorkSheet_Column(array(range(12))+1);
	ws1.set_col('month',wsk);
	for var_name in varl_name_ist:
		dataname=var_name+"_month_num"
		data=eval(dataname);
		wsk=WorkSheet_Column(data);
		ws1.set_col(dataname,wsk);
		
		dataname=var_name+"_month_mean"
		data=eval(dataname);
		wsk=WorkSheet_Column(data);
		ws1.set_col(dataname,wsk);
			
		dataname=var_name+"_month_std"
		data=eval(dataname);
		wsk=WorkSheet_Column(data);
		ws1.set_col(dataname,wsk);
	og.set('ws_month',ws1);

def daily_mean():
	import pydao;
	import mx.DateTime;
	og=pydao.cog();
	ws=og.get('newWorkSheet');
	varl_name_ist=['AOT_440','AOT_500','_440_675Angstrom'];
	date_var_name='Date_dd_mm_yy_';
	time_var_name='Time_hh_mm_ss_';
	
	date_array=ws.get_col(date_var_name).get('data');
	time_array=ws.get_col(time_var_name).get('data');
	
	N=365
	for var_name in varl_name_ist:
		cmd=var_name+"=ws.get_col('"+var_name+"').get('data');"
		exec(cmd);
		cmd=var_name+"_day_num=zeros(N)";
		exec(cmd);
		cmd=var_name+"_day_mean=zeros(N)";
		exec(cmd);
		cmd=var_name+"_day_std=zeros(N)";
		exec(cmd);
		
	for day in range(N):
		print "day:",day+1
		for var_name in varl_name_ist:
			cmd=var_name+"_day_list=[]";
			exec(cmd);
		for irow in range(len(date_array)):
			date_list=date_array[irow].split(':')
			time_list=time_array[irow].split(':')
			rowdate=mx.DateTime.Date(int(date_list[2]),int(date_list[1]),int(date_list[0]));
			rowtime=mx.DateTime.Time(int(date_list[0]),int(date_list[1]),int(date_list[2]));
			rowdatetime=rowdate+rowtime;
			if rowdatetime.day==day+1:
				for var_name in varl_name_ist:
					value=eval(var_name+"["+str(irow)+"]");
					if not isnan(value):
						cmd=var_name+"_day_list.append(value)";
						exec(cmd);
		for var_name in varl_name_ist:
			mlist=eval(var_name+"_day_list");
			
			cmd=var_name+"_day_num["+str(day)+"]=len(mlist)";
			exec(cmd);
			cmd=var_name+"_day_mean["+str(day)+"]=mean(mlist)";
			exec(cmd);
			cmd=var_name+"_day_std["+str(day)+"]=std(mlist)";
			exec(cmd);
				
	from pydao.math import WorkSheet,WorkSheet_Column;
	ws1=WorkSheet();
	wsk=WorkSheet_Column(array(range(12))+1);
	ws1.set_col('day',wsk);
	for var_name in varl_name_ist:
		dataname=var_name+"_day_num"
		data=eval(dataname);
		wsk=WorkSheet_Column(data);
		ws1.set_col(dataname,wsk);
		
		dataname=var_name+"_day_mean"
		data=eval(dataname);
		wsk=WorkSheet_Column(data);
		ws1.set_col(dataname,wsk);
			
		dataname=var_name+"_day_std"
		data=eval(dataname);
		wsk=WorkSheet_Column(data);
		ws1.set_col(dataname,wsk);
	og.set('ws_day',ws1);

def hourly_mean(month):
	import pydao;
	import mx.DateTime;
	og=pydao.cog();
	ws0=og.get('ws_month'); #worksheet name
	
	ws=og.get('gsfc');
	varl_name_ist=['a440_675','a440_870','a675_870','a675_1020'];
	varl_name_ist=varl_name_ist+['AOT_1020', 'AOT_870', 'AOT_675', 'AOT_440', 'SSA441_T', 'SSA673_T', 'SSA873_T', 'SSA1022_T', 'AOTAbsp441_T', 'AOTAbsp673_T', 'AOTAbsp873_T', 'AOTAbsp1022_T', 'RadiativeForcing_BOA_', 'RadiativeForcing_TOA_']
	
	date_var_name='Date_dd_mm_yyyy_';
	time_var_name='Time_hh_mm_ss_';
	
	date_array=ws.get_col(date_var_name).get('data');
	time_array=ws.get_col(time_var_name).get('data');
	
	N=24
	for var_name in varl_name_ist:
		cmd=var_name+"=ws.get_col('"+var_name+"').get('data');"
		exec(cmd);
		cmd=var_name+"_hour_num=zeros(N)";
		exec(cmd);
		cmd=var_name+"_hour_mean=zeros(N)";
		exec(cmd);
		cmd=var_name+"_hour_std=zeros(N)";
		exec(cmd);
		cmd=var_name+"_hour_diff=zeros(N)";
		exec(cmd);
		
	for hour in range(N):
		print "hour:",hour
		for var_name in varl_name_ist:
			cmd=var_name+"_hour_list=[]";
			exec(cmd);
		for irow in range(len(date_array)):
			date_list=date_array[irow].split(':')
			time_list=time_array[irow].split(':')
			rowdate=mx.DateTime.Date(int(date_list[2]),int(date_list[1]),int(date_list[0]));
			rowtime=mx.DateTime.Time(int(time_list[0]),int(time_list[1]),int(time_list[2]));
			rowdatetime=rowdate+rowtime;
			if rowdatetime.hour==hour and rowdatetime.month==month:
				for var_name in varl_name_ist:
					value=eval(var_name+"["+str(irow)+"]");
					if not isnan(value):
						cmd=var_name+"_hour_list.append(value)";
						exec(cmd);
		for var_name in varl_name_ist:
			mlist=eval(var_name+"_hour_list");
			
			cmd=var_name+"_hour_num["+str(hour)+"]=len(mlist)";
			exec(cmd);
			cmd=var_name+"_hour_mean["+str(hour)+"]=mean(mlist)";
			exec(cmd);
			cmd=var_name+"_hour_std["+str(hour)+"]=std(mlist)";
			exec(cmd);
				
	from pydao.math import WorkSheet,WorkSheet_Column;
	ws1=WorkSheet();
	wsk=WorkSheet_Column(array(range(N)));
	ws1.set_col('hour',wsk);
	for var_name in varl_name_ist:
		dataname=var_name+"_hour_num"
		data=eval(dataname);
		wsk=WorkSheet_Column(data);
		ws1.set_col(dataname,wsk);
			
		dataname=var_name+"_hour_std"
		data=eval(dataname);
		wsk=WorkSheet_Column(data);
		ws1.set_col(dataname,wsk);
		
		dataname=var_name+"_hour_mean"
		data=eval(dataname);
		wsk=WorkSheet_Column(data);
		ws1.set_col(dataname,wsk);
		
		dataname=var_name+"_hour_diff"
		monthlymean_name=var_name+"_month_mean"
		monthlymean_data=ws0.get_col(monthlymean_name).get('data')[month-1];
		datadiff=(data-monthlymean_data)/monthlymean_data;
		wsk=WorkSheet_Column(datadiff);
		ws1.set_col(dataname,wsk);
		
	og.set('ws_'+str(month)+'_hour',ws1);

def hourly_mean_batch():
	for month in range(12):
		print "month:",month+1
		hourly_mean(month+1);