from pylab import *;
from scipy.optimize import fmin;
	
def chi2_Ih(paras,Iv,Ih):
	gain=paras[0];
	shift=paras[1];
	mfit=Ih*gain+shift;
	chi2=sum((mfit-Iv)**2/(abs(Iv)+abs(mfit)));
	return chi2;
	
def normalize(Iv,Ih):
	paras0=[1,0];
	paras=fmin(chi2_Ih,paras0,args=(Iv,Ih));
	gain=paras[0];
	shift=paras[1];
	Ih1=gain*Ih+shift;
	Id=Ih1-Iv;
	return Ih1;

def chi2_sinfit(paras,eV,Id):
	#print paras;
	eV0=paras[0];
	amp=paras[1];
	period=paras[2];
	sinfit=sin((eV-eV0)/period*2*pi)*amp;
	chi2=sum((sinfit-Id)**2/(abs(Id)+abs(sinfit)));
	chi2=sum((sinfit-Id)**2);
	if period>10.:
		chi2=chi2*1e10;
	return chi2;
	
def sinfit(eV,Id):
	paras0=[mean(eV),-max(Id)+min(Id),max(eV)-min(eV)];
	print paras0
	paras=fmin(chi2_sinfit,paras0,args=(eV,Id));
	eV0=paras[0];
	amp=paras[1];
	period=paras[2];
	sfit=sin((eV-eV0)/period*2*pi)*amp;
	return paras,sfit;


def shift_Is(shift,eV,I1,I2):
	new_min=max(min(eV),min(eV)+shift);
	new_max=min(max(eV),max(eV)+shift);
	deV=mean(diff(eV));
	new_eV_range=arange(new_min,new_max+deV,deV);
	new_I1=interp(new_eV_range,eV,I1);
	new_I2=interp(new_eV_range,eV+shift,I2);
	return new_eV_range,new_I1,new_I2;
	
def chi2_shift(paras,eV,I1,I2):
	shift=paras;
	new_eV_range,new_I1,new_I2=shift_Is(shift,eV,I1,I2);
	chi2=mean((new_I2-new_I1)**2/(abs(new_I1)+abs(new_I2)));
	return chi2;
	
def shift_fit(eV,I1,I2):
	paras0=0;
	paras=fmin(chi2_shift,paras0,args=(eV,I1,I2));
	shift=paras;
	return shift;

def spect_stat(spects):
	i=0;
	N=len(spects);
	for sp in spects:
		if i==0:
			sp_sum=sp;
		else:
			sp_sum=sp+sp_sum;
		i=i+1;
	sp_ave=sp_sum/N;
	i=0;
	for sp in spects:
		if i==0:
			sp_dev=(sp-sp_ave)**2;
		else:
			sp_dev=sp_dev+(sp-sp_ave)**2;
	if N>1:
		sp_dev=(sp_dev/(N-1))**0.5;
	else:
		sp_dev=(sp_dev/(N))**0.5;
	return sp_ave,sp_dev;
		
def find_diff(directory,filename0,ifile0,ifnamerange,idchannel,polar0):
	polarization=polar0; # here to specify the first polarization

	i=0;	
	ty_hs=[];
	ty_vs=[];
	for ifname in ifnamerange:
		fname=directory+filename0+str(ifname);
		eV=load_data(fname,1)
		if i<2:
			if polarization=="h":
				ty_h=load_data(fname,idchannel);
				polarization="v";
				ty_hs.append(ty_h);
			else:
				ty_v=load_data(fname,idchannel);
				polarization="h";
				ty_vs.append(ty_v);
		else:
			if polarization=="h":
				temp=load_data(fname,idchannel);
				polarization="v";
				ty_hs.append(temp);
			else:
				temp=load_data(fname,idchannel);
				polarization="h";
				ty_vs.append(temp);
		i=i+1;

	ty_aveh,ty_devh=spect_stat(ty_hs);
	ty_avev,ty_devv=spect_stat(ty_vs);
	#err=(mean(ty_devh)**2+mean(ty_devv)**2)**0.5;
	
	aveh=mean(ty_aveh);
	avev=mean(ty_avev);
	
	ty_aveh=ty_aveh-aveh;
	sumh=sum(abs(ty_aveh));
	ty_avev=ty_avev-avev;
	sumv=sum(abs(ty_avev));
	
	ty_hsnorm=[];
	ty_vsnorm=[];
	for ty in ty_hs:
		ty=(ty-aveh)/sumh;
		ty_hsnorm.append(ty);
		
	for ty in ty_vs:
		ty=(ty-avev)/sumv;
		ty_vsnorm.append(ty);
	
	ty_aveh,ty_devh=spect_stat(ty_hsnorm);
	ty_avev,ty_devv=spect_stat(ty_vsnorm);
	err=(mean(ty_devh)**2+mean(ty_devv)**2)**0.5;
	
	ty_v=ty_avev;
	ty_h=ty_aveh;
	
	Nfactor=100000;	
	ty_h1=normalize(ty_v*Nfactor,ty_h*Nfactor)/Nfactor;
	ty_d=ty_v-ty_h1;
	
	paras,sfit=sinfit(eV,ty_d*Nfactor);
	sfit=sfit/Nfactor;
	eV0=paras[0];
	amp=paras[1]/Nfactor;
	period=paras[2];
	
	
	print sum(abs(ty_d)),
	print sum(ty_d[0:40])-sum(ty_d[41:]),
	print sum(abs(sfit))
	print "eV0:",eV0,"amp:",amp,"period:",period
	print "err:",err
	
	#shift=shift_fit(eV,ty_v*Nfactor,ty_h1*Nfactor)
	#print "shift:",shift
	#new_eV_range,new_I1,new_I2=shift_Is(shift,eV,ty_v,ty_h1);
	#plot(new_eV_range,new_I1);hold(True);
	#plot(new_eV_range,new_I2,'r');

	#subplot(236);
	#plot(new_eV_range,new_I1-new_I2);
	#show();
	amp1=sum(abs(ty_d));
	amp1=amp;
	return eV,ty_hs,ty_vs,ty_hsnorm,ty_vsnorm,ty_v,ty_h1,ty_d,sfit,amp1,err