from pylab import *;
from image_tools import *;

from enthought.traits.api import HasTraits;
import time;

class Progress_Teller(HasTraits):
	def __init__(self,Ntotal,separation=0.01,text=''):
		self.Ntotal=Ntotal;
		self.text=text;
		self.sep=separation;
		self.n_last_told=0;
		self.msg='';
		self.t0=time.time();
		self.t_last_told=time.time();
		self.t_total=0;
		self.L_msg=75;
		self.t_total_min=3;
		
	def tell(self,n):
		told=False;
		if n>0:
			n_from_last=n-self.n_last_told;
			ratio_from_last=float(n_from_last)/self.Ntotal;
			ratio=float(n)/self.Ntotal;
			pro=ratio*100;
			#print "n",n,"pro:",pro
			t1=time.time();
			t_elapsed=int(t1-self.t0);
			t_total=int((t1-self.t0)/pro*100);
			t_left=t_total-t_elapsed;
		
			if ratio_from_last>self.sep or (t_elapsed>5 and self.n_last_told==0):
				if t_total>0:
					self.sep=1./t_total;
			
				self.t_total=t_total;
			
				if self.t_total>self.t_total_min and self.gotcontrol():
					self.print_message(t_elapsed,t_left,t_total);
					self.n_last_told=n;
					n_next_predict=n+n_from_last;
					if n_next_predict>=self.Ntotal:
						print
					told=True;
		return told;
		
	def backspace(self,n):
		print (n+1)*"\b\b",
			
	def print_message(self,t_elapsed,t_left,t_total):
		self.t_last_told=time.time();
		self.backspace(len(self.msg));
			
		msg=self.text;
		msg=msg+str(t_elapsed)+"s"
		
		pro=float(t_elapsed)/t_total*100;
		pro_str='%5.2f' % pro;
		pro_str=pro_str.strip();
			
		#msg1=ceil(pro/5)*'-'+pro_str+"%";
		msg1='('+pro_str+"%";
		#msg1=msg1+ceil(pro/5)*'-'+'>';
		msg1=msg1+')'+'';
			
		#msg2=(45-len(msg1))*" ";
		msg2='';
				
		msg=msg+msg1+msg2;
			
		msg=msg+"/"+str(t_left)+"s"
		msg=msg+"/"+str(t_total)+"s "
				
		msg=msg+":"+self.text;
		if len(msg)>self.L_msg:
			msg=msg[0:self.L_msg];
		print msg,
		self.msg=msg;
		return;
		
	def checkstop(self):
		import pydao,sys;
		if pydao.stop:
			pydao.stop=False;
			sys.exit();
			
	def issilent(self):
		silence=False;
		dn=self.Ntotal-self.n_last_told;
		silenttime=time.time()-self.t_last_told;
		if dn<=1 or silenttime>60:
			silence=True;
		return silence;
		
	def gotcontrol(self):
		import pydao.etc;
		got=False;
		progress_teller=pydao.etc.progress_teller;
		if progress_teller is None:
			pydao.etc.progress_teller=self;
			got=True;
		elif  progress_teller.issilent():
			pydao.etc.progress_teller=self;
			got=True;
		elif progress_teller==self:
			got=True;
		return got;
		
import os;
import pydao;
		
def file_backup(filename):
	backupfname=filename+'.bak';
	for i_back in range(pydao.etc.N_Backup_File,0,-1):
		backupfname1=backupfname+str(i_back);
		backupfname2=backupfname+str(i_back-1);
		if os.path.exists(backupfname1):
			os.remove(backupfname1);
			print "Old backup file",backupfname1,'removed'
		if os.path.exists(backupfname2):
			os.rename(backupfname2,backupfname1);
			print backupfname2,'renamed to',backupfname1
					
	if os.path.exists(filename):
		os.rename(filename,backupfname2);
		print filename,'renamed to',backupfname
	#else:
	#	print self.name,'does not exist, creating new...';
			