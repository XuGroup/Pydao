from pylab import *;
from PIL import Image;
import matplotlib.pyplot as plt;
import numpy as np;
import matplotlib.cm as cm
from enthought.mayavi import mlab;
from scipy.optimize import fmin;

################################################
# input from an array
################################################
	
def int_filter(bmp_array,intmin=None,intmax=None):
	b=bmp_array;
	if intmin is not None:
		I=b<intmin;
		b[I]=intmin;
	if intmax is not None:
		I=b>intmax;
		b[I]=intmax;
	return b;
	
def array2bmp(bmp_array,filename,renormalize=False):
	linbmp=bmp_array.reshape(-1);
	if renormalize:
		vmean=mean(linbmp);
		vstd=std(linbmp);
		b_array=((bmp_array-vmean)/(3*vstd)+1.)*128;
	else:
		b_array=bmp_array;
	[Nrows,Ncols]=b_array.shape
	img=Image.new(mode='P',size=[Ncols,Nrows]);
	img.putdata(linbmp);
	# for icol in range(Ncols):
		# for irow in range(Nrows):
			# img.putpixel((icol,irow), b_array[irow,icol]);
	img.save(filename, "bmp");
	return b_array;

def gauss_smooth(bmp_array,sigma):
	from scipy.signal import convolve;
	import copy;
	img_array=copy.copy(bmp_array);
	N,M=bmp_array.shape;
	
	Ns=int(sigma*2)*2;
	x,y=mgrid[-Ns:Ns+1,-Ns:Ns+1];
	yg=exp(-(x**2+y**2)/2/sigma**2);
	yg=yg/yg.sum();
	
	img_array_smooth=convolve(img_array,yg,mode='valid');
	# print bmp_array.shape;
	# print img_array[Ns/2:N-Ns/2,Ns/2:M-Ns/2].shape
	# print img_array_smooth.shape
	img_array[Ns:N-Ns,Ns:M-Ns]=img_array_smooth;
	
	return img_array;

def get_roi(bmp_array,roi):
	return bmp_array[roi[0]:roi[1]+1,roi[2]:roi[3]+1];
	
def shift_array(dx,dy,bmp_array):
	import copy;
	from scipy import interpolate;
	N,M=bmp_array.shape;
	
	bmp_array=copy.copy(bmp_array);
	xs=arange(N);
	ys=arange(M);
	xss=xs+dx;
	yss=ys+dy;
	
	f2=interpolate.RectBivariateSpline(xss,yss,bmp_array);
	
	Ix=logical_and(xs>=min(xss), xs<=max(xss));
	Iy=logical_and(ys>=min(yss), ys<=max(yss));
	
	xs_in_min=min(xs[Ix]);
	xs_in_max=max(xs[Ix]);
	ys_in_min=min(ys[Iy]);
	ys_in_max=max(ys[Iy]);
	
	shiftedarray_in_grid=f2(xs[Ix],ys[Iy]);
	bmp_array[xs_in_min:xs_in_max+1,ys_in_min:ys_in_max+1]=shiftedarray_in_grid;
	common_region=[xs_in_min,xs_in_max,ys_in_min,ys_in_max];
	return bmp_array,shiftedarray_in_grid,common_region;

	
def chi2_shift_match(paras,barray1,barray2):
	dx,dy=paras;
	barrayshift,shiftedarray_in_grid,common_region=shift_array(dx,dy,barray1);
	xmin,xmax,ymin,ymax=common_region;
	barray2_in_grid=barray2[xmin:xmax+1,ymin:ymax+1];
	# chi2=mean(abs((shiftedarray_in_grid-barray2_in_grid)/(shiftedarray_in_grid+barray2_in_grid)));
	chi2=mean((shiftedarray_in_grid-barray2_in_grid)**2/abs(shiftedarray_in_grid+barray2_in_grid));
	chi2=chi2*1000;
	return chi2;

def shift2match(barray1,barray2,paras0=None):
	from scipy import optimize;
	if paras0 is None:
		paras0=[0.,0.,]
	paras=optimize.fmin(chi2_shift_match,paras0,args=(barray1,barray2));
		
	dx,dy=paras;
	chi2=chi2_shift_match(paras,barray1,barray2);
	# print paras,chi2;
	return paras,chi2;

def chi2_normalize_match(paras,barray1,barray2):
	factor,baseline=paras;
	barraynorm=barray1*factor+baseline;
	# chi2=mean(abs((barrayshift-barray2)/abs(barrayshift+barray2)));
	chi2=mean((barraynorm-barray2)**2/abs(barraynorm+barray2));
	chi2=chi2*1000;
	return chi2;
	
def normalize2match(barray1,barray2,paras0=None):
	from scipy import optimize;
	if paras0 is None:
		paras0=[1.,0.]
	paras=optimize.fmin(chi2_normalize_match,paras0,args=(barray1,barray2));
		
	factor,baseline=paras;
	barraynorm=barray1*factor+baseline;
	chi2=chi2_normalize_match(paras,barray1,barray2);
	# print paras,chi2;
	return paras,chi2;
	
def chi2_shiftnorm_2match(paras,barray1,barray2):
	dx,dy,factor=paras;
	barrayshift,shiftedarray_in_grid,common_region=shift_array(dx,dy,barray1);
	shiftedarray_in_grid=shiftedarray_in_grid*factor;
	
	xmin,xmax,ymin,ymax=common_region;
	barray2_in_grid=barray2[xmin:xmax+1,ymin:ymax+1];
	adiff=shiftedarray_in_grid-barray2_in_grid;
	asum=shiftedarray_in_grid+barray2_in_grid
	chi2=1./real(fft(adiff)-fft(asum)).mean();
	# chi2=chi2*mean((adiff)**2/abs(shiftedarray_in_grid+barray2_in_grid));
	# chi2=mean(adiff**2/abs(asum));
	# chi2=mean(adiff**2);
	# chi2=mean(abs((shiftedarray_in_grid-barray2_in_grid)/1.));
	return chi2*1000;
	
def shiftnorm_2match(barray1,barray2,paras0=None):
	from scipy import optimize;
	import scipy.ndimage.measurements as me;
	if paras0 is None:
		# paras0=[1.,1.,1.,0.]
		paras0=zeros(3);
		# com1=me.center_of_mass(barray1);
		# com2=me.center_of_mass(barray2);
		# paras0[0:2]=array(com2)-array(com1);
		paras0[0]=1.
		paras0[1]=1.
		paras0[2]=me.sum(barray2)/me.sum(barray1);
		print "auto paras0:",paras0
		
	paras=optimize.fmin(chi2_shiftnorm_2match,paras0,args=(barray1,barray2));
	dx,dy,factor=paras;
	chi2=chi2_shiftnorm_2match(paras,barray1,barray2);
	# print paras,chi2;
	barrayshift,shiftedarray_in_grid,common_region=shift_array(dx,dy,barray1);
	barrayshiftnorm=barrayshift*factor;
	return barrayshiftnorm,paras;

	
def match_byshiftnorm(barray1,barray2,paras0=None):
	if paras0 is None:
		paras0=array([1.,1.,1.,0.]);
	N=10;
	i=0;
	matched=False;
	paras=0+array(paras0);
	while i<N and not matched:
		parasshift,chi2shift = shift2match(barray1,barray2,paras[0:2]);
		paras[0:2]=parasshift;
		parasnorm,chi2norm = normalize2match(barray1,barray2,paras[2:4]);
		paras[2:4]=parasnorm;
		if (chi2shift-chi2norm)<1e-1 or i>N:
			matched=True;
		i=i+1;
		print "i:",i,"chi2shift:",chi2shift,"chi2norm:",chi2norm
		print "paras:",paras
	dx,dy,factor,baseline=paras;
	barrayshift,shiftedarray_in_grid,common_region=shift_array(dx,dy,barray1);
	shiftedarray_in_grid=shiftedarray_in_grid*factor+baseline;
	return barrayshift,paras;
	
	
def deinterlace(bmp_array,blank=0):
	[Nrows,Ncols]=bmp_array.shape
	for irow in range(Nrows):
		if mod(irow,2)==blank and irow-1>=0 and irow+1<Nrows:
			#print "irow",irow,Nrows
			bmp_array[irow,:]=(bmp_array[irow-1,:]+bmp_array[irow+1,:])/2;
	return bmp_array;
	
def crop(bmp_array,rowcenter,Nrow,colcenter,Ncol):
	rowmin=max(rowcenter-Nrow/2,0);
	rowmax=min(rowcenter+Nrow/2,bmp_array.shape[0]);	
	colmin=max(colcenter-Ncol/2,0);
	colmax=min(colcenter+Ncol/2,bmp_array.shape[1]);
	bmp_subarray=bmp_array[rowmin:rowmax,colmin:colmax];
	return bmp_subarray;
	
def find_vmax(bmp_array,centerrow=20):
	Nrow,Ncol=bmp_array.shape;
	bmp_centerarray=bmp_array[round(Nrow/2-centerrow):round(Nrow/2+centerrow),:];
	vmax=bmp_centerarray.max();
	return vmax;

def plot_bmp_array(bmp_array,lowboundary=0.05,highboundary=0.95):
	N,M=bmp_array.shape;
	bmp_array1d=reshape(bmp_array,N*M);
	bmp_array1d=sort(bmp_array1d);
	vmin=bmp_array1d[round(lowboundary*N*M)];
	vmax=bmp_array1d[round(highboundary*N*M)];
	#print vmin,vmax,min(bmp_array1d),max(bmp_array1d),mean(bmp_array1d);
	imshow(bmp_array,vmin=vmin,vmax=vmax);

def plot_bmp_array1(bmp_array,xmin=0.5,xmax=0.5,centerrow=20):
	vmin=xmin*bmp_array.mean()+(1-xmin)*bmp_array.min();
	#vmin=0;
	vmax=find_vmax(bmp_array,centerrow=20);
	vmax=xmax*bmp_array.mean()+(1-xmax)*vmax;
	imshow(bmp_array,vmin=vmin,vmax=vmax);
	
def logplot_bmp_array(bmp_array,xmin=0.5,xmax=0.5,centerrow=20):
	vmin=xmin*bmp_array.mean()+(1-xmin)*bmp_array.min();
	#vmin=0;
	vmax=find_vmax(bmp_array,centerrow=20);
	vmax=xmax*bmp_array.mean()+(1-xmax)*vmax;
	imshow(log(bmp_array+1),vmin=log(vmin+1),vmax=log(vmax+1));
	
def gauss_backsub(bmp_array,Niter=500):
	from pydao import math;
	Nrow,Ncol=bmp_array.shape;
	newarray=zeros([Nrow,Ncol]);
	figure();
	for irow in range(Nrow):
		#print irow;
		line=bmp_array[irow,:];
		line=line-line.min();
		x=arange(Ncol);
		xyfun=math.XyDiscreteFun();
		xyfun.set('x',x);
		xyfun.set('y',line);
		paras=xyfun.gaussfit()
		#print paras
		
		amp=paras[0];
		center=paras[1];
		sigma=paras[2];
		slope=paras[3];
		intercept=paras[4];
		
		yfit=amp*exp(-(x-center)**2/sigma**2/2)+slope*x+intercept;
		newline=line-yfit;
					
		minzero=False;
		ampmax=line.max();
		ampmin=-line.max();
		amp=0;
		iiter=0;
		while minzero is False:
			yfit=amp*exp(-(x-center)**2/sigma**2/2)+slope*x+intercept;
			newline=line-yfit;	
			centerline=newline[round(Ncol/2-Ncol/4):round(Ncol/2+Ncol/4)].copy();
			centerline.sort();
			centermin=centerline[2:10].mean();
			if abs(centermin)<1e-3 or iiter>Niter:
				minzero=True;
			elif centermin<0:
				ampmax=amp;
				amp=(ampmax+ampmin)/2;
			elif centermin>0:
				ampmin=amp;
				amp=(ampmax+ampmin)/2;
			iiter=iiter+1;
			#print amp,ampmax,ampmin,centermin
			#raw_input()
		if iiter>Niter:
			print "iiter reached Niter:",Niter
		newarray[irow,:]=newline;
		
		hold(False);
		plot(x,line);hold(True);
		plot(x,yfit);
		plot(x,newline);
		show();
		
	return newarray;

########################################
# input from a image file
########################################
def tif2array(tif_filename,intmin=None,intmax=None):
	import Image;
	im = Image.open(tif_filename);
	a=array(im);
	N,M,L=a.shape;
	b=zeros([N,M]);
	for l in range(L):
		b=b+a[:,:,l].astype('float32')*256**l;
	
	if intmin is not None:
		I=b<intmin;
		b[I]=intmin;
	if intmax is not None:
		I=b>intmax;
		b[I]=intmax;
	b=float32(b);
	return b;
	
def bmp2array(filename):
	img=Image.open(filename);
	pix=img.load();
	[Ncols,Nrows]=img.size
	bmp_array=zeros([Nrows,Ncols]);
	for icol in range(Ncols):
		for irow in range(Nrows):
			pixel=pix[icol,irow];
			if img.mode=='RGB':
				pixel=pixel[0]*0.3+pixel[1]*0.59+pixel[2]*0.11;
				# from http://en.wikipedia.org/wiki/Grayscale
			bmp_array[irow,icol]=pixel;
			#bmp_array[irow,icol]=pix[icol,irow];
	return bmp_array;
	
def mccd2array(filename):
	import fabio
	from fabio.marccdimage import marccdimage
	img = marccdimage();
	img.read(filename)
	img_array = img.data;
	return img_array;
	
def png162array(filename):
	from scipy.misc import imread;
	img_array = imread(filename);
	img_array = array(img_array,dtype = uint16);
	return img_array;
	
def mccd2png16(filename):
	from scipy.misc import toimage;
	img_array =  mccd2array(filename);
	
	fs = filename.split('.');
	filename_png=filename.replace(fs[-1],'png');
	img = toimage(img_array,high =img_array.max(),low = img_array.min(),mode='I');
	img.save(filename_png);
	return img_array;
	
def bmp_rotate(filename,degree):
	bmp_array=bmp2array(filename);
	[Nrows,Ncols]=bmp_array.shape
	print "array dims:",bmp_array.shape
	img=Image.new(mode='P',size=(Ncols,Nrows));
	print "image dims:",img.size
	for icol in range(Ncols):
		for irow in range(Nrows):
			bmp_array[irow,icol]
			img.putpixel((icol,irow), bmp_array[irow,icol]);
	rotatefilename=filename[:-4]+"_rotate.bmp";
	img.rotate(degree).save(rotatefilename,'bmp')
	bmp_array=bmp2array(rotatefilename);
	return bmp_array,rotatefilename;
	
def bmp_resize(filename,newsize):
	bmp_array=bmp2array(filename);
	[Nrows,Ncols]=bmp_array.shape
	print "array dims:",bmp_array.shape
	img=Image.new(mode='P',size=(Ncols,Nrows));
	print "image dims:",img.size
	for icol in range(Ncols):
		for irow in range(Nrows):
			bmp_array[irow,icol]
			img.putpixel((icol,irow), bmp_array[irow,icol]);
	resizefilename=filename[:-4]+"_resize.bmp";
	img.resize(newsize).save(resizefilename,'bmp')
	bmp_array=bmp2array(resizefilename);
	return bmp_array,resizefilename;
	
def bmp_deinterlace(filename,blank=0):
	bmp_array=bmp2array(filename);
	bmp_array_deinterlace=deinterlace(bmp_array,blank);
	filename=filename[:-4]+"_deinterlace.bmp";
	array2bmp(bmp_array_deinterlace,filename);
	return bmp_array_deinterlace,filename;

def bmp_crop(filename,rowcenter,Nrow,colcenter,Ncol):
	bmp_array=bmp2array(filename);
	bmp_array_crop=crop(bmp_array,rowcenter,Nrow,colcenter,Ncol);
	filename=filename[:-4]+"_crop.bmp";
	array2bmp(bmp_array_crop,filename);
	return bmp_array_crop,filename;
	
def bmp_bgsub(filename):
	bmp_array=bmp2array(filename);
	bmp_array_bgsub=gauss_backsub(bmp_array);
	filename=filename[:-4]+"_bgsub.bmp";
	array2bmp(bmp_array_bgsub,filename);
	return bmp_array_bgsub,filename;
	
def bmp_plot(filename,lowboundary=0.05,highboundary=0.95):
	bmp_array=bmp2array(filename);
	plot_bmp_array(bmp_array,lowboundary,highboundary);
	
# def rotatebmp(filename,degree):
	# bmp_array=bmp2array(filename);
	# bmp_array.rotate(degree).save('rotate'+filename, "bmp");
	# return

	
def standard_proc(filename,blank=0,degree=0,rowcenter=312,Nrow=150,colcenter=409,Ncol=210,action=3):
	bmp_array = [];
	bmp_subarray = [];
	bmp_subarray_nobg = [];
	
	bmp_arrayd,dfile=bmp_deinterlace(filename,blank=0)
	print "deinterlaced. blank=",blank
	bmp_plot(dfile);
	show();
	
	if action>=2:
		bmp_arrayr,rfile=bmp_rotate(dfile,degree);
		bmp_plot(rfile);
		print "rotated. degree=",degree
		show();

		bmp_array=bmp_arrayr;
		print bmp_array.shape
	
	if action>=3:
		rowmin=max(rowcenter-Nrow/2,0);
		rowmax=min(rowcenter+Nrow/2,bmp_array.shape[0]);	
		colmin=max(colcenter-Ncol/2,0);
		colmax=min(colcenter+Ncol/2,bmp_array.shape[1]);
		print "rowmin:",rowmin,",rowmax:",rowmax,",colmin:",colmin,",colmax:",colmax
		bmp_subarray=bmp_array[rowmin:rowmax,colmin:colmax];
		
	if action>=4:
		bmp_subarray_nobg=gauss_backsub(bmp_subarray);
		
	return bmp_array,bmp_subarray,bmp_subarray_nobg;
	

