from pylab import *;
from pydao.ohdf import OGroup;
from pydao.database import TextBlock;

class ASCIIFile(TextBlock):
	def __init__(self,filename=None):
		TextBlock.__init__(self);
		self.set('filename',filename);
		# print "filename in ASCIIFile:",filename
		if filename is not None:
			self.read_file_to_mem();
			
	def read_file_to_mem(self,filename=None):
		success=True;
		if filename is None:
			filename=self.get('filename');
		if filename is None:
				print ".read_file_to_mem failed, filename is None!"
				success=False;
		else:
			self.set('filename',filename);
			f=open(self.get('filename'),"rU");
			flist=list(f);
			self.set('textcontent',flist);
			# print "flist:",flist
			f.close();
		return success;
		
class LogFile(ASCIIFile):
	def __init__(self,filename=None):
		TextBlock.__init__(self,textcontent=[]);
		self.set('filename',filename);
			
	def save_file_to_disk(self,filename=None,startline=0):
		success=True;
		if filename is None:
			filename=self.get('filename');
		if filename is None:
				print ".save_file_to_disk failed, filename is None!"
				success=False;
		else:
			self.set('filename',filename);
			f=open(self.get('filename'),"a+");
			textcontent=self.get('textcontent');
			for iline in range(startline,len(textcontent)):
				line=textcontent[iline];
				f.write(line+'\n');
			f.close();
			# print "flist:",flist
		return success;
		
	def printf(self,line,screen=True):
		if type(line) is list:
			strline='';
			for l in line:
				strline=strline+str(l);
		elif type(line) is str:
			strline=line;
		else:
			strline=str(line);
		self.append_line(strline);
		self.save_file_to_disk(startline=self.get_nlines()-1);
		if screen:
			print strline;
		
	def timestamp(self,linebreak=True):
		import time;
		if linebreak:
			self.printf("\n");
		self.printf(time.ctime());