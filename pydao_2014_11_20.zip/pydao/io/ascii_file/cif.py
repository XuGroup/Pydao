from pylab import *;
from pydao.ohdf import OGroup;
from ascii_file import ASCIIFile,TextBlock;

class SpaceGroup(OGroup):
	def __init__(self,number=185):
		OGroup.__init__(self);
		self.set('space_group_number',number);
		
	def get_symmetry_operations(self):
		space_group_number=self.get('space_group_number');
		if space_group_number==185:
			pass;
	
class CIF(ASCIIFile):
	def __init__(self,filename=None):
		ASCIIFile.__init__(self,filename=filename);
		self.set('loops',None);
		
	def get_celllength(self):
		a0=self.find_pattern("%_cell_length_a%");
		a=a0[1];
		a0=self.find_pattern("%_cell_length_b%");
		b=a0[1];
		a0=self.find_pattern("%_cell_length_c%");
		c=a0[1];
		return array([a,b,c]);
		
	def get_cellangles(self):
		a0=self.find_pattern("%_cell_angle_alpha%");
		alpha=a0[1];
		a0=self.find_pattern("%_cell_angle_beta%");
		beta=a0[1];
		a0=self.find_pattern("%_cell_angle_gamma%");
		gamma=a0[1];
		return array([alpha,beta,gamma]);
	
	def get_spacegroup(self):
		a0=self.find_pattern("%_symmetry_int_tables_number%");
		gnum=a0[1];
		return gnum;
	
	def analyze_loops(self):
		blocks=self.get_block_sequence(blockstr="loop_");
		NB=self.get_nblocks(blockstr="loop_");
		# print "NB:",NB
		for ib in range(NB):
			block=blocks[ib];
			cifloop=block.typecast(CIFLoop());
			cifloop.analyze();
			blocks[ib]=cifloop;
			print "found _loop:",cifloop.get("colnames")[0]
		self.set('loops',blocks);
		return blocks;
		
	def get_loop(self,spec_string):
		loops=self.get('loops');
		foundloop = None;
		for i in range(len(loops)):
			loop=loops[i]
			if loop.get("colnames")[0]==spec_string:
				foundloop = loop;
				break;
		# print loop.get("colnames")[0]
		return foundloop;
		
	def get_symmetry_loop(self):
		loop=self.get_loop("_symmetry_equiv_pos_site_id");
		if loop is None:
			loop=self.get_loop("_symmetry_equiv_pos_as_xyz");
		loop=loop.typecast(SymmetryOperations());
		self.set('symmetry_loop',loop);
		return loop;
		
	def get_atomic_site_loop(self):
		loop=self.get_loop("_atom_site_label");
		self.set('atomic_site_loop',loop);
		return loop;
		
	def get_atom_type_loop(self):
		loop=self.get_loop("_atom_type_symbol");
		self.set('atom_type_loop',loop);
		return loop;
	
	def get_Wyckoff(self):
		from pydao.ohdf import remove_numstr;
		loop=self.get('atomic_site_loop');
		if loop is None:
			loop=self.get_atomic_site_loop();
		labels=loop.get_col("_atom_site_label");
		elements=loop.get_col("_atom_site_type_symbol");
		if elements is None:
			elements=loop.get_col("_atom_site_label");
		# print "elements:",elements
		for i in range(len(elements)):
			ele=elements[i];
			eles=ele.split('+');
			ele=eles[0];
			eles=ele.split('-');
			ele=eles[0];
			atom_type = remove_numstr(ele);
			elements[i] = atom_type;
		xs=loop.get_col("_atom_site_fract_x");
		ys=loop.get_col("_atom_site_fract_y");
		zs=loop.get_col("_atom_site_fract_z");
		positions=transpose(vstack((xs,ys,zs)));
		return labels,elements,positions;
	
	def get_valence(self):
		loop=self.get_atom_type_loop();
		elements=loop.get_col("_atom_type_symbol");
		if elements is None:
			elements=loop.get_col("_atom_site_label");
		for i in range(len(elements)):
			ele=elements[i];
			eles=ele.split('+');
			ele=eles[0];
			eles=ele.split('-');
			ele=eles[0];
			elements[i]=ele;
		labels=elements;
		oxidation_number=loop.get_col("_atom_type_oxidation_number");
		valences={};
		for i in range(len(labels)):
			valences[labels[i]]=oxidation_number[i]
		return valences;
################################################################################
# Below are the calculations we can use with the information from the cif file.#
################################################################################
	def generate_Wyckoff_lattice(self,Wyckoff=None):
		from pydao.physics import Lattice,Atom;
		from pydao.ohdf import remove_numstr;
		import pydao.chemistry as chem;
		if Wyckoff is None:
			labels,elements,positions=self.get_Wyckoff();
		else:
			labels,elements,positions=Wyckoff;
		print "labels:",labels
		print "elements:",elements
		print "positions:",positions
		la=Lattice();
		la.set('cif',self);
		basis=la.length_angle_2basis(self.get_celllength(),self.get_cellangles());
		la.set('basis',basis);
		la.cal_kbasis();
		atoms=OGroup();
		valences=self.get_valence();
		for i in range(len(elements)):
			atom_type=elements[i];
			
			print "atom_type",atom_type
			mass=chem.PTable[atom_type]['mass'];
			charge=valences[elements[i]];
			direct=array([float(positions[i,0]),float(positions[i,1]),float(positions[i,2])]);
			cartesian=la.direct2cartesian(direct,basis=basis)
			atom=Atom(mass,charge,atom_type,cartesian);
			atom.set('lattice_index',direct)
			atoms.set(labels[i],atom);
		la.set('atoms',atoms);
		return la;
		
	def generate_lattice(self,Wyckoff=None,verbose=False):
		if verbose:
			print "Generating Lattice:"
		la=self.generate_Wyckoff_lattice(Wyckoff);
		loop_sym=self.get_symmetry_loop();
		symmetry_operations=loop_sym.analyze_symmetry();
		atoms=la.get('atoms');
		newatoms=OGroup();
		Natoms=0;
		for k in atoms.keys():
			atom=atoms.get(k);
			atopos=atom.get('lattice_index');
			newposin,newpos=loop_sym.operate(atopos);
			distinct_newposin=array(loop_sym.distinct_atom_pos(newposin));
			# print k,"distinct_newposin\n",distinct_newposin
			ipos=0;
			for pos in distinct_newposin:
				newatom=atom.copy2mem();
				newatom.set('lattice_index',pos);
				newatoms.set(k+'_'+str(ipos),newatom);
				ipos=ipos+1;
			if verbose:
				print len(distinct_newposin),k,atom.get('type'),atom.get('charge');
			Natoms=Natoms+len(distinct_newposin)
		if verbose:
			print "Total ",Natoms,"generated."
		la.set('atoms',newatoms);
		self.set('lattice',la);
		return la;
	
	def cal_structure_factor_single(self,Q,lat=None):
		if lat is None:
			lat=self.get('lattice');
		# print "lat:",lat
		atoms=lat.get('atoms');
		sf=0
		for k in atoms.keys():
			atom=atoms.get(k);
			pos=atom.get('lattice_index');
			q=lat.cal_qabs(Q);
			f=atom.cal_xray_scattering_factor(q);
			sf=sf+f*exp(-1j*sum(Q*pos)*2*pi);
		return abs(sf),q;
		
	def cal_structure_factor(self,Q,lat=None):
		if type(Q) is not list:
			sfs,qs=self.cal_structure_factor_single(Q,lat);
		else:
			sfs=zeros(len(Q));
			qs=sfs-sfs;
			for i in range(len(Q)):
				sf,q=self.cal_structure_factor_single(Q[i],lat);
				sfs[i]=sf;
				qs[i]=q;
		return sfs,qs;
		
class CIFLoop(TextBlock):
	def __init__(self):
		TextBlock.__init__(self);
				
	def get_colnames(self):
		colnames=[];
		loopcontent=self.get("textcontent");
		for i in range(1,len(loopcontent)):
			line=loopcontent[i];
			if line[0]=="_":
				colnames.append(line);
			else:
				break;
		self.set('colnames',colnames);
		return colnames;
		
	def analyze(self):
		from pydao.ohdf import sscan, remove_consecutive_space;
		loopcontent=self.get("textcontent");
		colnames=self.get_colnames();
		
		pattern="%";
		for i in range(len(colnames)-1):
			pattern=pattern+' %';
		rows=[];
		for irow in range(len(colnames)+1,len(loopcontent)):
			line=loopcontent[irow];
			line=line.replace("\t"," ");
			line = remove_consecutive_space(line);
			row=sscan(line,pattern);
			#row=loopcontent[irow].split();
			rows.append(row);
		self.set('looprows',rows);
		return rows;
		
	def get_col(self,colname):
		colvalues=[];
		colnames=self.get('colnames');
		if colnames is None:
			colnames=self.get_colnames();
		rows=self.get('rows');
		if rows is None:
			rows=self.analyze();
		if colnames.count(colname)==1:
			icol=colnames.index(colname);
			# print "icol:",icol
			for row in rows:
				# print "row:",row
				colvalues.append(row[icol]);
		else:
			colvalues=None;
		return colvalues;
		
	def printloop(self):
		colnames=self.get('colnames');
		rows=self.get('rows');
		print "colnames:",colnames
		print "rows:",rows
		
class SymmetryOperations(CIFLoop):
	def __init__(self):
		CIFLoop.__init__(self);
		
	def analyze_symmetry(self):
		symmetry_operation_strs=self.get_col("_symmetry_equiv_pos_as_xyz");
		symmetry_operations=[];
		for operation_str in symmetry_operation_strs:
			xyzs = operation_str.replace("'","");
			# print "xyzs:",xyzs
			xyzs=xyzs.split(',');
			for i in range(3):
				xyzs[i]=xyzs[i].lower();
			symmetry_operations.append(xyzs);
			#print xyzs;
		self.set('symmetry_operations',symmetry_operations);
		return symmetry_operations;
		
	def operate(self,position):
		from pydao.math import translate_to_1st_cell;
		x,y,z=position;
		symmetry_operations=self.get('symmetry_operations');
		Nop=len(symmetry_operations);
		newpositions=range(Nop);
		newpositions_in=range(Nop);
		i=0;
		for sop in symmetry_operations:
			x1=eval(symmetry_operations[i][0]);
			y1=eval(symmetry_operations[i][1]);
			z1=eval(symmetry_operations[i][2]);
			newpositions[i]=array([x1,y1,z1]);
			newpositions_in[i]=translate_to_1st_cell(newpositions[i]);
			i=i+1;
		return newpositions_in,newpositions;
		
	def distinct_atom_pos(self,positions):
		from pydao.math import vlen;
		from pydao.database import distinct;
		poslist=list(positions);
		dist_pos,poslist=distinct(poslist,lambda pos1,pos2:vlen(pos1-pos2)<0.1);
		return dist_pos;