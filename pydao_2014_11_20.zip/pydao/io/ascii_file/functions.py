from pylab import *;
import os;

def construct_fullfilename(directory,exp_name,scan_number,scan_number_digits=None,suffix='.asc'):
	scan_numberstr=str(scan_number);
	if scan_number_digits is not None:
		scan_numberstr=(scan_number_digits-len(scan_numberstr))*'0'+scan_numberstr;
	fullfilenameH=os.path.join(directory,exp_name+scan_numberstr+suffix);
	return fullfilenameH;
	
def normalize_twoprofiles(I01,I02,y1,y2):
	N=10;
	Istart=range(0,N);
	Iend=range(-N,0);
	
	y1norm=y1/I01;
	y2norm=y2/I02;
	shift=mean(y1norm[Istart]-y2norm[Istart]);
	y2norm=y2norm+shift-mean(y1norm[Istart]);
	y1norm=y1norm-mean(y1norm[Istart]);
	factor=mean(y1norm[Iend])/mean(y2norm[Iend]);
	y2norm=y2norm*factor;
	return y1norm, y2norm;

def linearbgsub(y,N=10):
	# N=10;
	Istart=range(0,N);
	Iend=range(-N,0);
	Np=len(y);
	x=arange(Np);
	#background=mean(y[Istart])+(mean(y[Iend])-mean(y[Istart]))/(mean(x[Iend])-mean(x[Istart]))*(x-x[0]);
	p=polyfit(x[Istart+Iend],y[Istart+Iend],1);
	background=p[0]*x+p[1];
	ynorm=y-background;
	return ynorm,background;
	
def find_plateau(x,y,xmin,xmax,Xwidth):
	import scipy.optimize;
	I=logical_and(x>xmin,x<xmax);
	x1=x[I];
	y1=y[I];
	paras0=[mean(x1),max(y1)];
	print "paras0:",paras0
	paras=scipy.optimize.fmin(self.match_plateau_chi2,paras0,args=(x1,y1,Xwidth));
	Xcenter=paras[0];
	Y=paras[1];
	return Xcenter,Y;

def gfit_plateau(x,y,xmin,xmax,xwidth):
	import scipy.optimize;
	I=logical_and(x>xmin,x<xmax);
	x1=x[I];
	y1=y[I];
	x1st=sum(x1*y1)/sum(y1);
	# print "x1st:",x1st
	x2nd=sum((x1-x1st)**2*y1)/sum(y1)/2;
	# print type(x2nd),type(y1)
	# print x2nd.shape,y1.shape,x1.shape;
	# x2nd=x2nd/sum(y1);
	paras0=[max(y1),x1st,x2nd,min(y1)];
	print "paras0:",paras0
	paras=scipy.optimize.fmin(gfit_plateau_chi2,paras0,args=(x1,y1,xwidth));
	amp=paras[0];
	x0=paras[1];
	sigma=paras[2];
	baseline=paras[3];
	return amp,x0,sigma,baseline;

def gfit_plateau_chi2(paras,x,y,xwidth):
	amp=paras[0];
	x0=paras[1];
	sigma=paras[2];
	baseline=paras[3];
	I=logical_and(x-x0<xwidth/2,x-x0>-xwidth/2);
	x1=x[I];
	y1=y[I];
	yfit=amp*exp(-(x1-x0)**2/2/sigma**2)+baseline;
	chi2=sum((yfit-y1)**2);
	if amp<mean(y) or amp>1.5*max(y) or baseline<0:#or x0+sigma>max(x) or x0-sigma<min(x):
		chi2=chi2+1e100;
	return chi2;
	
def match_plateau_chi2(paras,x,y,Xwidth):
	#Xwidth=5;
	Xcenter=paras[0];
	Y=paras[1];
	yave=mean(y);
	I=logical_and(x<Xcenter+Xwidth/2,x>Xcenter-Xwidth/2);
	ycomp=y[I];
	yfit=ycomp-ycomp+Y;
	chi2=sum((yfit-ycomp)**2);
	if Y<yave or Xcenter+Xwidth/2>max(x) or Xcenter-Xwidth/2<min(x):
		chi2=chi2+1e100;
	return chi2;