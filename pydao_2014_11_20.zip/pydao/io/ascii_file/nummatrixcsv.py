from pydao.ohdf import OGroup;
from pylab import *;
from ascii_file import ASCIIFile;

class NumMatrixCSV(ASCIIFile):
	def __init__(self,filename=None,dilimiter="\t",row_width_chosen=None):
		ASCIIFile.__init__(self,filename=filename);
		self.set('filename',filename);
		self.set('dilimiter',dilimiter);
		self.set('row_width_chosen',row_width_chosen);
		self.set('num_matrix',None);
		# self.set('textcontent',None);
		
	def convertcsv(self):
		f=self.get('textcontent');
		num_matrix_array=None;
		
		numeric_rows=[];
		numeric_rows_width=[];
		
		for line in f:
			#print line
			valid_num_row=self.analyzerow(line,None);
			if len(valid_num_row)==0:
				valid_num_row=self.analyzerow(line,'\t');
			if len(valid_num_row)==0:
				valid_num_row=self.analyzerow(line,',');
			if 	len(valid_num_row)>0:
				numeric_rows.append(valid_num_row);
				numeric_rows_width.append(len(valid_num_row));
		
		row_width_kind=list(set(numeric_rows_width));
		row_width_chosen=self.get('row_width_chosen');
		
		try:
			index=row_width_kind.index(row_width_chosen);
			self.set('row_width_chosen',row_width_kind[index]);
		except:
			if row_width_chosen is None:
				count=0;
				chosen=None;
				for kind in row_width_kind:
					#print "kind:",kind,"count:",row_width_kind.count(kind)
					if numeric_rows_width.count(kind)>count:
						count=row_width_kind.count(kind);
						chosen=kind;
				if chosen is not None:
					self.set('row_width_chosen',chosen);
			elif row_width_chosen=="max":
				self.set('row_width_chosen',max(row_width_kind));
			elif row_width_chosen=="min":
				self.set('row_width_chosen',min(row_width_kind));
		#print "row_width_chosen",self.get('row_width_chosen')
		
		if chosen is not None:
			num_matrix_list=self.getnummatrix(numeric_rows,self.get('row_width_chosen'));
			#NrowNcol=self.findNcolNrow(NumCols);
			#dptablelist=self.formdptable(numeric_rows,self['row_width_chosen']);
			import numpy;
			num_matrix_array=numpy.array(num_matrix_list);
			self.set('num_matrix',num_matrix_array);
			#print self['filename'],'imported.'
			#print 'Found arrary with shape:',num_matrix_array.shape;
			Success=True;
		else:
			print "no arrary found."
		return num_matrix_array;
		
	def load_txt(self,filename):
		success=False;
		if filename is not None:
			try:
				self.read_file_to_mem(filename);
				mat=loadtxt(filename);
				self.set('num_matrix',mat);
				success=True;
			except:
				print ".load_txt failed to load file:",filename;
		else:
			print ".load_txt failed, file name is None!"	
		return success;
		
	def getfromheader(self,condition,method="pattern",npattern=None):
		resultstr=None;
		flist=self.get('textcontent');
		#print "len(f)",len(flist)
		#print "method:",method
		if method=="pattern":
			import re;
			for line in flist:
				g=re.search(condition,line);
				try: 	
					resultstr=g.group(npattern);
					break;
				except:
					pass;
		elif method=="lineNo":
			if len(flist)>condition:
				resultstr=flist[condition];
			else:
				resultstr="";
		elif method=="tokenline":
			import string;
			foundtoken=False;
			for line in flist:
				#print line,condition
				if foundtoken:
					resultstr=line;
					break;
				if string.strip(line)==condition:
					foundtoken=True;
					#print "foundtoken"
		else:
			print "wrong method:",method
		if isinstance(resultstr,str):
			resultstr=resultstr.replace("\n",'');
		return resultstr;
	
	def findNcolNrow(self,NumCols):
		NumColskind=list(set(NumCols));
		Nrows=[];
		for NCol in NumColskind:
			Nrows.append(NumCols.count(NCol));
		Nrowmax=max(Nrows);
		#print Nrows,Nrowmax
		#print type(Nrows),type(Nrowmax),
		index=Nrows.index(Nrowmax);
		Ncol=NumColskind[index];
		#print "Nrow:",Nrowmax,"Ncol:",Ncol
		NN=[Nrowmax,Ncol];
		return NN;
		
	def getnummatrix(self,Numline,Ncol):
		import numpy;
		dptable=[];
		#print numpy.shape(Numline);
		for row in Numline:
			#print "row:",row,type(row);
			if len(row)==Ncol:
				dptable.append(row);
		return dptable;		
	
	def analyzerow(self,row,sep):
		ele0=row;
		#ele0=line;
		if sep is None:
			row0=ele0.split();
		else:
			row0=ele0.split(sep);
		#print "ele0",ele0,"row0",row0;
		try:
			valid_num_row=[];
			for element in row0:
				f=float(element);
				valid_num_row.append(f);
			#print valid_num_row
		except:
			valid_num_row=[];
		#print "sep:",sep,"len",len(valid_num_row)
		return valid_num_row;
	
	#to operate columns
	def get_col(self,icol):
		scan_num_matrix=self.get('num_matrix');
		Nrow,Ncol=scan_num_matrix.shape;
		if icol<0:
			icol=Ncol+icol;
		scan_col=scan_num_matrix[:,icol];
		return scan_col;
		
	def get_size(self):
		scan_num_matrix=self.get('num_matrix');
		return scan_num_matrix.shape;
	
	def append_col(self,col):
		scan_num_matrix=self.get('num_matrix');
		scan_num_matrix=vstack((transpose(scan_num_matrix),col));
		scan_num_matrix=transpose(scan_num_matrix);
		self.set('num_matrix',scan_num_matrix);