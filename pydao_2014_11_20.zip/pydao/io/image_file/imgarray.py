from pylab import *;
from pydao.ohdf import OGroup;
from pydao.database import Relation_Table;

class ImgArray(OGroup):
	def __init__(self,filename=None,dilimiter='\t',row_width_chosen=None):
		OGroup.__init__(self);
		self.set('filename',filename);
		# print "filename in ASCIIFile:",filename
		# if filename is not None:
			# self.read();
		
	def read(self,filename=None):
		from scipy.misc import imread;
		success=True;
		if filename is None:
			filename=self.get('filename');
		if filename is None:
				print ".read_file_to_mem failed, filename is None!"
				success=False;
		else:
			self.set('filename',filename);
			img_array = imread(filename);
			img_array = array(img_array,dtype = uint16);
			print "read image",img_array.shape
			print "max:",img_array.max()
			self.set('img_array',img_array);
		return success;
	
	def savebmp(self,filename=None,renormalize=False):
		from pydao.tools import array2bmp;
		if filename is None:
			filename=self.get('filename');
		# print "savebmp filename:",filename
		filename=filename.replace('tif','bmp');
		if not filename.endswith('bmp'):
			filename=filename+'.bmp';
		img_array=self.get('img_array');
		# print "saving bmp to:",filename
		array2bmp(img_array,filename,renormalize=renormalize);
		return;
		
	def savepng(self,filename=None,renormalize=False):
		from matplotlib import image as im;
		from PIL import Image;
		if filename is None:
			filename=self.get('filename');
			fs = filename.split('.');
			filename=filename.replace(fs[-1],'png');
		if not filename.endswith('png'):
			filename=filename+'.png';
		
		# print "filename:",filename
		img_array = self.get('img_array');
		N,M = img_array.shape
		im = Image.new('L', (M,N));
		im.putdata(transpose(img_array).reshape(-1));
		im.save(filename);
		return;
	
	def save(self,filename=None,format='png'):
		from scipy.misc import toimage;
		if filename is None:
			filename=self.get('filename');
			fs = filename.split('.');
			filename=filename.replace(fs[-1],format);
		if not filename.endswith(format):
			filename=filename+'.'+format;
		
		# print "filename:",filename
		img_array = self.get('img_array');
		# print img_array.max(),img_array.min()
		img = toimage(img_array,high =img_array.max(),low = img_array.min(),mode='I');
		img.save(filename);
		return;
		
	def readpng(self,filename):
		from matplotlib import image as im;
		if filename is None:
			filename=self.get('filename');
		# print "savebmp filename:",filename
		filename=filename.replace('tif','png');
		if not filename.endswith('png'):
			filename = filename+'.png';
		img_array = im.imread(filename);
		self.set('img_array',img_array);
		
	
	def savetxt(self,filename=None):
		if filename is None:
			filename=self.get('filename');
		# print "savebmp filename:",filename
		filename=filename.replace('tif','txt');
		if not filename.endswith('txt'):
			filename=filename+'.txt';
		img_array=self.get('img_array');
		# print "img_array shape:",img_array.shape
		# print "txt filename:",filename
		savetxt(filename,img_array,"%5.2g");
			
	def scale(self,power):
		import copy;
		img_array=self.get('img_array');
		img_array=copy.copy(img_array);
		I=img_array>0;
		img_array[I]=img_array[I]**power;
		I=img_array<0;
		img_array[I]=-(-img_array[I])**power;
		
		new_mimg=ImgArray();	
		new_mimg.set('img_array',img_array);
		return new_mimg;
		

	def gsmooth(self,sigma):
		from pydao.tools import gauss_smooth;
		img_array=self.get('img_array');
		img_array_smooth=gauss_smooth(img_array,sigma);
		new_mimg=ImgArray();	
		new_mimg.set('img_array',img_array_smooth);
		return new_mimg;
		
	def set_roi(self,roi):
		self.set('roi',roi);
		return;
		
	def get_region_of_interest(self,roi):
		xmin,xmax,ymin,ymax=roi;
		
		img_array=self.get('img_array');
		N,M=img_array.shape;
	
		x1s=arange(N);
		y1s=arange(M);
	
		Ix=logical_and(x1s>=xmin, x1s<=xmax);
		Iy=logical_and(y1s>=ymin, y1s<=ymax);
	
		x1s_in_roi_min=min(x1s[Ix]);
		x1s_in_roi_max=max(x1s[Ix]);
		y1s_in_roi_min=min(y1s[Iy]);
		y1s_in_roi_max=max(y1s[Iy]);
	
		roi_array=img_array[x1s_in_roi_min:x1s_in_roi_max+1,y1s_in_roi_min:y1s_in_roi_max+1];

		return roi_array;
		
	def get_roi(self,roi=None):	
		return self.get_roi_img(roi);
		
	def get_roi_img(self,roi=None):
		if roi is None:
			roi=self.get('roi');
		xmin,xmax,ymin,ymax=roi;
		
		img_array=self.get('img_array');
		N,M=img_array.shape;
	
		x1s=arange(N);
		y1s=arange(M);
	
		Ix=logical_and(x1s>=xmin, x1s<=xmax);
		Iy=logical_and(y1s>=ymin, y1s<=ymax);
	
		x1s_in_roi_min=min(x1s[Ix]);
		x1s_in_roi_max=max(x1s[Ix]);
		y1s_in_roi_min=min(y1s[Iy]);
		y1s_in_roi_max=max(y1s[Iy]);
	
		roi_array=img_array[x1s_in_roi_min:x1s_in_roi_max+1,y1s_in_roi_min:y1s_in_roi_max+1];
		
		new_mimg=ImgArray();	
		new_mimg.set('img_array',roi_array);
		new_mimg.set('fromroi',roi);
		
		return new_mimg;
		
	def __sub__(self, mimg):
		img_array=self.get('img_array');
		if type(mimg) is ImgArray:
			img_array2=mimg.get('img_array');
			newarray=img_array-img_array2;
		else:
			newarray=img_array-mimg;
		new_mimg=ImgArray();
		new_mimg.set('img_array',newarray);
		return new_mimg;
	
	def __add__(self, mimg):
		img_array=self.get('img_array');
		if type(mimg) is ImgArray:
			img_array2=mimg.get('img_array');
			newarray=img_array+img_array2;
		else:
			newarray=img_array+mimg;
		new_mimg=ImgArray();
		new_mimg.set('img_array',newarray);
		return new_mimg;
		
	def __mul__(self, mimg) :
		img_array=self.get('img_array');
		N,M=img_array.shape;
		# print "self:",self.info();
		# print "mimg",mimg.info();
		if type(mimg) is ImgArray:
			img_array2=mimg.get('img_array');
			newarray=img_array*(img_array2+zeros([N,M]));
		else:
			newarray=img_array*(mimg+zeros([N,M]));
		new_mimg=ImgArray();
		new_mimg.set('img_array',newarray);
		# print type(newarray)
		return new_mimg;
		
	def __div__(self, mimg) :
		img_array=self.get('img_array');
		N,M=img_array.shape;
		# print "self:",self.info();
		# print "mimg",mimg.info();
		if type(mimg) is ImgArray:
			img_array2=mimg.get('img_array');
			newarray=img_array/(img_array2+zeros([N,M]));
		else:
			newarray=img_array/(mimg+zeros([N,M]));
		new_mimg=ImgArray();
		new_mimg.set('img_array',newarray);
		# print type(newarray)
		return new_mimg;
	
	def disp(self,roi=None,vmin=None,vmax=None):
		self.disp_img(roi,vmin,vmax);
		
	def disp_img(self,roi=None,vmin=None,vmax=None):
		img_array=self.get('img_array');
		imshow(img_array,vmin=vmin,vmax=vmax);
		if roi is not None:
			self.disp_roi(roi);
		# axis('tight');
	
	def disp_roi(self,roi,pstyle='-'):
		plot(roi[2:4],roi[0]+zeros(2),pstyle);
		plot(roi[2:4],roi[1]+zeros(2),pstyle);
		plot(roi[2]+zeros(2),roi[0:2],pstyle);
		plot(roi[3]+zeros(2),roi[0:2],pstyle);
		return;
	
	def info(self):
		img_array=self.get('img_array');
		img_lin=img_array.reshape(-1);
		return min(img_lin),max(img_lin),mean(img_lin),std(img_lin);
	
	def fft_info(self):
		img_array=self.get('img_array');
		imarr=fft(img_array);
		return real(imarr).mean(),real(imarr).std(),imag(imarr).mean(),imag(imarr).std(),abs(imarr).mean(),abs(imarr).std(),
	
	def sum(self):
		img_array=self.get('img_array');
		# imarr=fft(img_array);
		return img_array.sum();
		
	def mean(self):
		inf=self.info();
		return inf[2];
		
	def std(self):
		inf=self.info();
		return inf[3];
	
	def min(self):
		inf=self.info();
		return inf[0];
		
	def max(self):
		inf=self.info();
		return inf[1];
		
	def abs(self):
		img_array=self.get('img_array');
		new_mimg=ImgArray();
		new_mimg.set('img_array',abs(img_array));
		return new_mimg;
		
	def hist(self,N=100,range=None,plot=True):
		img_array=self.get('img_array');
		if plot:
			output=hist(img_array.reshape(-1),N,range=range);
		else:
			output=histogram(img_array.reshape(-1),N,range=range);
		return output;
		
	def average(self,roi=None):
		if roi is not None:
			roi_img=self.get_roi_img(roi);
			img_array=roi_img.get('img_array');
		else:
			img_array=self.get('img_array');
		return mean(img_array);
		
	def shift(self,dx,dy):
		from pydao.tools import shift_array;
		import copy;
		img_array=self.get('img_array');
		imga=copy.copy(img_array);
		imga,img_in,region=shift_array(dx,dy,imga);
		new_mimg=ImgArray();
		new_mimg.set('img_array',imga);
		return new_mimg;
		
	def smooth(self,sigma):
		from pydao.tools import gauss_smooth;
		img_array=self.get('img_array');
		img_array=gauss_smooth(img_array,sigma);
		new_mimg=ImgArray();
		new_mimg.set('img_array',img_array);
		return new_mimg;
		
	def normalize(self,factor,baseline):
		newimg=self*factor;
		newimg=newimg+baseline;
		return newimg;
		
	def shiftnorm(self,dx,dy,factor):
		shifted=self.shift(dx,dy);
		shiftednorm=shifted*factor;
		return shiftednorm;
	
	def shiftnormbg(self,dx,dy,factor,bg):
		shifted=self.shift(dx,dy);
		shiftednorm=shifted*factor+bg;
		return shiftednorm;
		
	def nthmoment(self,n):
		from pydao.math import XyDiscreteFun; 
		img_array = self.get('img_array');
		N,M = img_array.shape;
		if n == 0:
			answer = img_array.sum();
		else:
			x = arange(N);
			y = img_array.sum(1);
			spect = XyDiscreteFun();
			spect.set('x',x);
			spect.set('y',y);
			m0 = spect.nthmoment(n);
			x = arange(M);
			y = img_array.sum(0);
			spect = XyDiscreteFun();
			spect.set('x',x);
			spect.set('y',y);
			m1 = spect.nthmoment(n);
			answer = array([m0,m1]);
		return answer;
		
	def fix_ditch(self,imin,imax,dim='row'):
		img_array = self.get('img_array');
		N,M = img_array.shape;
		if dim == 'column':
			x = range(M);
			for i in range(N):
				y = img_array[i,:];
				xreplace = x[imin:imax+1];
				xkeep = array(list(x[0:imin])+list(x[imax+1:]));
				ykeep = array(list(y[0:imin])+list(y[imax+1:]));
				# print xreplace,xkeep,ykeep
				yreplace = interp(xreplace,xkeep,ykeep);
				img_array[i,imin:imax+1] = yreplace;
		if dim == 'row':
			x = range(N);
			for i in range(M):
				y = img_array[:,i];
				xreplace = x[imin:imax+1];
				xkeep = array(list(x[0:imin])+list(x[imax+1:]));
				ykeep = array(list(y[0:imin])+list(y[imax+1:]));
				# print xreplace,xkeep,ykeep
				yreplace = interp(xreplace,xkeep,ykeep);
				img_array[imin:imax+1,i] = yreplace;
		self.set('img_array',img_array);
		return;
		
	def find_match(self,img2,paras0=None,roi=None):
	# this is to adjust img2 = shift(img1)*ratio+bg
		from pydao.tools import shiftnormbg_2match,get_roi;
		import copy;
		img_array=self.get('img_array');
		img_array2=img2.get('img_array');
		N,M=img_array.shape;
		
		if roi is None:
			roi=[0,N,0,M];
		roi1=get_roi(img_array,roi);
		roi2=get_roi(img_array2,roi);
		if paras0 is None:
			ratio=(roi2.max()-roi2.min())/(roi1.max()-roi1.min());
			bg = roi2.min()-roi1.min()*ratio;
			paras0=[0.,0.,ratio,bg];
		print "paras0:",paras0
		arrayshiftnorm,paras=shiftnormbg_2match(roi1,roi2,paras0);
		
		new_mimg=ImgArray();
		new_mimg.set('img_array',copy.copy(img_array));
		new_mimg=new_mimg.shiftnormbg(paras[0],paras[1],paras[2],paras[3]);
		print paras;
		return new_mimg,paras;

	def find_match1(self,img2,paras0=None,roi=None):
		from pydao.tools import match_byshiftnorm,shiftnorm_2match,get_roi;
		import copy;
		img_array=self.get('img_array');
		img_array2=img2.get('img_array');
		N,M=img_array.shape;
		
		if roi is None:
			roi=[0,N,0,M];
		roi1=get_roi(img_array,roi);
		roi2=get_roi(img_array2,roi);
		if paras0 is None:
			ratio=roi2.sum()/roi1.sum();
			paras0=[0.5,0.5,ratio];
		print "paras0:",paras0
		arrayshiftnorm,paras=shiftnorm_2match(roi1,roi2,paras0);
		# arrayshift,paras=match_byshiftnorm(img_array,img_array2,paras0);
		
		new_mimg=ImgArray();
		new_mimg.set('img_array',copy.copy(img_array));
		new_mimg=new_mimg.shiftnorm(paras[0],paras[1],paras[2]);
		print paras;
		return new_mimg,paras;

	def remove_spikes(self,nslope=3):
		print "in ImgArray->remove_spikes"
		from pydao.math import XyDiscreteFun;
		arr = self.get('img_array');
		ave = arr.mean();
		sigma = arr.std();
		N,M = arr.shape;
		x = arange(M);
		nremove = 0;
		for i in range(N):
			row = arr[i,:];
			spect = XyDiscreteFun();
			spect.set('x',x);
			spect.set('y',row);
			xr,yr = spect.remove_spike(nslope=nslope);
			nremove = nremove+len(xr);
			#print xr,yr
			arr[i,:] = spect.get('y');
		x = arange(N);
		for i in range(M):
			row = arr[:,i];
			spect = XyDiscreteFun();
			spect.set('x',x);
			spect.set('y',row);
			xr,yr = spect.remove_spike(nslope=nslope);
			nremove = nremove+len(xr);
			#print xr,yr
			arr[:,i] = spect.get('y');
		self.set('img_array',arr);
		print "pixel change:", nremove,", total:",N*M,float(nremove)/(N*M)*100,"%"
		return;