from pylab import *;

#######################################
# Vectors, assuming Cartesian coordinates
#######################################
def vlen(vector):
	v=array(vector);
	#print "v:",v,type(v);
	l=((v**2).sum())**0.5;
	return l;
	
def vdotprod(v1,v2):
	v_1=array(v1);
	v_2=array(v2);
	return (v_1*v_2).sum();

def vcos(v1,v2):
	co=vdotprod(v1,v2)/vlen(v1)/vlen(v2);
	#print "vcos:",co
	return co;

def vXprod(v_1,v_2):
	v1=array(v_1);
	v2=array(v_2);
	v=(v1[1]*v2[2]-v2[1]*v1[2],v1[2]*v2[0]-v2[2]*v1[0],v1[0]*v2[1]-v2[0]*v1[1]);
	v=array(v);
	return v;

def vnorm(v):
	v1=array(v);
	v1=v1/vlen(v1);
	return v1;

	
#####################################
# 3D vectors and cells, assuming Cartesian coordinates
#####################################
def volume(basis):
	vol=vXprod(array(basis[0]),array(basis[1]));
	#print "vol",vol
	vol=vdotprod(vol,basis[2]);
	return vol;
	
def cell_limits(basis):
	xlimit=None;
	ylimit=None;
	zlimit=None;
	for i0 in range(0,2):
		for i1 in range(0,2):
			for i2 in range(0,2):
				b=i0*basis[0]+i1*basis[1]+i2*basis[2];
				if xlimit is None:
					xlimit=[b[0],b[0]];
				elif xlimit[0]>b[0]:
					xlimit[0]=b[0];
				elif xlimit[1]<b[0]:
					xlimit[1]=b[0];

				if ylimit is None:
					ylimit=[b[1],b[1]];
				elif ylimit[0]>b[1]:
					ylimit[0]=b[1];
				elif ylimit[1]<b[1]:
					ylimit[1]=b[1];
					
				if zlimit is None:
					zlimit=[b[2],b[2]];
				elif zlimit[0]>b[2]:
					zlimit[0]=b[2];
				elif zlimit[1]<b[2]:
					zlimit[1]=b[2];
					
	return array([xlimit,ylimit,zlimit]);
	
	
def angle_line2face(line,face):
	basis=array([line,face[0],face[1]]);
	cosa=volume(basis)/vlen(vXprod(face[0],face[1]))/vlen(line);
	if abs(cosa)>1:
		cosa=sign(cosa);
	alpha=arccos(cosa);
	#print "cosa:",cosa,"alpha:",alpha
	return alpha;
	
def faceintercept(line,face,distance):
	alpha=angle_line2face(line,face);
	intercept=distance/cos(alpha);
	#print "intercept:",intercept
	return abs(intercept);
	
def facedistance(line,face,intercept):
	alpha=angle_line2face(line,face);
	distance=intercept*cos(alpha);
	return abs(distance);

########################################
# Rotations, assuming Cartesian coordinates
########################################	
def rotate2xy(a1,a2):
	la1=vlen(a1);
	la2=vlen(a2);
	a1new=array([la1,0,0]);
	cos12=vcos(a1,a2);
	a2new=array([la2*cos12,la2*sin(arccos(cos12)),0]);
	anew=array([a1new,a2new,zeros(3)]);
	anew=matrix(anew);
	a=array([a1,a2,zeros(3)]);
	a=matrix(a);
	transform=anew/a;
	return (transform,a1new,a2new);
	
def point_face_distance(point,face,vintercept):
	transform,a1new,a2new = rotate2xy(face[0],face[1]);
	pointnew=transform*matrix(point);
	distance=pointnew[2]-vintercept;
	return distance;
	
# vector rotations
def mat_rotate_alongx(angle):
	mat=array([[1,0,0],[0,cos(angle),sin(angle)],[0,-sin(angle),cos(angle)]]);
	#v1=vector*mat;
	return matrix(mat);
	
def mat_rotate_alongy(angle):
	mat=array([[cos(angle),0,-sin(angle)],[0,1,0],[sin(angle),0,cos(angle)]]);
	#v1=vector*mat;
	return matrix(mat);
	
def mat_rotate_alongz(angle):
	mat=array([[cos(angle),sin(angle),0,],[-sin(angle),cos(angle),0],[0,0,1]]);
	#v1=vector*mat;
	return matrix(mat);
	
def mat_rotate2z(vector):
	theta=arccos(vcos(vector,array([0,0,1])));
	if theta==0:
		phi=0;
	else:
		phi=arccos(vcos(array([vector[0],vector[1],0]),array([1,0,0])));
	# print "theta,phi",theta/pi*180,phi/pi*180
	if vector[1]<0:
		phi=2*pi-phi;
	mat1=mat_rotate_alongz(-phi);
	mat2=mat_rotate_alongy(-theta);
	mat=matrix(mat1)*matrix(mat2);
	return mat;
	
def mat_rotation_along(vector,angle):
	mat1=mat_rotate2z(vector);
	mat2=mat_rotate_alongz(angle);
	mat=mat1*mat2*inv(mat1);
	return mat;
	
def rotate_along(axis,angle,vector):
	mat=mat_rotation_along(axis,angle);
	vector_rotated=array(vector*mat)[0];
	return vector_rotated;

########################################
# Translations, assuming Cartesian coordinates
########################################	
def translate_to_1st_cell_1d(x):
	if x>=1:
		move=-1;
	elif x<0:
		move=1;
	else:
		move=0;
	while x>=1 or x<0:
		x=x+move;
	return x;
	
def translate_to_1st_cell(pos):
	# print "pos:",pos
	pos1=array([pos[0],pos[1],pos[2]]);
	for i in range(3):
		pos1[i]=translate_to_1st_cell_1d(pos1[i]);
	# print "pos1:",pos1
	return pos1;

	
##############################################
# Cartesian and Direct
# Cartesian corresponds to the coordinates for the basis [(0,0,1), (0,1,0), (0,0,1)].
# Direct corresponds to the basis different from [(0,0,1), (0,1,0), (0,0,1)];
##############################################
def direct2cartesian(basis,direct):
	cartesian=zeros(3);
	for i in range(len(basis)):
		cartesian=cartesian+basis[i]*direct[i]
	return cartesian;
	
def cartesian2direct1(basis,cartesian):
	direct=zeros(3);
	
	alpha=angle_line2face(cartesian,array([basis[1],basis[2]]));
	direct[0]=cos(alpha)*vlen(cartesian)/vlen(basis[0]);
	
	alpha=angle_line2face(cartesian,array([basis[0],basis[2]]));
	direct[1]=cos(alpha)*vlen(cartesian)/vlen(basis[1]);
	
	alpha=angle_line2face(cartesian,array([basis[1],basis[0]]));
	direct[2]=cos(alpha)*vlen(cartesian)/vlen(basis[2]);
	
	return direct;
	
def cartesian2direct(basis,cartesian):
	indices=dot(cartesian,inv(basis));
	#print indices,direct
	return indices;
	
#################################################
## 3D vectors as objects
#################################################
from pydao.ohdf import OGroup;
class GArrow(OGroup):
	def __init__(self,direction=None,startpoint=zeros(3),length=1):
		OGroup.__init__(self);
		self.set('direction',direction);
		self.set('startpoint',startpoint);
		self.set('length',length);
	
	def copy(self):
		newV = GArrow(self.get('direction'),self.get('startpoint'),self.get('length'));
		return newV;
		
	def angles2direction(self,theta,phi):
		x = sin(theta)*cos(phi);
		y = sin(theta)*sin(phi);
		z = cos(theta);
		direction = array([x,y,z]);
		self.set('direction',direction);
		return;
		
	def rotate(self,axis,angle):
		direction = self.get('direction');
		# print "in GArrow->rotate:"
		# print "input type:",type(axis)
		# print "self type:",type(self);
		if type(axis) is type(self):
			axis_direction = axis.get('direction');
			# print "found GArrow input"
		else:
			axis_direction = axis;
		
		newdirection = rotate_along(axis_direction,angle,direction);
		# self.set('direction',newdirection);
		newV = self.copy();
		newV.set('direction',newdirection);
		return newV;
		
	def reverse(self):
		direction = self.get('direction');
		startpoint = self.get('startpoint');
		length = self.get('length');
		endpoint = startpoint + direction*length;
		startpoint = endpoint;
		direction = - direction;
		
		newV = self.copy();
		newV.set('direction',direction);
		newV.set('startpoint',startpoint);
		#newV = GArrow(direction,startpoint,self.get('length'));
		return newV;
		
	def resize(self,method = 'fixstart',factor=1):
		direction = self.get('direction');
		startpoint = self.get('startpoint');
		length = self.get('length')*factor;
		if method == 'fixend':
			endpoint = startpoint+direction*length/factor;
			startpoint = endpoint-direction*length;
			
		newV = self.copy();
		newV.set('startpoint',startpoint);
		newV.set('length',length);
		# newV = GArrow(direction,startpoint,length);
		return newV;
		
	def get_angles(self):
		direction = self.get('direction');
		theta = arccos(direction[2]/vlen(direction));
		phi = arctan(direction[1]/direction[0]);
		if direction[0]<0:
			phi = phi + pi;
		return theta, phi;
		
	
	def plot(self,text=None,textposition = 'end',resizemethod = None,factor=1):
		from enthought.mayavi import mlab;
		
		if resizemethod is not None:
			arrow = self.resize(resizemethod,factor);
		else:
			arrow = self;
		
		direction = arrow.get('direction');
		startpoint = arrow.get('startpoint');
		length = arrow.get('length');
		vector = direction/vlen(direction)*length;
		mlab.quiver3d([startpoint[0]], [startpoint[1]], [startpoint[2]],[vector[0]],[vector[1]],[vector[2]],scale_mode="none",scale_factor=vlen(vector),mode='2darrow');
		endpoint = startpoint + direction*length;
		if text is not None:
			textwidth = 0.01;
			if textposition == 'end':
				mlab.text(endpoint[0],endpoint[1],text,z=endpoint[2],width=len(text)*textwidth);
			elif textposition == 'start':
				mlab.text(startpoint[0],startpoint[1],text,z=startpoint[2],width=len(text)*textwidth);
			
		