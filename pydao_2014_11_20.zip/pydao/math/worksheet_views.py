from pylab import *;
from pydao.ohdf import OGroup;
from functions import *;
#from tables import *;

def worksheet_view_modify(work_sheet):
	from enthought.traits.ui.api import \
	Item,Group,Tabbed,VGroup,HGroup,View,\
	ArrayEditor,ButtonEditor,CheckListEditor,BooleanEditor,FileEditor,TextEditor;
	from worksheet_controls import WorkSheet_ModelView;
	import pydao;
	from pydao.ohdfvi import analyzable_view_modify;
	
	title=str(work_sheet.get_link());
	handler=WorkSheet_ModelView(work_sheet);
	view=analyzable_view_modify(work_sheet);
	view.handler=handler;
	view.title=title;
	
	menubar=view.menubar;
	menubar=worksheet_menubar(menubar);
	toolbar=worksheet_toolbar(view.toolbar);
	view.menubar=menubar;
	view.toolbar=toolbar;
	return view;

def worksheet_menubar(menubar):
	from enthought.traits.ui.menu import Menu, MenuBar, Action;
	
	disp= Action(name = "Disp",action = "On_disp")
	_import= Action(name = "Import CSV",action = "On_import_csv")
	#set= Action(name = "set",action = "On_group_set_atoms")
	file_menu=Menu(_import,name = 'File');
	view_menu=Menu(disp,name = 'View');
	
	#menubar=MenuBar();
	menubar.append(file_menu)
	menubar.append(view_menu)
	
	return menubar;

def worksheet_toolbar(toolbar=None):
	from enthought.traits.ui.menu import Menu, ToolBar, Action;
	from enthought.pyface.api import ImageResource;
		#from dfunction import imagefilename;		
	disp = Action(name = "Disp",action = "On_disp")
	if toolbar is None:
		toolbar=ToolBar(disp);
	else:
		toolbar.append(disp);
	return toolbar;
	
def worksheet_table_view(work_sheet,buttons=None):
	from enthought.traits.ui.api import Item,Group,View,TabularEditor;
	from enthought.traits.ui.table_column import ObjectColumn;
	from enthought.traits.ui.tabular_adapter import TabularAdapter;
		#from controls import spreadsheet_Spreadsheet_View_Handler;
		
	col_names=work_sheet.col_names();
	adapter=TabularAdapter();
	columns=[];
	for k in col_names:
		columns.append(k);
	adapter.columns=columns;
	editor = TabularEditor(adapter=adapter,editable=True,multi_select=True,operations=[ 'delete', 'insert', 'append', 'edit', 'move' ],clicked='clicked',column_clicked='column_clicked',right_clicked='right_clicked',dclicked='dclicked');
	ssview=View(Group(Item('spreadsheet',editor=editor,resizable = True,id='expeditorid'),show_labels=False),kind='live',width=.5,height=.5,resizable = True,scrollable=True);
	if buttons is not None:
		ssview.buttons=buttons;
	return ssview;
			
def worksheet_table_view_modify(work_sheet,buttons=None,title=None):
	from enthought.traits.ui.menu import Menu, MenuBar;
	from worksheet_controls import WorkSheet_Table_ModelView;
	view=worksheet_table_view(work_sheet,buttons);
	handler=WorkSheet_Table_ModelView(work_sheet);
	view.handler=handler;
	view.menubar=worksheet_table_view_menubar();
	view.toolbar=worksheet_table_view_toolbar();
	if buttons is not None:
		view.buttons=buttons;
	if title is not None:
		view.title=title;
	return view;

def worksheet_table_view_menubar():	
	from enthought.traits.ui.menu import Menu, MenuBar, Action;
	file_export = Action(name = "Export",action = "On_WorkSheet_export")
	filemenu=Menu(file_export,name = 'File');
	menubar = MenuBar(filemenu);
	return menubar;
		
def worksheet_table_view_toolbar():
	from enthought.traits.ui.menu import Menu, ToolBar, Action;
	from enthought.pyface.api import ImageResource;
	toolbar=ToolBar();
	return toolbar;
