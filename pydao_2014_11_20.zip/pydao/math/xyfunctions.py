
	def nthmoment(self,n):
		x=self['x'];
		y=self['y']
		dx=numpy.fabs(numpy.diff(x));
		dx=numpy.hstack((dx,dx[-1]));
		xmean=(x*y*dx).sum()/(y*dx).sum();
		if n==0:
			moment=(y*dx).sum();
		elif n==1:
			moment=xmean;
		else:
			moment=(numpy.power(x-xmean,n)*y*dx).sum()/(y*dx).sum();
		return moment;
	
	def gaussfit(x,y,xmin=None,xmax=None,method=None):
		spect=self.copyxy();
		spect.pick(xmin,xmax);
		x=spect['x'];
		y=spect['y'];
		
		center=spect.nthmoment(1);
		width=spect.nthmoment(2)**0.5;
		amp=spect.nthmoment(0)*2/(max(x)-min(x));
		slope=0;
		intercept=0;
		if method=="baseslope" or method==2:
			paras0=pylab.array([amp,center,width,slope,intercept]);
			paras=scipy.optimize.fmin(self.gaussfit_baseslope_chi2,paras0,args=(x,y));
		elif method=="base" or method==1:
			paras0=pylab.array([amp,center,width,intercept]);
			paras=scipy.optimize.fmin(self.gaussfit_base_chi2,paras0,args=(x,y));
			lp=list(paras)
			lp.append(0);
			paras=numpy.array(lp);
		elif method is None or method==0:
			paras0=pylab.array([amp,center,width]);
			paras=scipy.optimize.fmin(self.gaussfit_chi2,paras0,args=(x,y));
			lp=list(paras);
			lp.append(0);lp.append(0);
			paras=numpy.array(lp);
		return paras;

	def gaussfit_base_chi2(self,paras,x,y):
		#gainfactor=paras[0];
		#shift=paras[1];
		#print "shift and gain:",paras
		amp=paras[0];
		center=paras[1];
		sigma=paras[2];
		slope=0;
		intercept=paras[3];
		
		yfit=amp*numpy.exp(-(x-center)**2/sigma**2/2)+slope*x+intercept;
		check=numpy.core.maximum(numpy.core.fabs(y),numpy.core.fabs(yfit));
		chi2=((yfit-y)**2/check).sum();
		return chi2
		
	def gaussfit_chi2(self,paras,x,y):
		#gainfactor=paras[0];
		#shift=paras[1];
		#print "shift and gain:",paras
		amp=paras[0];
		center=paras[1];
		sigma=paras[2];
		slope=0#paras[3];
		intercept=0#paras[4];
		
		yfit=amp*numpy.exp(-(x-center)**2/sigma**2/2)+slope*x+intercept;
		check=numpy.core.maximum(numpy.core.fabs(y),numpy.core.fabs(yfit));
		chi2=((yfit-y)**2/check).sum();
		return chi2
