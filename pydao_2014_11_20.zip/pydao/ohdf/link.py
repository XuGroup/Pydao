def join(link_tuple,name):
	lt=(link_tuple[0],link_tuple[1]+"/"+name);
	return lt;
	
def link_parse(link_tuple):
	l1=link_tuple[1];
	lname=l1.split('/')[-1];
	ldir=l1.replace("/"+lname,'');
	return (ldir,lname);
	
def valid_link(link_tuple):
	valid=True;
	ldir,lname=link_parse(link_tuple);
	if lname=='':
		valid=False;
	return valid;