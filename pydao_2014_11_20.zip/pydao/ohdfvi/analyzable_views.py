from pylab import *;
from pydao.ohdf import OGroup;
#from tables import *;

def analyzable_view_modify(analyzable):
	from enthought.traits.ui.api import \
	Item,Group,Tabbed,VGroup,HGroup,View,\
	ArrayEditor,ButtonEditor,CheckListEditor,BooleanEditor,FileEditor,TextEditor;
	from analyzable_controls import Analyzable_ModelView;
	import pydao;
	from pydao.ohdfvi import application_group_list_view_modify;
	
	title=str(analyzable.get_link());
	handler=Analyzable_ModelView(analyzable);
	view=application_group_list_view_modify(analyzable,handler=handler,title=title);

	menubar=view.menubar;
	menubar=analyzable_menubar(menubar);
	toolbar=analyzable_toolbar(view.toolbar);
	view.menubar=menubar;
	view.toolbar=toolbar;
	return view;

def analyzable_menubar(menubar):
	from enthought.traits.ui.menu import Menu, MenuBar, Action;
	
	group_set= Action(name = "set",action = "On_OGroupElement_Set")
	group_menu=Menu(group_set,name = 'OGroupElement');
	
	worksheet_calculatenewcolumn= Action(name = "Calculate New Column",action = "On_WorkSheet_CalculateNewColumn")
	worksheet_menu=Menu(worksheet_calculatenewcolumn,name = 'WorkSheet');
	
	menubar.append(worksheet_menu);
	menubar.append(group_menu);
	#menubar=MenuBar();
	#menubar.append(group_menu)
	
	return menubar;

def analyzable_toolbar(toolbar=None):
	from enthought.traits.ui.menu import Menu, ToolBar, Action;
	from enthought.pyface.api import ImageResource;
		#from dfunction import imagefilename;		
	disp = Action(name = "Disp",action = "On_disp")
	if toolbar is None:
		toolbar=ToolBar(disp);
	else:
		toolbar.append(disp);
	return toolbar;