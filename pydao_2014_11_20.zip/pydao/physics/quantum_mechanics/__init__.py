from qmvariable import *;
from oneparticle import *;
from oneparticle_special import *;
from atomic_wavefunction_method import *;
from twoparticles import *;

from xas_oneelectron import *;
coulomb_integral_file="coulomb_intergral.hdf";
exchange_integral_file="exchange_intergral.hdf";