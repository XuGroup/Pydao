from pylab import *;
from pydao.ohdf import OGroup,isnumeric;
import pydao.math;
from qmvariable import QMVariable,WaveFunction,Operator;
from oneparticles import OnePWaveFunction_Xyz;
from twoparticles import Base_Xyz2B;

class MBOperator(Operator):
	def __init__(self):
		Operator.__init__(self);
		self.set('coefficient',1);
		self.set('particle_list',[0]);
		
	def lbaseopstackwfproduct(self,multiplier):
		multi=multiplier.qmvcopy();
		iparticle=self.get('iparticle');
		multi_stack=multi.get('stack');
		pr=self.lbaseopstackwfproduct(multi_stack[iparticle]);
		multi_stack[iparticle]=pr;
		return multi;
		
	def qmvcopy(self,qmv=None):
		if qmv is None:
			qmv=MBOperator();
		qmv.set('particle_list',self.get('particle_list'));
		return qmv;
	
class WaveFunction_Xyz2B(WaveFunction,Base_Xyz2B):
	def __init__(self):
		WaveFunction.__init__(self);
		Base_Xyz2B.__init__(self);
		self.set('coefficient',1);
		self.set('particle_list',[0]);
		
	def set2zero(self):
		self.set2qmvzero();
		self.set2xyz2bzero();
		return;

	def __call__(self,x,y,z,x1,y1,z1):
		wf_subs=self.get('subs');
		coefficient=self.get('coefficient');
		if self.qmvkind()=='base':
			value=Base_Xyz2B.__call__(self,x,y,z,x1,y1,z1);
			value=value*coefficient;
		else:
			value=0;
			for wf in wf_subs:
				value=value+wf(x,y,z,x1,y1,z1);
		return value;
		
	def info(self,indent=0):
		print indent*"|_","<WaveFunction_Xyz2B>"
		WaveFunction.info(self,indent+1);
		if self.qmvkind()=='base':
			Base_Xyz2B.info(self,indent+1);
		
	def baseinnerproduct(self,wf):
		self_cft=self.get('coefficient');
		wf_cft=wf.get('coefficient');
		product=self.baseiproduct_xyz(wf)*self_cft*wf_cft;
		return product;
	
	def qmvcopy(self,qmv=None):
		if qmv is None:
			qmv=WaveFunction_Xyz2B();
			qmv.initqmvkind(self.qmvkind());
		qmv=WaveFunction.qmvcopy(self,qmv);
		if self.qmvkind()=='base':
			qmv=Base_Xyz2B.qmvcopy(self,qmv);
		return qmv;

class Operator_Xyz2B(Operator,Base_Xyz2B):
	def __init__(self):
		Operator.__init__(self);
		Base_Xyz2B.__init__(self);
		self.set('coefficient',1);
		self.set('particle_list',[0]);
	
	def info(self,indent):
		print indent*"|_","<Operator_Xyz2B>"
		Operator.info(self,indent+1);
		Base_Xyz2B.info(self,indent+1);
	
	def baseopwfmultiply(self,multiplier):
		if isinstance(multiplier,OnePWaveFunction_Xyz):	
		return self.basemultiply_xyz(multiplier);
		
	def qmvcopy(self,qmv=None):
		if qmv is None:
			qmv=Operator_Xyz2B();
			qmv.initqmvkind(self.qmvkind());
		qmv=Operator.qmvcopy(self,qmv);
		if self.qmvkind()=='base':
			qmv=Base_Xyz2B.qmvcopy(self,qmv);
		return qmv;
