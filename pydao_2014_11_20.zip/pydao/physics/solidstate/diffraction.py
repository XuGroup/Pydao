from pylab import *;
from pydao.ohdf import OGroup;
from pydao.math import vlen,GArrow;

class Wave(GArrow):
	def __init__(self,type=None,energy=None,wavelength=None,direction=None,startpoint=zeros(3),length=1):
		GArrow.__init__(self,direction=direction,startpoint=startpoint,length=length);
		self.set('energy', energy); # Energy is in J, the SI unit.
		if type is not None and energy is not None:
			self.set('type',type);
			self.energy2wavelength(energy);
		if wavelength is not None:
			self.set('wavelength',wavelength);

	def copy(self):
		newV = GArrow.copy(self);
		newV.set('type',self.get('type'));
		newV.set('energy',self.get('energy'));
		newV.set('wavelength',self.get('wavelength'));
		return newV;
		
	def energy2wavelength(self,energy):
		from pydao.physics import hbar,e_mass,e_charge,v_light,neutron_mass;
		type = self.get('type');

		E = energy;
		if type == 'EM':
			wavelength = hbar*2*pi*v_light/E;
		elif type == 'electron':
			wavelength = hbar*2*pi/(2*e_mass*E);
		elif type == 'neutron':
			wavelength = hbar*2*pi/(2*neutron_mass*E);
		wavelength = wavelength*1e10; # in the unit of angstrom;
		self.set('wavelength',wavelength);
		return wavelength;

class CrystalPlane(OGroup):
	def __init__(self,lattice=None, index=None):
		OGroup.__init__(self);
		self.set('lattice', lattice);
		self.set('index',index);
		if lattice is not None and index is not None:
			self.cal_normal();

	def cal_normal(self):
		index = self.get('index');
		la = self.get('lattice');
		la.cal_kbasis();
		kbasis=la.get('kbasis');
		h,k,l = index;
		planenormal=h*kbasis[0]+k*kbasis[1]+l*kbasis[2];

		normal = GArrow(planenormal,length = vlen(planenormal));
		self.set('normal',normal);
		return planenormal;

	def plot(self):
		from pydao.math import vlen;
		from enthought.mayavi import mlab;
		normal = self.get('normal');
		lat = self.get('lattice');
		planenormal =normal.get('direction');
		plane_kx=planenormal[0]/planenormal[2];
		plane_ky=planenormal[1]/planenormal[2];

		x,y=mgrid[-100:101,-100:101]/100*vlen(lat.get('basis')[0]);
		z=-plane_kx*x-plane_ky*y;
		planenormal=planenormal/vlen(planenormal)*6;
		mlab.mesh(x,y,z,opacity=0.5);
		normal.plot('normal');
		lat.plot3d_basis(labelwidth = 0.01);

class CystalDiffraction(OGroup):
	def __init__(self,plane=None, incidentwave=None):
		OGroup.__init__(self);
		self.set('plane', plane);
		self.set('incidentwave',incidentwave);

	def cal_theta(self):
		from pydao.math import vlen;

		incidentwave = self.get('incidentwave');
		wavelength = incidentwave.get('wavelength');

		plane = self.get('plane');
		normal = plane.get('normal');
		Glen = normal.get('length');
		theta = arcsin(Glen*wavelength/4./pi);
		self.set('theta',theta);
		return theta;

	def angle_range(self):
		from pydao.math import vXprod;
		plane = self.get('plane');
		normal = plane.get('normal');
		theta = self.get('theta'); # this is the half of the 2theta

		normal_direction = normal.get('direction');
		axis1 = vXprod(normal_direction, array([0,0,1]));
		axis2 = vXprod(normal_direction,axis1);

		incident0_arrow = normal.rotate(axis1,pi/2-theta);

		rotationrange = arange(0,360,0.1)/180.*pi;
		thetacs = rotationrange-rotationrange;
		phics = rotationrange-rotationrange;
		i =  0;
		for rotation in rotationrange:
			# print "i:",i;
			incident = incident0_arrow.rotate(normal,rotation);
			thetac,phic = incident.get_angles();
			thetacs[i] = thetac;
			phics[i] = phic;
			i = i+1;
		#incident2 = normal.rotate(axis1,-pi/2+theta);
		#incident3 = normal.rotate(axis2,pi/2-theta);
		#incident4 = normal.rotate(axis2,-pi/2+theta);
		#theta1, phi1 = incident1.get_angles(); # this is the theta angle in the x,y,z coordinate system
		#theta2, phi2 = incident2.get_angles();
		#theta3, phi3 = incident3.get_angles();
		#theta4, phi4 = incident4.get_angles();
		#thetamin = min([theta1,theta2,theta3,theta4]);
		#thetamax = max([theta1,theta2,theta3,theta4]);
		#phimin = min([phi1,phi2,phi3,phi4]);
		#phimax = max([phi1,phi2,phi3,phi4]);

		return rotationrange,thetacs,phics;

	def thetac2phic(self,thetac):
		plane = self.get('plane');
		normal = plane.get('normal');
		plane_normal = normal.get('direction');
		theta = self.get('theta');

		phicrange = arange(0,pi,pi/100000);
		r = plane_normal[0]*sin(thetac)*cos(phicrange)+plane_normal[1]*sin(thetac)*sin(phi)+plane_normal[2]*cos(thetac);
		f = abs(sin(theta)-r/((sin(thetac)*cos(phicrange))**2+(sin(thetac)*sin(phicrange))**2+cos(thetac)**2)**0.5/vlen(plane_normal));
		fmin = min(f);
		I = list(f).index(fmin);
		phic = phicrange[I];
		return phic;

	def phic2thetac(self,phic):
		plane = self.get('plane');
		normal = plane.get('normal');
		plane_normal = normal.get('direction');
		theta = self.get('theta');

		#print "plane_normal,theta:",plane_normal,theta

		thetacrange = arange(0,pi,pi/100000);
		xs = sin(thetacrange)*cos(phic);
		ys = sin(thetacrange)*sin(phic);
		zs = cos(thetacrange);
		r = plane_normal[0]*xs+plane_normal[1]*ys+plane_normal[2]*zs;
		f = abs(sin(theta)-r/vlen(plane_normal));
		fmin = min(f);
		I = list(f).index(fmin);
		thetac = thetacrange[I];
		return thetac;

	def align_incident(self,thetac=None,phic=None):
		#print "in align_incident:",thetac,phic
		if phic is None and thetac is not None:
			phic = self.thetac2phic(thetac);
		elif phic is not None and thetac is None:
			thetac = self.phic2thetac(phic);
		else:
			print "in align_incident, no input of angle!"
		incidentwave = self.get('incidentwave');
		incidentwave.angles2direction(thetac,phic);
		# print "direction:",incidentwave.get('direction');
		# print "startpoint:",incidentwave.get('startpoint');
		incidentwave = incidentwave.reverse();
		self.set('incidentwave',incidentwave);
		return incidentwave;

	def find_diffracted(self):
		from pydao.math import vXprod;
		from pydao.physics import Wave;
		theta = self.get('theta');

		incidentwave = self.get('incidentwave');

		diffracted = incidentwave.reverse();

		plane = self.get('plane');
		normal = plane.get('normal');

		normal_direction = normal.get('direction');
		axis1 = vXprod(normal_direction, diffracted.get('direction'));
		diffracted = diffracted.rotate(axis1,-2*(pi/2-theta));

		self.set('diffractedwave',diffracted);
		return diffracted;
