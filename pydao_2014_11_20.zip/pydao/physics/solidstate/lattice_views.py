from pylab import *;
from pydao.ohdf import OGroup;
from functions import *;
#from tables import *;

def lattice_analysis_view(lattice):
	from enthought.traits.ui.api import \
	Item,Group,Tabbed,VGroup,HGroup,View,\
	ArrayEditor,ButtonEditor,CheckListEditor,BooleanEditor,FileEditor;
	from lattice_controls import Lattice_ModelView;
	import pydao;
	
	handler=Lattice_ModelView(lattice);
	
	#print "in OnAnalyze"
	#lattice.atom_list_name=['atoms'];
	#lattice.basis_name=['basis'];
	lattice.atom_list_name=str(lattice.get_link('atoms'));
	lattice.basis_name=str(lattice.get_link('basis'));
		
	editor1=CheckListEditor(values=lattice.keys());
	editor2=CheckListEditor(values=lattice.keys());
	
	#item1=Item('atom_list_name',editor=editor1);
	#item2=Item('basis_name',editor=editor2);
	item1=Item('atom_list_name');
	item2=Item('basis_name');
	Group1=Group(item1,item2);
		
	lattice.cif_filename='';
	lattice.xyz_filename='';
	
	lattice.cif_filename=pydao.viewer.history_file.get('path_open');
	lattice.xyz_filename=pydao.viewer.history_file.get('path_open');
	
	group_imp_basis=Group(
	Item('cif_filename',editor=FileEditor(),style='simple',show_label=True),\
	Item('bu_import_basis',editor=ButtonEditor(label='import')),\
	show_labels=False,show_border = True,label='basis');
		
	group_imp_atompos=Group(
	Item('xyz_filename',editor=FileEditor(),style='simple',show_label=True),\
	Item('bu_import_atoms_fromxyz',editor=ButtonEditor(label='import')),\
	show_labels=False,show_border = True,label='atom positions');
		
	group_import=VGroup(group_imp_basis,group_imp_atompos,
	show_labels=False,show_border = True,label='Import');

	Group2=VGroup(Item('bu_unify_coordinates',editor=ButtonEditor(label='unify_coordinates')),\
	Item('bu_cal_k_basis',editor=ButtonEditor(label='cal_k_basis')),\
	Item('bu_register_nearest',editor=ButtonEditor(label='register_nearest')),\
	Item('bu_register_neighbor',editor=ButtonEditor(label='register_neighbor')),\
	Item('bu_cal_neighbor_matPhi',editor=ButtonEditor(label='cal_neighbor_matPhi')),\
	show_labels=False,show_border = True,label='Analysis');

	lattice.coordinate=['direct'];
	lattice.displacement=zeros(3);
	lattice.transfomation_matrix=[lattice.keys()[0]];
	lattice.new_atom_list_name='new_atoms';
	lattice.new_basis_name='new_basis';
	lattice.displace_intrapos=True;
	editor3=CheckListEditor(values=lattice.keys());
	#editor2=CheckListEditor(values=lattice.keys());
		
	Group3=VGroup(\
	Item('displacement',editor=ArrayEditor(),show_label=True,width=0.1),\
	Item('coordinate',editor=CheckListEditor(values=['direct','cartesian']),show_label=True),\
	Item('new_atom_list_name',show_label=True),\
	Item('displace_intrapos',editor=BooleanEditor(),show_label=True),\
	Item('bu_translate_atoms',editor=ButtonEditor(label='translate_atoms')),\
	Item('transfomation_matrix',editor=editor3,show_label=True),\
	Item('new_basis_name',show_label=True),\
	Item('bu_transform_basis',editor=ButtonEditor(label='transform_basis')),\
	Item('bu_intra_pos_direct2Cartesian',editor=ButtonEditor(label='intra_pos_direct2Cartesian')),\
	Item('bu_intra_pos_Cartesian2direct',editor=ButtonEditor(label='intra_pos_Cartesian2direct')),\
	show_labels=False,show_border = True,label='Tools');

	lattice.color=zeros(3);
	lattice.atom_name=lattice.get('atoms').keys()[0];
	Group4=VGroup(\
	Item('color',show_label=True,editor=ArrayEditor()),\
	Item('atom_name',show_label=True),\
	Item('bu_plot_atoms',editor=ButtonEditor(label='plot_atoms')),\
	Item('bu_plot_basis',editor=ButtonEditor(label='plot_basis')),\
	Item('bu_plot_primitive_cell',editor=ButtonEditor(label='plot_primitive_cell')),\
	Item('bu_plot_kbasis',editor=ButtonEditor(label='plot_kbasis')),\
	Item('bu_plot_nearest',editor=ButtonEditor(label='plot_nearest')),\
	Item('bu_plot_neighbors',editor=ButtonEditor(label='plot_neighbors')),\
	show_labels=False,show_border = True,label='View');
		
	view=View(VGroup(Group1,Tabbed(group_import,Group2,Group3,Group4)),handler=handler,kind='live');
	#lattice.configure_traits(view=view);
	return view;
	
# def lattice_program_view(lattice):
	# from enthought.traits.ui.api import \
	# Item,Group,Tabbed,VGroup,HGroup,View,\
	# ArrayEditor,ButtonEditor,CheckListEditor,BooleanEditor,FileEditor,TextEditor;
	# from lattice_controls import Lattice_Program_ModelView;
	# import pydao;
	
	# handler=Lattice_Program_ModelView(lattice);
	# lattice.intro=str(lattice);
	# print "intro:",lattice.intro
	# menubar=lattice_program_view_menubar();
	
	# view=View(Item('intro',style='readonly'),handler=handler,kind='live',buttons=['OK','Cancel'],title=str(lattice.get_link()),menubar=menubar,height=0.3,width=0.3);
	# return view;
	
def lattice_program_view_modify(lattice):
	from enthought.traits.ui.api import \
	Item,Group,Tabbed,VGroup,HGroup,View,\
	ArrayEditor,ButtonEditor,CheckListEditor,BooleanEditor,FileEditor,TextEditor;
	from lattice_controls import Lattice_Program_ModelView;
	import pydao;
	from pydao.ohdfvi import application_view_modify;
	
	title=str(lattice.get_link());
	handler=Lattice_Program_ModelView(lattice);
	view=application_view_modify(lattice,handler=handler,title=title);
	
	#view=lattice.trait_view();
	#view=lattice.app_view;
	menubar=lattice_program_view_menubar();
	toolbar=lattice_program_view_toolbar()
	view.menubar=menubar;
	view.toolbar=toolbar;
	#lattice.trait_view('');
	#view=View(Item('intro',style='readonly'),handler=handler,kind='live',buttons=['OK','Cancel'],,menubar=menubar,height=0.3,width=0.3);
	return view;
	
def lattice_program_view_menubar():
	from enthought.traits.ui.menu import Menu, MenuBar, Action;
	
	import_basis= Action(name = "import basis",action = "On_import_basis")
	import_atoms= Action(name = "import atoms",action = "On_import_atoms")
	import_menu=Menu(import_basis,import_atoms,name = 'Import');
	
	filter_atoms_primitivecell = Action(name = "filter atoms using primitive cell",\
	action = "On_filter_atoms_primitivecell")
	transform_basis= Action(name = "transform basis",action = "On_transform_basis")
	translate_atoms= Action(name = "translate atoms",action = "On_translate_atoms")
	intra_pos_direct2Cartesian=Action(name = "intra_pos_direct2Cartesian",\
	action = "On_intra_pos_direct2Cartesian")
	intra_pos_Cartesian2direct=Action(name = "intra_pos_Cartesian2direct",\
	action = "On_intra_pos_Cartesian2direct")
	modify_menu=Menu(filter_atoms_primitivecell,transform_basis,\
	translate_atoms,intra_pos_direct2Cartesian,intra_pos_Cartesian2direct,name = 'Modify');
	
	unify_coordinates=Action(name = "unify coordinates",action = "On_unify_coordinates")
	register_nearest=Action(name = "register nearest",action = "On_register_nearest")
	register_neighbor=Action(name = "register neighbor",action = "On_register_neighbor")
	cal_k_basis=Action(name = "cal k basis",action = "On_cal_k_basis")
	cal_neighbor_matPhi=Action(name = "cal_neighbor_matPhi",\
	action = "On_cal_neighbor_matPhi")
	analyze_menu=Menu(unify_coordinates,register_nearest,\
	register_neighbor,cal_k_basis,cal_neighbor_matPhi,name = 'Analyze');
	
	plot_atoms=Action(name = "plot_atoms",action = "On_plot_atoms");
	plot_basis=Action(name = "plot_basis",action = "On_plot_basis");
	plot_kbasis=Action(name = "plot_kbasis",action = "On_plot_kbasis");
	plot_nearest=Action(name = "plot_nearest",action = "On_plot_nearest");
	plot_neighbors=Action(name = "plot_neighbors",action = "On_plot_neighbors");
	plot_primitive_cell=Action(name = "plot_primitive_cell",\
	action = "On_plot_primitive_cell");
	plot_Brillouin_zone=Action(name = "plot_Brillouin_zone",\
	action = "On_plot_Brillouin_zone");
	view_menu=Menu(plot_atoms,plot_basis,plot_kbasis,\
	plot_nearest,plot_neighbors,plot_primitive_cell,plot_Brillouin_zone,name = 'View');
	
	return MenuBar(import_menu,modify_menu,analyze_menu,view_menu);
	
def lattice_program_view_toolbar(toolbar=None):
	from enthought.traits.ui.menu import Menu, ToolBar, Action;
	from enthought.pyface.api import ImageResource;
		#from dfunction import imagefilename;		
	plot_atoms = Action(name = "Atoms",action = "On_plot_atoms_button")
	plot_cell = Action(name = "Cell",action = "On_plot_primitive_cell_button")
	if toolbar is None:
		toolbar=ToolBar(plot_atoms,plot_cell);
	else:
		toolbar.append(plot_atoms);
		toolbar.append(plot_cell);
	return toolbar;


def lattice_program_group_view_modify(lattice):
	from enthought.traits.ui.api import \
	Item,Group,Tabbed,VGroup,HGroup,View,\
	ArrayEditor,ButtonEditor,CheckListEditor,BooleanEditor,FileEditor,TextEditor;
	from lattice_controls import Lattice_Program_Group_ModelView;
	import pydao;
	from pydao.ohdfvi import application_group_view_modify;
	
	title=str(lattice.get_link());
	handler=Lattice_Program_Group_ModelView(lattice);
	view=application_group_view_modify(lattice,handler=handler,title=title);

	menubar=lattice_program_group_view_menubar();
	toolbar=lattice_program_view_toolbar();
	view.menubar=menubar;
	view.toolbar=toolbar;
	return view;

def lattice_program_group_view_menubar():
	from enthought.traits.ui.menu import Menu, MenuBar, Action;
	group_set= Action(name = "group_set",action = "On_group_set_atoms")
	set_menu=Menu(group_set,name = 'set');
	
	return MenuBar(set_menu);

def lattice_program_group_list_view_modify(lattice):
	from enthought.traits.ui.api import \
	Item,Group,Tabbed,VGroup,HGroup,View,\
	ArrayEditor,ButtonEditor,CheckListEditor,BooleanEditor,FileEditor,TextEditor;
	from lattice_controls import Lattice_Program_Group_List_ModelView;
	import pydao;
	from pydao.ohdfvi import application_group_list_view_modify;
	
	title=str(lattice.get_link());
	handler=Lattice_Program_Group_List_ModelView(lattice);
	view=application_group_list_view_modify(lattice,handler=handler,title=title);

	menubar=view.menubar;
	menubar=lattice_program_group_list_view_menubar(menubar);
	toolbar=lattice_program_view_toolbar(view.toolbar);
	view.menubar=menubar;
	view.toolbar=toolbar;
	return view;

def lattice_program_group_list_view_menubar(menubar):
	from enthought.traits.ui.menu import Menu, MenuBar, Action;
	
	group_set= Action(name = "group_set_list",action = "On_group_set_atoms")
	set_menu=Menu(group_set,name = 'set');
	
	#menubar=MenuBar();
	menubar.append(set_menu)
	
	return menubar;
