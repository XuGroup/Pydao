from pylab import *;
from  pydao.ohdfvi import Application;
from  pydao.ohdf import OGroup;
from  pydao.physics import electromagnetism;

class EMWSpect_Ana(OGroup,Application):

	def __init__(self):
		OGroup.__init__(self);
		
	def contextmenu(self,parentmenu):
		Application.contextmenu(self,parentmenu);
		import wx;
		item=parentmenu.Append(wx.NewId(),"New EMWSpect","New EMWSpect");
		parentmenu.Bind(wx.EVT_MENU,self.OnNewEMWSpect,item)
		
		item=parentmenu.Append(wx.NewId(),"Load EMWSpect","Load EMWSpect");
		parentmenu.Bind(wx.EVT_MENU,self.OnLoadEMWSpect,item)
		
		item=parentmenu.Append(wx.NewId(),"New Config","New Config");
		parentmenu.Bind(wx.EVT_MENU,self.OnNewConfig,item);
		
		item=parentmenu.Append(wx.NewId(),"Analyze","Analyze");
		parentmenu.Bind(wx.EVT_MENU,self.OnAnalyze,item);

#============================On call methods=========================================

	def OnLoadEMWSpect(emspa,event):
		from pydao.physics import Spectrum;
		#print "in OnLoadEMWSpect"
		Spect=Spectrum();
		emspa.set('lattice',lattice);
		print "default lattice constructed"
			
	def OnNewConfig(emspa,event):
		config=OGroup();
		config.set('source_folder','');
		config.set('k_direction',array([1,0,0]));
		#config.set('k_direction_list',
		ldc.set('config',config);
		print "new ldc done."

	def OnAnalyze(ldc,event):
		from ldc_view import ldc_analysis_view;
		view=ldc_analysis_view(ldc);
		ldc.configure_traits(view=view);

# =================================methods========================================	
	def get_spectrum(ldc,i_dim):
		i_polar=1;
		multiplename='multiple'+str(i_polar);
		result=ldc.get('result');
		multiple=result.get(multiplename);
		Emat=result.get('Emat');
			
		shape=multiple.shape;
		#plot(Emat[:,0],abs(multiple[:,i_polar]),'o-');
		spectrum=(Emat[:,0],abs(multiple[:,i_dim]))
		result.set('spectrum'+str(i_dim),spectrum)
		return spectrum;