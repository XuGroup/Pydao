from pylab import *;
import pydao;
ogroup=pydao.viewer.current_explorer.get_current_ogroup();
lat=ogroup.get('lattice');
strength=3;
B=8e-1

Imat,SzMat=lat.NNIsingHamiltonian(strength,lat.get('atoms3'));
Hmat=Imat+SzMat*B
E,V=eigh(Hmat);
print Imat
#plot(E,'o-')

#hear capacity
Tmax=3.;
TRange=arange(Tmax/1e5,Tmax,Tmax/500);
ERange=TRange-TRange;
iT=-1;
for T in TRange:
	iT=iT+1;
	ERange[iT]=diag(matrix(exp(-Hmat/T))*matrix(Hmat)).sum()/diag(matrix(exp(-Hmat/T))).sum();
plot(TRange[1:],diff(ERange),'o-');
xlabel('Temperature ');
ylabel('Specific Heat');
legend(['J='+str(strength)]);

# magnetization
# strength=2;
# J=0.5;

# Tmax=5.;
# Bmax=10*Tmax/10;

# BRange=arange(Bmax/1000,Bmax,Bmax/500);
# TRange=arange(Tmax/100,Tmax,Tmax/2);

# Sz2D=zeros([len(TRange),len(BRange)]);

# iT=-1
# for T in TRange:
	# iT=iT+1;
	# x=J*BRange/T;

	# SzRange=lat.MT(T,BRange,strength,lat.get('atoms3'));
	# Sz2D[iT,:]=SzRange;
	#plot(x,SzRange/3/J,'o-');

# from enthought.mayavi import mlab;
# extent=[TRange.min(),TRange.max(),BRange.min(),BRange.max(),Sz2D.min(),Sz2D.max()];
# s=mlab.surf(TRange,BRange,Sz2D,warp_scale=(TRange.max()-TRange.min())/Sz2D.max(),extent=extent);
# mlab.outline();

#Br=(2*J+1)/2/J/tanh((2*J+1)/2/J*x)-1./2/J/tanh(x/2/J);
#plot(x,Br);
#grid(True);

#xlabel('JB/T')
#ylabel('M/J per site')
#legend(['M spin liquid','Brillouvin'],4);
