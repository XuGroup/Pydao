from pylab import *;
import copy;

def find_closest_index(data_dict,i_list,vname,value):
	absdiff=abs(data_dict[vname][i_list]-value);
	i=list(absdiff).index(min(absdiff));
	index=i_list[i]
	return index;

def filter_data_firstj(data,criteria):
	tof=criteria
	return recordlist;

def filter_data_firstj1(data_dict,i_list,j_list,vname,criteria):
	recordlist=[];
	for i in i_list:
		cmd=vname+"=data_dict['"+vname+"']";
		exec(cmd);

		vname1=vname+'[i][j_list]'
		criteria1=criteria.replace(vname,vname1);
		cmd='torf='+criteria1; # torf means true or false
		exec(cmd);
		#print "torf shape",torf.shape
		reshape(torf,len(j_list));
		#print "torf shape",torf.shape
		j_listnew=j_list[torf];
		if len(j_listnew)>0:
			record={};
			record['Row']=i;
			record['Column']=j_listnew[0];
			j=j_listnew[0];
			cmd='record[vname]='+vname+'[i][j]';
			exec(cmd);
			recordlist.append(record);
	return recordlist;

def lowest_deep_convect(cloud_scenario):
	indices=mod(cloud_scenario/2,16)==8;
	shape=cloud_scenario.shape;
	#print "type:",type(indices),type(indices[0]),indices.shape,indices[0].shape
	for i in range(shape[0]):
		indices[i]=first_true(indices[i]);
	return indices;

def first_true(indices):
	indices1=copy.deepcopy(indices);
	I=arange(len(indices1));
	i1st=I[indices1];
	if len(i1st)>0:
		i1st=i1st[0];
		tof=I>I;
		tof[i1st]=True;
		indices1=tof;
	return indices1;
	
def getMedian(numericValues):
	theValues = sorted(numericValues)
	if len(theValues) % 2 == 1:
		return theValues[(len(theValues)+1)/2-1]
	else:
		lower = theValues[len(theValues)/2-1]
		upper = theValues[len(theValues)/2]
	return (float(lower + upper))/2;