import os;

#===================================
def wherepackageis():
	ps=os.path.abspath(__file__);
	for i in range(2):
		ps=os.path.dirname(ps);
	return ps;	
	
def packagerootdir():
	ps=os.path.abspath(__file__);
	for i in range(1):
		ps=os.path.dirname(ps);
	return ps;
	
def packagename():
	ps=os.path.abspath(__file__);
	for i in range(1):
		ps=os.path.dirname(ps);
	fs=os.path.split(ps);
	f=fs[1];
	return f;
	
def setpath():
	import etc;
	path2add=[];
	packname=packagename();
	
	packpath=wherepackageis();
	path2add.append(packpath);
	
	rootpath=packagerootdir();
	#path2add.append(rootpath);
	
	addonpath=os.path.join(rootpath,etc.plugindir);
	path2add.append(addonpath);
	
	#dlibpath=os.path.join(rootpath,etc.libdir);
	#path2add.append(dlibpath);
	
	d3rdpath=os.path.join(rootpath,etc.thirdpartydir);
	path2add.append(d3rdpath);
	
	print "Path added:"
	for p in path2add:
		addpath(p);
		print p
	return;

def addpath(path2add):
	import sys;
	if sys.path.count(path2add)==0:
		sys.path.append(path2add);

#--------------------------------------------------------------------
def gohome():
	import os;
	#global homedir;
	import pydao;
	#print "homedir:",pydao.homedir
	os.chdir(pydao.homedir);

def cog():
	import pydao;
	viewer=pydao.viewer;
	return viewer.current_explorer.get_current_ogroup();
	
#-------------------------------------------------------------------

def importcmd(importname,modname=None):
	if type(modname) is list:
		if modname[0]==packagename():
			mname=packagename()
		else:
			mname=modname[0]
		for i in range(len(modname)-2):
			mname=mname+"."+modname[i+1];
	elif type(modname) is str:
		mname=packagename()+"."+modname;
	else:
		mname=packagename();
	cmd="from "+mname+" import "+importname;
	return cmd;
	
def getimagedir():
	import os;
	from etc import imagedir;
	rootpath=packagerootdir();
	imagedir1=os.path.join(rootpath,imagedir);
	return imagedir1;

def getlibdir():
	import os;
	from etc import libdir;
	rootpath=packagerootdir();
	libdir1=os.path.join(rootpath,libdir);
	return libdir1;

def getplugindir():
	import os;
	from etc import libdir;
	rootpath=packagerootdir();
	libdir1=os.path.join(rootpath,libdir);
	return libdir1;
	
def imagefullfilename(fname):
	import os;
	imagedir=getimagedir();
	fullfilename=os.path.join(imagedir,fname);
	#print "imagefile:",fullfilename
	return fullfilename;

#===========================================================
def add_extended_methods(self, methods):
	import inspect,pydao,time;
	#print "pydao.globmgr.lazy_reload",pydao.globmgr.lazy_reload
	#t0=time.time();
	if not methods.lazy and not pydao.etc.globalcfg.lazy_reload:
		reload(methods);
		#print "reload methods",methods,"in add_extended_methods"
	self.methods=methods;
	
	#t1=time.time();
	modulefile=inspect.getfile(methods);
	modulefile=modulefile.replace('.pyc','.py');
	#t2=time.time();
	for k in methods.__dict__.keys():
		#print 't1',time.time()-t2
		expr="methods."+k;
		v=eval(expr);
		if inspect.isfunction(v) and inspect.getfile(v)==modulefile:
			import new;
			cmd="self."+k+"=new.instancemethod(methods."+k+", self, type(self))";
			exec(cmd);
			#print 't2',time.time()-t2
	#t3=time.time();
	
	if pydao.etc.globalcfg.add_extended_methods_count.has_key(str(methods)):
		count=pydao.etc.globalcfg.add_extended_methods_count[str(methods)];
		count=count+1;
	else:
		count=1;
	pydao.etc.globalcfg.add_extended_methods_count[str(methods)]=count;
	
	if not methods.lazy and not pydao.etc.globalcfg.lazy_reload:
		if pydao.etc.globalcfg.reload_extended_methods_count.has_key(str(methods)):
			count=pydao.etc.globalcfg.reload_extended_methods_count[str(methods)];
			count=count+1;
		else:
			count=1;
		pydao.etc.globalcfg.reload_extended_methods_count[str(methods)]=count;
	t4=time.time();
	#print "add_extended_methods",t1-t0,t2-t1,t3-t2,t4-t3;
	
def add_temp_path1(fileobj):
	import os,sys,inspect;
	abspath=inspect.getabsfile(fileobj);
	#abspath=os.path.abspath(abspath);
	print "abspath:",abspath
	abspath=os.path.dirname(abspath);
	sys.path.append(abspath);
	
def remove_temp_path1(fileobj):
	import os,sys,inspect;
	abspath=inspect.getabsfile(fileobj);
	#abspath=os.path.abspath(abspath);
	abspath=os.path.dirname(abspath);
	sys.path.remove(abspath);
	
#============================================================
def passed_filename_filter(filename,filter):
	passed=True;
	ffilename=filter;
	#ffilename=filter.get('filename');
	#print "filename:",filename;
	
	contain=ffilename.get('contain');
	if contain is not None and contain!='':
		if type(contain) is str:
			contain_list=[contain];
		else:
			contain_list=contain;
		for ct in contain_list:
			if filename.find(ct.encode('ascii'))==-1:
				passed=False;
				#print filename, 'does not contain',ct
				#print filename.count(ct),filename.find(ct)
				print "contain not passed"
				if type(ct) is not str:
					print 'contain filter has wrong type:',type(ct)
				break;
			#print "looking for:",ffilename.get('contain'),
		
	exclude=ffilename.get('exclude');
	if exclude is not None and exclude!='':
		if type(exclude) is str:
			exclude_list=[exclude];
		else:
			exclude_list=exclude;
		for ct in exclude_list:
			if filename.find(ct)!=-1:
				passed=False;
				print "exclude not passed"
				if type(ct) is not str:
					print 'contain filter has wrong type:',type(ct)
				break;
				
	if passed and  ffilename.get('beginwith') is not None and ffilename.get('beginwith')!='':
		ct=ffilename.get('beginwith');
		if not filename.startswith(ct):
			passed=False;
			if type(ct) is not str:
				print 'contain filter has wrong type:',type(ct)
			print "beginwith not passed"
	if passed and  ffilename.get('endwith') is not None and ffilename.get('endwith')!='':
		ct=ffilename.get('endwith');
		if not filename.endswith(ct):
			passed=False;
			if type(ct) is not str:
				print 'contain filter has wrong type:',type(ct)
			print "endwith not passed"
	return passed;