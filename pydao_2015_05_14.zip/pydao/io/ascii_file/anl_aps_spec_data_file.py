from pylab import *;
from scipy.optimize import fmin;
from pydao.ohdf import OGroup;
from pydao.database import Relation_Table;
from nummatrixcsv import NumMatrixCSV;
from pydao.ohdf import sscan;

# For the SPEC datafile: one file contains multiple scans
# So here we load the datafile and analyze that to get individual scans.
class ANLAPSSPEC_DataFile(NumMatrixCSV):
	def __init__(self,filename=None, Ndim=None,shape=None,dilimiter='\t'):
		NumMatrixCSV.__init__(self,filename=filename,dilimiter=dilimiter,row_width_chosen=None);
		self.set('nscan',0);
#		self.set('scan_content',None);
#		self.set('scan_num_matrix',None);
		
	def n_scans(self):
		fstr=self.get('textcontent');
		nscan=0;
		for line in fstr:
			fields=line.split();
			if len(fields)>1:
				if fields[0]=="#S":
					nscan=nscan+1;
		self.set('nscan',nscan);
		return nscan;
		
	def get_nscans(self):
		return self.get_nblocks("#S");
	
	def get_scan1(self,iscan):
		textcontent=self.get('textcontent');
		scan=ANLAPSSPEC_Scan();
		scan_content=[]
		jscan=0;
		for line in textcontent:
			fields=line.split();
			if len(fields)>1:
				if fields[0]=="#S":
					jscan=int(fields[1]);
					#print jscan,iscan,jscan>iscan
			if jscan==iscan:
				scan_content.append(line);
			elif jscan>iscan:
				break;
		scan.set('textcontent',scan_content);
		scan.set('iscan',iscan);
		scan.analyze();
		return scan;
		
	def get_scansequence1(self,iscanlist=None):
		if iscanlist is None:
			nscan=self.get('nscan');
			iscanlist=range(1,nscan+1);
		scansequence=ANLAPSSPEC_Sequence();
		for iscan in iscanlist:
			#print "iscan:",iscan
			scan=self.get_scan(iscan);
			scansequence.append(scan);
		scansequence.set('iscanlist',iscanlist);	
		return scansequence;
		
	def get_scansequence_all(self):
		scansequence=ANLAPSSPEC_Sequence();
		nblocks=self.get_nscans();
		for iblock in range(nblocks):
			block=self.get_block(iblock,'#S');
			scan=ANLAPSSPEC_Scan();
			scan.set('textcontent',block.get('textcontent'));
			scan.analyze();
			scansequence.append(scan);
		self.set('scansequence',scansequence);
		return scansequence;
		
	def get_scansequence(self,iscanlist=None):
		scansequence=ANLAPSSPEC_Sequence();
		scansequence_all=self.get('scansequence');
		if scansequence_all is None:
			scansequence_all=self.get_scansequence_all();

		for scan in scansequence_all.get('sequence'):
			iscan=scan.get('iscan');
			if iscanlist is None:
				scansequence.append(scan);
			else:
				n=iscanlist.count(iscan);
				if n>0:
					scansequence.append(scan);
		return scansequence;
		
	def analyze_scan_dbase(self,iblock_start=0,iblock_end=None):
		scansequence=ANLAPSSPEC_DataBase(idname="iscan");
		nblocks=self.get_nscans();
		if iblock_end is None or iblock_end<0:
			iblock_end=nblocks;
		iblock1=max(iblock_start,0);
		from pydao.tools import Progress_Teller;
		pt=Progress_Teller(nblocks);
		for iblock in range(iblock_start,iblock_end):
			block=self.get_block(iblock,'#S');
			scan=ANLAPSSPEC_Scan();
			scan.set('textcontent',block.get('textcontent'));
			nummatrix=scan.analyze();
			if nummatrix is not None:
				scansequence.append(scan);
			pt.tell(iblock);
		self.set('scansequence',scansequence);
		return scansequence;

	def get_scan(self,iscan):
		scansequence=self.get_scansequence([iscan]);
		scan=scansequence.get('sequence')[0];
		return scan;
		
	def plotscan(self,iscan,xname,yname,pstyle='-'):
		scan=self.get_scan(iscan);
		x=scan.get_col(xname);
		y=scan.get_col(yname);
		plot(x,y,pstyle);
		return x,y;
		
	def get_scan_col(self,iscan,colname):
		scan=self.get_scan(iscan);
		scan_col=scan.get_col(colname);
		return scan_col;
	
class ANLAPSSPEC_DataBase(Relation_Table):
	def __init__(self,rows=None,idname=None):
		Relation_Table.__init__(self,rows,idname);
		# if type(rows) is ANLAPSSPEC_DataBase:
			# self.set('rows',rows.get('rows'));
			# self.set('idname',rows.get('idname'));
		
	def plot(self,xname=None,yname=None,pstyle="o-"):
		rows=self.get('rows');
		legendlist=[];
		for scan in rows:
			iscan=scan.get('iscan');
			scan.plot_xy(xname,yname,pstyle=pstyle);
			scanx=scan.get_col(xname);
			scany=scan.get_col(yname);
			scanmon=scan.get_col('Ion_Ch_2');
			legendlist.append(str(iscan));
		xlabel(xname);
		# legend(iscanlist)
		axis('tight');
		return;
	
	
class ANLAPSSPEC_Scan(NumMatrixCSV):
	def __init__(self,filename=None, Ndim=None,shape=None,dilimiter='\t'):
		NumMatrixCSV.__init__(self,filename=filename,dilimiter=dilimiter,row_width_chosen=None);
		self.set('iscan',0);
		
	def analyze(self):
		num_matrix=self.convertcsv();
		colnames=self.get_colnames();
		scaninfo=self.get_scaninfo();
		Q=self.get_Q();
		scantype=self.get_scan_type();
		Ncol=self.assign_cols();
		self.get_angles()
		# print "scaninfo:",scaninfo
		# print "Q:",Q
		# print "scantype:",scantype
		#print colnames
		return num_matrix;
		
	def get_colnames(self):
		scan_content=self.get('textcontent');
		scan_colnames=[];
		for line in scan_content:
			fields=line.split();
			if len(fields)>1:
				if fields[0]=="#L":
					scan_colnames=fields[1:];
		self.set('col_names',scan_colnames);
		return scan_colnames;
		
	def assign_cols(self):
		Ncol=0;
		scan_colnames=self.get_colnames();
		for colname in scan_colnames:
			col=self.get_col(colname);
			self.set(colname,col);
			if col is not None:
				Ncol=len(col);
		return Ncol;		
		
	def get_col(self,colname):
		scan_colnames=self.get('col_names');
		if type(colname) is str:
			if scan_colnames.count(colname)==1:
				icol=scan_colnames.index(colname);
		elif type(colname) is int:
			if colname<len(scan_colnames):
				icol=colname;
		scan_num_matrix=self.get('num_matrix');
		if scan_num_matrix is not None:
			scan_col=scan_num_matrix[:,icol];
		else:
			scan_col=None;
		return scan_col;
			
	def get_T(self):
		scan_content=self.get('textcontent');
		scan_T=None;
		for line in scan_content:
			fields=line.split();
			if len(fields)>1:
				if fields[0]=="#X":
					scan_T=float(fields[1]);
					#print jscan,iscan,jscan>iscan
		self.set('scan_T',scan_T);
		return scan_T;
		
	def get_angles(self):
		pstr=self.find_pattern("%#ALP_BET % %");
		a,alpha,beta=pstr;
		#print iscan, pstr
		self.set('alpha',alpha);
		self.set('beta',beta);
		pstr=self.find_pattern("%#P0 % % % % % % %");
		a,delta,eta,chi,phi,nu,mu,b=pstr;
		self.set('delta',delta);
		self.set('eta',eta);
		self.set('chi',chi);
		self.set('phi',phi);
		self.set('nu',nu);
		self.set('mu',mu);
		return alpha,beta,delta,eta,chi,phi,nu,mu;
	
	
	def get_Q(self):
		pstr=self.find_pattern("%#Q % % %");
		a,H,K,L=pstr;
		#print iscan, pstr
		Q=array([H,K,L]);
		self.set('Q',Q);
		return Q;
	
	def get_scaninfo(self):
		scaninfo=self.find_pattern("%#S % %");
		# print "scaninfo:",scaninfo
		i=int(scaninfo[1])
		cmd=scaninfo[2];
		self.set('iscan',i);
		self.set('command',cmd);
		return i,cmd;
		
	def get_scan_type(self):
		scantype="";
		scanpara="";
		iscan,cmd=self.get_scaninfo();
		pstr=sscan(cmd,"% % %");
		scantype=pstr[0];
		if scantype=="ascan":
			scanpara=pstr[1];
			#scanpara=scanpara.replace(scanpara[0],scanpara[0].upper(),1);
		elif scantype=="hklscan":
			paras=sscan(cmd,"% % % % % % % % %");
			paras.remove(paras[0]);
			if abs(paras[0]-paras[1])>1e-2:
				scanpara="H";
			elif abs(paras[2]-paras[3])>1e-2:
				scanpara="K";
			elif abs(paras[4]-paras[5])>1e-2:
				scanpara="L";
		self.set('scantype',scantype);
		self.set('scanpara',scanpara);
		return scantype,scanpara;
	
	def isHKL(self,H,K,L,precision=0.1):
		match=False;
		Q=self.get_Q();
		if abs(H-Q[0])<precision and abs(K-Q[1])<precision and abs(L-Q[2])<precision:
			match=True;
		return match;
		
	def get_timestamp(self):
		import time;
		scan_content=self.get('textcontent');
		scan_T=None;
		for line in scan_content:
			fields=line.split();
			if len(fields)>1:
				if fields[0]=="#D":
					scan_time=line.strip('#D ');
					scan_time=scan_time.strip('\n');
					scan_time=time.strptime(scan_time);
					scan_time=time.mktime(scan_time);
					#print jscan,iscan,jscan>iscan
		self.set('scan_time',scan_time);
		return scan_time;
		
	def plot_xy(self,xcolname,ycolname,monitor="Ion_Ch_2",pstyle="o-"):
		x=self.get_col(xcolname);
		y=self.get_col(ycolname);
		if monitor is not None:
			ym=self.get_col(monitor);
		if x is not None:
			plot(x,y/ym,pstyle);
			
			
class ANLAPSSPEC_Sequence(OGroup):
	def __init__(self):
		OGroup.__init__(self,);
		self.set('sequence',[]);
		
	def append(self,scan):
		scansequence=self.get('sequence');
		scansequence.append(scan);
		self.set('sequence',scansequence);
		
	def get_col_mat(self,colname):
		scansequence=self.get('sequence');
		i=0;
		for scan in scansequence:
			col=scan.get_col(colname);
			if i==0:
				col_mat=col;
			else:
				col_mat=vstack((col_mat,col));
			i=i+1;
			#print "i:",i
		return col_mat;
		
	def get_Ts(self):
		scansequence=self.get('sequence');
		Ts=[];
		for scan in scansequence:
			T=scan.get_T();
			Ts.append(T);
		return Ts;
	
	def get_timestamps(self):
		scansequence=self.get('sequence');
		timestamps=[];
		for scan in scansequence:
			timestamp=scan.get_timestamp();
			timestamps.append(timestamp);
		return timestamps;
	
	def find_scan_atQ(self,ScanType,Q,iscanstart=1,iscanend=None,precision=0.1):
		scanlist=[];
		H,K,L=Q;
		if iscanend==None:
			iscanend=1e10;
		for scan in self.get('sequence'):
			st,scanpara=scan.get_scan_type();
			iscan=scan.get('iscan');
			if iscan>=iscanstart and iscan<=iscanend:
				if scan.isHKL(H,K,L,precision) and scanpara==ScanType:
					print "found scan:",iscan,scan.get_Q()
					scanlist.append(scan);
		return scanlist;
					
	def plot_scan_atQ(self,ScanType,Q,xname=None,yname=None,iscanstart=1,iscanend=None,pstyle="o-",precision=0.1):
		iscanlist=[];
		scanlist=self.find_scan_atQ(ScanType,Q,iscanstart,iscanend);
		legendlist=[];
		if xname==None:
			xname=ScanType;
		if yname==None:
			yname="imroi1";
		for scan in scanlist:
			iscan=scan.get('iscan');
			scan.plot_xy(xname,yname,pstyle=pstyle);
			iscanlist.append(iscan);
			scanx=scan.get_col(xname);
			scany=scan.get_col(yname);
			scanmon=scan.get_col('Ion_Ch_2');
			legendlist.append(str(iscan));
		xlabel(xname);
		# legend(iscanlist)
		axis('tight');
		return iscanlist;