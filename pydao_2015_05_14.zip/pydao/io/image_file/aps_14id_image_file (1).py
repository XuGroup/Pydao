from pylab import *;
from pydao.tools import mccd2array,int_filter,Progress_Teller;
from scipy.signal import convolve;

from scipy.optimize import fmin;
from pydao.database import Relation_Table;
from imgarray import ImgArray;
from pydao.math import vlen;
import gc;

class Img14ID_AngleScan(Relation_Table):
	def __init__(self,directory=None,roi=None):
		Relation_Table.__init__(self,rows=None,idname=None);
		if directory is not None:
			self.set('directory',directory);
		if roi is not None:
			self.set('roi',roi);
		
	def read_scan(self,rois=None,roinames='',logfile=None):
		import os;
		directory = self.get('directory');
		if rois is None:
			rois = self.get('roi');
		# print "in read_scan, roi:",roi
		files=os.listdir(directory);
		pt = Progress_Teller(len(files));

		i=0;
		for file in files:
			#gc.collect();
			i=i+1;
			pt.tell(i);
			fullfile=os.path.join(directory,file);
			if not os.path.isdir(fullfile):
				fs = file.split('.');
				if fs[-1]=='png':
					print "\n file#:",i
					print "fullfile:",fullfile;
					if logfile is not None:
						logfile.printf(["\n file#:",i]);
						logfile.printf(["fullfile:",fullfile]);
					img = Img14ID(fullfile);
					img.read(rois=rois,roinames=roinames);
					self.append(img);	
		return;
	
	def get_iomega_pix_map(self,roiname):
		rows = self.get('rows');
		img_array = rows[0].get('img_array'+roiname);
		Nz,Ny = img_array.shape;
		Nrow = len(rows);
		
		omegay_map = zeros([len(rows),Ny]);
		omegaz_map = zeros([len(rows),Nz]);
		i=0;
		for row in rows:
			img_array = row.get('img_array'+roiname);
			omegay_map[i] = img_array.sum(0); # sum the "y" or horizontal dimension.
			omegaz_map[i] = img_array.sum(1);
			i = i+1;
		
		intensity_y = omegay_map.sum(0);
		intensity_z = omegaz_map.sum(0);
		intensity_iangle = omegaz_map.sum(1);
		
		self.set('iomegay_pix_map',omegay_map);
		self.set('iomegaz_pix_map',omegaz_map);
		savetxt(roiname+'iomegay_pix_map.txt',omegay_map)
		savetxt(roiname+'iomegaz_pix_map.txt',omegaz_map)
		savetxt(roiname+'intensity_y.txt',intensity_y)
		savetxt(roiname+'intensity_z.txt',intensity_z)
		savetxt(roiname+'intensity_iangle.txt',intensity_iangle)
		
		figure();
		subplot(2,3,1);
		sigma = omegay_map.std();
		average = omegay_map.mean();
		imshow(transpose(omegay_map),vmin = average-sigma,vmax=average+sigma);axis('tight');
		colorbar();
		ylabel('ypix');xlabel('iangle')
		subplot(2,3,2);
		sigma = omegaz_map.std();
		average = omegaz_map.mean();
		imshow(transpose(omegaz_map),vmin = average-sigma,vmax=average+sigma);axis('tight');
		ylabel('zpix');xlabel('iangle')
		colorbar();
		subplot(2,3,4);
		plot(intensity_y);xlabel('ypix')
		subplot(2,3,5);
		plot(intensity_z);xlabel('zpix')
		subplot(2,3,6);
		plot(intensity_iangle);xlabel('iangle')
		show();
		return omegay_map,omegaz_map;
	
	def analyze_reflection(self,roiname,origin,factor):
		from pydao.math import find_peak_trajectory_linear;
		omegay_map,omegaz_map = self.get_iomega_pix_map(roiname);
		
		rows = self.get('rows');
		roi = rows[0].get('fromroi'+roiname);
			
		Iangle,Izpix,p = find_peak_trajectory_linear(omegaz_map,slope=-1,precision=1);
		
		subplot(2,3,2);
		plot(Iangle,Izpix,'ro');
		p = polyfit(Izpix,Iangle,1);
		plot(Izpix*p[0]+p[1],Izpix,'r');
		axis('tight');
		
		iangles = Iangle+1;
		zs = (Izpix+roi[2]-origin[1])*factor;
		omegas = arctan(zs)/2*180/pi;
				
		p = polyfit(iangles,omegas,1);
		
		self.set('iangle2omega',p);
		print "roi:",roi
		print "origin:",origin
		print "polyfit iangles",p;
		return;
		
class Img14ID(ImgArray):
	def __init__(self,filename=None,dilimiter='\t',row_width_chosen=None):
		ImgArray.__init__(self,filename=None,dilimiter=dilimiter,row_width_chosen=None);
		if filename is not None:
			self.analyze_filename(filename);
			self.set('filename',filename);
			
	def analyze_filename(self,filename):
		import os;
		# S003_0.6mj_-1ns1_001
		# print "fullname:",filename
		fs = os.path.split(filename);
		# print "path fs:",fs
		fname = fs[-1];
		fs = fname.split('.');
		# print "suffix fs:",fs
		fname = fname.replace('.'+fs[-1],'');
		
		fs = fname.split('_');
		# print "file fs:",fs
		sample_name = fs[0];
		
		fluencestr = fs[1].replace('mj','');
		fluence = float(fluencestr);
		
		pulsedelaystr = fs[2];
		if pulsedelaystr.count('ns')==1:
			pulsedelayunit = 'ns';
		elif pulsedelaystr.count('ps')==1:
			pulsedelayunit = 'ps';
		
		ss = pulsedelaystr.split(pulsedelayunit);
		pulsedelay = float(ss[0]);
		iscan = int(ss[1]);
		
		iangle = int(fs[3]);
		
		self.set('sample_name',sample_name);
		self.set('fluence',fluence);
		self.set('pulsedelay',pulsedelay);
		self.set('pulsedelayunit',pulsedelayunit);
		self.set('iscan',iscan);
		self.set('iangle', iangle);
		print "sample_name:",sample_name
		print "fluence:",fluence
		print "pulsedelay:",pulsedelay
		print "pulsedelayunit:",pulsedelayunit
		print "iscan:",iscan
		print "iangle:",iangle
		return ;
		
	def read(self,rois,filename=None,roinames=''):
		if filename is None:
			filename = self.get('filename');
		# print "filename:",filename
		success = ImgArray.read(self,filename);
		if success:
			img_array = self.get('img_array');
			print "original image shape:",img_array.shape;
			print "rois:",rois
			print "roinames:",roinames
			if len(rois.shape)>1:
				i = 0;
				for roi in rois:
					img_array1 = img_array[roi[0]:roi[1],roi[2]:roi[3]];
					img_array1 = img_array1 +zeros(img_array1.shape);
					self.set('img_array'+roinames[i],img_array1);
					self.set('fromroi'+roinames[i],roi);
					i = i+1;
			else:	
				roi = rois;
				roiname = roinames;
				img_array1 = img_array[roi[0]:roi[1],roi[2]:roi[3]];
				img_array1 = img_array1 +zeros(img_array1.shape); # to release the memory of 'img_array'
				#print "img_array1.shape",img_array1.shape
				self.set('img_array'+roiname,img_array1);
				self.set('fromroi'+roiname,roi);
			#del img_array;
			if roinames is not None:
				self.set('img_array',None);
			return success;
		
	def set_geometric_factor(self,factor):
		# Here we assume detector-sample distance is 1.
		# The -x axis is the incident beam.
		# So y = y_pixel*geometric_factor
		# z = z_pixel*geometric_factor
		self.set('geometric_factor',factor); 
		return;
	
	def set_origin_pixel(self,origin):
		self.set('origin_pixel',origin);
		return;
		
	def set_lattice_basis(self,basis):
		self.set('basis',basis);
		return;
	
	def set_omega(self,omega):
		self.set('omega',omega);
		return;
		
	def set_xray_energy(self,energy):
		self.set('energy',energy);
		k0 = energy*1.60217657e-19/2.99792458e8/(6.62606957e-34/2/pi);
		self.set('k0',k0);
		return;
		
	def yzs2hl(xy_pix,ys,zs,k0=None,origin=None,factor=None,iangle2omega=None):
		if k0 is None:
			k0 = self.get('k0');
		if origin is None:
			origin_pix = self.set('origin_pixel');
		if factor is None:
			factor = self.get('geometric_factor'); 
		if iangle2omega is None:
			iangle2omega=self.get('iangle2omega');
			
		omega = self.get('iangle')*iangle2omega[0]+iangle2omega[1];
		omegar = omega*pi/180;

		qls = zeros([len(ys),len(zs)]);
		qhks = zeros([len(ys),len(zs)]);
		
		
		surface_normal = array([sin(omegar),0,cos(omega(r))]);
		
		for i in range(len(ys)):
			y = ys[i]
			for j in range(len(zs)):
				z = zs[j];
				yz_pix = (y,z);
				yz = yz_pix-origin_pix;
				yz = yz*factor;
				xyz = array([1,yz[0],yz[1]]);
				k_dif = array(xyz);
				k_dif = k_dif/vlen(k_dif)*k0;
				k_inc = array([-1.,0,0])*k0;
				q = k_dif-k_inc;
				qls[i,j] = sum(q*surface_normal);
				qhk[i,j] = vlen(q-qls[i,j]);
		return qls,qls;
	
	def xy2hkl(xy_pix):
		k0 = self.get('k0');
		origin_pix = self.set('origin_pixel');
		xy = xy_pix-origin_pix;
		factor = self.get('geometric_factor'); 
		basis = self.get('basis');
		xy = xy*factor;
		xyz = array([xy[0],xy[1],1]);
		
		k_dif = array(xyz);
		k_dif = k_dif/vlen(k_dif)*k0;
		k_inc = array([-1,0,0])*k0;
		q = k_dif-k_inc;
		hkl = cartesian2direct(basis,q);
		return hkl;
		
		