from pylab import *;
from pydao.tools import tif2array,int_filter,array2bmp;
from scipy.signal import convolve;

from scipy.optimize import fmin;
from pydao.database import Relation_Table;
from ..ascii_file import NumMatrixCSV;
from imgarray import *;

# The procedure is:
# First load the images, which become array of integers. The maximum array element can be 2^24.
# The we normalize using preedge image. The results are stored in new img_array. The array elements are float, which are normally 1-2.
# Then we convert array to bmp by multiplying the array elements by 128. So we get values between 0 and 256.

def getloxfile(dirname,ilox,stack=None):
	import os;
	if stack:
		lox=os.path.join(dirname,ilox,ilox);
	else:
		lox=os.path.join(dirname,ilox);
	return lox;

class CLS_LOX(NumMatrixCSV):
	def __init__(self,filename=None, Ndim=None,shape=None,dilimiter='\t'):
		if not filename.endswith('.lox'):
			loxfilename=filename+'.lox';
		NumMatrixCSV.__init__(self,filename=loxfilename,dilimiter=dilimiter,row_width_chosen=None);
	
	def analyze(self,istart=None,iend=None,isep=None):
		loxtype=self.find_pattern('%<loxheader type="%"%');
		loxtype=loxtype[1];
		print "loxtype:",loxtype
		if loxtype =="image":
			img=self.analyze_img();
		elif loxtype == "spectra":
			img=self.analyze_spectra(istart,iend,isep);
		elif loxtype == "stack":
			img=self.analyze_stack(istart,iend,isep);
			print "Nrow=",img.get_Nrow();
		return img;
		
	def analyze_img(self):
		filename=self.get('filename');
		tif_filename=filename.replace('.lox','.tif');
		img = ImgArray(tif_filename);
		img.read(dtype=0);
		img.set('filecontent',self.get('filecontent'));
		img.set('T',self.get_T());
		img.set('Energy',self.get_energy());
		img.set('ilox',self.get_ilox());
		return img;
		
	def analyze_spectra(self,istart=None,iend=None,isep=None):
		import os;
		img_dbase=Relation_Table();
		if istart is None:
			istart=1;
		if iend is None:
			iend=1e10;
		i=istart;
		pa=self.find_pattern('%point index="'+str(i)+'" Time(s)="%"%');
		while len(pa)>0 and i<iend:
			# print "pa:",pa
			filename=self.get('filename');
			filename=filename.replace('.lox','');
			tif_filename=filename+"#"+str(i)+'.tif';
			img = ImgArray(tif_filename);
			img.read(dtype=0);
			img.set('T',self.get_T());
			img.set('Energy',self.get_energy());
			img.set('ilox',self.get_ilox());
			img.set('iscan',i);
			img_dbase.append(pa[1]);
			img.set('Time',time);
			# print i,pa[1];
			i=i+1;
			pa=self.find_pattern('%point index="'+str(i)+'" Energy(eV)="%"%');
			# print pa
		return img_dbase;
		
		
	def analyze_stack(self,istart=None,iend=None,isep=None):
		import os;
		from pydao.ohdf import natural_name;
		img_dbase=Relation_Table();
		if istart is None:
			istart=1;
		if iend is None:
			iend=1e10;
		if isep is None:
			isep=1;
		i=istart;
		# <point index="1" Time(s)="1.796" dwell="1000" averaging="1" />
		# <point index="1" Energy(eV)="700.004" dwell="1000" averaging="8" />
		pa=self.find_pattern('%<point index="'+str(i)+'" %="%" dwell="%" averaging="%" /%');
		# print "pa:",pa,len(pa)
		while len(pa)>2 and i<iend:
			# print i,len(pa)
			# print "\t",pa;
			scan_varname =  pa[1];
			scan_varvalue = pa[2];
			scan_varname = natural_name(scan_varname);
			# print "pa:",pa
			filename=self.get('filename');
			filename=filename.replace('.lox','');
			tif_filename=filename+"#"+str(i)+'.tif';
			img = ImgArray(tif_filename);
			img.read(dtype=0);
			img.set('T',self.get_T());
			img.set(scan_varname,scan_varvalue);
			img.set('ilox',self.get_ilox());
			img.set('iscan',i);
			img.set('Energy',self.get_energy());
			img.set('RingCurrent',self.get_RingCurrent());
			img_dbase.append(img);
			i=i+isep;
			pa=self.find_pattern('%<point index="'+str(i)+'" %="%" dwell="%" averaging="%" /%');
			# print pa
		return img_dbase;
		
	def get_ilox(self):
		import os;
		filename=self.get('filename');
		# print filename
		fs=os.path.split(filename);
		# print fs
		ilox=fs[1];
		return ilox;
		
	def get_energy(self):
		E=self.find_pattern("%Energy	%");
		# print "E:",E
		self.set('Energy',E[1]);
		return E[1];
		
	def get_T(self):
		T=self.find_pattern("%Sample Temp.	%");
		self.set('T',T[1]);
		return T[1];
		
	def get_RingCurrent(self):
		rc=self.find_pattern("%RingCurrent	%");
		self.set('RingCurrent',rc);
		return rc;	


class Lox_Stack(Relation_Table):
	def __init__(self,dirname=None,ilox=None):
		Relation_Table.__init__(self,rows=None,idname=None);
		if dirname is not None and ilox is not None:
			self.setfile(dirname,ilox);
			
	def setfile(self,dirname,ilox):
		loxfile=getloxfile(dirname,ilox,stack=True);
		self.set('dirname',dirname);
		self.set('ilox',ilox);
		self.set('filename',loxfile);
		return loxfile;
	
	def read_img_seq(self,dirname,ilox_start,ilox_end):
		for ilox in range(ilox_start,ilox_end+1):
			loxfile = getloxfile(dirname,str(ilox));
			# print "loxfile:",loxfile
			lox = CLS_LOX(loxfile);
			img = lox.analyze();
			self.append(img);
		return;
	
	def read_imgs(self,isep=1,dirname=None,ilox=None):
		if dirname is not None and ilox is not None:
			self.setfile(dirname,ilox);
		loxfile=self.get('filename');
		
		lox=CLS_LOX(loxfile);
		img_dbase=lox.analyze(isep=isep);
		for k in img_dbase.keys():
			self.set(k,img_dbase.get(k));
		return;
			
	def light_intensity_normalization(self,pre_energy,post_energy=None,method='preedge'):
		if method == "preedge" or method == "slope":
			pre_dbase=self.select('Energy_eV_<pre_energy',['pre_energy'],[pre_energy]);
			pre=pre_dbase.avg();
			pre=pre.get('img_array');
			print "mean(pre)",pre.mean();
		
		if method == "slope":
			post_dbase=self.select('Energy_eV_>post_energy',['post_energy'],[post_energy]);
			post=post_dbase.avg();
			post=post.get('img_array');
			print "mean(post)",post.mean();
		
		if method == "slope":
			DE=post_energy-pre_energy;
			self.exe('_row.set("img_array",img_array/(pre+(Energy_eV_-pre_energy)/DE*(post-pre)))',['pre','post','pre_energy','DE'],[pre,post,pre_energy,DE]);
		elif method == "preedge":
			self.update_para('img_array','img_array/pre',['pre'],[pre]);
		elif method == "external":
			external_row = pre_energy;
			imgext = external_row.get('img_array');
			self.update_para('img_array','img_array/imgext',['imgext'],[imgext]);
		
		return;
		
	def linear_background_subtract(self,pre_energy,post_energy=None,method="preedge"):
		if method == "slope" or method == "preedge":
			pre_dbase=self.select('Energy_eV_<pre_energy',['pre_energy'],[pre_energy]);
			pre=pre_dbase.avg();
			pre=pre.get('img_array');
			print "mean(pre)",pre.mean();
	
		if method == "slope":
			post_dbase=self.select('Energy_eV_>post_energy',['post_energy'],[post_energy]);
			post=post_dbase.avg();
			post=post.get('img_array');
			print "mean(post)",post.mean();
			
		if method == "preedge":
			self.exe('_row.set("img_array",img_array-pre)',['pre'],[pre]);
		elif method == "slope":
			self.exe('_row.set("img_array",img_array-(pre+(post-pre)*(Energy_eV_-pre_energy)/DE))',['pre','post','pre_energy','DE'],[pre,post,pre_energy,DE]);
		elif method == "external":
			pre = pre_energy.get('img_array');
			self.exe('_row.set("img_array",img_array-pre)',['pre'],[pre]);
		return;
	
	def constant_sum_normalize(self,loxstack):
		a1=self.roi_mean().sum();
		a2=loxstack.roi_mean().sum();
		self.update('img_array','img_array/a1*a2',['a1','a2'],[a1,a2]);
		return a1,a2;
		
	def roi_mean(self,roi=None):
		if roi is None:
			self.update('_temp','_row.mean()');
		else:
			self.update_para('_temp','_row.get_region_of_interest(roi).mean()',['roi'],[roi]);
		roi=self.get_col('_temp');
		return array(roi);
		
	def save_img(self):
		from PIL import Image;
		from pydao.tools import Progress_Teller;
		N=self.get_Nrow();
		pt=Progress_Teller(N,text='Saving image')
		ilox=self.get('ilox');
		rows = self.get('rows')
		for i in range(N):
			pt.tell(i);
			img = rows[i];
			iscan = img.get('iscan');
			filename = ilox+"#"+str(iscan)+"_"+str(i)+'.bmp';
			filename = filename;
			# img.save(filename);
			img_array = img.get('img_array');
			print "img_array max:",img_array.max()
			imarr = img_array*128;
			array2bmp(imarr,filename);
			# im = Image.fromarray(img_array)
			# im.save(filename);
		return;
		
	def save_diff(self,loxstack):
		from pydao.tools import Progress_Teller;
		N=self.get_Nrow();
		pt=Progress_Teller(N,text='Saving image difference in bmp')
		ilox=self.get('ilox');
		ilox1=loxstack.get('ilox');
		import time;
		for i in range(N):
			pt.tell(i);
			cw=self.get('rows')[i];
			ccw=loxstack.get('rows')[i];
			iscan=cw.get('iscan');
			iscan1=ccw.get('iscan');
			dif=cw-ccw;
			dif=((cw-ccw)+1)*2**7;
			filename = ilox+'-'+str(ilox1)+'#'+str(iscan)+"_"+str(i)+'.bmp';
			# print "filename:",filename
			dif.savebmp(filename);
		return;

	def compare_roi(self,loxstack,varname,roi=None,disp=True):
		# print "in compare_roi:"
		# print "varname:",varname
		Energy = array(self.get_col(varname));
		# print "Energy:", Energy
		roi_cw = self.roi_mean(roi);
		roi_ccw = loxstack.roi_mean(roi);
		dif_roi = array(roi_cw)-array(roi_ccw);
		if disp:
			plot(Energy,roi_cw);
			plot(Energy,roi_ccw,'r');
			plot(Energy,dif_roi);
			plot(Energy,Energy-Energy);
			axis('tight')
			title(str(roi));
		return Energy,roi_cw,roi_ccw,dif_roi;
	
##########################################################################
##						 Back up										##
##########################################################################
		
class CLS_LOX_Stack(NumMatrixCSV,Relation_Table):
	def __init__(self,filename=None, Ndim=None,shape=None,dilimiter='\t'):
		if not filename.endswith('.lox'):
			loxfilename=filename+'.lox';
		NumMatrixCSV.__init__(self,filename=loxfilename,dilimiter=dilimiter,row_width_chosen=None);
		img=None;
		if filename is not None:
			self.convertcsv();
		
	def analyze(self):
		num_matrix=self.get('num_matrix');	
		Nimg,Nroi=num_matrix.shape;
		self.set('Nimg',Nimg);
		self.set('Nroi',Nroi);
		print "Nimg,Nroi:",Nimg,Nroi;
		
	def get_singleimg(self,i_img):
		filename=self.get('filename');
		tiffilename=filename.replace('.lox','#'+str(i_img)+'.tif');
		img_array=tif2array(tiffilename);
		new_mimg = ImgArray();		
		new_mimg.set('img_array',img_array);
		return new_mimg;
		
	def img_sum(self,shiftnorm=False,imgrange=None,roi=None):
		Nimg=self.get('Nimg');
		if shiftnorm:
			shiftnorm_paras_list=self.get('shiftnorm_paras_list');
			# print "shiftnorm_paras_list:",len(shiftnorm_paras_list);
			# print "Nimg:",Nimg
		img=None;
		if imgrange is None:
			imgrange=range(1,Nimg+1);
		for i in imgrange:
			# print "i:"
			new_img=self.get_singleimg(i);
			if shiftnorm and i>0:
				print i,len(shiftnorm_paras_list)
				paras=shiftnorm_paras_list[i-1];
				new_img=new_img.shiftnorm(paras[0],paras[1],paras[2],paras[3]);
			if img is None:
				img=new_img;
			else:
				img=img+new_img;
		return img;
		
	def img_average(self,shiftnorm=False,imgrange=None):
		Nimg=self.get('Nimg');
		img=self.img_sum(shiftnorm,imgrange,roi);
		img=img/Nimg;
		return img;
		
	def find_shiftnorm(self,roi=None,paras=None):
		Nimg=self.get('Nimg');
		stardard_img=self.get_singleimg(1);
		N,M=(stardard_img.get('img_array')).shape;
		if roi is None:
			roi=[0,N,0,M];
		stardard_img.disp_img();
		stardard_img.disp_roi(roi);
		paras_list=[];
		if paras is None:
			paras=[1.,1.,1.,0.]
		for i in range(1,Nimg):
			print "align, i:",i
			img=self.get_singleimg(i);
			img_roi=img.get_roi_img(roi);
			paras0=[1.,1.,1.,0.];
			new_mimg,paras=img_roi.find_match(stardard_img.get_roi_img(roi),paras);
			paras_list.append(paras);
			print paras;
		self.set('shiftnorm_paras_list',paras_list);
		return paras_list;

	def get_dim(self):
		stardard_img=self.get_singleimg(1);
		N,M=(stardard_img.get('img_array')).shape;
		return N,M

	def substract(self,loxs,roi=None,shiftnorm=False):
		if roi is None:
			N,M=self.get_dim();
			roi=[0,N,0,M];
		if shiftnorm:
			paras_list=self.find_shiftnorm(roi,[1.,1.,1.,0]);
			paras_list1=loxs.find_shiftnorm(roi,[1.,1.,1.,0]);
		self_mean_img=self.img_average(shiftnorm);
		loxs_mean_img=loxs.img_average(shiftnorm);
		
		if shiftnorm:
			self_mean_img,paras=self_mean_img.find_match(loxs_mean_img,roi=roi);
		diff_mean_img=self_mean_img-loxs_mean_img;
			
		return diff_mean_img;
		