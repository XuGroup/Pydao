from pylab import *;

def divisors(n):
	divs=[1];
	for i in range(2,n):
		if n/i==float(n)/i:
			divs.append(i);
	divs.append(n);
	return divs;
	
def factorial(N):
	f=1;
	i=N;
	while i>1:
		f=f*i;
		i=i-1;
	return f;
	
def orderofmagnitude(x):
	y=abs(x);
	n=1;
	if y==0:
		n=-1e100;
	elif y>=10:
		while y>=10:
			y=y/10.;
			n=n+1;
	elif y<1:
		while y<1:
			y=y*10;
			n=n-1;
			#print "x,y,n:",x,y,n
	return n;
	
def orderofmagnitude_vec(X):
	V=X-X;
	for i in range(len(X)):
		V[i]=orderofmagnitude(X[i]);
	return V;
	
def orderofmagnitude_mat(X):
	Nr,Nc=X.shape;
	M=zeros([Nr,Nc]);
	for ir in range(Nr):
		for ic in range(Nc):
			M[ir,ic]=orderofmagnitude(X[ir,ic]);
	return M;

def sig_dig(x,N):
	M=orderofmagnitude_mat(x)
	#print "M:",M
	oom=M.max();
	#print oom,N
	oom=10.**oom;
	#print oom
	y=(x/oom*10.**N).round()/10.**N*oom;
	return y;
	
def complement_array(fullarray,part):
	import copy;
	comp = list(copy.copy(fullarray));
	for p in part:
		comp.remove(p);
	return array(comp);
	