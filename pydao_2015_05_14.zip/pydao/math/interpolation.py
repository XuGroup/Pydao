from pylab import *;

def angularinterp2d(xs,Intxs,ys,Intys):

# first setup the 2D space of the -1 to 1 scale
	xN=len(xs);
	yN=len(ys);
	X,Y=mgrid[0:xN,0:yN];
	X=X/(xN-1.)*2-1;
	Y=Y/(yN-1.)*2-1;
	R=(X**2+Y**2)**0.5;
	
# then convert the xs, ys to that scale.
# this will be used for interpolation.
	xD=max(xs)-min(xs);
	xmean=mean(xs);
	yD=max(ys)-min(ys);
	ymean=mean(ys);
	xs1=(xs-xmean)/xD*2;
	ys1=(ys-ymean)/yD*2;

# the new xs, ys with the same min, max, and number of points, but even separations
	newxs=mgrid[0:xN]/(xN-1.)*xD+min(xs);
	newys=mgrid[0:yN]/(yN-1.)*yD+min(ys);

# then interpolate using the arc angles
	Intxys=R-R;
	I=R<=1;
	phi=arctan(Y/X);
	I1=X<0;
	phi[I1]=phi[I1]+pi;

	I2= logical_and(phi>=-pi/2, phi<0);
	fx=interp(R[I2],xs1,Intxs);
	fy=interp(-R[I2],ys1,Intys);
	Intxys[I2]=fy+(fx-fy)/(0+pi/2)*(phi[I2]+pi/2);

	I2= logical_and(phi>=0, phi<pi/2);
	fx=interp(R[I2],xs1,Intxs);
	fy=interp(R[I2],ys1,Intys);
	Intxys[I2]=fx+(fy-fx)/(pi/2-0)*(phi[I2]-0);
	
	I2= logical_and(phi>=pi/2, phi<pi);
	fx=interp(-R[I2],xs1,Intxs);
	fy=interp(R[I2],ys1,Intys);
	Intxys[I2]=fy+(fx-fy)/(pi-pi/2)*(phi[I2]-pi/2);

	I2= logical_and(phi>=pi, phi<pi/2*3);
	fx=interp(-R[I2],xs1,Intxs);
	fy=interp(-R[I2],ys1,Intys);
	Intxys[I2]=fx+(fy-fx)/(pi/2*3-pi)*(phi[I2]-pi);

	return newxs,newys,Intxys;
	
def interp1d(x,xs,ys,method=None):
	y=interp(x,xs,ys);
	ysL=ys[0:-1];
	ysR=ys[1:];
	I=arange(len(ys)-1);
	I0=logical_and(y>=ysL,y<ysR);
	# print "I:",I,"I0:",I0
	i=I[I0];
	if method=="floor":
		y=ys[i][0];
	elif method=='ceil':
		y=ys[i+1][0];
	return y;
	
# the interp2d from scipy.interpolation is quite good, we can use that.
# def interp2d(xs,ys,zs,xs2interp,ys2interp):
	# xs and ys are one-dimensional the coordinates of the mesh
	# xs and ys are assumed to be sorted: index 0 is the minimum, index -1 is the maximum
	# zs is the two-dimensional value on the mesh
	# zs=zeros(len(xs2interp));
	# I=logical_and(xs2interp>min(xs),xs2interp<max(xs),ys2interp>min(ys),ys2interp<max(ys));
	
	# xsinterped=xs2interp[I];
	# ysinterped=ys2interp[I];
	# for i in range(len(xsinterped)):
		# x=xsinterped[]
	
	