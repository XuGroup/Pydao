from pydao.ohdfvi import MyModelView;
from pydao.ohdfvi import Analyzable_ModelView;
from pylab import *;

class WorkSheet_ModelView(Analyzable_ModelView):
	def init_info(self,info):
		Analyzable_ModelView.init_info(self,info);
		#self.preprocess(self.model);
		print "info:",info
		
	def On_disp(self,event):
		from worksheet_viewers import WorkSheet_Viewer;
		work_sheet=self.model;
		viewer=WorkSheet_Viewer(work_sheet,work_sheet.get_worksheet_2darray(),work_sheet.col_names());
		viewer.main();
		
	def On_import_csv(self,info=None):
		import pydao,sys;
		from pydao.ohdf import OGroup;
		from pydao.ohdfvi import ogroup_analyzer_view,Analyzable_ModelView;
		if info is not None:
			work_sheet=self.model;
			func_name=sys._getframe().f_code.co_name
			ana_method=eval("self."+func_name);
			ana_name=func_name;
			
			work_space_list=work_sheet.work_space_list;
			print work_space_list,type(work_space_list)
			found_work_space=False;
			for ws in work_space_list:
				if ws.name==ana_name:
					found_work_space=True;
			if found_work_space:
				print "found_work_space",ana_name
			else:
				work_space=Analyzable_ModelView().get_default_work_space(work_sheet);
			
				#group=work_space.get('group');
				#outputs=work_space.get('outputs');
				#group.set('criteria',['mass']);
				work_space.get('config').remove('_0group');
				work_space.get('config').remove('_2analysis');
				work_space.remove('data');
				
				#parameters=OGroup();
				#parameters.set('key','charge');
				#parameters.set('value',2.5);
				#work_space.set('analysis_parameters',parameters);
				
				inputs=OGroup();
				inputs.set('csv_filename','csvfile.asc');
				work_space.get('config').set('_1inputs',inputs);
				
				#outputs.set('dir_link',str(lattice.get_link()));
				work_space.name=ana_name;
				
				work_sheet.work_space_list.selected=work_space;
				work_sheet.work_space_list.append(work_space);
				work_sheet.ana_method_list.append(ana_method);
		else:
			work_sheet=self.model;
			work_space=work_sheet.work_space_list.selected;
			inputs=work_space.get('config').get('_1inputs');
			
			csv_filename=inputs.get('csv_filename');
			print "csv_filename:",csv_filename
			work_sheet.import_from_csv(csv_filename);
			
			#outgroup=group.copy2mem();
			#outgroup.get('dbases').set('atoms',newatoms);
			#return outgroup;

class WorkSheet_Table_ModelView(MyModelView):
	def init_info(self,info):
		from enthought.traits.api import Event,Any;
		MyModelView.init_info(self,info);
		#print "OGroup_Tabular_ModelView init_info",self.model
		if self.model is not None:
			self.model.uiinfo=info;
			self.prepare_traits(self.model);
		#print self.model.tabular
		
	def init(self,info):
		import wx;
		from ..ohdf import dkeys;
		#print "OGroup_Tabular_ModelView init"
		#self.prepare_traits(info.object);
		self.model=info.object;
		self.model.uiinfo=info;
		
		listctr=self.get_listctr();
		listctr.Bind(wx.EVT_MOTION,self.ONMouseMotion,id=listctr.GetId());
		
		#print "info.object",info.object.keys();
		#print "self dkeys:",dkeys(self),self.class_trait_names()

	def prepare_traits(self,work_sheet):
		from ..ohdf import OGroup,ddel,dkeys;
		from enthought.traits.api import Event,Any;
		
		spreadsheet=work_sheet.get_worksheet_2darray();
		#ddel(work_sheet,'tabular');
		#print "subwork_sheet type",type(work_sheet)
		if dkeys(work_sheet).count('spreadsheet')==0:
			work_sheet.add_class_trait('spreadsheet',array(spreadsheet));
		work_sheet.spreadsheet=array(spreadsheet);
		#print work_sheet.tabular
		
		model=work_sheet;
		
		ctn=model.class_trait_names();
		#print "ctn:",ctn
		#print type(model)
		if ctn.count('clicked')==0:
			try:
				model.add_class_trait('clicked',Any);
			except: 
				pass;
		if ctn.count('dclicked')==0:
			try:
				model.add_class_trait('dclicked',Any);
			except:
				pass;
		if ctn.count('column_clicked')==0:
			try:
				model.add_class_trait('column_clicked',Any);
			except:
				pass;
		if ctn.count('right_clicked')==0:
			try:
				model.add_class_trait('right_clicked',Any);
			except:
				pass;
	
		#model.on_trait_change(self.OnCliked, 'clicked');
		model.on_trait_change(self.OnDCliked, 'dclicked');
		model.on_trait_change(self.OnClikedColumn, 'column_clicked');
		model.on_trait_change(self.OnRightClicked, 'right_clicked');
		
	def get_listctr(self):
		uiroot=self.get_uiroot();
		listctr=uiroot.GetChildren()[0].GetChildren()[0].GetChildren()[0];
		return listctr;
		
	def OnCliked(self):
		clicked=self.model.clicked
		print "OnCliked:",clicked.column, clicked.row
		name=self.model.tabular[clicked.row][0];
		print name,self.model.get(name)
		
	def OnDCliked(self):
		dclicked=self.model.dclicked
		print "OndCliked:",dclicked.column, dclicked.row
		name=self.model.tabular[dclicked.row][0];
		print name,self.model.get(name);
		
	def OnClikedColumn(self):
		print "OnClikedColumn";
		model=self.model;
		column=model.column_clicked.column;
		field_names=model.column_clicked.editor.adapter.columns;
		columnname=field_names[column];
		#self.inmemory.sort(order=columnname);
		
	def OnRightClicked(self):
		import wx;
		model=self.model;
		right_clicked=self.model.right_clicked;
		print "OnRightCliked:",right_clicked.column, right_clicked.row
		listctr=self.get_listctr();
		menu=wx.Menu();
		
		item=menu.Append(wx.NewId(),"Refresh","Refresh");
		self.get_uiroot().Bind(wx.EVT_MENU, self.On_Refresh, item);

		item=menu.Append(wx.NewId(),"Plot Column","Plot Column");
		self.get_uiroot().Bind(wx.EVT_MENU, self.On_PlotColumn, item);

		listctr.PopupMenu(menu,self.model.mouse_position);
		
		
	def ONMouseMotion(self, event):
		#print event.GetPosition() 
		self.model.mouse_position=event.GetPosition();

	def On_Refresh(self,event):
		model=self.model;
		right_clicked=self.model.right_clicked;
		print "Refresh OnRightCliked:",right_clicked.column, right_clicked.row
		print "refreshed!"

	def On_PlotColumn(self,event):
		model=self.model;
		right_clicked=self.model.right_clicked;
		icol=right_clicked.column;
		colname=model.col_names()[icol];
		model.plotline(y=colname,pstyle='o-');