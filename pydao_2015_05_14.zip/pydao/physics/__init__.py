#from units import *;
from unit import *;
from solidstate import *;
from quantum_mechanics import *;
from thermodynamics import *;
from functions import *;

#from expdatafile import *;

e_mass = 9.10938188e-31;
e_charge = 1.60217646e-19;
hbar = 1.05457148e-34;
k_E = 9e9;
v_light = 299792458.;
muB = 9.27400968e-24;
k_B = 1.3806488e-23;
epsilon_0 =  8.85418782e-12;
mu_0 =  1.25663706e-6;
neutron_mass = 1.674927351e-27;