from pylab import *;
from pydao.ohdf import OGroup,isnumeric;
import pydao.math,copy;
from qmvariable import Operator;
from oneparticle import Base_Mat;
from pydao.io import Savable_MethodResultdBase;

class Base_Xyz2B(OGroup):
	def __init__(self):
		#OGroup.__init__(self);
		self.set2xyz2bzero();
	
	def __call__(self,x,y,z,x1,y1,z1):
		value=1.*x*y*z/x/y/z*x1/x1*y1/y1*z1/z1;
		wfunction=self.get('xyz2bfun');
		if wfunction is not None:
			value=value*wfunction(x,y,z,x1,y1,z1);
		return value;
		
	def xyz2bpara_get(self,name):
		xyz2bparas=self.get('xyz2bparas');
		return xyz2bparas.get(name);
		
	def xyz2bpara_set(self,name,value):
		xyz2bparas=self.get('xyz2bparas');
		xyz2bparas.set(name,value);
		return;
		
	def xyz2bpara_keys(self):
		xyz2bparas=self.get('xyz2bparas');
		return xyz2bparas.keys();
		
	def set2xyz2bzero(self):
		self.set('xyz2bfun',0);
		self.set('xyz2bparas',OGroup());
		
	def qmvcopy(self,qmv=None):
		if qmv is None:
			qmv=Base_Xyz();
		qmv.set('xyz2bfun',self.get('xyz2bfun'));
		return qmv;
		
	def info(self,indent=0):
		print indent*"|_","<Base_Xyz2B>"
		print indent*"|_",
		if self.qmvkind()=='base':
			print "xyz2b function:",self.get('xyz2bfun')

	def baseiproduct_xyz2b(self,wf):
		if isinstance(wf,Base_Xyz2B):
			r_max=self.rrange();
			xmin=-r_max;
			xmax=r_max;
			ymin=-r_max;
			ymax=r_max;
			zmin=-r_max;
			zmax=r_max;
			Np=self.xyz2bpara_get('Np');
			if Np is None:
				Np=12;
			dx=1.*(xmax-xmin)/(Np-1);
			dy=1.*(ymax-ymin)/(Np-1);
			dz=1.*(zmax-zmin)/(Np-1);
			x,y,z,x1,y1,z1= mgrid[xmin:xmax:Np*1j,ymin:ymax:Np*1j,zmin:zmax:Np*1j,xmin:xmax:Np*1j,ymin:ymax:Np*1j,zmin:zmax:Np*1j];
			self_fun=self.get('xyz2bfun');
			wf_fun=wf.get('xyz2bfun');
			product=(self_fun(x,y,z,x1,y1,z1)*conjugate(wf_fun(x,y,z,x1,y1,z1))).sum()*(dx*dy*dz)**2;
		return product;
		
	def base_braopket_mate_xyz2b(self,bra0,bra1,ket0,ket1,Np):
		bra_fun0=bra0.get('xyzfun');
		bra_fun1=bra1.get('xyzfun');
		ket_fun0=ket0.get('xyzfun');
		ket_fun1=ket1.get('xyzfun');
		bra_2bfun=lambda x,y,z,x1,y1,z1: bra_fun0(x,y,z)*bra_fun1(x1,y1,z1);
		ket_2bfun=lambda x,y,z,x1,y1,z1: ket_fun0(x,y,z)*ket_fun1(x1,y1,z1);
		op_2bfun=self.get('xyz2bfun');
			
		#bra0.info();
		#print bra0.rpeak(),bra1.rpeak(),ket0.rpeak(),ket1.rpeak()
		r_peak=max([bra0.rpeak(),bra1.rpeak(),ket0.rpeak(),ket1.rpeak()]);
		#print bra0.rspread(),bra1.rspread(),ket0.rspread(),ket1.rspread()
		r_sigma=max([bra0.rspread(),bra1.rspread(),ket0.rspread(),ket1.rspread()]);
		r_max=r_peak+2*r_sigma;
		
		r_max=self.rrange();
		
		xmin=-r_max;
		xmax=r_max;
		ymin=-r_max;
		ymax=r_max;
		zmin=-r_max;
		zmax=r_max;
			
			
		#print r_max,Np
		dx=1.*(xmax-xmin)/(Np-1);
		dy=1.*(ymax-ymin)/(Np-1);
		dz=1.*(zmax-zmin)/(Np-1);
		#x,y,z,x1,y1,z1= mgrid[xmin:xmax:Np*1j,ymin:ymax:Np*1j,zmin:zmax:Np*1j,xmin:xmax:Np*1j,ymin:ymax:Np*1j,zmin:zmax:Np*1j];
		X = mgrid[xmin:xmax:Np*1j];
		X1 = mgrid[xmin+dx/2:xmax+dx/2:Np*1j];
		y,z,y1,z1= mgrid[ymin:ymax:Np*1j,zmin:zmax:Np*1j,ymin+dy/2:ymax+dy/2:Np*1j,zmin+dz/2:zmax+dz/2:Np*1j];
		
		from pydao.tools import Progress_Teller;
		pt=Progress_Teller(len(X)*len(X1));
		
		mate=0;
		i=0;
		for x in X:
			for x1 in X1:
				gket=ket_2bfun(x,y,z,x1,y1,z1);
				gop=op_2bfun(x,y,z,x1,y1,z1);
				gbra=bra_2bfun(x,y,z,x1,y1,z1);
				I=isfinite(gop);
				#print gop,I
				num_grid=conjugate(gbra[I])*gop[I]*gket[I];
				#num_grid_finite=num_grid[I];
				#print gop.shape,num_grid.shape
				mate=mate+num_grid.sum()*(dx*dy*dz)**2;		
				i=i+1;
				pt.tell(i);
		return mate;
		
	def rrange(self):
		rmax=self.xyz2bpara_get('rrange');
		if rmax is None:
			rmax=self.rpeak()+2.*self.rspread();
		return rmax;
		
class Operator_Xyz2B(Operator,Base_Xyz2B):
	def __init__(self):
		Operator.__init__(self);
		Base_Xyz2B.__init__(self);
		self.set('coefficient',1);
		self.set('particle_list',[0]);
		
	def basestack_braopket_mate(self,bras,kets,Np):
		plist=self.get('particle_list');
		mate=1;
		bra_stack=bras.get('stack');
		ket_stack=kets.get('stack');
		product=1;
		for i in range(len(bra_stack)):
			if plist.count(i)==0:
				br=bra_stack[i];
				ke=ket_stack[i];
				pr=br.innerproduct(ke);
				product=product*pr;
				if product==0:
					break;
		if product!=0:
			bra0=bra_stack[plist[0]];
			bra1=bra_stack[plist[1]];
			ket0=ket_stack[plist[0]];
			ket1=ket_stack[plist[1]];
			pr=self.base_braopket_mate_xyz2b(bra0,bra1,ket0,ket1,Np);
			cftb0=bra0.get('coefficient');
			cftb1=bra1.get('coefficient');
			cftk0=ket0.get('coefficient');
			cftk1=ket0.get('coefficient');
			mate=product*pr*cftb0*cftb1*cftk0*cftk1;
		else:
			mate=product;
		return mate;
			
	def qmvcopy(self,qmv=None):
		if qmv is None:
			qmv=MBOperator();
		qmv.set('particle_list',self.get('particle_list'));
		return qmv;

class Coulomb_Interaction(Operator_Xyz2B,Savable_MethodResultdBase):
	def __init__(self):
		Operator_Xyz2B.__init__(self);
		from pydao.physics import e_mass,e_charge,hbar,k_E;
		fun2b=lambda x,y,z,x1,y1,z1: k_E*e_charge**2/((x-x1)**2+(y-y1)**2+(z-z1)**2)**0.5;
		self.set('xyz2bfun',fun2b);
		self.xyz2bpara_set('Np',10);
		self.set('particle_list',[0,1]);
		self.set('savedresult_dbasename','coulomb_interaction');
			
	# def save_integral_records(self):
		# self.save_resultdbase_2disk('coulomb_integral');
		# self.save_resultdbase_2disk('exchange_integral')
	
	def find_integral_from_records(self,bras,kets,Np):
		plist=self.get('particle_list');
		value=None;
		bra_stack=bras.get('stack');
		ket_stack=kets.get('stack');
		bra0=bra_stack[plist[0]];
		bra1=bra_stack[plist[1]];
		ket0=ket_stack[plist[0]];
		ket1=ket_stack[plist[1]];
		
		parameters=OGroup();
		parameters.set('rrange',self.xyz2bpara_get('rrange'));
		parameters.set('Np',Np);
		
		print "to find ",
		print bra0.qmnumbers(),bra1.qmnumbers(),ket0.qmnumbers(),ket1.qmnumbers(),Np
		if bra0.hassameqmnumbers(ket0) and bra1.hassameqmnumbers(ket1):
			#this is case of coulomb integral
			print "coulomb integral",
			parameters.set('varname','coulomb_integral');
			Z0,n0,l0,m0=bra0.qmnumbers();
			Z1,n1,l1,m1=bra1.qmnumbers();
			parameters.set('Znl0',(Z0,n0,l0));
			parameters.set('Znl1',(Z1,n1,l1));
			value=self.find_resultrecord_fromdbase(parameters);
			if value is None:
				parameters.set('Znl1',(Z0,n0,l0));
				parameters.set('Znl0',(Z1,n1,l1));
				value=self.find_resultrecord_fromdbase(parameters);
		elif bra0.hassameqmnumbers(ket1) and bra1.hassameqmnumbers(ket0):
			#this is the case exchange integral
			print "exchange integral",
			parameters.set('varname','exchange_integral');
			Z0,n0,l0,m0=bra0.qmnumbers();
			Z1,n1,l1,m1=bra1.qmnumbers();
			parameters.set('Znlm0',(Z0,n0,l0,m0));
			parameters.set('Znlm1',(Z1,n1,l1,m1));
			value=self.find_resultrecord_fromdbase(parameters);
			if value is None:
				parameters.set('Znlm1',(Z0,n0,l0,m0));
				parameters.set('Znlm0',(Z1,n1,l1,m1));
				value=self.find_resultrecord_fromdbase(parameters);
		else:
			print "general coulomb integral",
			parameters.set('varname','general_coulomb_integral');
			Z0,n0,l0,m0=bra0.qmnumbers();
			Z1,n1,l1,m1=bra1.qmnumbers();
			Z2,n2,l2,m2=ket0.qmnumbers();
			Z3,n3,l3,m3=ket1.qmnumbers();
			parameters.set('Znlm0',(Z0,n0,l0,m0));
			parameters.set('Znlm1',(Z1,n1,l1,m1));
			parameters.set('Znlm2',(Z2,n2,l2,m2));
			parameters.set('Znlm3',(Z3,n3,l3,m3));
			value=self.find_resultrecord_fromdbase(parameters);
			if value is None:
				parameters.set('Znlm1',(Z0,n0,l0,m0));
				parameters.set('Znlm0',(Z1,n1,l1,m1));
				parameters.set('Znlm3',(Z2,n2,l2,m2));
				parameters.set('Znlm2',(Z3,n3,l3,m3));
				value=self.find_resultrecord_fromdbase(parameters);
			if value is None:
				parameters.set('Znlm2',(Z0,n0,l0,m0));
				parameters.set('Znlm3',(Z1,n1,l1,m1));
				parameters.set('Znlm0',(Z2,n2,l2,m2));
				parameters.set('Znlm1',(Z3,n3,l3,m3));
				value=self.find_resultrecord_fromdbase(parameters);
				if value is not None:
					value=conjugate(value);
			if value is None:
				parameters.set('Znlm3',(Z0,n0,l0,m0));
				parameters.set('Znlm2',(Z1,n1,l1,m1));
				parameters.set('Znlm1',(Z2,n2,l2,m2));
				parameters.set('Znlm0',(Z3,n3,l3,m3));
				value=self.find_resultrecord_fromdbase(parameters);
				if value is not None:
					value=conjugate(value);
		if value is None:
			print ", not found."
		else:
			print ", found."
		return value;		
	
	def store_integral_to_records(self,bras,kets,Np,value):
		import time;
		plist=self.get('particle_list');
		bra_stack=bras.get('stack');
		ket_stack=kets.get('stack');
		bra0=bra_stack[plist[0]];
		bra1=bra_stack[plist[1]];
		ket0=ket_stack[plist[0]];
		ket1=ket_stack[plist[1]];
		
		record=OGroup();
		record.set('Np',Np);
		record.set('rrange',self.xyz2bpara_get('rrange'));
		
		print "to store ",
		print bra0.qmnumbers(),bra1.qmnumbers(),ket0.qmnumbers(),ket1.qmnumbers(),Np
		if bra0.hassameqmnumbers(ket0) and bra1.hassameqmnumbers(ket1):
			#this is case of coulomb integral
			print  "coulomb integral"
			record.set('varname','coulomb_integral');
			Z0,n0,l0,m0=bra0.qmnumbers();
			Z1,n1,l1,m1=bra1.qmnumbers();
			record.set('Znl0',(Z0,n0,l0));
			record.set('Znl1',(Z1,n1,l1));
			record.set('value',value);
			self.store_resultrecord_2dbase(record);
		elif bra0.hassameqmnumbers(ket1) and bra1.hassameqmnumbers(ket0):
			#this is the case exchange integral
			print "exchange integral"
			record.set('varname','exchange_integral');
			Z0,n0,l0,m0=bra0.qmnumbers();
			Z1,n1,l1,m1=bra1.qmnumbers();
			record.set('Znlm0',(Z0,n0,l0,m0));
			record.set('Znlm1',(Z1,n1,l1,m1));
			record.set('value',value);
			self.store_resultrecord_2dbase(record);
		else:
			print "general coulomb integral"
			record.set('varname','general_coulomb_integral');
			Z0,n0,l0,m0=bra0.qmnumbers();
			Z1,n1,l1,m1=bra1.qmnumbers();
			Z2,n2,l2,m2=ket0.qmnumbers();
			Z3,n3,l3,m3=ket1.qmnumbers();
			record.set('Znlm0',(Z0,n0,l0,m0));
			record.set('Znlm1',(Z1,n1,l1,m1));
			record.set('Znlm2',(Z2,n2,l2,m2));
			record.set('Znlm3',(Z3,n3,l3,m3));
			record.set('value',value);
			self.store_resultrecord_2dbase(record)
		return;
		
	def basestack_braopket_mate(self,bras,kets):
		Np=self.xyz2bpara_get('Np');
		if Np is None:
			Np=10;
		plist=self.get('particle_list');
		bra_stack=bras.get('stack');
		ket_stack=kets.get('stack');
		mate=1;
		for i in range(len(bra_stack)):
			if plist.count(i)==0:
				mate=mate*bra_stack[i].innerproduct(ket_stack[i]);
				if mate==0:
					break;
		if mate!=0:
			bra0=bra_stack[plist[0]];
			bra1=bra_stack[plist[1]];
			ket0=ket_stack[plist[0]];
			ket1=ket_stack[plist[1]];
			if isinstance(bra0,Base_Mat):
				mate=mate*bra0.baseiproduct_mat(ket0);
			if isinstance(bra1,Base_Mat):
				mate=mate*bra1.baseiproduct_mat(ket1);
			if mate!=0:
				#if bra0.hassameqmnumbers(ket0) and bra1.hassameqmnumbers(ket1) or \
				#bra0.hassameqmnumbers(ket1) and bra1.hassameqmnumbers(ket0): 
				I=self.find_integral_from_records(bras,kets,Np);
				if I is None:
					I=Operator_Xyz2B.basestack_braopket_mate(self,bras,kets,Np);
					self.store_integral_to_records(bras,kets,Np,I);
				mate=mate*I;	
				for i in plist:
					bra_cft=bra_stack[i].get('coefficient');
					ket_cft=ket_stack[i].get('coefficient');
					mate=mate*bra_cft*ket_cft;
				#else:
				#	mate=0;
		return mate;