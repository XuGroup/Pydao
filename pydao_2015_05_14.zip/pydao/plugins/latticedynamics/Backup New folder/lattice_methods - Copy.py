from pylab import *;
from functions import *;
lazy=False;

def OnAnalyze(lattice,event):
	from lattice_views import lattice_analysis_view;
	view=lattice_analysis_view(lattice);
	lattice.configure_traits(view=view);
	
def import_basis_fromcif(lattice,cif_filename):
	from ciffile import CifFile,ReadCif
	#cif_filename=lattice.cif_filename;
	cf=ReadCif(cif_filename);
	block=cf.first_block();
	la=eval(block['_cell_length_a']);
	lb=eval(block['_cell_length_b']);
	lc=eval(block['_cell_length_c']);
	alpha=eval(block['_cell_angle_alpha'])/180.*pi;
	beta=eval(block['_cell_angle_beta'])/180.*pi;
	gamma=eval(block['_cell_angle_gamma'])/180.*pi;
	print la,lb,lc,alpha,beta,gamma
	b0=[la,0,0];
	b1=[lb*cos(gamma),lb*sin(gamma),0];
	if abs(cos(alpha))<1e-5 and abs(cos(beta))<1e-5:
		b2=[0,0,lc];
	else:
		t1=(cos(alpha)*cos(gamma)-cos(beta))/sin(gamma);
		t2=cos(alpha);
		theta=arcsin((t1*t1+t2*t2)**0.5);
		if (theta-pi/2)<1e-5:
			b2=[0,0,lc];
		else:
			phisin=arcsin(t1/sin(theta));
			phicos=arccos(t2/sin(theta));
			if phicos<0:
				phi=phisin+pi;
			else:
				phi=phisin;
			b2=[lc*sin(theta)*cos(phi),lc*sin(theta)*sin(phi),lc*cos(theta)];
	basis=array([b0,b1,b2]);
	lattice.set('basis_imported_fromcif',basis);
		
		
def import_atoms_fromxyz(lattice,xyz_filename):
	from atoms import Atom;
	from pydao.ohdf import OGroup;
	import pydao.chemistry as chem;
	atoms=OGroup();
	f = open(xyz_filename, "r");
	for line in f:
		line_strs=line.split();
		print "line_strs",line_strs
		if len(line_strs)==4:
			pos_str=str(line_strs[1:]).replace("'","");
			print pos_str
			try:
				atom_pos=array(eval(pos_str));
			except:
				atom_pos=None;
			if atom_pos is not None:
				print "atom_pos:",atom_pos
				atom_type=line_strs[0];
				mass=chem.PTable[atom_type]['mass'];
				charge=chem.PTable[atom_type]['charge'];
				atom=Atom(mass,charge,atom_type,atom_pos);
				i=0;
				atomstr=atom_type+str(i);
				atom0=atoms.get(atomstr);
				while atom0 is not None:
					i=i+1;
					atomstr=atom_type+str(i);
					atom0=atoms.get(atomstr);
				atoms.set(atomstr,atom);
	f.close();
	lattice.set('atom_imported_fromxyz',atoms);
	
def filter_atoms_primitivecell(lattice,atoms=None,basis=None):
	if atoms is None:
		atoms=lattice.get('atoms');
	if basis is None:
		basis=lattice.get('basis');
	
	for k in atoms.keys():
		print "atom:",k
		atom=atoms.get(k);
		direct=lattice.cartesian2direct(atom.get('position'),basis=basis);
		outofbox=False;
		for b in direct:
			if b>=0.99 or b<0:
				outofbox=True;
		if outofbox:
			atoms.remove(k);
		
def cal_kbasis(lattice,basis=None):
	if basis is None:
		basis=lattice.get('basis');
	lattice.cal_basis3d(basis);
	basis3d=lattice.get('basis3d');
	vol=volume(basis3d);
	k0max=2*pi*vXprod(array(basis3d[1]),basis3d[2])/vol;
	k1max=2*pi*vXprod(basis3d[2],array(basis3d[0]))/vol;
	k2max=2*pi*vXprod(basis3d[0],array(basis3d[1]))/vol;
	lattice.set('kbasis3d',array([k0max,k1max,k2max]));
	if len(basis)<3:
		lattice.set('kbasis',lattice.get('kbasis3d')[0:len(basis)]);
	else:
		lattice.set('kbasis',lattice.get('kbasis3d'));
				
def cal_basis3d(lattice,basis):
	if len(basis)==3:
		basis3d=basis;
	elif len(basis)==1:
		basis3d=list(basis)+[(0,1,0),(0,0,1)];
	elif len(basis)==2:
		base3=vXprod(basis[0],basis[1]);
		base3=vnorm(base3);
		basis3d=list(basis)+[base3];
		basis3d=array(basis3d);
	lattice.set('basis3d',basis3d);

def direct2cartesian(lattice,direct,basis=None):
	if basis is None:
		basis=lattice.get('basis');
	cartpos=zeros(3);
	for i in range(3):
		cartpos=cartpos+direct[i]*basis[i];
		#print "cartpos",cartpos
	return cartpos;
		
def cartesian2direct(lattice,cartesian,basis=None):
	if basis is None:
		basis=lattice.get('basis');
	return lattice.find_lattice_index(basis,cartesian);
		
def centerofmass(lattice):
	atoms=lattice.get('atoms');
	cm=zeros(3);
	mass=0;
	for k in atoms.keys():
		atom=atoms.get(k);
		mass=mass+atom.get('mass');
		cm=cm+atom.get('position')*atom.get('mass');
	cm=cm/mass;
	return cm;
		
def find_pack_max_indices_withindistance(lattice,nei_distance):
	basis=lattice.get('basis');
	intercept0=faceintercept(basis[0],[basis[1],basis[2]],nei_distance);
	intercept1=faceintercept(basis[1],[basis[0],basis[2]],nei_distance);
	intercept2=faceintercept(basis[2],[basis[1],basis[0]],nei_distance);
	index0=int(ceil(abs(intercept0)/vlen(basis[0])));
	index1=int(ceil(abs(intercept1)/vlen(basis[1])));
	index2=int(ceil(abs(intercept2)/vlen(basis[2])));
	max_indices=array([index0,index1,index2]);
	return max_indices;
		
def find_pack_max_indices_withinparallelepiped(lattice,basis1):
	basis=lattice.get('basis');
	a0=zeros(3);
	for i0 in [0,1]:
		for i1 in [0,1]:
			for i2 in [0,1]:
				b=i0*basis1[0]+i1*basis1[1]+i2*basis1[2];
				a=cartesian2direct(basis,b);
				for i in [0,1,2]:
					if a[i]>a0[i]:
						a0[i]=a[i];
	max_indices=a0;
	return max_indices;
		
def register_nearest_kind(lattice,atoms=None,basis=None):
	if atoms is None:
		atoms=lattice.get('atoms');
	if basis is None:
		basis=lattice.get('basis');
	for k in atoms.keys():
		print k
		#if k=='Bi1':
		atom=atoms.get(k);
		atom.register_nearest_kind(atoms,basis);
	print "registered nearest kind"

def register_neighbors(lattice,atoms=None,basis=None,nei_distance=None):
	if nei_distance is None:
		nei_distance=lattice.get('nei_distance');
	if atoms is None:
		atoms=lattice.get('atoms');
	if basis is None:
		basis=lattice.get('basis');
	pack_max_indices=lattice.find_pack_max_indices_withindistance(nei_distance);
	print "pack_max_indices:",pack_max_indices
	for k in atoms.keys():
		atom=atoms.get(k);
		nei=atom.register_neighbor(atoms,basis,nei_distance,pack_max_indices);
		print "atom name:",k
		print "number of neis:",nei
		
def fill_parallepiped(lattice,basis1):
	max_indices=find_pack_max_indices_withinparallelepiped(basis1);
	print "pack_max_indices:",pack_max_indices
	atoms=lattice.get('atoms');
	basis=lattice.get('basis');
	for k in atoms.keys():
		atom=atoms.get(k);
		nei=atom.register_neighbor(atoms,basis,nei_distance,pack_max_indices);
		print "atom name:",k
		print "number of neis:",nei
	
def find_force_constant(lattice,atom1,atom2,forcetype='Coulomb'):
	force_constant_list=lattice.get('force_constant_list');
	strength=None;
	#force=None;
	if forcetype=='Coulomb':
		distance=atom1.distancefrom(atom2);
		strength=atom1.get('charge')*atom2.get('charge')/distance**3;
		strength=abs(strength);
	else:
		for force_constant in force_constant_list:
			atom_type1=force_constant.atomtypes[0];
			atom_type2=force_constant.atomtypes[1];
			distance=atom1.distancefrom(atom2);
			#print "atom1:",atom_type1,
			#print "atom2:",atom_type2,
			if (atom_type1==atom1.get_type() and atom_type2==atom2.get_type()) or (atom_type1==atom2.get_type() and atom_type2==atom1.get_type()):
			#print "distance:",distance
				if abs(distance-force_constant.distance)<1e-3*force_constant.distance:
					if type(force_constant.strength) is not str:
						strength=force_constant.strength;
					elif force_constant.strength=='Coulomb':
						strength=atom1.charge*atom2.charge/distance**3;
						strength=abs(strength);
			
	if strength is None:
		print "wrong! no foce constant found!"
		print "atom1:",atom1.get_type(),
		print "atom2:",atom2.get_type(),
		#print "distance:",distance
		print "\n"
		atom1.disp();
		atom2.disp();
	return strength;
		
def plot3d_basis(lattice,basis=None,color=(0,0,1)):
	if basis is None:
		basis=lattice.get('basis')
	for b in basis:
		b0=zeros(3);
		plot3d_vector(b0,b,color);

def plot3d_primitive_cell(lattice,basis=None,color=(0,1,0)):
		#lattice.plot3d_basis();
	if basis is None:
		basis=lattice.get('basis');
	b0=zeros(3);
		
	plot3d_vector(b0,basis[0],color,mode='2ddash');
	plot3d_vector(basis[1],basis[0],color,mode='2ddash');
	plot3d_vector(basis[2],basis[0],color,mode='2ddash');
	plot3d_vector(basis[1]+basis[2],basis[0],color,mode='2ddash');
	
	plot3d_vector(b0,basis[1],color,mode='2ddash');
	plot3d_vector(basis[0],basis[1],color,mode='2ddash');
	plot3d_vector(basis[2],basis[1],color,mode='2ddash');
	plot3d_vector(basis[0]+basis[2],basis[1],color,mode='2ddash');
	
	plot3d_vector(b0,basis[2],color,mode='2ddash');
	plot3d_vector(basis[1],basis[2],color,mode='2ddash');
	plot3d_vector(basis[0],basis[2],color,mode='2ddash');
	plot3d_vector(basis[1]+basis[0],basis[2],color,mode='2ddash');
		
def plot3d_kbasis(lattice,color=(1,0,0)):
	for b in lattice.get('kbasis'):
		b0=zeros(3);
		plot3d_vector(b0,b,color);

def plot3d_atoms(lattice,atoms=None,color=None,textwidth=None):
	if atoms is None:
		atoms=lattice.get('atoms');
	for k in atoms.keys():
		atom=atoms.get(k);
		atom.plot3d(color,textwidth);

def plot3d_nearest(lattice,atom_name,color=None):
	atoms=lattice.get('atoms');
	basis=lattice.get('basis');
	atom=atoms.get(atom_name);
	atom.plot3d(textwidth=atom_name);
	nearest_table=atom.get('nearest_table');
	for row in nearest_table.get_ondisk().iterrows():
		nei=atoms.get(row['name']);
		nei=nei.copy2mem();
		lattice_index=array([row['i0'],row['i1'],row['i2']]);
		nei.set_position(basis,lattice_index);
		nei.plot3d();
			
def plot3d_neighbors(lattice,atom_name,color=None):
	atoms=lattice.get('atoms');
	basis=lattice.get('basis');
	atom=atoms.get(atom_name);
	atom.plot3d(textwidth=atom_name);
	neighbor_table=atom.get('neighbor_table');
	for row in neighbor_table.get_ondisk().iterrows():
		nei=atoms.get(row['name']);
		nei=nei.copy2mem();
		lattice_index=array([row['i0'],row['i1'],row['i2']]);
		nei.set_position(basis,lattice_index);
		nei.plot3d();

def unify_coordinates(lattice,atoms=None):
	if atoms is None:
		atoms=lattice.get('atoms');
	basis=lattice.get('basis');
	for k in atoms.keys():
		atom=atoms.get(k);
		if atom.get('lattice_index') is not None:
			atom.set_abs_intrapos(basis);
			atom.set_position(basis);
		
def translate_atoms(lattice,atoms,basis,displacement,coordinate,displace_intrapos):
	from pydao.ohdf import get_empty_instance;
	#basis=lattice.get('basis');
	if coordinate[0]=="direct":
		cart_disp=lattice.direct2cartesian(displacement,basis);
	else:
		cart_disp=displacement;
	print "displacement:",displacement
	print "cart_disp:",cart_disp
	newatoms=get_empty_instance(atoms);
	for k in atoms.keys():
		atom=atoms.get(k);
		newatom=atom.copy2mem();
		newatom.translate_cart(cart_disp);
		newatoms.set(k,newatom);
		if displace_intrapos:
			newatom.set('intrapos',newatom.get('position'));
			newatom.set('coordinate','cartesian');
	return newatoms;
		
def DynamicMat(lattice,veck):
	nei_distance=lattice.get('nei_distance');
	atoms=lattice.get('atoms');
	basis=lattice.get('basis');
		
	ndims=len(basis);
	natoms=len(atoms.keys());
	Dynamicmat=zeros([ndims*natoms,ndims*natoms],'complex');
	#lattice.neighbor_matPhi_withindistance(nei_distance);
	iatom=-1;
	for katom in atoms.keys():
		iatom=iatom+1;
		atom1=atoms.get(katom);
		#print atom.name
		atomname1=katom;
		atommass1=atom1.get('mass');
		neighbor_table=atom1.get('neighbor_table');
		matPhi_list=atom1.get('matPhi_list');
		phi00=zeros([ndims,ndims],'complex');
			
		i_nei=-1;
		for row in neighbor_table.get_ondisk().iterrows():
			i_nei=i_nei+1;
			atomname2=row['name'];
			nei=atoms.get(atomname2);
			matPhi=matPhi_list[i_nei];
			phi00=phi00-matPhi;
			lattice_index=array([row['i0'],row['i1'],row['i2']]);
			atommass2=nei.get('mass');
			jatom=atoms.keys().index(atomname2);
			delta=zeros(3);
			for dim in range(ndims):
				delta=delta+array(basis[dim])*lattice_index[dim];
			deltadotk=vdotprod(delta,veck);
			jj=complex(0,1);
			for i_v in range(ndims):
				for i_h in range(ndims):
					temp=matPhi[i_v][i_h]*exp(jj*deltadotk)/sqrt(atommass1*atommass2);
					Dynamicmat[iatom*ndims+i_v][jatom*ndims+i_h]=Dynamicmat[iatom*ndims+i_v][jatom*ndims+i_h]+temp;

		for i_v in range(ndims):
			for i_h in range(ndims):
				Dynamicmat[iatom*ndims+i_v][iatom*ndims+i_h]+=phi00[i_v][i_h]/atommass1;
	#print "Dynamicmat:\n",real(Dynamicmat)
	return Dynamicmat;
	
def find_exchange_interaction(lattice,atom1,atom2):
	sz1=atom1.get('sz');
	sz2=atom2.get('sz');
	strength=sz1*sz2;
	return strength;
	
def NNIsingHamiltonian(lattice,strength=1,atoms=None):
	import pydao.tools;
	import pydao.physics.Heisenberg_model as hm;
	if atoms is None:
		atoms=lattice.get('atoms');
	Na=len(atoms.keys());
	Nv=2**Na;
	IMat=zeros([Nv,Nv]);
	SzMat=zeros([Nv,Nv]);
	pt=pydao.tools.Progress_Teller(Nv*Nv,0.001);
	atomkeys=atoms.keys();
	for iv in range(Nv):
		i_atom=-1;
		for katom in atomkeys:
			i_atom=i_atom+1;
			szi=floor(mod(iv,2**(i_atom+1))/2**i_atom)-0.5;
			SzMat[iv,iv]+=szi;
		for jv in range(Nv):
			pt.tell(iv*Nv+jv);
			iatom=-1
			for katom in atomkeys:
				iatom=iatom+1;
				szi=floor(mod(iv,2**(iatom+1))/2**iatom)-0.5;
				
				atom1=atoms.get(katom);
				neighbor_table=atom1.get('neighbor_table');
				for row in neighbor_table.get_ondisk().iterrows():
					atomname2=row['name'];
					jatom=atomkeys.index(atomname2);
					szj=floor(mod(jv,2**(jatom+1))/2**jatom)-0.5;
					#szj=mod(floor(jv/2**jatom),2**(jatom+1))-0.5;
					#print iv,jv,iatom,jatom,szi,szj
					IMat[iv,jv]+=strength*szi*szj;
	return (IMat,SzMat);
	
def ET(lattice,TRange,strength=1,atoms=None):
	IMat,SzMat=lattice.NNIsingHamiltonian(strength,atoms);
	ERange=TRange-TRange;
	i=-1;
	for T in TRange:
		i=i+1;
		ERange[i]=diag(IMat*exp(-IMat/T)).sum()/diag(exp(-IMat/T)).sum();
	return ERange;
	
def MT(lattice,T,BRange,strength=1,atoms=None):
	IMat,SzMat=lattice.NNIsingHamiltonian(strength,atoms);
	SzRange=BRange-BRange;
	i=-1;
	for B in BRange:
		i=i+1;
		HMat=IMat-SzMat*B;
		SzRange[i]=diag(SzMat*exp(-HMat/T)).sum()/diag(exp(-HMat/T)).sum();
	return SzRange;
