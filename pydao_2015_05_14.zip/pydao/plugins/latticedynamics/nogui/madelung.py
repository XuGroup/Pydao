import pydao;
from pylab import *;
from pydao.ohdf import OFile;
la=pydao.cog().get('lattice');
nei_dist_range=arange(4,50,1.);
ofile=OFile('Emadelung.hdf');

E_made=nei_dist_range-nei_dist_range;
i_dist=0;
for nei_dist in nei_dist_range:
	print "nei_dist",nei_dist
	la.register_neighbors(nei_distance=nei_dist);
	E_made[i_dist]=la.Madelung();
	ofile.open();
	ofile.set('E_made',E_made);
	ofile.close();
	i_dist=i_dist+1;