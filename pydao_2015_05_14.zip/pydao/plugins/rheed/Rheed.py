from pylab import *;
from  pydao.ohdfvi import Application;
from  pydao.ohdf import OGroup;

class RHEED(OGroup,Application):

	def __init__(self):
		OGroup.__init__(self);
		
	def contextmenu(self,parentmenu):
		Application.contextmenu(self,parentmenu);
		import wx;
		item=parentmenu.Append(wx.NewId(),"New Lattice","New Lattice");
		parentmenu.Bind(wx.EVT_MENU,self.OnNewLattice,item)
		
		item=parentmenu.Append(wx.NewId(),"New Config","New Config");
		parentmenu.Bind(wx.EVT_MENU,self.OnNewConfig,item);
		
		item=parentmenu.Append(wx.NewId(),"Analyze","Analyze");
		parentmenu.Bind(wx.EVT_MENU,self.OnAnalyze,item);

#============================methods=========================================

	def OnNewLattice(app,event):
		from pydao.physics.solidstate.lattice import Lattice;
		from pydao.physics.solidstate.atoms import Atom;
		#print "in OnNewConfiguration"
		a=5.35;
		a1=array([a, a, 0.])
		a2=array([a, 0,  a])
		a3=array([0., a, a]);
		basis=array([a1,a2,a3]);
		
		
		atoms=OGroup();
		print Atom
		AtomBi = Atom(mass=209.,charge=3.,intrapos=array([0.01,0.01,0.01]),\
		coordinate='direct',type='Bi');
		atoms.set('Bi1',AtomBi);
		
		AtomBi = Atom(mass=209.,charge=3.,intrapos=array([0.51,0.51,0.51]),\
		coordinate='direct',type='Bi');
		atoms.set('Bi2',AtomBi);
		
		AtomFe = Atom(mass=56.,charge=3.,intrapos=array([0.25,0.25,0.25]),\
		coordinate='direct',type='Fe');
		atoms.set('Fe1',AtomFe);

		AtomFe = Atom(mass=56.,charge=3.,intrapos=array([0.75,0.75,0.75]),\
		coordinate='direct',type='Fe');
		atoms.set('Fe2',AtomFe);
		
		AtomO1 = Atom(mass=16.,charge=-2.,intrapos=array([0.5,0.,0.]),\
		coordinate='direct',type='O');
		atoms.set('O1',AtomO1);
		
		AtomO2 = Atom(mass=16.,charge=-2.,intrapos=array([0.,0.5,0.]),\
		coordinate='direct',type='O');
		atoms.set('O2',AtomO2);

		AtomO3 = Atom(mass=16.,charge=-2.,intrapos=array([0.,0.,0.5]),\
		coordinate='direct',type='O');
		atoms.set('O3',AtomO3);
		
		AtomO1 = Atom(mass=16.,charge=-2.,intrapos=array([0.5,0.5,0.]),\
		coordinate='direct',type='O');
		atoms.set('O4',AtomO1);
		
		AtomO2 = Atom(mass=16.,charge=-2.,intrapos=array([0.,0.5,0.5]),\
		coordinate='direct',type='O');
		atoms.set('O5',AtomO2);

		AtomO3 = Atom(mass=16.,charge=-2.,intrapos=array([0.5,0.,0.5]),\
		coordinate='direct',type='O');
		atoms.set('O6',AtomO3);
			
		lattice=Lattice();
		lattice.set('atoms',atoms);
		lattice.set('basis',basis);
		lattice.set('nei_distance',2**0.5*a/2*1.1);
		app.set('lattice',lattice);
		print "default lattice constructed"
			
	def OnNewConfig(app,event):
		config=OGroup();
		config.set('Ebeam',34.5e3*1.6e-19);
		config.set('theta0',2/180.*pi);
		config.set('phi0',0);
		config.set('hklface',array([1,1,1]));
		config.set('hklbeam',array([1,-1,0]));
		config.set('Nk',4);
		config.set('marker','bo');
		#config.set('k_direction_list',
		app.set('config',config);
		print "new app done."

	def OnAnalyze(app,event):
		from Rheed_view import rheed_analysis_view;
		view=rheed_analysis_view(app);
		app.configure_traits(view=view);

	def rotate_kspace(app,theta0,phi0,hklface,hklbeam):
		from pydao.math import direct2cartesian,mat_rotate_alongx,mat_rotate_alongy,mat_rotate_alongz,mat_rotate2z,vcos;
		from pydao.physics.solidstate import plot3d_vector;
		result=OGroup();
		lattice=app.get('lattice');
		atoms=lattice.get('atoms');
		force_constant_list=lattice.get('force_constant_list');
		basis=lattice.get('basis');
		k_basis=lattice.get('kbasis');
		
		#===========
		kface_cart=direct2cartesian(k_basis,hklface);
		mat=mat_rotate2z(kface_cart);
		k_basis1=matrix(k_basis)*mat;
		kface_cart_rotated=array(matrix(kface_cart)*mat)[0];
		# print kface_cart
		# print mat
		# print k_basis1
		# print kface_cart_rotated
		#lattice.plot3d_kbasis(array(k_basis1));
		#lattice.plot3d_primitive_cell(array(k_basis1));
		#plot3d_vector((0,0,0),kface_cart_rotated,color=(1,1,0));
		
		kbeam_cart=direct2cartesian(array(k_basis1),hklbeam);
		phi=arccos(vcos(array([kbeam_cart[0],kbeam_cart[1],0]),array([1,0,0])));
		if kbeam_cart[1]<0:
			phi=phi+pi;
		mat=mat_rotate_alongz(pi-phi);
		k_basis1=matrix(k_basis1)*mat;
		kbeam_cart_rotated=array(matrix(kbeam_cart)*mat)[0];
		#lattice.plot3d_kbasis(array(k_basis1));
		#lattice.plot3d_primitive_cell(array(k_basis1));
		#plot3d_vector((0,0,0),kbeam_cart_rotated,color=(1,0,1));
		
		#mat_theta=mat_rotate_alongy(theta0);
		mat_phi=mat_rotate_alongz(phi0);
		#k_basis_rotated=matrix(k_basis1)*mat_theta*mat_phi;
		k_basis_rotated=matrix(k_basis1)*mat_phi;
		#print k_basis_rotated
		result.set('k_basis_rotated',k_basis_rotated);
		lattice.plot3d_kbasis(array(k_basis_rotated));
		lattice.plot3d_primitive_cell(array(k_basis_rotated));
		
		#print "kface_cart",kface_cart_rotated
		#print matrix(kface_cart_rotated)*mat_theta*mat_phi
		#print "kbeam_cart1",kbeam_cart_rotated
		#print matrix(kbeam_cart_rotated)*mat_theta*mat_phi
		plot3d_vector((0,0,0),array(matrix(kface_cart_rotated)*mat_phi)[0],color=(1,1,0));
		plot3d_vector((0,0,0),array(matrix(kbeam_cart_rotated)*mat_phi)[0],color=(1,0,1));
		print "Done rotating k space."
		return result;

	def cal_list_theta_phi(app,Nk,Ebeam,theta0,marker='bo'):
		from pydao.math import direct2cartesian,vlen,vcos,cell_limits;
		result=app.get('result');
		k_basis_rotated=result.get('k_basis_rotated');
		Nk_Range=range(-2*Nk,2*Nk+1);
		
		eV=1.6e-19;
		hbar=1.05e-34;
		me=9.1e-31;
		k_in=(2*me*Ebeam)**0.5/hbar/1e10;
		k_origin_eward=array([-k_in*cos(theta0),0,k_in*sin(theta0)]);
		print "k_in",k_in
		print "k_origin_eward",k_origin_eward
		
		k_list=[];
		theta_list=[];
		phi_list=[];
		intensity_list=[];
		
		k_limits=cell_limits(array(k_basis_rotated));
		kz_width=k_limits[2][1]-k_limits[2][0];
		for ik0 in Nk_Range:
			for ik1 in Nk_Range:
				for ik2 in Nk_Range:
					k=direct2cartesian(k_basis_rotated,array([ik0,ik1,ik2]));
					if len(k.shape)==2:
						k=array(k)[0];
					k1=array(k)-k_origin_eward;
					k_xy=array([k1[0],k1[1],0]);
					if (vlen(k_xy)<k_in or abs(vlen(k1)-k_in)<1e-3) and vlen(k)<=Nk*vlen(k_basis_rotated[0]) and k[2]>k_limits[2][0]-kz_width*1.1  and k[2]<k_limits[2][1]+kz_width*1.1:
						if vlen(k1)>k_in:
							print "out of Eward sphere",ik0,ik1,ik2
						theta=arccos(vlen(k_xy)/k_in)+theta0;
						#print "k1",k1
						# if theta<theta0:
							# print 'negative theta0'
						phi=arccos(vcos(k_xy,array([1,0,0])))*sign(k1[1]);
						
						z=(k_in**2-vlen(k_xy)**2)**0.5;
						k_xyz=array([k1[0],k1[1],z]);
						alpha=arccos(vcos(k_xyz-k_origin_eward,k_origin_eward));
						
						intensity=(sin(theta0)/sin(alpha))**3;
						theta_list.append(theta);
						phi_list.append(phi);
						intensity_list.append(intensity);
						k_list.append(k);
					# if ik0==0 and ik1==0 and ik2==0:
						# print ik0,ik1,ik2
						# print "k",k
						# print "k_origin_eward",k_origin_eward
						# print "k1",k1
						# print "k_xy",k_xy
						# print "theta",theta,theta0
						# print "phi",phi
					#elif 
		result.set('theta_list',theta_list);
		result.set('phi_list',phi_list);
		result.set('intensity_list',intensity_list);
		result.set('k_list',k_list);
		result.set('k_in',k_in);
		result.set('k_origin_eward',k_origin_eward)
		plot(0,sin(theta0),'+',markersize=10);
		for i in range(len(theta_list)):
			z=sin(theta_list[i]);
			y=sin(phi_list[i]);
			if abs(theta_list[i]-2*theta0)<1e-3 and phi_list[i]==0:
				plot(y,z,'bp',markersize=intensity_list[i]/max(intensity_list)*10);
			else:
				plot(y,z,marker,markersize=intensity_list[i]/max(intensity_list)*10);
				
		print "Done calculating theta phi intensity"
		return result;
		

	def cal_list_theta_phi_island(app,Nk,Ebeam,theta0):
		from pydao.math import direct2cartesian,vlen,vcos;
		result=app.get('result');
		k_basis_rotated=result.get('k_basis_rotated');
		Nk_Range=range(-4*Nk,4*Nk+1);
		
		eV=1.6e-19;
		hbar=1.05e-34;
		me=9.1e-31;
		k_in=(2*me*Ebeam)**0.5/hbar/1e10;
		k_origin_eward=array([-k_in*cos(theta0),0,k_in*sin(theta0)]);
		print "k_in",k_in
		print "k_origin_eward",k_origin_eward
		
		k_list=[];
		theta_list=[];
		phi_list=[];
		intensity_list=[];
		for ik0 in Nk_Range:
			for ik1 in Nk_Range:
				for ik2 in Nk_Range:
					k=direct2cartesian(k_basis_rotated,array([ik0,ik1,ik2]));
					if len(k.shape)==2:
						k=array(k)[0];
					k1=array(k)-k_origin_eward;
					if (vlen(k1)<k_in or abs(vlen(k1)-k_in)<1e-3) and vlen(k)<Nk*vlen(k_basis_rotated[0]) and k[2]>k_origin_eward[2]:
						k_yz=array([0,k1[1],k1[2]]);
						x=(k_in**2-vlen(k_yz)**2)**0.5;
						k_xyz=array([x,k1[1],k1[2]]);
						
						k_xy=array([x,k1[1],0]);
						theta=arccos(vlen(k_xy)/k_in)+theta0;
						#print "k1",k1
						if theta<theta0:
							print 'negative theta0'
						
						phi=arccos(vcos(k_xy,array([1,0,0])))*sign(k1[1]);
						#phi=arccos(vcos(array([k_xyz[0],k_xyz[1],0]),array([1,0,0])))*sign(k1[1]);
						# print "x:",x
						# print "k_xyz:",k_xyz
						# print "phi:",phi
						
						alpha=arccos(vcos(k_xyz-k_origin_eward,k_origin_eward));
						if alpha<theta0:
							print "wrong alpha:",apha,theta0
						intensity=(sin(theta0)/sin(alpha))**1;
						theta_list.append(theta);
						phi_list.append(phi);
						intensity_list.append(intensity);
						k_list.append(k);
						if ik0==0 and ik1==0 and ik2==0:
							print ik0,ik1,ik2
							print "k",k
							print "k_origin_eward",k_origin_eward
							print "k1",k1
							print "k_xy",k_xy
							print "theta",theta,theta0
							print "phi",phi
			
		result_island=OGroup();
		result_island.set('theta_list',theta_list);
		result_island.set('phi_list',phi_list);
		result_island.set('intensity_list',intensity_list);
		result_island.set('k_list',k_list);
		result_island.set('k_in',k_in);
		result_island.set('k_origin_eward',k_origin_eward)
		plot(0,sin(theta0),'+',markersize=10);
		for i in range(len(theta_list)):
			z=sin(theta_list[i]);
			y=sin(phi_list[i]);
			if abs(theta_list[i]-2*theta0)<1e-3 and phi_list[i]==0:
				plot(y,z,'rp',markersize=intensity_list[i]/max(intensity_list)*10);
			else:
				plot(y,z,'rs',markersize=intensity_list[i]/max(intensity_list)*10);
				
		print "Done calculating theta phi intensity"
		#figure();
		#plot(intensity_list);
		return result_island;