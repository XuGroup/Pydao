import os;
import mx.DateTime;
from scipy import interpolate;
from scipy.optimize import fmin;
from copy import *;
from numpy import *;

from  pydao.ohdf import OGroup,OTable;
from  pydao.ohdfvi import Application;
from enthought.traits.api import HasTraits;
from tables import *;

from eas_hdf import *;
from pydao.ohdf import natural_name

class Data_Table(OTable,Application):
	def __init__(self,*args,**kwargs):
		OTable.__init__(self,*args,**kwargs);
		
	def contextmenu(self,parentmenu):
		import wx;
		item=parentmenu.Append(wx.NewId(),"Histogram","Hist");
		parentmenu.Bind(wx.EVT_MENU,self.OnHist,item);
		item=parentmenu.Append(wx.NewId(),"TableView","TableView");
		parentmenu.Bind(wx.EVT_MENU,self.OnTableView,item);
		item=parentmenu.Append(wx.NewId(),"ExcelView","ExcelView");
		parentmenu.Bind(wx.EVT_MENU,self.OnExcelView,item);
		
	def OnHist(self,event):
		from enthought.traits.ui.api import Item,View,EnumEditor;
		values=dict(Enum(self.get_fieldnames()));
		self.field_chosen='';
		for k in values.keys():
			values[k]=k;
		view1=View(Item(name='field_chosen',editor=EnumEditor(values=values),style="custom"),buttons = ['OK', 'Cancel'],resizable=True,width=.5,height=.5,kind='livemodal');
		ok=self.configure_traits(view=view1);
		if ok:
			print "chosen field:",self.field_chosen;
			self.histogram(self.field_chosen);
			
	def OnTableView(self,event):
		from pydao.ohdfvi import SpreadSheet_Viewer;
		#self.convert2list();
		print self.read2memory().shape
		viewer=SpreadSheet_Viewer(self,self.read2memory(),self.get_fieldnames());
		viewer.main();
		#viewer.append_table(self);
		#viewer.tabbed_spreadsheet_view();

	def OnExcelView(self,event):
	#self.spreadsheet=self.get_worksheet_2darray();
		from win32com.client import constants, Dispatch;
		import pythoncom;
		excelapp = Dispatch("Excel.Application");
		excelapp.visible=1;
		workbook = excelapp.Workbooks.Add();
		spreadsheet0=array(self.read2memory());
		#print "spreadsheet0.shape:",spreadsheet0.shape
		#nrow,ncol=spreadsheet.shape;
		nrow=spreadsheet0.shape[0];
		spreadsheet=None;
		for irow in range(nrow):
			#print spreadsheet0[irow],type(spreadsheet0[irow])
			#print type(array(spreadsheet0[irow])),array(spreadsheet0[irow]).shape
			#print len(list(spreadsheet0[irow]))
			if spreadsheet is None:
				spreadsheet=array(list(spreadsheet0[irow]));
			else:
				spreadsheet=vstack((spreadsheet,array(list(spreadsheet0[irow]))));
		nrow,ncol=spreadsheet.shape;
		#print "spreadsheet.shape:",spreadsheet.shape
		
		iname=1;
		for col_name in self.get_fieldnames():
			ran=self.nn2an(1,iname);
			excelapp.Range(ran).Value=col_name;
			iname=iname+1;
		
	# for irow in range(nrow):
		# for icol in range(ncol):
			# ran=self.nn2an(irow+2,icol+1);
			#print "ran:",ran;
			# excelapp.Range(ran).Value=spreadsheet[irow,icol];
		coldatalist=range(nrow);
		for icol in range(ncol):
			print 'icol:',icol
			coldata=array(spreadsheet[:,icol]);
			for irow in range(nrow):
				coldatalist[irow]=(float(spreadsheet[irow,icol]),);
			ran1=self.nn2an(0+2,icol+1);
			ran2=self.nn2an(nrow+1,icol+1);
			excelapp.Range(ran1+":"+ran2).Value=tuple(coldatalist);
		
	def histogram(self,fieldname):
		datafield=self.get_column(fieldname);
		hist(datafield,100);
		show();
		pass;
		
	def nn2an(self,r,c):
	#Thanks Brett Shoelson
		col=c;
		colstr='';
		while col>26:
			co=col%26;
			colstr=chr(co+65)+colstr;
			col=(col-co)/26;
		colstr=chr(col+64)+colstr;
		return colstr+str(r);
#=========================================================================
class EOS_Data_Analysis(OGroup,Application):
	def __init__(self):
		OGroup.__init__(self);
		Application.__init__(self);
		#pass;
	
	def contextmenu(self,parentmenu):
		import wx;
		#print "in context menu:"
		item=parentmenu.Append(wx.NewId(),"Open Analysis","Open Analysis");
		parentmenu.Bind(wx.EVT_MENU,self.OnOpen,item);
		item=parentmenu.Append(wx.NewId(),"New MLS Filter","New MLS Filter");
		parentmenu.Bind(wx.EVT_MENU,self.OnNew_MLS_Config,item);
		item=parentmenu.Append(wx.NewId(),"New CloudSat Filter","New CloudSat Filter");
		parentmenu.Bind(wx.EVT_MENU,self.OnNew_CloudSat_Config,item);
		item=parentmenu.Append(wx.NewId(),"New AIRS Filter","New AIRS Filter");
		parentmenu.Bind(wx.EVT_MENU,self.OnNew_AIRS_Config,item);
		item=parentmenu.Append(wx.NewId(),"Load MLS","Load MLS");
		parentmenu.Bind(wx.EVT_MENU,self.OnLoad_MLS,item);
		item=parentmenu.Append(wx.NewId(),"Load CloudSat","Load CloudSat");
		parentmenu.Bind(wx.EVT_MENU,self.OnLoad_CloudSat,item);
		item=parentmenu.Append(wx.NewId(),"Load AIRS","Load AIRS");
		parentmenu.Bind(wx.EVT_MENU,self.OnLoad_AIRS,item);
		item=parentmenu.Append(wx.NewId(),"New EAS WorkSheet","New EAS WorkSheet");
		parentmenu.Bind(wx.EVT_MENU,self.OnNew_EASWorkSheet,item);
		#item=parentmenu.Append(wx.NewId(),"New Mesh Match Config","New Mesh Match Config");
		#parentmenu.Bind(wx.EVT_MENU,self.OnNew_Mesh_Match_Config,item);
		#item=parentmenu.Append(wx.NewId(),"Mesh Match","Mesh Match");
		#parentmenu.Bind(wx.EVT_MENU,self.OnMesh_Match,item);
		#item=parentmenu.Append(wx.NewId(),"Mesh Match Batch","Mesh Match Batch");
		#parentmenu.Bind(wx.EVT_MENU,self.OnMesh_Match_Batch,item);
		
	def OnNew_AIRS_Config(self,event):
		self.new_EAS_HDF_Config('AIRS');

	def OnNew_MLS_Config(self,event):
		self.new_EAS_HDF_Config('MLS');
		
	def OnNew_CloudSat_Config(self,event):
		self.new_EAS_HDF_Config('CloudSat');
		
	def OnLoad_MLS(self,event):
		self.load_EAS_HDF('MLS');
		
	def OnLoad_CloudSat(self,event):
		self.load_EAS_HDF('CloudSat');
		
	def OnLoad_AIRS(self,event):
		self.load_EAS_HDF('AIRS');
		
	def OnLoad_EAS_HDF(self,event):
		self.load_EAS_HDF('EAS_HDF');
		
	def OnNew_Mesh_Match_Config(self,event):
		self.new_mesh_match_config();
		
	def OnMesh_Match(self,event):
		from pydao.ohdfvi import Hanlder_to_Fix_TextEditor;
		from enthought.traits.ui.api import Item,Group,VGroup,View,CheckListEditor;
		configname="mesh_match_config";
		config=self.get(configname);
		
		self.x_resolution=1;
		self.y_resolution=1;
		self.table1_name=[self.keys()[0]];
		self.table2_name=[self.keys()[0]];
		self.output_table_name='';
		
		group=VGroup(\
		Item('x_resolution',show_label=True),\
		Item('y_resolution',show_label=True),\
		Item('table1_name',editor=CheckListEditor(values=self.keys()),show_label=True),\
		Item('table2_name',editor=CheckListEditor(values=self.keys()),show_label=True),\
		Item('output_name',show_label=True),\
		show_labels=False,show_border = True,label='Mesh Match');
		
		view=View(group,handler=Hanlder_to_Fix_TextEditor(),kind='modal',buttons=['OK','Cancel'],width=0.5);
		
		ok=self.configure_traits(view=view);
		if ok:
			table1=config.get('table1');
			table1.set('name',self.table1_name[0]);
			table2=config.get('table2');
			table2.set('name',self.table2_name[0]);
			config.set('x_resolution',self.x_resolution);
			config.set('y_resolution',self.y_resolution);
			config.set('output_name',self.output_table_name);
			self.mesh_match(config);
		
	def OnMesh_Match_Batch(self,event):
		configname='mesh_match_config';
		config=self.get(configname);
		self.mesh_match_batch(config);
		

		
	def load_EAS_HDF(self,filetype='EAS_HDF'):
		configfname='read_parameters_'
		config=self.get(configfname+filetype);
		import os;
		input=config.get('input');
		ffilename=input.get('filename');
		shape=input.get('shape');
		files=os.listdir(ffilename.get('directory'));
		for file in files:
			print "------------------------------"
			print file
			eos_file=self.filter_filename_date(file,filetype,config,shape=shape);
			if eos_file is not None:
				work_sheet=self.output_filtered_data(eos_file,config);
				if work_sheet is not None:
					work_sheet.set_meta('eas_hdf_type',filetype);
		
	def mesh_match(self,config):
		import pydao.math as pymath;
		reload(pymath);
		
		table1=config.get('table1');
		table2=config.get('table2');
		
		t1=self.get(table1.get('name'));
		t2=self.get(table2.get('name'));
		print t1,t2,table1.get('name'),table2.get('name')
		x1=t1.get_column(table1.get('x_name'));
		y1=t1.get_column(table1.get('y_name'));
		z1=t1.get_column(table1.get('z_name'));
		x2=t2.get_column(table2.get('x_name'));
		y2=t2.get_column(table2.get('y_name'));
		z2=t2.get_column(table2.get('z_name'));
		
		xmin=min(min(x1),min(x2));
		xmax=max(max(x1),max(x2));
		dx=config.get('x_resolution');
		x_mesh=arange(xmin-dx,xmax+dx,dx);
		
		ymin=min(min(y1),min(y2));
		ymax=max(max(y1),max(y2));
		dy=config.get('y_resolution');
		y_mesh=arange(ymin-dx,ymax+dx,dx);
		
		print "x range",xmin,xmax;
		print "y range",ymin,ymax;
		
		result1=pymath.xyz2index(x1,y1,z1,x_mesh,y_mesh);
		result2=pymath.xyz2index(x2,y2,z2,x_mesh,y_mesh);
		I=logical_and(result1['I'],result2['I']);
		x1=result1['x_mesh_indexed'][I];
		y1=result1['y_mesh_indexed'][I];
		z1=result1['z_indexed'][I];
		zcount1=result1['z_indexed_count'][I];
		
		x2=result2['x_mesh_indexed'][I];
		y2=result2['y_mesh_indexed'][I];
		z2=result2['z_indexed'][I];
		zcount2=result2['z_indexed_count'][I];
		
		output_name=config.get('output_name');
		if output_name=='':
			output_name=table1.get('name')+table2.get('name');
		result=OGroup();
		result.set(table1.get('name')+'_'+table1.get('x_name'),x1);
		result.set(table1.get('name')+'_'+table1.get('y_name'),y1);
		result.set(table1.get('name')+'_'+table1.get('z_name'),z1);
		result.set(table1.get('name')+'_'+table1.get('z_name')+'_count',zcount1);
		
		result.set(table2.get('name')+'_'+table2.get('x_name'),x2);
		result.set(table2.get('name')+'_'+table2.get('y_name'),y2);
		result.set(table2.get('name')+'_'+table2.get('z_name'),z2);
		result.set(table2.get('name')+'_'+table2.get('z_name')+'_count',zcount2);
		
		self.set(output_name,result);
		print "mesh match done."
		
	def mesh_match_batch(self,config):
		import pydao.math as pymath;
		reload(pymath);
		results={};
		
		folder_name=config.get('folder_name');
		dx=config.get('x_resolution');
		dy=config.get('y_resolution');
		
		table_cfg=config.get('table');
		co_table_names=table_cfg.get('co_table_names');
		x_name=table_cfg.get('x_name');
		y_name=table_cfg.get('y_name');
		z_names=table_cfg.get('z_names');
		
		
		ogroup=self.get(folder_name);
		
		for k in ogroup:
			if k.startswith(co_table_names[0]):
				tb=ogroup.get(k);
				x=tb.get_column(x_name);
				y=tb.get_column(y_name);
				xmin=min(x);
				xmax=max(x);
				ymin=min(y);
				ymax=max(y);
				for co_table_name in co_table_names[1:]:
					co_tb=ogroup.get(co_table_name);
					x1=tb.get_column(x_name);
					y1=tb.get_column(y_name);
					xmin=min(min(x1),xmin);
					xmax=max(max(x1),xmax);
					ymin=min(min(y1),ymin);
					ymax=max(max(y1),ymax);
				x_mesh=arange(xmin-dx,xmax+dx,dx);
				y_mesh=arange(ymin-dy,ymax+dy,dy);
				for z_name in z_names:
					try:
						z=tb.get_column(z_name);
						result=pymath.xyz2index(x,y,z,x_mesh,y_mesh);
						result_list.append(result);
					except:
						pass;
				for co_table_name in co_table_names[1:]:
					co_tb=ogroup.get(co_table_name);
					for z_name in z_names:
						try:
							z=tb.get_column(z_name);
							result=pymath.xyz2index(x,y,z,x_mesh,y_mesh);
							results[z_name]=result;
						except:
							pass;
				overlapI=logical_and(results['Height']['I'],results['CO_VMR_eff_A']['I']);
				non_overlapI=logical_xor(results['Height']['I'],results['CO_VMR_eff_A']['I']);
				height_overlap=results['Height']['z_mesh_indexed'][overlapI];
				Radar_Reflectivity_overlap=results['Radar_Reflectivity']['z_mesh_indexed'][overlapI];
				height_non_overlap=results['Height']['z_mesh_indexed'][non_overlapI];
				Radar_Reflectivity_non_overlap=results['Radar_Reflectivity']['z_mesh_indexed'][non_overlapI];
				matched=OGroup();
				matched.set('height_olp',height_overlap);
				matched.set('Radar_Reflectivity_olp',Radar_Reflectivity_overlap);
				matched.set('height_nolp',height_non_overlap);
				matched.set('Radar_Reflectivity_nolp',Radar_Reflectivity_non_overlap);
				self.set(k+'_matched',matched);
			else:
				print "skip co_table"
		
	def passed_filename_Config(self,filename,filter):
		#filter=self.get('filter');
		passed=True;
		ffilename=filter.get('filename');
		#print "filename:",filename;
		
		contain=ffilename.get('contain');
		if contain is not None and contain!='':
			if type(contain) is str:
				contain_list=[contain];
			else:
				contain_list=contain;
			for ct in contain_list:
				if filename.find(ct)==-1:
					passed=False;	
					print filename,'does not contain',ct
					print "contain not passed"
					break;
				#print "looking for:",ffilename.get('contain'),
		
		exclude=ffilename.get('exclude');
		if exclude is not None and exclude!='':
			if type(exclude) is str:
				exclude_list=[exclude];
			else:
				exclude_list=exclude;
			for ct in exclude_list:
				if filename.find(ct)!=-1:
					passed=False;
					print "exclude not passed"
					break;
					
		#if passed and ffilename.get('exclude') is not None and ffilename.get('exclude')!='':
		#	if filename.count(ffilename.get('exclude'))>0:
		#		passed=False;
		#		print "exclude not passed"
		if passed and  ffilename.get('beginwith') is not None and ffilename.get('beginwith')!='':
			if not filename.startswith(ffilename.get('beginwith')):
				passed=False;
				print "beginwith not passed"
		if passed and  ffilename.get('endwith') is not None and ffilename.get('endwith')!='':
			if not filename.endswith(ffilename.get('endwith')):
				#l1=len(filename);
				#l2=len(ffilename.get(endwith);
				#print filename[l1-l2:l1]
				passed=False;
				print "endwith not passed"
		return passed;
		
	def passed_time_Config(self,yymmdd,filter):
		passed=True;
		#filter=self.get('filter');
		ftime=filter.get('time');
		if ftime.get('year') is not None and ftime.get('year')>=0:
			if ftime.get('year').count(yymmdd.year)==0:
				passed=False;
		if ftime.get('month') is not None and ftime.get('month')>0:
			if ftime.get('year').count(yymmdd.month)==0:
				passed=False;
		if ftime.get('day') is not None and ftime.get('day')>0:
			if ftime.get('year').count(yymmdd.day)==0:
				passed=False;
		return passed;
		
	def filter_filename_date(self,filename,filetype,config,shape=None):
		input=config.get('input');
		output=config.get('output');
		ffilter=config.get('filter');
		cs_file=None;
		ffilename=input.get('filename');
		if self.passed_filename_Config(filename,input):
			co_filename_list=ffilename.get('co_filename_list');
			if co_filename_list is None:
				co_filename_list=[];
			co_file_count=len(co_filename_list);
			if co_file_count>0:
				count=filename.find(co_filename_list[0]);
			else:
				count=0;
			if count!=-1:
				import os;
				fullname=os.path.join(ffilename.get('directory'),filename);
				shape=input.get('shape');
				Ndim=input.get('Ndim')
				expr=filetype+"_File(fullname,Ndim,shape=shape)";
				#cs_file=AIRS_File(fullname,shape);
				cs_file=eval(expr);
				yymmdd=cs_file.get_ymd();
				cs_file.Ndim=input.get('Ndim');
				if self.passed_time_Config(yymmdd,input):
					for co_file in co_filename_list[1:]:
						co_filename=cs_file.filename.replace(co_filename_list[0],co_file);
						print "co file:\n",co_filename
						cs_file.co_filename_list.append(co_filename);
				else:
					print "Non-first cofile skipped."
		return cs_file;

	def output_filtered_data(self,cs_file,config):
		work_sheet=None;
		output=config.get('output');
		ffilter=config.get('filter');
		success=cs_file.open();
		if success:
			print "HDF file opened."
			for condition in ffilter.get('condition_list'):
				cs_file.filter_index(ffilter.get('alias_dict'),condition);
			print "Data filtered."
			if output.get('output_table_name')=="":
				output_table_name=natural_name(cs_file.filename);
			else:
				output_table_name=output.get('output_table_name');
			ymd=cs_file.get_ymd();
			
			if output.get('grouping')=='day':
				str1='_day_'+str(ymd.year)+'_'+str(ymd.month)+'_'+str(ymd.day);
			elif output.get('grouping')=='month':
				str1='_month_'+str(ymd.year)+'_'+str(ymd.month);
			elif output.get('grouping')=='year':
				str1='_year_'+str(ymd.year);
			else:
				str1='';
			output_table_name=output_table_name+str1;
			#eos_table=cs_file.save_filtered_data_to_table(self,output.get('output_list'),output_table_name);
			work_sheet=cs_file.savechosen2worksheet(output.get('output_list'));
			work_sheet.set_meta('eas_hdf_date',str(cs_file.get_ymd()));
			self.set(output_table_name,work_sheet);
			print "Output to table done, current size:",work_sheet.size();
		else:
			print "Opening file/cofile failed.",success
		return work_sheet;
		
	def new_EAS_HDF_Config(self,filetype='EAS_HDF'):
		configfname='read_parameters_'
		if self.og_keys().count(configfname+filetype)==0:
			expr="self.get_empty_Config_"+filetype+"()";
			#config=self.get_empty_Config_CloudSat();
			config=eval(expr);
			self.set(configfname+filetype,config);
			self.refresh_editor();
		else:
			print "filter exist!"
		return;
		
	def new_mesh_match_config(self):
		mesh_match_config=OGroup();
		table=OGroup();
		#table2=OGroup();
		
		table.set('x_name','Longitude');
		table.set('y_name','Latitude');
		table.set('z_names',['CO_VMR_eff_A','Radar_Reflectivity','Height']);
		table.set('co_table_names',['AIRS','CloudSat'])
		
		#table2.set('x_name','Longitude');
		#table2.set('y_name','Latitude');
		#table2.set('z_name',['Radar_Reflectivity','Height']);
		
		mesh_match_config.set('table',table);
		#mesh_match_config.set('table2',table2);
		
		mesh_match_config.set('x_resolution',1);
		mesh_match_config.set('y_resolution',1);
		mesh_match_config.set('folder_name','table_folder');
		self.set('mesh_match_config',mesh_match_config)


	def get_empty_Config_MLS(self):
		read_parameter=self.get_empty_Config_EAS_HDF();
		filter=read_parameter.get('filter');
		input=read_parameter.get('input');
		output=read_parameter.get('output');
		
		ftime=input.get('time');
		filename=input.get("filename");

		filename.set('directory','C:\\Home\\Yan\\program\\sample_hdf');
		filename.set('contain','MLS-Aura_L2GP-H2O_v02-21-c01_2004d270');
		filename.set('endwith','.he5');
		
		input.set('time',ftime);
		input.set("filename",filename);
		input.set('shape',[45,30,9]);
		input.set('Ndim',2);
		
		alias_dict={'Time':['HDFEOS','SWATHS','H2O','Geolocation Fields','Time'],'Quality':['HDFEOS','SWATHS','H2O','Data Fields','Quality'],'H2O':['HDFEOS','SWATHS','H2O','Data Fields','H2O']};
		condition_list=['Quality>1.5','H2O>0.01'];
		filter.set('alias_dict',alias_dict);
		filter.set('condition_list',condition_list);
		
		output_list=['Time','Quality','H2O'];
		output.set('output_list',output_list);
		output.set('output_table_name','')
		
		read_parameter.set('input',input);
		read_parameter.set('output',output);
		read_parameter.set('filter',filter);
		#print "filter:",filter
		return read_parameter;
		
	def get_empty_Config_CloudSat(self):
		read_parameter=self.get_empty_Config_EAS_HDF();
		filter=read_parameter.get('filter');
		input=read_parameter.get('input');
		output=read_parameter.get('output');
		
		ftime=input.get('time');
		filename=input.get("filename");


		filename.set('directory','C:\\Home\\Yan\\program\\sample_hdf\\CLDSat');
		filename.set('contain','2006195191657_01128_CS_2B-CLDCLASS_GRANULE_P_R04_E01');
		filename.set('endwith','.hdf');
		
		input.set('time',ftime);
		input.set("filename",filename);
		input.set('shape',(45,30,9));
		input.set('Ndim',3);
		
		alias_dict={'cloud_scenario':["2B-CLDCLASS","Data Fields","cloud_scenario"],'Latitude':["2B-CLDCLASS","Geolocation Fields","Latitude"],'Longitude':["2B-CLDCLASS","Geolocation Fields","Longitude"]};
		condition_list=['Latitude>-15','Latitude<15','Longitude>70','Longitude<110','mod(cloud_scenario/2,16)==8'];
		filter.set('alias_dict',alias_dict);
		filter.set('condition_list',condition_list);
		
		output_list=['cloud_scenario','Latitude','Longitude'];
		output.set('output_list',output_list);
		output.set('output_table_name','')
		
		read_parameter.set('input',input);
		read_parameter.set('output',output);
		read_parameter.set('filter',filter);
		#print "filter:",filter
		return read_parameter;
		
	def get_empty_Config_AIRS(self):
		read_parameter=self.get_empty_Config_EAS_HDF();
		filter=read_parameter.get('filter');
		input=read_parameter.get('input');
		output=read_parameter.get('output');
		
		ftime=input.get('time');
		filename=input.get("filename");
		
		filename.set('directory','C:\\Home\\Yan\\program\\sample_hdf\\AIRS');
		filename.set('contain','');
		filename.set('endwith','.hdf');
		
		input.set('time',ftime);
		input.set("filename",filename);
		input.set('shape',(7,180,360));
		input.set('Ndim',3);
		
		alias_dict={'Latitude': ['location', 'Data Fields', 'Latitude'], 'CO_VMR_eff_A': ['ascending', 'Data Fields', 'CO_VMR_eff_A'],'CO_VMR_eff_D': ['descending', 'Data Fields', 'CO_VMR_eff_D']}
		condition_list=['Latitude>-40', 'CO_VMR_eff_A>3.2e-8','CO_VMR_eff_D>3.2e-8', 'I_2==2']
		filter.set('alias_dict',alias_dict);
		filter.set('condition_list',condition_list);
		
		output_list=['Latitude', 'CO_VMR_eff_A','CO_VMR_eff_D'];
		output.set('output_list',output_list);
		output.set('output_table_name','')
		
		read_parameter.set('input',input);
		read_parameter.set('output',output);
		read_parameter.set('filter',filter);
		#print "filter:",filter
		return read_parameter;
		
	def get_empty_Config_EAS_HDF(self):
		#from enthought.traits.api import OGroup;
		read_parameter=OGroup();
		
		filter=OGroup();
		input=OGroup();
		output=OGroup();
		
		filename=OGroup();
		filename.set('directory','H:\\Aura\\AIRS\\200707');
		filename.set('contain','AIRS.2007.07.01.001.L2.RetSup.v5.0.14.0.G07319235104.hdf');
		filename.set('exclude','');
		filename.set('beginwith','');
		filename.set('endwith','.hdf');
		filename.set('co_filename_list',[]);
		
		ftime=OGroup();
		ftime.set('year',-1);
		ftime.set('month',-1);
		ftime.set('day',-1);
		
		input.set('time',ftime);
		input.set("filename",filename);
		input.set('shape',(45,30,9));
		input.set('Ndim',3);
		
		alias_dict={'Latitude': ['L2_Support_atmospheric&surface_product', 'Geolocation Fields', 'Latitude'], 'CO_VMR_eff': ['L2_Support_atmospheric&surface_product', 'Data Fields', 'CO_VMR_eff']}
		condition_list=['Latitude>-40', 'CO_VMR_eff>3.2e-8', 'I_2==2']
		filter.set('alias_dict',alias_dict);
		filter.set('condition_list',condition_list);
		
		output_list=['Latitude', 'CO_VMR_eff'];
		output.set('output_list',output_list);
		output.set('output_table_name','')
		output.set('grouping','file')
		
		read_parameter.set('input',input);
		read_parameter.set('output',output);
		read_parameter.set('filter',filter);
		#print "filter:",filter
		return read_parameter;
		
	def get_empty_Config_Aeronet(self):
		#from enthought.traits.api import OGroup;
		read_parameter=OGroup();
		
		parameters=OGroup();
		input=OGroup();
		
		filename=OGroup();
		filename.set('directory','C:\\Home\\Yan\\program\\aeronet\\INV\\LEV15\\DUBOV\\ALL_POINTS');
		filename.set('contain','');
		filename.set('exclude','');
		filename.set('beginwith','');
		filename.set('endwith','');
		filename.set('co_filename_list',[]);
		
		input.set("filename",filename);

		
		var_list=['AOT_440','AOT_500','Date_dd_mm_yyyy_','Time_hh_mm_ss_'];
		condition_list=[]
		parameters.set('var_list',var_list);
		parameters.set('condition_list',condition_list);
		
		output=OGroup();
		output_list=[];
		output.set('output_list',output_list);
		output.set('output_table_name','')
		output.set('grouping','file')
		output.set('name','aeronet_imported')
		
		read_parameter.set('input',input);
		read_parameter.set('output',output);
		read_parameter.set('parameters',parameters);
		#print "filter:",filter
		return read_parameter;
		
#==================================methods====================================================

	def OnOpen(self,event):
		from eos_data_analysis_views import eos_data_analysis_view_modify;
		view=eos_data_analysis_view_modify(self);
		#from pydao.math.worksheet_views import worksheet_view_modify;
		#view=worksheet_view_modify(self);
		self.configure_traits(view=view);
		
	def OnNew_EASWorkSheet(self,event):
		from eas_worksheet import EAS_WorkSheet;
		ews=EAS_WorkSheet();
		print type(ews),ews,ews.keys()
		if self.keys().count('new_ews')==0:
			self.set('new_ews',ews);
		print type(self.get('new_ews'))