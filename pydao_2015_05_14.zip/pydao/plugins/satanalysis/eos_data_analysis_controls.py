from pylab import *;
#from pydao.ohdfvi import OGroup_Analyzer_Group_List_ModelView;
from pydao.ohdfvi import Analyzable_ModelView;
from pylab import *;

class EOS_Data_Analysis_ModelView(Analyzable_ModelView):
	def init_info(self,info):
		Analyzable_ModelView.init_info(self,info);
		#self.preprocess(self.model);
		#print "info:",info
		
	def On_Aeronet_BatchImport(self,info=None):
		import pydao,sys;
		from pydao.ohdf import OGroup;
		from pydao.ohdfvi import Analyzable_ModelView;
		if info is not None:
			eos_ana=self.model;
			func_name=sys._getframe().f_code.co_name
			ana_method=eval("self."+func_name);
			ana_name=func_name;
			
			work_space_list=eos_ana.work_space_list;
			print work_space_list,type(work_space_list)
			found_work_space=False;
			for ws in work_space_list:
				if ws.name==ana_name:
					found_work_space=True;
			if found_work_space:
				print "found_work_space",ana_name
			else:
				work_space=Analyzable_ModelView().get_default_work_space(eos_ana);
#=============================================================================================
# make change between the two lines
				ws=eos_ana.get_empty_Config_Aeronet();
				config=work_space.get('config');
				config.remove('_0group');
				config.set('_1inputs',ws.get('input'));
				config.set('_2analysis',ws.get('parameters'));
				
				for k in ws.get('output').keys():
					v=ws.get('output').get(k);
					work_space.get('config').get('_3outputs').set(k,v);
				
# make change between the two lines
#==============================================================================================
				work_space.name=ana_name;
				eos_ana.work_space_list.selected=work_space;
				eos_ana.work_space_list.append(work_space);
				eos_ana.ana_method_list.append(ana_method);
		else:
			import os;
			import eas_worksheet;
			eos_ana=self.model;
			#group=eos_ana.current_group;
			work_space=eos_ana.work_space_list.selected;
			
			config=work_space.get('config');
			inputs=config.get('_1inputs');
			filename_filter=inputs.get('filename');
			files=os.listdir(filename_filter.get('directory'));
			
			parameters=config.get('_2analysis');
			condition_list=parameters.get('condition_list');
			var_list=parameters.get('var_list');
			
			output=config.get('_3outputs');
			output_list=output.get('output_list');
			output_dir=pydao.viewer.get_data_of_link(output.get('dir_link'));
			output_name=output.get('name');
			
			output_pack=OGroup();
			output_dir.set(output_name,output_pack);
			for file in files:
				print "------------------------------"
				print file
				if pydao.passed_filename_filter(file,filename_filter):
					csv_filename=file;
					print "csv_filename:",csv_filename
					work_sheet=eas_worksheet.EAS_WorkSheet();
					csv_filename=os.path.join(filename_filter.get('directory'),file);
					work_sheet.import_from_csv(csv_filename);
					#output_dir.set(file,work_sheet);
					
					work_sheet.init_chosen_indices();
					work_sheet.multi_filter_index(var_list,condition_list);
					ws1=eas_worksheet.EAS_WorkSheet();
					ws1=work_sheet.savechosen2worksheet(var_list,ws1);
					
					if len(output_list)==0:
						output_list=var_list;
					for col_name in ws1.col_names():
						if output_list.count(col_name)==0 \
						and not col_name.startswith('I_'):
							print col_name,"deleted."
							ws1.del_col(col_name);
					from pydao.ohdf import natural_name;
					legal_name=natural_name(file);
					output_pack.set(legal_name,ws1);
			#ready4output=work_space.get('data').get('_3ready4output');
			#ready4output.set('ws1',ws1);
			
	def On_Aeronet_MonthlyMean(self,info=None):
		import pydao,sys;
		from pydao.ohdf import OGroup;
		from pydao.ohdfvi import Analyzable_ModelView;
		if info is not None:
			eos_ana=self.model;
			func_name=sys._getframe().f_code.co_name
			ana_method=eval("self."+func_name);
			ana_name=func_name;
			
			work_space_list=eos_ana.work_space_list;
			print work_space_list,type(work_space_list)
			found_work_space=False;
			for ws in work_space_list:
				if ws.name==ana_name:
					found_work_space=True;
			if found_work_space:
				print "found_work_space",ana_name
			else:
				work_space=Analyzable_ModelView().get_default_work_space(eos_ana);
#=============================================================================================
# make change between the two lines
				eos_ana.set_workspace_nonegrouped(work_space);
				
				from pydao.ohdf import join;
				pack_link=join(eos_ana.get_link(),'aeronet_imported');
				eos_ana.set_workspace_cfg(work_space,'input','pack_link',str(pack_link));
				
				var_name_list=['a440_675','a440_870','a675_870','a675_1020'];
				var_name_list=var_name_list+['AOT_1020', 'AOT_870', 'AOT_675', 'AOT_440', 'SSA441_T', 'SSA673_T', 'SSA873_T', 'SSA1022_T', 'AOTAbsp441_T', 'AOTAbsp673_T', 'AOTAbsp873_T', 'AOTAbsp1022_T', 'RadiativeForcing_BOA_', 'RadiativeForcing_TOA_']
				var_name_list=['AOT_440'];
				
				date_var_name='Date_dd_mm_yyyy_';
				time_var_name='Time_hh_mm_ss_';

				eos_ana.set_workspace_cfg(work_space,'analysis','var_name_list',var_name_list);
				eos_ana.set_workspace_cfg(work_space,'analysis','condition_list',['AOT_440<2']);
				eos_ana.set_workspace_cfg(work_space,'analysis','date_var_name',date_var_name);
				eos_ana.set_workspace_cfg(work_space,'analysis','time_var_name',time_var_name);
			
				eos_ana.set_workspace_cfg(work_space,'output','name','monthly_mean');
# make change between the two lines
#==============================================================================================
				work_space.name=ana_name;
				eos_ana.work_space_list.selected=work_space;
				eos_ana.work_space_list.append(work_space);
				eos_ana.ana_method_list.append(ana_method);
				print eos_ana.isgrouped()
		else:
			import os;
			import eas_worksheet;
			eos_ana=self.model;
			#group=eos_ana.current_group;
			
			var_name_list=eos_ana.get_cfg_analysis('var_name_list');
			condition_list=eos_ana.get_cfg_analysis('condition_list');
			date_var_name=eos_ana.get_cfg_analysis('date_var_name');
			time_var_name=eos_ana.get_cfg_analysis('time_var_name');
			
			input_dir=pydao.viewer.get_data_of_link(eos_ana.get_cfg_input('pack_link'));
			output_dir=pydao.viewer.get_data_of_link(eos_ana.get_cfg_output('dir_link'));
			output_name=eos_ana.get_cfg_output('name');
			
			output_pack=OGroup();
			output_dir.set(output_name,output_pack);
			
			for k in input_dir.keys():
				ws=input_dir.get(k);
				if isinstance(ws,eas_worksheet.EAS_WorkSheet):
					print k
					ws1=ws.monthly_mean(var_name_list,condition_list,date_var_name,time_var_name);
					output_pack.set(k,ws1);
					

	def On_Aeronet_HourlyMean(self,info=None):
		import pydao,sys;
		from pydao.ohdf import OGroup;
		from pydao.ohdfvi import Analyzable_ModelView;
		if info is not None:
			eos_ana=self.model;
			func_name=sys._getframe().f_code.co_name
			ana_method=eval("self."+func_name);
			ana_name=func_name;
			
			work_space_list=eos_ana.work_space_list;
			print work_space_list,type(work_space_list)
			found_work_space=False;
			for ws in work_space_list:
				if ws.name==ana_name:
					found_work_space=True;
			if found_work_space:
				print "found_work_space",ana_name
			else:
				work_space=Analyzable_ModelView().get_default_work_space(eos_ana);
				
#=============================================================================================
# make change between the two lines
				eos_ana.set_workspace_nonegrouped(work_space);
				import pydao.ohdf.link as link;
				raw_link=link.join(eos_ana.get_link(),'aeronet_imported');
				
				eos_ana.set_workspace_cfg(work_space,'input','rawdata_pack_link',str(raw_link));
				eos_ana.set_workspace_cfg(work_space,'input','monthly_mean_pack_link',str(link.join(eos_ana.get_link(),'monthly_mean')));
				
				var_name_list=['a440_675','a440_870','a675_870','a675_1020'];
				var_name_list=var_name_list+['AOT_1020', 'AOT_870', 'AOT_675', 'AOT_440', 'SSA441_T', 'SSA673_T', 'SSA873_T', 'SSA1022_T', 'AOTAbsp441_T', 'AOTAbsp673_T', 'AOTAbsp873_T', 'AOTAbsp1022_T', 'RadiativeForcing_BOA_', 'RadiativeForcing_TOA_']
				var_name_list=['AOT_440'];
				
				date_var_name='Date_dd_mm_yyyy_';
				time_var_name='Time_hh_mm_ss_';

				eos_ana.set_workspace_cfg(work_space,'analysis','var_name_list',var_name_list);
				eos_ana.set_workspace_cfg(work_space,'analysis','condition_list',['AOT_440<2.']);
				eos_ana.set_workspace_cfg(work_space,'analysis','date_var_name',date_var_name);
				eos_ana.set_workspace_cfg(work_space,'analysis','time_var_name',time_var_name);
			
				eos_ana.set_workspace_cfg(work_space,'output','name','hourly_mean');
				
# make change between the two lines
#==============================================================================================
				work_space.name=ana_name;
				eos_ana.work_space_list.selected=work_space;
				eos_ana.work_space_list.append(work_space);
				eos_ana.ana_method_list.append(ana_method);
					
		else:
			import os;
			import eas_worksheet;
			eos_ana=self.model;
			#group=eos_ana.current_group;
			
			var_name_list=eos_ana.get_cfg_analysis('var_name_list');
			condition_list=eos_ana.get_cfg_analysis('condition_list');
			date_var_name=eos_ana.get_cfg_analysis('date_var_name');
			time_var_name=eos_ana.get_cfg_analysis('time_var_name');
			
			input_rawdata_pack=pydao.viewer.get_data_of_link(eos_ana.get_cfg_input('rawdata_pack_link'));
			input_montlymean_pack=pydao.viewer.get_data_of_link(eos_ana.get_cfg_input('monthly_mean_pack_link'));
			
			output_dir=pydao.viewer.get_data_of_link(eos_ana.get_cfg_output('dir_link'));
			output_name=eos_ana.get_cfg_output('name');
			
			output_pack=OGroup();
			output_dir.set(output_name,output_pack);
			
			for k in input_rawdata_pack.keys():
				ws=input_rawdata_pack.get(k);
				if isinstance(ws,eas_worksheet.EAS_WorkSheet):
					print k
					ws_monthly_mean=input_montlymean_pack.get(k);
					#ws1=ws.monthly_mean(var_name_list,date_var_name,time_var_name);
					ws_list=ws.hourly_mean_allmonth(ws_monthly_mean,var_name_list,condition_list,date_var_name,time_var_name);
					for i_month in range(len(ws_list)):
						month=i_month+1;
						ws_name=k+"_month_"+str(month)+'_hourly'
						output_pack.set(ws_name,ws_list[i_month]);
					
