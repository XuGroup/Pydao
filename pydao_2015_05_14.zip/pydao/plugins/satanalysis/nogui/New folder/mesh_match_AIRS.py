from pylab import *;
# we changed this program so that both tables are in WorkSheet format instead of OTables
def mesh_match(table1_name=None,table2_name=None,output_name=None):
	import pydao;
	import pydao.math as pymath;
	
	ogroup=pydao.viewer.current_explorer.get_current_ogroup();
	#print "ogroup:",ogroup
	
	if table1_name is None:
		table1_name='CLD_20070717_CLDsat';
	if table2_name is None:
		table2_name='AIRS_2007_07_17_L3_RetStd001_v5_0_14_0_G07319164923_hdf';
	if output_name is None:
		output_name=table1_name;
	
	dx=1;
	dy=1;
	x_name='Longitude';
	y_name='Latitude';
	#z1_names=['Radar_Reflectivity','Height'];
	z1_names=['CO_VMR_eff_A','CO_VMR_eff_D']; # in this program z1 comes from AIRS and z2 comes from the other dataset, if we don't set the variables right, the program will show error.
	#z2_names=['CO_VMR_eff_A_1','CO_VMR_eff_A_2'];
	z2_names=['Radar_Reflectivity','Height'];

	tb1=ogroup.get(table1_name);
	tb2=ogroup.get(table2_name);
	
	x1=tb1.get_col(x_name);
	y1=tb1.get_col(y_name);
	x2=tb2.get_col(x_name);
	y2=tb2.get_col(y_name);
	
	xmin=min(min(x1),min(x2));
	xmax=max(max(x1),max(x2));
	ymin=min(min(y1),min(y2));
	ymax=max(max(y1),max(y2));

	x_mesh=arange(xmin-dx,xmax+2*dx,dx);
	y_mesh=arange(ymin-dy,ymax+2*dy,dy);
	
	result1_list=[];
	result2_list=[];
	
	for z_name in z1_names:
		z=tb1.get_col(z_name);
		result=pymath.xyz2_meshindex(x1,y1,z,x_mesh,y_mesh);
		result1_list.append(result);
	
	for z_name in z2_names:
		z=tb2.get_col(z_name);
		result=pymath.xyz2_meshindex(x2,y2,z,x_mesh,y_mesh);
		result2_list.append(result);
		
	I1=result1_list[0]['I'];
	I2=result2_list[0]['I'];
	
	ws_com=pymath.WorkSheet();

	I=logical_and(I1,I2);
	x_filtered=result1_list[0]['x_mesh_indexed'][I];
	y_filtered=result1_list[0]['y_mesh_indexed'][I];
	print "common x,y:\n",x_filtered,'\n',y_filtered
	#colx=pymath.WorkSheet_Column(x_filtered)
	#coly=pymath.WorkSheet_Column(y_filtered);
	ws_com.set_col(x_name,x_filtered);
	ws_com.set_col(y_name,y_filtered);
	
	i=0;
	for z_name in z1_names:
		col=result1_list[i]['z_mesh_indexed'][I];
		i=i+1;
		ws_com.set_col(z_name+'_1',col);
	i=0;
	for z_name in z2_names:
		col=result2_list[i]['z_mesh_indexed'][I];
		i=i+1;
		ws_com.set_col(z_name+'_2',col);
		
	ws_dif=pymath.WorkSheet();
	
	I=logical_and(I1,logical_not(I2));
	x_filtered=result1_list[0]['x_mesh_indexed'][I];
	y_filtered=result1_list[0]['y_mesh_indexed'][I];
	print "different x,y:\n",x_filtered,"\n",y_filtered
	#colx=pymath.WorkSheet_Column(x_filtered);
	#coly=pymath.WorkSheet_Column(y_filtered);
	ws_dif.set_col(x_name,x_filtered);
	ws_dif.set_col(y_name,y_filtered);
	i=0;
	for z_name in z1_names:
		col=result1_list[i]['z_mesh_indexed'][I];
		i=i+1;
		ws_dif.set_col(z_name,col);
	
	#ogroup.set(output_name+'_com',ws_com);
	#ogroup.set(output_name+'_diff',ws_diff);
	
	opcom=output_name+'_com';
	if ogroup.has_key(opcom):
		ws_com0=ogroup.get(opcom);
		for k in ws_com.col_names():
			data=ws_com.get_col(k).get('data');
			ws_com0.append2col(k,data);
	else:
		ogroup.set(opcom,ws_com);
		
	# opdif=output_name+'_dif';
	# if ogroup.has_key(opdif):
		# ws_dif0=ogroup.get(opdif);
		# for k in ws_dif.col_names():
			# data=ws_dif.get_col(k).get('data');
			# ws_dif0.append2col(k,data);
	# else:
		# ogroup.set(opdif,ws_dif);
		
	return (ws_com,ws_dif)

def mesh_match_batch():
	import pydao;
	from pydao.ohdf import OTable;
	from pydao.math import WorkSheet;
	from mx.DateTime import ISO,DateTime;
	ogroup=pydao.viewer.current_explorer.get_current_ogroup();
	compared_files=[];
	
	okeys=ogroup.keys();
	
	for k in okeys:
		#print "k",k
		v=ogroup.get(k);
		if isinstance(v,OTable) or isinstance(v,WorkSheet):
			#if v.get_meta('eas_hdf_type')=='CloudSat':
			if v.get_meta('eas_hdf_type')=='AIRS':
				ymd=ISO.ParseAny(v.get_meta('eas_hdf_date'));
				for k1 in okeys:
					#print k1
					if k1!=k and compared_files.count(k)==0 and compared_files.count(k1)==0:
						v1=ogroup.get(k1);
						if isinstance(v1,OTable) or isinstance(v1,WorkSheet):
							ymd1=ISO.ParseAny(v1.get_meta('eas_hdf_date'));
							if ymd==ymd1:
								compared_files.append(k);
								compared_files.append(k1);
								print '---------------------------------'
								print "found match date:\n",k,'\n',k1
								print ymd
								#output_name='AIRS_'+str(ymd.year)\
								#output_name='Matched_'+str(ymd.year)\
								output_name='AIRS_'+str(ymd.year)\
								+'_'+str(ymd.month)\
								+'_'+str(ymd.day);
								ws_com,ws_dif=mesh_match(k,k1,output_name);
								ws_com.set_meta('eas_hdf_type','AIRS');
								ws_com.set_meta('eas_hdf_date',str(ymd));
								ws_dif.set_meta('eas_hdf_type','AIRS');
								ws_dif.set_meta('eas_hdf_date',str(ymd));
								
def bin_batch():
	import pydao;
	from pydao.ohdf import OTable;
	from pydao.math import WorkSheet;
	from mx.DateTime import ISO,DateTime;
	import pydao.math as pymath;
	
	ogroup=pydao.viewer.current_explorer.get_current_ogroup();
	
	y_name='Height';
	x_name='Radar_Reflectivity';
	x_mesh=arange(-60,0,10)*100.;
	
	okeys=ogroup.keys(True);
	for k in okeys:
		#print "k",k
		v=ogroup.get(k);
		if isinstance(v,OTable) or isinstance(v,WorkSheet):
			x_list=v.get_col(x_name);
			y_list=v.get_col(y_name);
			result=pymath.xy2_meshindex(x_list,y_list,x_mesh);
			
			ws=WorkSheet();
			colx=result['xnew']
			coly=result['ynew']
			colyerr=result['ynew_err']
			ws.set_col(x_name,colx);
			ws.set_col(y_name,coly);
			ws.set_col(y_name+'_err',colyerr);
			ogroup.set(k+'_bin',ws);
			
def acontour(filename=None):
	import pydao.math as pymath;
	
	if filename is None:
		filename='aa.dat';
	aa=load(filename);
	print aa.shape
	
	N=5;
	x_mesh=arange(-60,-10,50./N)*100.;
	y_mesh=arange(6000,16000,10000./N);
	
	result=pymath.xyz2_meshindex(aa[:,5],aa[:,2],aa[:,1]/aa[:,0],x_mesh,y_mesh);
	
	xmesh=(x_mesh[0:len(x_mesh)-1]+x_mesh[1:])/2;
	ymesh=(y_mesh[0:len(y_mesh)-1]+y_mesh[1:])/2;
	zmesh=result['z_mesh_indexed'];
	
	
	im=imshow(zmesh,interpolation='bilinear', origin='lower',\
	extent=(min(xmesh),max(xmesh),min(ymesh),max(ymesh)));
	#cs=contour(xmesh,ymesh,zmesh,cmap=cm.gray);
	cs=contour(xmesh,ymesh,zmesh,colors='w');
	
	#plt.clabel(cs, levels[1::2],inline=1,fmt='%1.1f',fontsize=14)
	#clabel(cs, inline=1, fontsize=10)

	
	save("mesh_x_"+filename,xmesh);
	save("mesh_y_"+filename,ymesh);
	save("mesh_z_"+filename,zmesh);

